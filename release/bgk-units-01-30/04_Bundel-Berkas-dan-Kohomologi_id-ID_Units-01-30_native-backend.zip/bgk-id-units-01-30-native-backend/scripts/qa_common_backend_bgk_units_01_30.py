#!/usr/bin/env python3
"""Replay and bind the BGK Units 1--30 common-backend-v1 preflight.

The common model remains an additive, zero-copy projection of the native BGK
backend.  ``--static-check`` validates contracts and delegates to the native
write-free readiness check even before the cumulative Unit-30 backend exists.
Default mode requires the complete native and reader QA boundary, then performs
two deterministic common projections and one unchanged classical regression.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "qa" / "BGK_UNITS_01_30_COMMON_ADAPTER_PREFLIGHT_QA.json"
ADAPTER = ROOT / "scripts" / "generate_common_backend_v1_receipts.py"
EXPORTER = ROOT / "scripts" / "export_backend_bgk_units_01_30.py"
NATIVE_QA_DRIVER = ROOT / "scripts" / "qa_backend_bgk_units_01_30.py"
NATIVE = ROOT / "backend" / "bgk-units-01-30"
MANIFEST = NATIVE / "MANIFEST.json"
RECORDS = NATIVE / "records.jsonl"
NATIVE_QA = ROOT / "qa" / "BGK_UNITS_01_30_BACKEND_QA.json"
READER_QA = ROOT / "qa" / "BGK_UNITS_01_30_READER_QA.json"
RESPONSIVE_QA = ROOT / "qa" / "BGK_UNITS_01_30_RESPONSIVE_QA.json"
VISUAL_QA = ROOT / "qa" / "BGK_UNITS_01_30_VISUAL_QA.json"
ACCEPTED_COMMON = ROOT / "qa" / "BGK_UNITS_01_12_COMMON_ADAPTER_PREFLIGHT_QA.json"
MODEL = "OpenAI Codex gpt-5.6-sol, Ultra."

ADAPTER_SHA256 = "ead98b528a7898411fe3fc371add4da6ca31f163ae36bd5ca8b4845e9db936c6"
ACCEPTED_COMMON_SHA256 = "20de23a27cf9a909222fc0840d2ee8dc79ade80a401c7410caf2f64ee9624572"
CONTRACT = [
    (
        ROOT / "backend" / "common-backend-v1-contract" / "upstream" /
        "backend-v1.v0.41.0.schema.json",
        "3de8d107b1c75db0f8d60c42ef7e3488bc3fcc93f72e955def71a771475cf2b2",
    ),
    (
        ROOT / "backend" / "common-backend-v1-contract" / "upstream" /
        "source-format-profile-v1.v0.41.0.schema.json",
        "2bb1429c36236329be94d58205b6123a0266a1e111277e3d303692ca8430e271",
    ),
    (
        ROOT / "backend" / "common-backend-v1-contract" / "upstream" /
        "backend-migration-receipt-v1.v0.42.0.schema.json",
        "0147b14972dd562805b3b5f76fac453a9f32a6d298827d3f588316d4a8f5ffe0",
    ),
    (
        ROOT / "backend" / "common-backend-v1-contract" / "upstream" /
        "MIGRATION_HANDOFF_V1.v0.42.0.md",
        "83de5379aa08f25fb3fb2774ed8bde99eca76e9a6ba80da9ccf2ee211e5e3a7a",
    ),
]

CLASSICAL_EXPECTED = {
    "native_records": 22752,
    "common_records": 53953,
    "virtual_sha256": "b0a9d21a0ad8b7ce30323f78af3aa9509da663a61d32ee915239dcea9a71ba2c",
    "reverse_sha256": "dfdaebfa185c09b5e96ee4834b8b52f1c52329477eae0b48c5e8950b1b228dd7",
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def rel(path: Path) -> str:
    return path.resolve().relative_to(ROOT).as_posix()


def fact(path: Path) -> dict[str, Any]:
    require(path.is_file() and not path.is_symlink(), f"Missing/non-regular file: {rel(path)}")
    return {"path": rel(path), "bytes": path.stat().st_size, "sha256": digest(path)}


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    require(isinstance(value, dict), f"Expected JSON object: {rel(path)}")
    return value


def pass_status(value: Any) -> bool:
    return isinstance(value, str) and value.upper().startswith("PASS")


def output_snapshot() -> dict[str, Any]:
    result: dict[str, Any] = {
        "common_receipt": fact(OUTPUT) if OUTPUT.is_file() else None,
        "native_backend": {},
    }
    if NATIVE.is_dir():
        result["native_backend"] = {
            path.name: fact(path) for path in sorted(NATIVE.iterdir())
            if path.is_file() and not path.is_symlink()
        }
    return result


def run_json(command: list[str], *, accepted_codes: tuple[int, ...] = (0,)) -> tuple[dict[str, Any], bytes, int]:
    process = subprocess.run(
        command, cwd=ROOT, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    require(process.returncode in accepted_codes,
            f"Command failed ({process.returncode}): {' '.join(command)}\n"
            f"{process.stderr.decode('utf-8', errors='replace')}")
    stdout = process.stdout.replace(b"\r\n", b"\n")
    value = json.loads(stdout)
    require(isinstance(value, dict), "Command did not emit a JSON object")
    return value, stdout, process.returncode


def static_check() -> dict[str, Any]:
    before = output_snapshot()
    require(digest(ADAPTER) == ADAPTER_SHA256, "Common-backend adapter drifted")
    contract_facts: list[dict[str, Any]] = []
    for path, expected_sha in CONTRACT:
        require(digest(path) == expected_sha, f"Frozen common contract drifted: {rel(path)}")
        contract_facts.append(fact(path))
    require(digest(ACCEPTED_COMMON) == ACCEPTED_COMMON_SHA256,
            "Accepted Unit-12 common receipt bytes drifted")
    accepted = load(ACCEPTED_COMMON)
    require(accepted.get("status") == "PASS" and accepted.get("model_provenance") == MODEL,
            "Accepted Unit-12 common receipt drifted")
    native, native_stdout, native_code = run_json(
        [sys.executable, rel(NATIVE_QA_DRIVER), "--static-check"], accepted_codes=(0, 2)
    )
    require(native.get("static_validation_status") == "PASS"
            and native.get("through_unit_required") == 30,
            "Native Unit-30 static validation did not complete")
    ready = bool(native.get("ready_for_export"))
    require((native_code == 0) == ready,
            "Native static exit status does not match readiness")
    after = output_snapshot()
    require(before == after, "Common static check modified backend or QA output")
    return {
        "schema": "ag-bridge-bgk-units-01-30-common-static-v1",
        "status": "READY" if ready else "INCOMPLETE",
        "static_validation_status": "PASS",
        "ready_for_common_preflight": ready and MANIFEST.is_file() and NATIVE_QA.is_file(),
        "through_unit_required": 30,
        "adapter": {**fact(ADAPTER), "mode": "additive zero-copy adapter"},
        "contracts": contract_facts,
        "accepted_unit_12_control": fact(ACCEPTED_COMMON),
        "native_static": native,
        "native_static_stdout_sha256": sha256(native_stdout),
        "writes_performed": False,
        "output_snapshot_unchanged": True,
        "credentials_recorded": False,
    }


def preflight(native: str) -> tuple[dict[str, Any], bytes]:
    value, stdout, _ = run_json([
        sys.executable, rel(ADAPTER), "--native-backend", native, "--preflight",
    ])
    require(value.get("status") == "PASS", "Common adapter did not emit exact PASS")
    return value, stdout


def verify_final_boundary() -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    manifest = load(MANIFEST)
    native_qa = load(NATIVE_QA)
    require(manifest.get("through_unit") == 30 and manifest.get("model_provenance") == MODEL,
            "Native manifest is not exact Unit-30/model boundary")
    require(native_qa.get("through_unit") == 30 and native_qa.get("status") == "PASS"
            and native_qa.get("model_provenance") == MODEL,
            "Native QA is not exact PASS through Unit 30")
    records_fact = fact(RECORDS)
    records_binding = next(
        (row for row in manifest.get("files", []) if row.get("path") == rel(RECORDS)), None
    )
    require(records_binding is not None
            and int(records_binding["bytes"]) == records_fact["bytes"]
            and records_binding["sha256"] == records_fact["sha256"],
            "Native manifest does not bind exact records.jsonl bytes")
    require(native_qa["backend"]["records"]["sha256"] == records_fact["sha256"]
            and native_qa["backend"]["manifest"]["sha256"] == digest(MANIFEST),
            "Native QA does not bind current backend bytes")
    for path in (READER_QA, RESPONSIVE_QA, VISUAL_QA, NATIVE_QA):
        qa = load(path)
        require(qa.get("through_unit") == 30 and qa.get("status") == "PASS"
                and qa.get("model_provenance") == MODEL,
                f"Final evidence is not exact PASS through Unit 30: {rel(path)}")
    return manifest, native_qa, records_fact


def write_atomic(path: Path, data: bytes) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_bytes(data)
    require(temporary.read_bytes() == data, f"Temporary write/readback mismatch: {rel(path)}")
    temporary.replace(path)
    require(path.read_bytes() == data, f"Receipt write/readback mismatch: {rel(path)}")


def run_full_preflight() -> dict[str, Any]:
    readiness = static_check()
    require(readiness["ready_for_common_preflight"],
            "Unit-30 common preflight is incomplete; run --static-check for finite prerequisites")
    manifest, _native_qa, records_fact = verify_final_boundary()

    first, first_stdout = preflight("backend/bgk-units-01-30")
    second, second_stdout = preflight("backend/bgk-units-01-30")
    require(first == second and first_stdout == second_stdout,
            "Unit-30 common adapter double replay is nondeterministic")
    require(first["native_records"] == int(manifest["record_count"])
            and first["reverse_sha256"] == records_fact["sha256"]
            and int(first["strict_profiles"]) > 0
            and int(first["strict_profile_witness_files"]) > 0
            and int(first["foreign_keys_checked"]) > 0,
            "Unit-30 common projection closure failed")

    accepted_bgk = load(ACCEPTED_COMMON)["common_projection"]
    bgk_12, bgk_12_stdout = preflight("backend/bgk-units-01-12")
    for key in ("status", "native_records", "common_records", "virtual_bytes",
                "virtual_sha256", "reverse_sha256", "strict_profiles",
                "strict_profile_witness_files", "foreign_keys_checked"):
        require(bgk_12[key] == accepted_bgk[key],
                f"Accepted BGK Units 1--12 common projection changed: {key}")

    classical_a, classical_stdout_a = preflight("backend/units-01-30")
    classical_b, classical_stdout_b = preflight("backend/units-01-30")
    require(classical_a == classical_b and classical_stdout_a == classical_stdout_b,
            "Classical common-backend regression is nondeterministic")
    for key, expected in CLASSICAL_EXPECTED.items():
        require(classical_a[key] == expected,
                f"Accepted classical common-backend regression changed: {key}")

    final_paths = (READER_QA, VISUAL_QA, RESPONSIVE_QA, NATIVE_QA)
    receipt = {
        "schema": "ag-bridge-common-backend-v1-preflight-qa-v1",
        "scope": "BGK Units 1--30 cumulative native backend",
        "language": "id-ID", "status": "PASS",
        "verification_date": str(manifest["generated_from_authority_utc"])[:10],
        "model_provenance": MODEL,
        "preflight_driver": fact(Path(__file__).resolve()),
        "exporter": fact(EXPORTER),
        "adapter": {**fact(ADAPTER), "mode": "additive zero-copy adapter",
                    "native_records_mutated": False},
        "contract": [fact(path) for path, _ in CONTRACT],
        "native_backend": {
            "path": rel(NATIVE), "records": int(manifest["record_count"]),
            "records_file": records_fact, "manifest": fact(MANIFEST),
            "native_qa": fact(NATIVE_QA),
        },
        "final_qa_evidence": [{**fact(path), "status": load(path)["status"]} for path in final_paths],
        "common_projection": {
            **first, "lossless_reverse_sha256": first["reverse_sha256"],
            "double_preflight_stdout_identical": True,
            "double_preflight_stdout_sha256": sha256(first_stdout),
        },
        "classical_regression": {
            "status": "PASS_UNCHANGED_ACCEPTED_BASELINE",
            "accepted_control": fact(ACCEPTED_COMMON),
            "accepted_baseline": CLASSICAL_EXPECTED,
            "current_result": classical_a,
            "double_preflight_stdout_identical": True,
            "double_preflight_stdout_sha256": sha256(classical_stdout_a),
        },
        "bgk_01_12_regression": {
            "status": "PASS_UNCHANGED_ACCEPTED_BASELINE",
            "accepted_control": fact(ACCEPTED_COMMON),
            "current_result": bgk_12,
            "preflight_stdout_sha256": sha256(bgk_12_stdout),
        },
        "checks": {
            "common_schema_valid": True, "strict_profiles_valid": True,
            "all_foreign_keys_closed": True, "lossless_native_round_trip": True,
            "deterministic_double_preflight": True,
            "frozen_native_and_final_qa_identities_match": True,
            "accepted_classical_regression_replayed_and_unchanged": True,
            "accepted_bgk_01_12_projection_replayed_and_byte_identical": True,
            "native_records_mutated": False,
            "migration_receipt_emitted_after_public_version_identity_reservation": False,
        },
        "credentials_recorded": False,
    }
    data = (json.dumps(receipt, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")
    write_atomic(OUTPUT, data)
    return {"status": "PASS", "output": fact(OUTPUT), "projection": first}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--static-check", action="store_true",
                        help="Validate contracts/readiness without writing receipts")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.static_check:
        result = static_check()
        print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
        return 0 if result["ready_for_common_preflight"] else 2
    print(json.dumps(run_full_preflight(), ensure_ascii=False, sort_keys=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
