#!/usr/bin/env python3
"""Deterministic native-backend QA for the cumulative BGK Units 1--30.

``--static-check`` is deliberately write-free.  It validates the immutable
Units 1--12 prefix and the already translated Units 13--30 ID topology, then
reports every missing terminal input.  The default mode is fail-closed: it is
usable only after all authority, rights, translation, reader, responsive, and
visual gates are exact PASS through Unit 30.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import io
import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[1]
EXPORTER_PATH = ROOT / "scripts" / "export_backend_bgk_units_01_30.py"
BACKEND = ROOT / "backend" / "bgk-units-01-30"
BASE = ROOT / "backend" / "bgk-units-01-12"
BASE_RECORDS = BASE / "records.jsonl"
BASE_MANIFEST = BASE / "MANIFEST.json"
BASE_QA = ROOT / "qa" / "BGK_UNITS_01_12_BACKEND_QA.json"
CLASSICAL_RECORDS = ROOT / "backend" / "units-01-30" / "records.jsonl"
READER_QA = ROOT / "qa" / "BGK_UNITS_01_30_READER_QA.json"
RESPONSIVE_QA = ROOT / "qa" / "BGK_UNITS_01_30_RESPONSIVE_QA.json"
VISUAL_QA = ROOT / "qa" / "BGK_UNITS_01_30_VISUAL_QA.json"
RECEIPT = ROOT / "qa" / "BGK_UNITS_01_30_BACKEND_QA.json"
SOURCE_DIR = ROOT / "source" / "id-ID" / "bgk"
ADDITIVE_TERMINOLOGY = ROOT / "00_control" / "BGK_UNITS_13_30_TERMINOLOGY.csv"
ADDITIVE_CORRECTIONS = ROOT / "00_control" / "BGK_UNITS_13_30_CORRECTIONS.csv"
READER_GLOSSARY = SOURCE_DIR / "glossary-bgk-units-01-30.md"
MODEL = "OpenAI Codex gpt-5.6-sol, Ultra."

BASE_MANIFEST_SHA256 = "6ead72bff45e4815aee62a63ddccd055e47d04c47eb70d39fcd4d872e6ed9927"
BASE_RECORDS_SHA256 = "9b15776df6cc87bee3568872a12bf2ab26696ee220fb6ffddc49fd13ea74832f"
BASE_QA_SHA256 = "4d2e877b1f5996714d3788a773c8e2fa1d22c75d4a8a9932c6d901bff6ea57e6"

# Only these accepted generated-reader locations may be interpreted historically.
# This is NOT a wildcard for source, rights, ledgers, or current Unit-30 artifacts.
BASE_READER_BINDINGS = {
    "build/reader-bgk-id/BUILD_RECEIPT.json": (
        17478, "08360126b8f1b7ca6cdf26be7467129edc95249e483ae2191b7902f57cafff66"),
    "build/reader-bgk-id/index.html": (
        3979627, "d88da9b0b65c8cb75a1549d4349b48176355201e372e314f9fe655b8c90b1cf2"),
    "build/reader-bgk-id/bundel-berkas-dan-kohomologi-id-units-01-12.pdf": (
        1311189, "95da79e1fa7c22212218f72f71981d3200111488ecfe15f884661a368c6421eb"),
}
HISTORICAL_READER_ARTIFACT_IDS = {
    4: ("artifact.br-bgk-2019.u04.22", "artifact.br-bgk-2019.u04.23",
        "artifact.br-bgk-2019.u04.24"),
    6: ("artifact.br-bgk-2019.u06.048", "artifact.br-bgk-2019.u06.049",
        "artifact.br-bgk-2019.u06.050"),
    7: ("artifact.br-bgk-2019.u07.023", "artifact.br-bgk-2019.u07.024",
        "artifact.br-bgk-2019.u07.025"),
    8: ("artifact.br-bgk-2019.u08.023", "artifact.br-bgk-2019.u08.024",
        "artifact.br-bgk-2019.u08.025"),
    12: ("artifact.br-bgk-2019.u12.cumulative-008",
         "artifact.br-bgk-2019.u12.cumulative-009",
         "artifact.br-bgk-2019.u12.cumulative-010"),
}
CLASSICAL_RECORDS_SHA256 = "dfdaebfa185c09b5e96ee4834b8b52f1c52329477eae0b48c5e8950b1b228dd7"

UNITS = tuple(range(13, 31))
EXPECTED_EXERCISES = {
    13: 23, 14: 26, 15: 20, 16: 23, 17: 24, 18: 25,
    19: 12, 20: 13, 21: 13, 22: 20, 23: 21, 24: 5,
    25: 13, 26: 8, 27: 14, 28: 14, 29: 15, 30: 5,
}
EXPECTED_PUBLIC_SOLUTIONS = {
    13: (), 14: (), 15: (), 16: (12,), 17: (), 18: (6, 17, 18),
    19: (10,), 20: (), 21: (3, 9, 10), 22: (19,), 23: (), 24: (),
    25: (1,), 26: (), 27: (), 28: (6,), 29: (5, 12), 30: (),
}
EXPECTED_MEDIA = {unit: (3 if unit == 29 else 0) for unit in UNITS}
EXPECTED_NEW_HEADING_IDS = 784

HEADING_RE = re.compile(r"^(#{1,6})[ \t]+(.+?)[ \t]+\{#([^}]+)\}[ \t]*$", re.MULTILINE)
EXERCISE_RE = re.compile(r"-w(?P<unit>\d{2})-ex(?P<number>\d{2})$")
SOLUTION_RE = re.compile(
    r"-w(?P<unit>\d{2})(?:-sol-ex(?P<new>\d{2})|-ex(?P<old>\d{2})-solution)$"
)


# Exact inherited records; tuple = historical path, bytes, content SHA-256, full canonical record SHA-256.
HISTORICAL_ARTIFACT_BINDINGS = {
    "artifact.br-bgk-2019.u01.12": (
        "00_control/TERMINOLOGY.csv", 45817,
        "29fdd728ca85183cd870a5d72a62ee3dff777bf6feadf7165e685c587bcc5109",
        "0f7c8550d39e195d46bccfef7a8a53e4c0ee2c5d4fd3e1620cadcd5a242d680f"),
    "artifact.br-bgk-2019.u01.13": (
        "00_control/CORRECTIONS.csv", 88600,
        "22aaa7665956da60a4cfe3916c1d6c80865b5abf8da8770aa4829b3e2b183f74",
        "523cc7b4306a1f220129041bd17571ab9f6ea2f3c170b801b23a988d5b6aa44a"),
    "artifact.br-bgk-2019.u02.18": (
        "00_control/TERMINOLOGY.csv", 47145,
        "c903b851cb96133d560f3ac4d6f0cc8ffb93947c4c64bc44a8cad74f10284260",
        "b8f197263de0abdd41d73cc1bfad4cc8d0b86401dae6b401105b162533e67afd"),
    "artifact.br-bgk-2019.u02.19": (
        "00_control/CORRECTIONS.csv", 92937,
        "ce7546c6e8a31866ae78180c0a080e4c6489bf90376e7325118afc3973016266",
        "b12e72c70c218f75468a9cafad0457ea6433fcde4927448dad20cda12f643cd9"),
    "artifact.br-bgk-2019.u03.18": (
        "00_control/TERMINOLOGY.csv", 49722,
        "043a0370707a1f50b8af8ca3700d388a7e78bae53879919f40b7f5689e57ad19",
        "086a451b792ec5f13a0267feb826cae472fa336dde5a15cbbeea3a2daf7e0145"),
    "artifact.br-bgk-2019.u03.19": (
        "00_control/CORRECTIONS.csv", 96333,
        "8ddb2e4f54b80f3b825cbd630c73e3c90c3b617bb0caa21e7b4977e030975755",
        "73b9b40a937f1c4300b8e31943d8571fd121c8d24e89609d139cdd391e71f26a"),
    "artifact.br-bgk-2019.u04.17": (
        "00_control/TERMINOLOGY.csv", 51230,
        "db567eb87fa30247e747fe15c3c3b9fd0ef64bb55f4f776286b35491ad11c421",
        "88f93cd3614b7c7876aae54fe6b84ef1e264d301b2a0ed60fa3612ff5cbd7ed3"),
    "artifact.br-bgk-2019.u04.18": (
        "00_control/CORRECTIONS.csv", 98843,
        "fe486065197a2839a0e341f4634154d47bb9a63db10ac3fa0c6e1ee00645edde",
        "356525bd7f17ce560bb17b1cdb3a8372570e399e7e8b06290e8f4cd703c639fc"),
    "artifact.br-bgk-2019.u04.22": (
        "build/reader-bgk-id/BUILD_RECEIPT.json", 7666,
        "7b3230d851f721350d830d5d61a8d1d2f86622186c91fa3991b78a61cfb31fba",
        "61139964a3c884a09d2d9a7eaddf60945e828e041d138bb6fcf8e8b93bb6bdeb"),
    "artifact.br-bgk-2019.u04.23": (
        "build/reader-bgk-id/index.html", 3062967,
        "ca9d860f1b0dd68d18ffe4017efbf755ed7819aa0727d4194f880863bcd1609b",
        "c97aac64e5254ae4789da64edd7ae8db947ab131b272f709d31c20a1da2ed706"),
    "artifact.br-bgk-2019.u04.24": (
        "build/reader-bgk-id/bundel-berkas-dan-kohomologi-id-units-01-04.pdf", 774444,
        "26db50d9ca0fc0b343e67025b1d2d6f17393703f30df586da03db059a0d02ea0",
        "60ce7b9f9578b7045a07a0f50952633f9abeda52cbd48350725bb54235ef372d"),
    "artifact.br-bgk-2019.u06.045": (
        "00_control/TERMINOLOGY.csv", 54358,
        "eee5c52af4122e4a2ae4e14c8ef4df76302e388075ea73fb72e7a92fce80fc06",
        "cb66321b95da02eaa1a7d1aa2b085c11a2ac7c749d40de26db6db7f446679d14"),
    "artifact.br-bgk-2019.u06.046": (
        "00_control/CORRECTIONS.csv", 103784,
        "23a2f4afa6955ecd729e1716dfa19610b7c0b728668b694f27af5aad409242b7",
        "abc53eadb805b9639d563cd6b450dceffbf088f71a1cce4340fc2662d8e50387"),
    "artifact.br-bgk-2019.u06.048": (
        "build/reader-bgk-id/BUILD_RECEIPT.json", 10118,
        "e69b24950f0d7ede5cf8c33b6bec32298c08555758936193e1bb4a002844937b",
        "e14e27d8d486ceb243571319b9c56bf8a677cfe058e80d00fbd5b279c972bac8"),
    "artifact.br-bgk-2019.u06.049": (
        "build/reader-bgk-id/index.html", 3272151,
        "feb45d21d6168feaedf35719fdcb0b7f5532687846041d9fd75573c6d66fc5e9",
        "2da4e5b736a2979ebc8da9e629573bd8d16356d7a2900111ebce645a545dfcd1"),
    "artifact.br-bgk-2019.u06.050": (
        "build/reader-bgk-id/bundel-berkas-dan-kohomologi-id-units-01-06.pdf", 896202,
        "f89a622f15acab90f683fb2a0b72a150363fc71d0f41f971c48b8c8ee43c2c9b",
        "af185c7fb32a84e7ad52d9ebe1ba8589601ed914234d58e6997132de710b80d1"),
    "artifact.br-bgk-2019.u07.004": (
        "source/id-ID/bgk/lecture-07.md", 14479,
        "0c2341b1adbaa70ea00a699fb3f7786146232cf7318163976950f215a0c70009",
        "8bc0dc81467146119130a05192ac344cc5432d4dda5d3e89eadfc83c66b73bf5"),
    "artifact.br-bgk-2019.u07.010": (
        "qa/BGK_UNIT_07_TRANSLATION_QA.json", 3314,
        "4840d41617dbe75099d391ba9225d9a490f1d0fd8285042050f0a80717403d76",
        "9bceb42116cd52bafc97f0fe7ab5269d8e909279f004a72c127133d10232bf3b"),
    "artifact.br-bgk-2019.u07.018": (
        "00_control/TERMINOLOGY.csv", 55581,
        "829dbff0916d9e87ccb6f4ca050a5943c789a6d1b31cb3de2e8278af572f27c1",
        "8fcc3c73ee3ee115093ae99166a0e83d408a8f2dd78fd52aabaf9c6ad9c1ea55"),
    "artifact.br-bgk-2019.u07.019": (
        "00_control/CORRECTIONS.csv", 105612,
        "99d35c37aab30c991465b051104eaa8b26a2ddd66a32f5c1a18ec50711877e0e",
        "dad79f47ac0e8a246b06f6bbde17dfba1c31ad01c8386ad19e12970493748d8c"),
    "artifact.br-bgk-2019.u07.023": (
        "build/reader-bgk-id/BUILD_RECEIPT.json", 11345,
        "1b66076fcd55f8e278dec257f3c05f76beba0f4bd59b47d1871b1a7005e12e86",
        "708c585d059b7bd680310e97f93f920a68612e064d7e829d11a0fef86d3bdd8e"),
    "artifact.br-bgk-2019.u07.024": (
        "build/reader-bgk-id/index.html", 3376900,
        "a9b664c091ff1dca9606d1bbc4383d38716a6a314a34d71fbb9d2b2cab817029",
        "4c366c253c97f2a40c68bae22da6147388c8242026f2598261a3ba7cd155f826"),
    "artifact.br-bgk-2019.u07.025": (
        "build/reader-bgk-id/bundel-berkas-dan-kohomologi-id-units-01-07.pdf", 963371,
        "4cc5012417cfb820ddc15484c9d78050079292060941480b3de4f41479f10f51",
        "baa102931d7407d2334f7949793f9d2afd4d3a83e9d9d72bbe906a1978f37764"),
    "artifact.br-bgk-2019.u08.018": (
        "00_control/TERMINOLOGY.csv", 57306,
        "677388255a5f53af44a4d6f0b75769a5fb6e28cf3abda11d34a1b12d99d08b20",
        "113599088d4e09464eedc6d8a118e11fc7fdd8d7572c55ac2e2150886cad2b6f"),
    "artifact.br-bgk-2019.u08.019": (
        "00_control/CORRECTIONS.csv", 107736,
        "bcf848876bc30d67c5447e853060a13c148b64c6818bde06ddec5fed7f1e77b7",
        "b021c80e2a0027593da89b926e63665f16748dc5cc882cda303afcbfcf554d7f"),
    "artifact.br-bgk-2019.u08.023": (
        "build/reader-bgk-id/BUILD_RECEIPT.json", 12574,
        "0827a05da0062d349350936c858bba11cd504e5f1cc9e88ffd42efc04067d527",
        "5a5899154a5e93dd32386324c019ab57d3887b54e3229608b4aa95692753a189"),
    "artifact.br-bgk-2019.u08.024": (
        "build/reader-bgk-id/index.html", 3527732,
        "b8f169ba790451433d5a48b3b3defaa6582ba464cd1f081fb9cdda948bb3f7d3",
        "26208ac06c8078d7cbb3cef2e937c7e46be98c4ad30539e02159b667fad118a0"),
    "artifact.br-bgk-2019.u08.025": (
        "build/reader-bgk-id/bundel-berkas-dan-kohomologi-id-units-01-08.pdf", 1045082,
        "7f701bb9fbf10bfdc198040ca0f99934b96dc339539661e32b5a7351b3f2d2b2",
        "b4b2fce89c961efffaee95faef967ac42d97a8c7cb2c4f761391b362e9e80bb2"),
    "artifact.br-bgk-2019.u12.cumulative-008": (
        "build/reader-bgk-id/BUILD_RECEIPT.json", 17478,
        "08360126b8f1b7ca6cdf26be7467129edc95249e483ae2191b7902f57cafff66",
        "d1b53a01774645ba809146a617fe665330c691c4f7f6fca91d6dc2304f376342"),
    "artifact.br-bgk-2019.u12.cumulative-009": (
        "build/reader-bgk-id/index.html", 3979627,
        "d88da9b0b65c8cb75a1549d4349b48176355201e372e314f9fe655b8c90b1cf2",
        "07fd94f0ee2611c890b03cc905fa21a3e0f1a5e6b28f9a2127ba32a629a97ac8"),
    "artifact.br-bgk-2019.u12.cumulative-010": (
        "build/reader-bgk-id/bundel-berkas-dan-kohomologi-id-units-01-12.pdf", 1311189,
        "95da79e1fa7c22212218f72f71981d3200111488ecfe15f884661a368c6421eb",
        "3e00f121e9211fa2b7232c96a827cdd4d4a63bb56846b16447b50334ca0b91b7"),
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def digest_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def rel(path: Path) -> str:
    return path.resolve().relative_to(ROOT).as_posix()


def fact(path: Path) -> dict[str, Any]:
    require(path.is_file() and not path.is_symlink(), f"Missing/non-regular file: {rel(path)}")
    return {"path": rel(path), "bytes": path.stat().st_size, "sha256": digest(path)}


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    require(isinstance(value, dict), f"Expected JSON object: {rel(path)}")
    return value


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def split_frontmatter(text: str) -> str:
    normalized = text.replace("\r\n", "\n")
    if not normalized.startswith("---\n"):
        return normalized
    end = normalized.find("\n---\n", 4)
    require(end >= 0, "Unclosed Markdown front matter")
    return normalized[end + 5 :]


def output_snapshot() -> dict[str, dict[str, Any]]:
    if not BACKEND.is_dir():
        return {}
    return {
        path.name: {"bytes": path.stat().st_size, "sha256": digest(path)}
        for path in sorted(BACKEND.iterdir()) if path.is_file() and not path.is_symlink()
    }


def load_exporter() -> Any:
    spec = importlib.util.spec_from_file_location("bgk_units_01_30_exporter", EXPORTER_PATH)
    require(spec is not None and spec.loader is not None, "Cannot load Unit-30 exporter")
    module = importlib.util.module_from_spec(spec)
    previous = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = previous
    return module


def independent_source_topology() -> dict[str, Any]:
    all_ids: list[str] = []
    per_unit: dict[str, Any] = {}
    expected_exercise_ids: set[str] = set()
    expected_solution_ids: set[str] = set()
    for unit in UNITS:
        unit_s = f"{unit:02d}"
        unit_ids: list[str] = []
        exercises: set[str] = set()
        solutions: set[str] = set()
        for stem in ("lecture", "worksheet", "worksheet-{unit}-solutions"):
            filename = (stem.format(unit=unit_s) if "{" in stem else f"{stem}-{unit_s}") + ".md"
            path = SOURCE_DIR / filename
            require(path.is_file() and not path.is_symlink(), f"Translated source absent: {rel(path)}")
            ids = [match.group(3).strip() for match in HEADING_RE.finditer(
                split_frontmatter(path.read_text(encoding="utf-8"))
            )]
            require(ids, f"No stable heading IDs: {rel(path)}")
            unit_ids.extend(ids)
            for stable_id in ids:
                exercise = EXERCISE_RE.search(stable_id)
                solution = SOLUTION_RE.search(stable_id)
                if exercise and int(exercise.group("unit")) == unit:
                    exercises.add(stable_id)
                if solution and int(solution.group("unit")) == unit:
                    solutions.add(stable_id)
        require(len(unit_ids) == len(set(unit_ids)), f"Duplicate source heading ID in Unit {unit}")
        expected_exercises = {
            f"br-bgk-2019-w{unit_s}-ex{number:02d}"
            for number in range(1, EXPECTED_EXERCISES[unit] + 1)
        }
        expected_solution_numbers = {
            int(match.group("new") or match.group("old"))
            for stable_id in solutions for match in [SOLUTION_RE.search(stable_id)] if match
        }
        require(exercises == expected_exercises,
                f"Independent exact exercise-ID set failed for Unit {unit}")
        require(expected_solution_numbers == set(EXPECTED_PUBLIC_SOLUTIONS[unit]),
                f"Independent exact public-solution set failed for Unit {unit}")
        all_ids.extend(unit_ids)
        expected_exercise_ids.update(exercises)
        expected_solution_ids.update(solutions)
        per_unit[unit_s] = {
            "heading_ids": len(unit_ids),
            "exercise_ids": len(exercises),
            "public_solution_ids": sorted(solutions),
        }
    require(len(all_ids) == len(set(all_ids)) == EXPECTED_NEW_HEADING_IDS,
            "Units 13--30 source heading-ID count/uniqueness failed")
    return {
        "heading_ids": set(all_ids),
        "exercise_ids": expected_exercise_ids,
        "solution_ids": expected_solution_ids,
        "per_unit": per_unit,
    }


def independent_additive_csv(text: str, kind: str) -> list[dict[str, str]]:
    """Read the sidecar independently of exporter counts and row selection."""
    require(kind in ("terminology", "corrections"), "Unknown additive intake kind")
    terminology = kind == "terminology"
    fields = (
        "term_id", "unit", "source_language", "source_term", "target_language",
        "preferred_target", "accepted_variants", "scope", "status", "rationale",
    ) if terminology else (
        "correction_id", "unit", "kind", "scope", "authority_identity",
        "authority_observation", "target_action", "mathematical_effect", "status",
    )
    parser = csv.reader(io.StringIO(text.removeprefix("\ufeff"), newline=""), strict=True)
    require(next(parser, None) == list(fields), f"Wrong independent {kind} columns")
    rows: list[dict[str, str]] = []
    semantic_keys: set[tuple[str, ...]] = set()
    for values in parser:
        if not values:
            continue
        require(len(values) == len(fields), f"Malformed independent {kind} row")
        row = dict(zip(fields, values))
        require(all((name == "scope" or value.strip() == value)
                    and (value.strip() or name == "accepted_variants")
                    for name, value in row.items()), f"Invalid independent {kind} field")
        prefix = "BGK-T13-30-" if terminology else "BGK-C13-30-"
        id_name = "term_id" if terminology else "correction_id"
        require(row[id_name] == f"{prefix}{len(rows) + 1:04d}",
                f"Nonsequential/duplicate independent {kind} ID")
        require(row["unit"].isdigit() and str(int(row["unit"])) == row["unit"]
                and int(row["unit"]) in UNITS, f"Invalid independent {kind} unit")
        require(row["status"] == ("admitted" if terminology else "applied"),
                f"Invalid independent {kind} admission status")
        if terminology:
            require((row["source_language"], row["target_language"]) == ("de", "id-ID"),
                    "Independent terminology has wrong language pair")
            key_fields = ("unit", "source_language", "source_term", "target_language", "scope")
        else:
            key_fields = ("unit", "kind", "scope", "authority_identity")
        key = tuple(row[name].strip().casefold() for name in key_fields)
        require(key not in semantic_keys, f"Duplicate independent {kind} semantic key")
        semantic_keys.add(key)
        rows.append(row)
    require(bool(rows), f"Empty independent {kind} intake")
    return rows


def independent_intake() -> dict[str, list[dict[str, str]] | None]:
    result: dict[str, list[dict[str, str]] | None] = {}
    for kind, path in (("terminology", ADDITIVE_TERMINOLOGY),
                       ("corrections", ADDITIVE_CORRECTIONS)):
        if path.is_file():
            require(not path.is_symlink(), f"Symlink intake rejected: {rel(path)}")
            result[kind] = independent_additive_csv(path.read_text(encoding="utf-8-sig"), kind)
        else:
            result[kind] = None
    return result


def historical_reader_replay(
    manifest: dict[str, Any], records: list[dict[str, Any]], accepted_qa: dict[str, Any]
) -> dict[str, Any]:
    """Classify exactly 31 inherited aliases after authenticating baseline file hashes.

    Only three generated-reader MANIFEST bindings can be superseded. The other
    16 historical non-reader artifact rows are exact earlier versions; current
    source/ledger/rights MANIFEST bindings are still rehashed without exceptions.
    """
    require(manifest.get("through_unit") == 12
            and accepted_qa.get("through_unit") == 12
            and accepted_qa.get("status") == "PASS", "Historical baseline is not accepted Unit 12")
    require(accepted_qa.get("backend", {}).get("manifest_sha256") == BASE_MANIFEST_SHA256
            and accepted_qa.get("backend", {}).get("records_sha256") == BASE_RECORDS_SHA256,
            "Historical baseline QA anchor drifted")
    reader = manifest.get("reader_binding", {})
    require(accepted_qa.get("reader_binding") == reader,
            "Accepted historical reader receipt identity disagrees")
    aliases = []
    for kind, path in zip(("receipt", "html", "pdf"), BASE_READER_BINDINGS):
        size, sha256 = BASE_READER_BINDINGS[path]
        require(reader.get(kind + "_path") == path
                and reader.get(kind + "_sha256") == sha256,
                "Historical reader anchor drifted: " + path)
        expected = {"path": path, "bytes": size, "sha256": sha256}
        matches = [row for row in manifest["source_bindings"] if row.get("path") == path]
        require(matches == [expected], "Historical reader source alias drifted: " + path)
        require(not any(row.get("path") == path for row in manifest["files"]),
                "Historical reader alias cannot exempt native backend files")
        aliases.append(expected)
    by_id = {row["stable_id"]: row for row in records}
    artifacts = []
    reader_ids = {stable_id for group in HISTORICAL_READER_ARTIFACT_IDS.values()
                  for stable_id in group}
    require(len(HISTORICAL_ARTIFACT_BINDINGS) == 31 and len(reader_ids) == 15
            and reader_ids <= HISTORICAL_ARTIFACT_BINDINGS.keys(),
            "Historical artifact whitelist is not exact 31/15")
    for stable_id, (path, size, sha256, record_sha256) in HISTORICAL_ARTIFACT_BINDINGS.items():
        row = by_id.get(stable_id, {})
        canonical_bytes = json.dumps(row, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode("utf-8")
        require(row.get("entity_class") == "artifact" and row.get("path") == path
                and row.get("payload", {}).get("bytes") == size
                and row.get("content_sha256") == sha256
                and hashlib.sha256(canonical_bytes).hexdigest() == record_sha256,
                "Historical full-record pin drifted: " + stable_id)
        artifacts.append({
            "stable_id": stable_id, "path": path, "bytes": size, "sha256": sha256,
            "canonical_record_sha256": record_sha256,
            "classification": ("superseded_generated_reader_alias" if stable_id in reader_ids
                               else "superseded_nonreader_version_alias"),
        })
    return {
        "policy": "exact-31-accepted-historical-artifact-aliases",
        "baseline_manifest_sha256": BASE_MANIFEST_SHA256,
        "baseline_records_sha256": BASE_RECORDS_SHA256,
        "baseline_backend_qa_sha256": BASE_QA_SHA256,
        "accepted_reader_receipt": aliases[0],
        "source_aliases": aliases,
        "historical_artifacts": artifacts,
        "historical_loose_bytes_rehashed": False,
        "evidence": "hash-locked accepted native records, full canonical record pins, manifest and PASS backend QA",
        "current_reader": "independently validated through Unit 30 against current build and QA receipts",
        "current_nonreader_source_and_rights_bindings_exempted": False,
    }


def validate_baseline_binding(
    binding: dict[str, Any], historical_aliases: dict[str, dict[str, Any]]
) -> None:
    historical = historical_aliases.get(binding["path"])
    if historical is not None:
        require(binding == historical, "Historical source alias identity changed: " + binding["path"])
        return
    path = ROOT / binding["path"]
    require(path.is_file() and not path.is_symlink()
            and path.stat().st_size == int(binding["bytes"])
            and digest(path) == binding["sha256"],
            "Accepted BGK baseline binding drifted: " + binding["path"])


def static_check() -> dict[str, Any]:
    before = output_snapshot()
    require(digest(BASE_MANIFEST) == BASE_MANIFEST_SHA256, "Units 1--12 manifest drifted")
    require(digest(BASE_RECORDS) == BASE_RECORDS_SHA256, "Units 1--12 records drifted")
    require(digest(BASE_QA) == BASE_QA_SHA256, "Units 1--12 backend QA drifted")
    base_manifest = load_json(BASE_MANIFEST)
    replay = historical_reader_replay(base_manifest, load_jsonl(BASE_RECORDS), load_json(BASE_QA))
    aliases = {row["path"]: row for row in replay["source_aliases"]}
    for binding in base_manifest["files"]:
        validate_baseline_binding(binding, {})
    for binding in base_manifest["source_bindings"]:
        validate_baseline_binding(binding, aliases)
    require(digest(CLASSICAL_RECORDS) == CLASSICAL_RECORDS_SHA256,
            "Classical collision baseline drifted")
    topology = independent_source_topology()
    exporter = load_exporter()
    exporter_result = exporter.static_check()
    require(exporter_result["baseline"]["historical_reader_replay"] == replay,
            "Exporter/independent historical reader classification disagrees")
    after = output_snapshot()
    require(before == after, "Static check modified the Unit-30 backend directory")
    require(exporter_result.get("ready_for_export") in (True, False),
            "Exporter static result lacks readiness state")
    require(exporter_result["independent_expectations"]["new_heading_ids"] == EXPECTED_NEW_HEADING_IDS,
            "Exporter/static independent heading expectation disagrees")
    require(exporter_result["independent_expectations"]["new_exercises"] ==
            sum(EXPECTED_EXERCISES.values()), "Exporter/static exercise expectation disagrees")
    require(exporter_result["independent_expectations"]["new_public_solutions"] ==
            sum(len(values) for values in EXPECTED_PUBLIC_SOLUTIONS.values()),
            "Exporter/static solution expectation disagrees")
    require(exporter_result["independent_expectations"]["reader_media_positions"] == 3,
            "Exporter/static media expectation disagrees")
    intake = independent_intake()
    for kind, count_key in (("terminology", "new_term_records"),
                            ("corrections", "new_correction_records")):
        rows = intake[kind]
        require(exporter_result["independent_expectations"][count_key] ==
                (len(rows) if rows is not None else None),
                f"Exporter/static independent {kind} count disagrees")
        for unit in UNITS:
            expected = sum(row["unit"] == str(unit) for row in rows) if rows is not None else None
            require(exporter_result["independent_expectations"]["additive_intake_per_unit"]
                    [f"{unit:02d}"][kind] == expected,
                    f"Exporter/static independent Unit {unit} {kind} count disagrees")
    ready = bool(exporter_result["ready_for_export"])
    return {
        "schema": "ag-bridge-bgk-units-01-30-native-qa-static-v1",
        "status": "READY" if ready else "INCOMPLETE",
        "static_validation_status": "PASS",
        "ready_for_export": ready,
        "through_unit_required": 30,
        "immutable_baseline": {
            "manifest": fact(BASE_MANIFEST), "records": fact(BASE_RECORDS), "qa": fact(BASE_QA),
            "historical_reader_replay": replay,
        },
        "independent_expectations": {
            "source_heading_ids": len(topology["heading_ids"]),
            "exercises": len(topology["exercise_ids"]),
            "public_solutions": len(topology["solution_ids"]),
            "reader_media_positions": sum(EXPECTED_MEDIA.values()),
            "term_records": len(intake["terminology"]) if intake["terminology"] else None,
            "correction_records": len(intake["corrections"]) if intake["corrections"] else None,
            "per_unit": topology["per_unit"],
        },
        "exporter": {"file": fact(EXPORTER_PATH), "readiness": exporter_result},
        "missing_inputs": exporter_result["missing_inputs"],
        "nonfinal_qas": exporter_result["nonfinal_qas"],
        "writes_performed": False,
        "output_snapshot_unchanged": True,
        "credentials_recorded": False,
    }


def verify_foreign_keys(records: Iterable[dict[str, Any]]) -> int:
    rows = list(records)
    ids = {row["stable_id"] for row in rows}
    checked = 0
    for row in rows:
        for key in ("parent_id", "rights_id", "resource_id", "edition_id", "supersedes"):
            value = row.get(key)
            if value is not None:
                checked += 1
                require(value in ids, f"Missing {key} target for {row['stable_id']}: {value}")
        for key in ("concept_ids", "prerequisite_ids"):
            for value in row.get(key, []):
                checked += 1
                require(value in ids, f"Missing {key} target for {row['stable_id']}: {value}")
        if row["entity_class"] == "relation":
            for key in ("subject_id", "object_id"):
                value = row["payload"][key]
                checked += 1
                require(value in ids, f"Missing relation {key} for {row['stable_id']}: {value}")
    return checked


def exact_file_set(directory: Path) -> dict[str, dict[str, Any]]:
    return {
        path.name: fact(path) for path in sorted(directory.iterdir())
        if path.is_file() and not path.is_symlink()
    }


def verify_additive_records(
    records: list[dict[str, Any]], manifest: dict[str, Any], new_ids: set[str],
) -> dict[str, Any]:
    intake = independent_intake()
    require(all(rows is not None for rows in intake.values()), "Additive intake missing")
    terms = intake["terminology"] or []
    corrections = intake["corrections"] or []
    by_id = {row["stable_id"]: row for row in records}
    expected_terms = {f"term.br-bgk-2019.{row['term_id'].casefold()}": row for row in terms}
    expected_concepts = {f"concept.br-bgk-2019.{row['term_id'].casefold()}" for row in terms}
    expected_corrections = {
        f"correction.br-bgk-2019.u{int(row['unit']):02d}."
        f"{int(row['correction_id'].rsplit('-', 1)[1]):04d}": row for row in corrections
    }
    contains = {
        (row["payload"]["subject_id"], row["payload"]["object_id"])
        for row in records if row["stable_id"] in new_ids and row["entity_class"] == "relation"
        and row["payload"].get("predicate") == "contains"
    }
    for entity, expected in (("term", set(expected_terms)), ("concept", expected_concepts),
                             ("correction", set(expected_corrections))):
        observed = {row["stable_id"] for row in records
                    if row["stable_id"] in new_ids and row["entity_class"] == entity}
        require(observed == expected, f"Exact additive {entity} ID set failed")
    for stable_id, row in list(expected_terms.items()) + list(expected_corrections.items()):
        term = stable_id in expected_terms
        actual = by_id[stable_id]
        intake_path = ADDITIVE_TERMINOLOGY if term else ADDITIVE_CORRECTIONS
        row_id = row["term_id" if term else "correction_id"]
        canonical_row = json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        require(actual["source_local_id"] == row_id
                and actual["source_locator"] == f"{rel(intake_path)}#{row_id}"
                and actual["content_sha256"] == digest_bytes(canonical_row.encode("utf-8"))
                and actual["provenance"].get("source_file_sha256") == digest(intake_path)
                and actual["payload"].get("ledger_row") == row
                and actual["payload"].get("unit") == int(row["unit"]),
                f"Additive row/source binding failed: {stable_id}")
        require((actual["parent_id"], stable_id) in contains,
                f"Additive containment relation missing: {stable_id}")
        if term:
            concept_id = f"concept.br-bgk-2019.{row_id.casefold()}"
            concept = by_id[concept_id]
            require(actual["parent_id"] == concept_id and actual["concept_ids"] == [concept_id]
                    and concept["payload"]["introduced_in_unit"] == int(row["unit"])
                    and concept["payload"]["preferred_label"] == row["preferred_target"]
                    and concept["payload"]["source_label"] == row["source_term"],
                    f"Additive term/concept binding failed: {stable_id}")
            require(all(actual["payload"].get(name) == row[name] for name in
                        ("source_language", "source_term", "target_language", "preferred_target",
                         "accepted_variants", "rationale")),
                    f"Common-adapter-visible terminology fields missing: {stable_id}")
        else:
            require(actual["parent_id"].startswith(f"br-bgk-2019-l{int(row['unit']):02d}")
                    and by_id[actual["parent_id"]]["entity_class"] == "unit"
                    and actual["payload"].get("disclosed_in_reader") is True
                    and actual["payload"].get("silent_change") is False,
                    f"Additive correction parent/disclosure failed: {stable_id}")
            require(all(actual["payload"].get(name) == row[name] for name in
                        ("kind", "authority_observation", "target_action", "mathematical_effect")),
                    f"Common-adapter-visible correction fields missing: {stable_id}")
    binding = manifest.get("additive_editorial_intake", {})
    require(binding.get("central_ledgers_unchanged") is True,
            "Manifest does not preserve central-ledger contract")
    source_bindings = {row["path"]: row for row in manifest["source_bindings"]}
    for name, path in (("terminology", ADDITIVE_TERMINOLOGY),
                       ("corrections", ADDITIVE_CORRECTIONS), ("reader_glossary", READER_GLOSSARY)):
        require(binding.get(name) == fact(path) and source_bindings.get(rel(path)) == fact(path),
                f"Additive source/manifest binding failed: {name}")
        artifacts = [row for row in records if row["stable_id"] in new_ids
                     and row["entity_class"] == "artifact" and row["path"] == rel(path)]
        require(len(artifacts) == 1 and artifacts[0]["content_sha256"] == digest(path)
                and artifacts[0]["payload"]["bytes"] == path.stat().st_size,
                f"Additive artifact binding failed: {name}")
    require(binding.get("terminology_ids") == [row["term_id"] for row in terms]
            and binding.get("correction_ids") == [row["correction_id"] for row in corrections],
            "Manifest additive ID inventory disagrees")
    require(manifest.get("units_13_30_term_count") == len(terms)
            and manifest.get("units_13_30_correction_count") == len(corrections),
            "Manifest additive total counts disagree")
    return {"terms": len(terms), "corrections": len(corrections), "per_unit": {
        f"{unit:02d}": {
            "terminology_ids": [row["term_id"] for row in terms if row["unit"] == str(unit)],
            "correction_ids": [row["correction_id"] for row in corrections if row["unit"] == str(unit)],
        } for unit in UNITS
    }}


def verify_artifact_binding(
    row: dict[str, Any], base_by_id: dict[str, dict[str, Any]],
    historical_ids: set[str],
) -> str:
    stable_id = row["stable_id"]
    if stable_id in historical_ids:
        require(row == base_by_id.get(stable_id),
                "Inherited historical artifact was modified: " + stable_id)
        pin = HISTORICAL_ARTIFACT_BINDINGS.get(stable_id)
        require(pin is not None
                and digest_bytes(json.dumps(row, ensure_ascii=False, sort_keys=True,
                                            separators=(",", ":")).encode("utf-8")) == pin[3],
                "Historical artifact full-record hash drifted: " + stable_id)
        return "historical"
    path = ROOT / row["path"]
    require(path.is_file() and not path.is_symlink()
            and path.stat().st_size == int(row["payload"]["bytes"])
            and digest(path) == row["content_sha256"],
            "Artifact byte binding drifted: " + stable_id)
    return "current"


def validate_materialized_backend(
    expected_bytes: dict[str, bytes], manifest: dict[str, Any]
) -> dict[str, Any]:
    require(manifest.get("through_unit") == 30 and manifest.get("model_provenance") == MODEL,
            "Native manifest is not exact Unit-30/model boundary")
    schema_path = BACKEND / "record.schema.json"
    records_path = BACKEND / "records.jsonl"
    schema = load_json(schema_path)
    records = load_jsonl(records_path)
    require(len(records) == int(manifest["record_count"]), "Manifest record count drifted")

    validator = Draft202012Validator(schema)
    for index, row in enumerate(records, start=1):
        errors = sorted(validator.iter_errors(row), key=lambda error: list(error.absolute_path))
        require(not errors,
                f"Schema error at record {index} {row.get('stable_id')}: "
                f"{errors[0].message if errors else ''}")

    ids = [row["stable_id"] for row in records]
    require(len(ids) == len(set(ids)), "Duplicate cumulative stable IDs")
    by_id = {row["stable_id"]: row for row in records}
    foreign_keys_checked = verify_foreign_keys(records)
    base_records = load_jsonl(BASE_RECORDS)
    base_ids = {row["stable_id"] for row in base_records}
    new_ids = set(ids) - base_ids
    require(len(new_ids) == int(manifest["units_13_30_added_record_count"]),
            "Manifest added-record count drifted")
    require(all(by_id[stable_id]["provenance"].get("model") == MODEL for stable_id in new_ids),
            "A new record lacks exact model provenance")

    entity_classes = list(schema["properties"]["entity_class"]["enum"])
    projected: dict[str, dict[str, Any]] = {}
    class_ids: dict[str, set[str]] = {}
    for entity_class in entity_classes:
        path = BACKEND / f"{entity_class}.jsonl"
        rows = load_jsonl(path)
        class_ids[entity_class] = {row["stable_id"] for row in rows}
        require(len(rows) == len(class_ids[entity_class]) == int(manifest["counts"][entity_class]),
                f"Projection count/uniqueness drifted: {entity_class}")
        for row in rows:
            require(row["entity_class"] == entity_class,
                    f"Wrong entity in {entity_class} projection: {row['stable_id']}")
            require(row["stable_id"] not in projected,
                    f"Projection overlap: {row['stable_id']}")
            projected[row["stable_id"]] = row
    require(projected == by_id, "Class projections do not exactly reconstruct records.jsonl")

    for name in ("records.jsonl", *(f"{entity}.jsonl" for entity in entity_classes)):
        require((BACKEND / name).read_bytes().startswith((BASE / name).read_bytes()),
                f"Accepted Unit 1--12 byte prefix changed: {name}")
    require(records_path.read_bytes()[: BASE_RECORDS.stat().st_size] == BASE_RECORDS.read_bytes(),
            "Accepted records.jsonl prefix is not byte-identical")

    topology = independent_source_topology()
    additive = verify_additive_records(records, manifest, new_ids)
    require(topology["heading_ids"] <= set(ids), "A translated heading ID is missing from backend")
    require(set(manifest.get("units", {})) == {f"{unit:02d}" for unit in UNITS},
            "Manifest does not contain the exact Units 13--30 summary set")
    for unit in UNITS:
        unit_s = f"{unit:02d}"
        summary = manifest["units"][unit_s]
        require(int(summary["heading_id_count"]) == topology["per_unit"][unit_s]["heading_ids"]
                and int(summary["exercise_count"]) == EXPECTED_EXERCISES[unit]
                and tuple(summary["public_solution_numbers"]) == EXPECTED_PUBLIC_SOLUTIONS[unit]
                and int(summary["reader_media_positions"]) == EXPECTED_MEDIA[unit]
                and int(summary["term_count"]) == len(additive["per_unit"][unit_s]["terminology_ids"])
                and int(summary["correction_count"]) == len(additive["per_unit"][unit_s]["correction_ids"])
                and summary["terminology_ids"] == additive["per_unit"][unit_s]["terminology_ids"]
                and summary["correction_ids"] == additive["per_unit"][unit_s]["correction_ids"],
                f"Manifest Unit {unit} summary contradicts independent expectations")
    observed_exercises = {
        stable_id for stable_id in class_ids["exercise"]
        if (match := EXERCISE_RE.search(stable_id)) and int(match.group("unit")) in UNITS
    }
    observed_solutions = {
        stable_id for stable_id in class_ids["solution"]
        if (match := SOLUTION_RE.search(stable_id)) and int(match.group("unit")) in UNITS
    }
    require(observed_exercises == topology["exercise_ids"],
            "Units 13--30 exercise projection is not the exact independent set")
    require(observed_solutions == topology["solution_ids"],
            "Units 13--30 solution projection is not the exact independent set")

    expected_assets: set[str] = set()
    for unit in UNITS:
        unit_s = f"{unit:02d}"
        closure = load_json(ROOT / "authority" / f"ASSET_CLOSURE-bgk-unit-{unit_s}.json")
        assets = {row["asset_id"] for row in closure.get("assets", [])}
        require(int(closure["reader_media_positions"]) == EXPECTED_MEDIA[unit] and
                int(closure["unique_local_assets"]) == len(assets) == EXPECTED_MEDIA[unit],
                f"Independent media closure failed for Unit {unit}")
        expected_assets.update(assets)
    require(class_ids["asset"] & new_ids == expected_assets,
            "New asset projection is not the exact per-unit closure set")
    depicts = [
        row for row in records if row["stable_id"] in new_ids and row["entity_class"] == "relation"
        and row.get("payload", {}).get("predicate") == "depicts_with"
    ]
    require(len(depicts) == 3 and {row["payload"]["object_id"] for row in depicts} == expected_assets,
            "Unit 29 depicts-with relation closure failed")

    classical_ids = {row["stable_id"] for row in load_jsonl(CLASSICAL_RECORDS)}
    require(not (set(ids) & classical_ids), "BGK/classical namespace collision")
    for binding in list(manifest["files"]) + list(manifest["source_bindings"]):
        path = ROOT / binding["path"]
        require(path.is_file() and path.stat().st_size == int(binding["bytes"])
                and digest(path) == binding["sha256"],
                f"Manifest binding drifted: {binding['path']}")
    expected_manifest_file_paths = set(expected_bytes) - {rel(BACKEND / "MANIFEST.json")}
    require({row["path"] for row in manifest["files"]} == expected_manifest_file_paths,
            "Manifest files inventory is not the exact generated output set excluding itself")
    for path, expected in ((BASE_MANIFEST, BASE_MANIFEST_SHA256),
                           (BASE_RECORDS, BASE_RECORDS_SHA256), (BASE_QA, BASE_QA_SHA256)):
        require(digest(path) == expected, "Immutable baseline changed during QA: " + rel(path))
    replay = historical_reader_replay(load_json(BASE_MANIFEST), base_records, load_json(BASE_QA))
    require(manifest["units_01_12_immutable_baseline"].get("historical_reader_replay") == replay,
            "Manifest historical alias classification disagrees with exact independent pins")
    historical_ids = {item["stable_id"] for item in replay["historical_artifacts"]}
    base_by_id = {row["stable_id"]: row for row in base_records}
    historical_checked = 0
    current_artifacts_checked = 0
    for row in records:
        if row["entity_class"] == "artifact":
            classification = verify_artifact_binding(row, base_by_id, historical_ids)
            historical_checked += classification == "historical"
            current_artifacts_checked += classification == "current"
    require(historical_checked == 31, "Historical alias record inventory is not exact 31")

    expected_names = {Path(path).name for path in expected_bytes}
    actual_names = set(exact_file_set(BACKEND))
    require(actual_names == expected_names, "Materialized backend has missing/unexpected files")
    for path_s, data in expected_bytes.items():
        require((ROOT / path_s).read_bytes() == data, f"Materialized bytes drifted: {path_s}")

    for qa_path in (READER_QA, RESPONSIVE_QA, VISUAL_QA):
        qa = load_json(qa_path)
        require(qa.get("through_unit") == 30 and qa.get("status") == "PASS"
                and qa.get("model_provenance") == MODEL,
                f"Final QA is not exact PASS through Unit 30: {rel(qa_path)}")
    require(manifest["reader_binding"]["qa_sha256"] == digest(READER_QA)
            and manifest["responsive_binding"]["sha256"] == digest(RESPONSIVE_QA)
            and manifest["visual_binding"]["sha256"] == digest(VISUAL_QA),
            "Manifest does not bind final reader/responsive/visual receipts")

    return {
        "records": len(records), "new_records": len(new_ids),
        "foreign_keys_checked": foreign_keys_checked,
        "new_heading_ids": len(topology["heading_ids"]),
        "new_exercises": len(observed_exercises), "new_public_solutions": len(observed_solutions),
        "new_assets": len(expected_assets), "depicts_relations": len(depicts),
        "new_terms": additive["terms"], "new_corrections": additive["corrections"],
        "counts": manifest["counts"],
        "historical_alias_replay": replay,
        "historical_artifacts_checked": historical_checked,
        "current_artifacts_rehashed": current_artifacts_checked,
    }


def write_atomic(path: Path, data: bytes) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_bytes(data)
    require(temporary.read_bytes() == data, f"Temporary write/readback mismatch: {rel(path)}")
    temporary.replace(path)
    require(path.read_bytes() == data, f"Receipt write/readback mismatch: {rel(path)}")


def run_full_qa() -> dict[str, Any]:
    readiness = static_check()
    require(readiness["ready_for_export"],
            "Unit-30 export is incomplete; run --static-check for the finite missing-input list")
    exporter = load_exporter()
    first_bytes, first_manifest = exporter.build_export()
    second_bytes, second_manifest = exporter.build_export()
    require(first_bytes == second_bytes and first_manifest == second_manifest,
            "In-memory double replay is not byte deterministic")
    exporter.write_export(first_bytes)
    validation = validate_materialized_backend(first_bytes, first_manifest)
    backend_files = exact_file_set(BACKEND)
    receipt = {
        "schema": "ag-bridge-bgk-native-backend-qa-v1",
        "through_unit": 30, "status": "PASS",
        "verification_date": str(first_manifest["generated_from_authority_utc"])[:10],
        "model_provenance": MODEL,
        "driver": fact(Path(__file__).resolve()), "exporter": fact(EXPORTER_PATH),
        "backend": {
            "path": rel(BACKEND), "record_count": validation["records"],
            "records": fact(BACKEND / "records.jsonl"),
            "manifest": fact(BACKEND / "MANIFEST.json"),
            "files": list(backend_files.values()), "counts": validation["counts"],
        },
        "immutable_baseline": {
            "path": rel(BASE), "record_count": len(load_jsonl(BASE_RECORDS)),
            "manifest_sha256": digest(BASE_MANIFEST), "records_sha256": digest(BASE_RECORDS),
            "records_and_every_class_projection_are_exact_byte_prefixes": True,
            "historical_alias_replay": validation["historical_alias_replay"],
        },
        "units_13_30": {
            "heading_ids": validation["new_heading_ids"],
            "exercise_ids": validation["new_exercises"],
            "public_solution_ids": validation["new_public_solutions"],
            "reader_media_positions": sum(EXPECTED_MEDIA.values()),
            "asset_ids": validation["new_assets"],
            "depicts_relations": validation["depicts_relations"],
            "term_records": validation["new_terms"], "correction_records": validation["new_corrections"],
            "added_records": validation["new_records"],
        },
        "deterministic_replay": {
            "runs": 2, "all_in_memory_output_bytes_identical": True,
            "manifest_object_identical": True,
            "output_file_sha256": {
                Path(path).name: digest_bytes(data) for path, data in sorted(first_bytes.items())
            },
        },
        "final_qa_evidence": [fact(path) for path in (READER_QA, RESPONSIVE_QA, VISUAL_QA)],
        "checks": {
            "json_schema_all_records": True, "unique_stable_ids": True,
            "parent_rights_resource_edition_concept_prerequisite_supersedes_and_relation_closure": True,
            "class_projections_exactly_reconstruct_records": True,
            "accepted_units_01_12_exact_byte_prefix_preserved": True,
            "independent_heading_exercise_solution_and_media_exact_sets": True,
            "independent_per_unit_additive_term_and_correction_exact_sets": True,
            "additive_sidecars_and_reader_glossary_source_and_artifact_bindings_exact": True,
            "unit_29_three_asset_depicts_closure": True,
            "artifact_bytes_and_manifest_bindings_exact": True,
            "historical_artifact_records_full_hash_pinned": validation["historical_artifacts_checked"],
            "nonhistorical_artifacts_live_bytes_rehashed": validation["current_artifacts_rehashed"],
            "historical_aliases_not_claimed_as_current_loose_bytes": True,
            "classical_namespace_intersection_zero": True,
            "exact_model_provenance_on_every_new_record": True,
            "reader_visual_responsive_gates_exact_pass_through_unit_30": True,
            "foreign_keys_checked": validation["foreign_keys_checked"],
        },
        "credentials_recorded": False,
    }
    data = (json.dumps(receipt, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")
    write_atomic(RECEIPT, data)
    return {"status": "PASS", "receipt": fact(RECEIPT), "backend": receipt["backend"]}


def terminology_intake_self_test() -> dict[str, Any]:
    """Exercise both independent parsers without opening/writing corpus files."""
    exporter = load_exporter()
    checked = 0

    def encoded(fields: list[str], rows: list[dict[str, str]]) -> str:
        stream = io.StringIO(newline="")
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(fields)
        writer.writerows([[row[name] for name in fields] for row in rows])
        return stream.getvalue()

    fixtures = {
        "terminology": {
            "term_id": "BGK-T13-30-0001", "unit": "13", "source_language": "de",
            "source_term": "Garbe", "target_language": "id-ID", "preferred_target": "berkas",
            "accepted_variants": "", "scope": "BGK Unit 13", "status": "admitted",
            "rationale": "Distinct from a vector bundle.",
        },
        "corrections": {
            "correction_id": "BGK-C13-30-0001", "unit": "13", "kind": "notation_typesetting",
            "scope": "BGK Unit 13", "authority_identity": "frozen-page#section",
            "authority_observation": "A notation treatment is already disclosed.",
            "target_action": "Preserve the visible disclosure.", "mathematical_effect": "none",
            "status": "applied",
        },
    }
    for kind, row in fixtures.items():
        fields = list(row)
        id_key = "term_id" if kind == "terminology" else "correction_id"
        valid = encoded(fields, [row])
        valid_bom = "\ufeff" + valid
        invalid: list[str] = [
            valid.split("\n", 1)[0] + "\n",  # empty intake
            valid.replace(",unit,", f",{id_key},", 1),  # duplicate header key
            valid.replace(",unit,", ",unclaimed_column,", 1),
            valid.split("\n", 1)[0] + "\n" + valid.split("\n")[1] + ",extra\n",
            valid.split("\n", 1)[0] + "\n" + ",".join(valid.split("\n")[1].split(",")[:-1]) + "\n",
            encoded(fields, [row, row]),  # duplicate ID
        ]
        duplicate = {**row, id_key: row[id_key][:-4] + "0002"}
        invalid.append(encoded(fields, [row, duplicate]))  # duplicate semantic key
        invalid.append(encoded(fields, [row, {**duplicate, "scope": row["scope"] + " "}]))
        for field, value in (
            ("unit", "12"), ("unit", "31"), ("unit", "013"), ("unit", "13.0"),
            ("unit", "13 "), ("scope", ""), ("scope", " "), ("status", "draft"),
            (id_key, row[id_key][:-4] + "0000"), (id_key, row[id_key][:-4] + "0002"),
            (id_key, "unrelated-0001"),
        ):
            invalid.append(encoded(fields, [{**row, field: value}]))
        if kind == "terminology":
            invalid.extend(encoded(fields, [{**row, key: value}]) for key, value in
                           (("source_language", "en"), ("target_language", "id"),
                            ("preferred_target", ""), ("source_term", " Garbe")))
        for parser in (exporter.parse_additive_csv, independent_additive_csv):
            for text in (valid, valid_bom):
                require(parser(text, kind) == [row], f"{parser.__name__} rejected valid {kind}")
                checked += 1
            quoted_scope = {**row, "scope": row["scope"] + " "}
            require(parser(encoded(fields, [quoted_scope]), kind) == [quoted_scope],
                    f"{parser.__name__} failed to preserve valid verbatim scope text")
            checked += 1
            for index, text in enumerate(invalid):
                try:
                    parser(text, kind)
                except (RuntimeError, csv.Error):
                    checked += 1
                else:
                    raise RuntimeError(f"{parser.__name__} accepted invalid {kind} fixture {index}")
    return {"status": "PASS", "checks": checked,
            "scope": "independent additive terminology/correction CSV parsers",
            "corpus_files_opened": False, "writes_performed": False}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--static-check", action="store_true",
                        help="Validate existing topology and enumerate missing inputs without writes")
    mode.add_argument("--terminology-self-test", action="store_true",
                      help="Test additive terminology/correction parsing without corpus writes")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.terminology_self_test:
        print(json.dumps(terminology_intake_self_test(), ensure_ascii=False, sort_keys=True, indent=2))
        return 0
    if args.static_check:
        result = static_check()
        print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
        return 0 if result["ready_for_export"] else 2
    print(json.dumps(run_full_qa(), ensure_ascii=False, sort_keys=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
