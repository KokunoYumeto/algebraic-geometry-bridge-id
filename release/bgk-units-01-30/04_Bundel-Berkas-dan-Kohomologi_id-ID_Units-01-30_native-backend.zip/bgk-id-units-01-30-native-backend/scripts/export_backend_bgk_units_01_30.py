#!/usr/bin/env python3
"""Append verified BGK Units 13--30 to the immutable Units 1--12 backend.

Default mode materializes ``backend/bgk-units-01-30``. ``--preflight`` (alias
``--dry-run``) builds the complete export in memory without writing it. ``--static-check`` verifies
the immutable baseline, translated stable-ID topology, and the finite input
matrix even while terminal authority/reader inputs are still missing.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Iterable


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "backend" / "bgk-units-01-12"
OUT = ROOT / "backend" / "bgk-units-01-30"
BASE_MANIFEST = BASE / "MANIFEST.json"
BASE_RECORDS = BASE / "records.jsonl"
BASE_QA = ROOT / "qa" / "BGK_UNITS_01_12_BACKEND_QA.json"
BASE_MANIFEST_SHA256 = "6ead72bff45e4815aee62a63ddccd055e47d04c47eb70d39fcd4d872e6ed9927"
BASE_RECORDS_SHA256 = "9b15776df6cc87bee3568872a12bf2ab26696ee220fb6ffddc49fd13ea74832f"
BASE_QA_SHA256 = "4d2e877b1f5996714d3788a773c8e2fa1d22c75d4a8a9932c6d901bff6ea57e6"

# Only these accepted generated-reader locations may be interpreted historically.
# This is NOT a wildcard for source, rights, ledgers, or current Unit-30 artifacts.
BASE_READER_BINDINGS = {
    "build/reader-bgk-id/BUILD_RECEIPT.json": (
        17478, "08360126b8f1b7ca6cdf26be7467129edc95249e483ae2191b7902f57cafff66"),
    "build/reader-bgk-id/index.html": (
        3979627, "d88da9b0b65c8cb75a1549d4349b48176355201e372e314f9fe655b8c90b1cf2"),
    "build/reader-bgk-id/bundel-berkas-dan-kohomologi-id-units-01-12.pdf": (
        1311189, "95da79e1fa7c22212218f72f71981d3200111488ecfe15f884661a368c6421eb"),
}
HISTORICAL_READER_ARTIFACT_IDS = {
    4: ("artifact.br-bgk-2019.u04.22", "artifact.br-bgk-2019.u04.23",
        "artifact.br-bgk-2019.u04.24"),
    6: ("artifact.br-bgk-2019.u06.048", "artifact.br-bgk-2019.u06.049",
        "artifact.br-bgk-2019.u06.050"),
    7: ("artifact.br-bgk-2019.u07.023", "artifact.br-bgk-2019.u07.024",
        "artifact.br-bgk-2019.u07.025"),
    8: ("artifact.br-bgk-2019.u08.023", "artifact.br-bgk-2019.u08.024",
        "artifact.br-bgk-2019.u08.025"),
    12: ("artifact.br-bgk-2019.u12.cumulative-008",
         "artifact.br-bgk-2019.u12.cumulative-009",
         "artifact.br-bgk-2019.u12.cumulative-010"),
}

SCHEMA_NAME = "ag-bridge-backend-record"
SCHEMA_VERSION = "1.0.0"
MANIFEST_SCHEMA = "ag-bridge-bgk-native-backend-export-manifest-v1"
WORKFLOW_ID = "workflow.o016-d100.algebraic-geometry-bridge-id"
COURSE_ID = "course.o016-d100.bgk-bridge"
SOURCE_RESOURCE = "resource.brenner.bgk.wikiversity.2019-2020"
LOCAL_RESOURCE = "resource.bgk-id.editorial-layer"
SEMANTIC_RIGHTS = "rights.bgk-semantic-text.cc-by-sa-4.0"
EDITORIAL_RIGHTS = "rights.bgk-id.derivative.cc-by-sa-4.0"
DERIVATIVE_EDITION = "edition.bgk-id.units-01-30.2026-08-31"
MODEL_PROVENANCE = "OpenAI Codex gpt-5.6-sol, Ultra."
UNITS = tuple(range(13, 31))

EXPECTED_EXERCISES = {
    13: 23, 14: 26, 15: 20, 16: 23, 17: 24, 18: 25,
    19: 12, 20: 13, 21: 13, 22: 20, 23: 21, 24: 5,
    25: 13, 26: 8, 27: 14, 28: 14, 29: 15, 30: 5,
}
EXPECTED_PUBLIC_SOLUTIONS = {
    13: (), 14: (), 15: (), 16: (12,), 17: (), 18: (6, 17, 18),
    19: (10,), 20: (), 21: (3, 9, 10), 22: (19,), 23: (), 24: (),
    25: (1,), 26: (), 27: (), 28: (6,), 29: (5, 12), 30: (),
}
EXPECTED_READER_MEDIA = {unit: (3 if unit == 29 else 0) for unit in UNITS}
EXPECTED_NEW_HEADING_IDS = 784

SOURCE_DIR = ROOT / "source" / "id-ID" / "bgk"
FRONTMATTER = SOURCE_DIR / "frontmatter-bgk-units-01-30.md"
TERMINOLOGY = ROOT / "00_control" / "TERMINOLOGY.csv"
CORRECTIONS = ROOT / "00_control" / "CORRECTIONS.csv"
ADDITIVE_TERMINOLOGY = ROOT / "00_control" / "BGK_UNITS_13_30_TERMINOLOGY.csv"
ADDITIVE_CORRECTIONS = ROOT / "00_control" / "BGK_UNITS_13_30_CORRECTIONS.csv"
READER_GLOSSARY = SOURCE_DIR / "glossary-bgk-units-01-30.md"
TERMINOLOGY_FIELDS = (
    "term_id", "unit", "source_language", "source_term", "target_language",
    "preferred_target", "accepted_variants", "scope", "status", "rationale",
)
CORRECTION_FIELDS = (
    "correction_id", "unit", "kind", "scope", "authority_identity",
    "authority_observation", "target_action", "mathematical_effect", "status",
)
READER_QA = ROOT / "qa" / "BGK_UNITS_01_30_READER_QA.json"
RESPONSIVE_QA = ROOT / "qa" / "BGK_UNITS_01_30_RESPONSIVE_QA.json"
VISUAL_QA = ROOT / "qa" / "BGK_UNITS_01_30_VISUAL_QA.json"
READER_RECEIPT = ROOT / "build" / "reader-bgk-id" / "BUILD_RECEIPT.json"
READER_HTML = ROOT / "build" / "reader-bgk-id" / "index.html"
READER_PDF = (
    ROOT / "build" / "reader-bgk-id"
    / "bundel-berkas-dan-kohomologi-id-units-01-30.pdf"
)
CLASSICAL_RECORDS = ROOT / "backend" / "units-01-30" / "records.jsonl"
NATIVE_QA_DRIVER = ROOT / "scripts" / "qa_backend_bgk_units_01_30.py"
COMMON_QA_DRIVER = ROOT / "scripts" / "qa_common_backend_bgk_units_01_30.py"

HEADING_RE = re.compile(r"^(#{1,6})[ \t]+(.+?)[ \t]+\{#([^}]+)\}[ \t]*$", re.MULTILINE)
EXERCISE_RE = re.compile(r"-w(?P<unit>\d{2})-ex(?P<number>\d{2})$")
SOLUTION_RE = re.compile(
    r"-w(?P<unit>\d{2})(?:-sol-ex(?P<new>\d{2})|-ex(?P<old>\d{2})-solution)$"
)


# Exact inherited records; tuple = historical path, bytes, content SHA-256, full canonical record SHA-256.
HISTORICAL_ARTIFACT_BINDINGS = {
    "artifact.br-bgk-2019.u01.12": (
        "00_control/TERMINOLOGY.csv", 45817,
        "29fdd728ca85183cd870a5d72a62ee3dff777bf6feadf7165e685c587bcc5109",
        "0f7c8550d39e195d46bccfef7a8a53e4c0ee2c5d4fd3e1620cadcd5a242d680f"),
    "artifact.br-bgk-2019.u01.13": (
        "00_control/CORRECTIONS.csv", 88600,
        "22aaa7665956da60a4cfe3916c1d6c80865b5abf8da8770aa4829b3e2b183f74",
        "523cc7b4306a1f220129041bd17571ab9f6ea2f3c170b801b23a988d5b6aa44a"),
    "artifact.br-bgk-2019.u02.18": (
        "00_control/TERMINOLOGY.csv", 47145,
        "c903b851cb96133d560f3ac4d6f0cc8ffb93947c4c64bc44a8cad74f10284260",
        "b8f197263de0abdd41d73cc1bfad4cc8d0b86401dae6b401105b162533e67afd"),
    "artifact.br-bgk-2019.u02.19": (
        "00_control/CORRECTIONS.csv", 92937,
        "ce7546c6e8a31866ae78180c0a080e4c6489bf90376e7325118afc3973016266",
        "b12e72c70c218f75468a9cafad0457ea6433fcde4927448dad20cda12f643cd9"),
    "artifact.br-bgk-2019.u03.18": (
        "00_control/TERMINOLOGY.csv", 49722,
        "043a0370707a1f50b8af8ca3700d388a7e78bae53879919f40b7f5689e57ad19",
        "086a451b792ec5f13a0267feb826cae472fa336dde5a15cbbeea3a2daf7e0145"),
    "artifact.br-bgk-2019.u03.19": (
        "00_control/CORRECTIONS.csv", 96333,
        "8ddb2e4f54b80f3b825cbd630c73e3c90c3b617bb0caa21e7b4977e030975755",
        "73b9b40a937f1c4300b8e31943d8571fd121c8d24e89609d139cdd391e71f26a"),
    "artifact.br-bgk-2019.u04.17": (
        "00_control/TERMINOLOGY.csv", 51230,
        "db567eb87fa30247e747fe15c3c3b9fd0ef64bb55f4f776286b35491ad11c421",
        "88f93cd3614b7c7876aae54fe6b84ef1e264d301b2a0ed60fa3612ff5cbd7ed3"),
    "artifact.br-bgk-2019.u04.18": (
        "00_control/CORRECTIONS.csv", 98843,
        "fe486065197a2839a0e341f4634154d47bb9a63db10ac3fa0c6e1ee00645edde",
        "356525bd7f17ce560bb17b1cdb3a8372570e399e7e8b06290e8f4cd703c639fc"),
    "artifact.br-bgk-2019.u04.22": (
        "build/reader-bgk-id/BUILD_RECEIPT.json", 7666,
        "7b3230d851f721350d830d5d61a8d1d2f86622186c91fa3991b78a61cfb31fba",
        "61139964a3c884a09d2d9a7eaddf60945e828e041d138bb6fcf8e8b93bb6bdeb"),
    "artifact.br-bgk-2019.u04.23": (
        "build/reader-bgk-id/index.html", 3062967,
        "ca9d860f1b0dd68d18ffe4017efbf755ed7819aa0727d4194f880863bcd1609b",
        "c97aac64e5254ae4789da64edd7ae8db947ab131b272f709d31c20a1da2ed706"),
    "artifact.br-bgk-2019.u04.24": (
        "build/reader-bgk-id/bundel-berkas-dan-kohomologi-id-units-01-04.pdf", 774444,
        "26db50d9ca0fc0b343e67025b1d2d6f17393703f30df586da03db059a0d02ea0",
        "60ce7b9f9578b7045a07a0f50952633f9abeda52cbd48350725bb54235ef372d"),
    "artifact.br-bgk-2019.u06.045": (
        "00_control/TERMINOLOGY.csv", 54358,
        "eee5c52af4122e4a2ae4e14c8ef4df76302e388075ea73fb72e7a92fce80fc06",
        "cb66321b95da02eaa1a7d1aa2b085c11a2ac7c749d40de26db6db7f446679d14"),
    "artifact.br-bgk-2019.u06.046": (
        "00_control/CORRECTIONS.csv", 103784,
        "23a2f4afa6955ecd729e1716dfa19610b7c0b728668b694f27af5aad409242b7",
        "abc53eadb805b9639d563cd6b450dceffbf088f71a1cce4340fc2662d8e50387"),
    "artifact.br-bgk-2019.u06.048": (
        "build/reader-bgk-id/BUILD_RECEIPT.json", 10118,
        "e69b24950f0d7ede5cf8c33b6bec32298c08555758936193e1bb4a002844937b",
        "e14e27d8d486ceb243571319b9c56bf8a677cfe058e80d00fbd5b279c972bac8"),
    "artifact.br-bgk-2019.u06.049": (
        "build/reader-bgk-id/index.html", 3272151,
        "feb45d21d6168feaedf35719fdcb0b7f5532687846041d9fd75573c6d66fc5e9",
        "2da4e5b736a2979ebc8da9e629573bd8d16356d7a2900111ebce645a545dfcd1"),
    "artifact.br-bgk-2019.u06.050": (
        "build/reader-bgk-id/bundel-berkas-dan-kohomologi-id-units-01-06.pdf", 896202,
        "f89a622f15acab90f683fb2a0b72a150363fc71d0f41f971c48b8c8ee43c2c9b",
        "af185c7fb32a84e7ad52d9ebe1ba8589601ed914234d58e6997132de710b80d1"),
    "artifact.br-bgk-2019.u07.004": (
        "source/id-ID/bgk/lecture-07.md", 14479,
        "0c2341b1adbaa70ea00a699fb3f7786146232cf7318163976950f215a0c70009",
        "8bc0dc81467146119130a05192ac344cc5432d4dda5d3e89eadfc83c66b73bf5"),
    "artifact.br-bgk-2019.u07.010": (
        "qa/BGK_UNIT_07_TRANSLATION_QA.json", 3314,
        "4840d41617dbe75099d391ba9225d9a490f1d0fd8285042050f0a80717403d76",
        "9bceb42116cd52bafc97f0fe7ab5269d8e909279f004a72c127133d10232bf3b"),
    "artifact.br-bgk-2019.u07.018": (
        "00_control/TERMINOLOGY.csv", 55581,
        "829dbff0916d9e87ccb6f4ca050a5943c789a6d1b31cb3de2e8278af572f27c1",
        "8fcc3c73ee3ee115093ae99166a0e83d408a8f2dd78fd52aabaf9c6ad9c1ea55"),
    "artifact.br-bgk-2019.u07.019": (
        "00_control/CORRECTIONS.csv", 105612,
        "99d35c37aab30c991465b051104eaa8b26a2ddd66a32f5c1a18ec50711877e0e",
        "dad79f47ac0e8a246b06f6bbde17dfba1c31ad01c8386ad19e12970493748d8c"),
    "artifact.br-bgk-2019.u07.023": (
        "build/reader-bgk-id/BUILD_RECEIPT.json", 11345,
        "1b66076fcd55f8e278dec257f3c05f76beba0f4bd59b47d1871b1a7005e12e86",
        "708c585d059b7bd680310e97f93f920a68612e064d7e829d11a0fef86d3bdd8e"),
    "artifact.br-bgk-2019.u07.024": (
        "build/reader-bgk-id/index.html", 3376900,
        "a9b664c091ff1dca9606d1bbc4383d38716a6a314a34d71fbb9d2b2cab817029",
        "4c366c253c97f2a40c68bae22da6147388c8242026f2598261a3ba7cd155f826"),
    "artifact.br-bgk-2019.u07.025": (
        "build/reader-bgk-id/bundel-berkas-dan-kohomologi-id-units-01-07.pdf", 963371,
        "4cc5012417cfb820ddc15484c9d78050079292060941480b3de4f41479f10f51",
        "baa102931d7407d2334f7949793f9d2afd4d3a83e9d9d72bbe906a1978f37764"),
    "artifact.br-bgk-2019.u08.018": (
        "00_control/TERMINOLOGY.csv", 57306,
        "677388255a5f53af44a4d6f0b75769a5fb6e28cf3abda11d34a1b12d99d08b20",
        "113599088d4e09464eedc6d8a118e11fc7fdd8d7572c55ac2e2150886cad2b6f"),
    "artifact.br-bgk-2019.u08.019": (
        "00_control/CORRECTIONS.csv", 107736,
        "bcf848876bc30d67c5447e853060a13c148b64c6818bde06ddec5fed7f1e77b7",
        "b021c80e2a0027593da89b926e63665f16748dc5cc882cda303afcbfcf554d7f"),
    "artifact.br-bgk-2019.u08.023": (
        "build/reader-bgk-id/BUILD_RECEIPT.json", 12574,
        "0827a05da0062d349350936c858bba11cd504e5f1cc9e88ffd42efc04067d527",
        "5a5899154a5e93dd32386324c019ab57d3887b54e3229608b4aa95692753a189"),
    "artifact.br-bgk-2019.u08.024": (
        "build/reader-bgk-id/index.html", 3527732,
        "b8f169ba790451433d5a48b3b3defaa6582ba464cd1f081fb9cdda948bb3f7d3",
        "26208ac06c8078d7cbb3cef2e937c7e46be98c4ad30539e02159b667fad118a0"),
    "artifact.br-bgk-2019.u08.025": (
        "build/reader-bgk-id/bundel-berkas-dan-kohomologi-id-units-01-08.pdf", 1045082,
        "7f701bb9fbf10bfdc198040ca0f99934b96dc339539661e32b5a7351b3f2d2b2",
        "b4b2fce89c961efffaee95faef967ac42d97a8c7cb2c4f761391b362e9e80bb2"),
    "artifact.br-bgk-2019.u12.cumulative-008": (
        "build/reader-bgk-id/BUILD_RECEIPT.json", 17478,
        "08360126b8f1b7ca6cdf26be7467129edc95249e483ae2191b7902f57cafff66",
        "d1b53a01774645ba809146a617fe665330c691c4f7f6fca91d6dc2304f376342"),
    "artifact.br-bgk-2019.u12.cumulative-009": (
        "build/reader-bgk-id/index.html", 3979627,
        "d88da9b0b65c8cb75a1549d4349b48176355201e372e314f9fe655b8c90b1cf2",
        "07fd94f0ee2611c890b03cc905fa21a3e0f1a5e6b28f9a2127ba32a629a97ac8"),
    "artifact.br-bgk-2019.u12.cumulative-010": (
        "build/reader-bgk-id/bundel-berkas-dan-kohomologi-id-units-01-12.pdf", 1311189,
        "95da79e1fa7c22212218f72f71981d3200111488ecfe15f884661a368c6421eb",
        "3e00f121e9211fa2b7232c96a827cdd4d4a63bb56846b16447b50334ca0b91b7"),
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def bytes_digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def text_digest(value: str) -> str:
    return bytes_digest(value.encode("utf-8"))


def rel(path: Path) -> str:
    return path.resolve().relative_to(ROOT).as_posix()


def canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def pretty_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def jsonl_bytes(rows: Iterable[dict[str, Any]]) -> bytes:
    return "".join(canonical(row) + "\r\n" for row in rows).encode("utf-8")


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    require(isinstance(value, dict), f"Expected JSON object: {rel(path)}")
    return value


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def fact(path: Path) -> dict[str, Any]:
    require(path.is_file() and not path.is_symlink(), f"Missing/non-regular input: {rel(path)}")
    return {"path": rel(path), "bytes": path.stat().st_size, "sha256": digest(path)}


def fact_from_bytes(path: Path, data: bytes) -> dict[str, Any]:
    return {"path": rel(path), "bytes": len(data), "sha256": bytes_digest(data)}


def unique_paths(paths: Iterable[Path]) -> list[Path]:
    result: list[Path] = []
    seen: set[Path] = set()
    for path in paths:
        resolved = path.resolve()
        if resolved not in seen:
            seen.add(resolved)
            result.append(path)
    return result


def parse_additive_csv(text: str, kind: str) -> list[dict[str, str]]:
    """Validate an explicit append-only intake; never infer unit from prose."""
    require(kind in {"terminology", "corrections"}, f"Unknown additive intake: {kind}")
    is_term = kind == "terminology"
    fields = TERMINOLOGY_FIELDS if is_term else CORRECTION_FIELDS
    id_key = "term_id" if is_term else "correction_id"
    id_prefix = "BGK-T13-30-" if is_term else "BGK-C13-30-"
    reader = csv.DictReader(io.StringIO(text.removeprefix("\ufeff"), newline=""), strict=True)
    require(tuple(reader.fieldnames or ()) == fields,
            f"Additive {kind} must have the exact ordered, unique columns {fields}")
    result: list[dict[str, str]] = []
    ids: set[str] = set()
    keys: set[tuple[str, ...]] = set()
    for index, row in enumerate(reader, start=1):
        require(set(row) == set(fields) and all(isinstance(value, str) for value in row.values()),
                f"Malformed additive {kind} CSV row {index}")
        # Scope may contain a verbatim visible-note fragment with boundary
        # whitespace. Preserve its bytes; only identity-key comparison trims.
        require(all((key == "scope" or value == value.strip())
                    and (value.strip() or key == "accepted_variants")
                    for key, value in row.items()),
                f"Empty/whitespace-padded additive {kind} field at row {index}")
        require(row[id_key] == f"{id_prefix}{index:04d}" and row[id_key] not in ids,
                f"Additive {kind} IDs must be unique and sequential from {id_prefix}0001")
        require(row["unit"] in {str(unit) for unit in UNITS},
                f"Additive {kind} unit must be an integer in 13--30: {row['unit']}")
        require(row["status"] == ("admitted" if is_term else "applied"),
                f"Unadmitted additive {kind} row: {row[id_key]}")
        if is_term:
            require(row["source_language"] == "de" and row["target_language"] == "id-ID",
                    f"Additive terminology must be de to id-ID: {row[id_key]}")
            key = tuple(row[name].strip().casefold() for name in
                        ("unit", "source_language", "source_term", "target_language", "scope"))
        else:
            key = tuple(row[name].strip().casefold() for name in
                        ("unit", "kind", "scope", "authority_identity"))
        require(key not in keys, f"Duplicate additive {kind} key: {row[id_key]}")
        ids.add(row[id_key])
        keys.add(key)
        result.append(row)
    require(bool(result), f"Empty additive {kind} intake")
    return result


def read_additive_csv(path: Path, kind: str) -> list[dict[str, str]]:
    require(path.is_file() and not path.is_symlink(), f"Missing/non-regular intake: {rel(path)}")
    return parse_additive_csv(path.read_text(encoding="utf-8-sig"), kind)


def split_frontmatter(text: str) -> tuple[str, str]:
    normalized = text.replace("\r\n", "\n")
    if not normalized.startswith("---\n"):
        return "", normalized
    end = normalized.find("\n---\n", 4)
    require(end >= 0, "Unclosed Markdown front matter")
    return normalized[4:end], normalized[end + 5 :]


def block_kind(block: str) -> str:
    stripped = block.strip()
    if stripped.startswith("$$") and stripped.endswith("$$"):
        return "display_math"
    if stripped.startswith("```{=latex}"):
        return "raw_latex"
    if "![" in stripped and "](" in stripped:
        return "image"
    if stripped.startswith("<!--"):
        return "source_comment"
    if stripped.startswith(">"):
        return "blockquote"
    if re.match(r"^(?:[-*+] |\d+\. )", stripped):
        return "list"
    return "paragraph"


def boolish(value: Any) -> bool:
    return str(value).strip().casefold() in {"1", "true", "yes"}


def media_type(path: Path) -> str:
    return {
        ".md": "text/markdown", ".json": "application/json", ".csv": "text/csv",
        ".pdf": "application/pdf", ".html": "text/html", ".xml": "application/xml",
        ".tex": "text/x-tex", ".png": "image/png", ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg", ".gif": "image/gif", ".svg": "image/svg+xml",
    }.get(path.suffix.casefold(), "application/octet-stream")


def unit_paths(unit: int) -> dict[str, Path]:
    unit_s = f"{unit:02d}"
    directory = ROOT / "authority" / "wikiversity-bgk" / f"unit-{unit_s}"
    return {
        "manifest": directory / "UNIT_AUTHORITY_MANIFEST.json",
        "exercise_map": directory / "ORDERED_EXERCISE_MAP.json",
        "candidates": directory / "worksheet-solution-candidates-api.json",
        "pdf_api": directory / "official-pdfs-api.json",
        "authority_freeze": ROOT / "authority" / f"BGK_UNIT_{unit_s}_AUTHORITY_FREEZE.md",
        "authority_qa": ROOT / "qa" / f"BGK_UNIT_{unit_s}_AUTHORITY_QA.json",
        "translation_qa": ROOT / "qa" / f"BGK_UNIT_{unit_s}_TRANSLATION_QA.json",
        "rights": ROOT / "authority" / f"RIGHTS-bgk-unit-{unit_s}.csv",
        "closure": ROOT / "authority" / f"ASSET_CLOSURE-bgk-unit-{unit_s}.json",
        "commons": ROOT / "authority" / f"commons-imageinfo-bgk-unit-{unit_s}.json",
        "credits": ROOT / "source" / "id-ID" / f"media-credits-bgk-unit-{unit_s}.md",
        "lecture_pdf": ROOT / "authority" / "artifacts" / f"bgk-lecture-{unit_s}-official.pdf",
        "worksheet_pdf": ROOT / "authority" / "artifacts" / f"bgk-worksheet-{unit_s}-official.pdf",
        "lecture": SOURCE_DIR / f"lecture-{unit_s}.md",
        "worksheet": SOURCE_DIR / f"worksheet-{unit_s}.md",
        "solutions": SOURCE_DIR / f"worksheet-{unit_s}-solutions.md",
    }


def historical_reader_replay(
    manifest: dict[str, Any], records: list[dict[str, Any]], accepted_qa: dict[str, Any]
) -> dict[str, Any]:
    """Classify exactly 31 inherited aliases after authenticating baseline file hashes.

    Only three generated-reader MANIFEST bindings can be superseded. The other
    16 historical non-reader artifact rows are exact earlier versions; current
    source/ledger/rights MANIFEST bindings are still rehashed without exceptions.
    """
    require(manifest.get("through_unit") == 12
            and accepted_qa.get("through_unit") == 12
            and accepted_qa.get("status") == "PASS", "Historical baseline is not accepted Unit 12")
    require(accepted_qa.get("backend", {}).get("manifest_sha256") == BASE_MANIFEST_SHA256
            and accepted_qa.get("backend", {}).get("records_sha256") == BASE_RECORDS_SHA256,
            "Historical baseline QA anchor drifted")
    reader = manifest.get("reader_binding", {})
    require(accepted_qa.get("reader_binding") == reader,
            "Accepted historical reader receipt identity disagrees")
    aliases = []
    for kind, path in zip(("receipt", "html", "pdf"), BASE_READER_BINDINGS):
        size, sha256 = BASE_READER_BINDINGS[path]
        require(reader.get(kind + "_path") == path
                and reader.get(kind + "_sha256") == sha256,
                "Historical reader anchor drifted: " + path)
        expected = {"path": path, "bytes": size, "sha256": sha256}
        matches = [row for row in manifest["source_bindings"] if row.get("path") == path]
        require(matches == [expected], "Historical reader source alias drifted: " + path)
        require(not any(row.get("path") == path for row in manifest["files"]),
                "Historical reader alias cannot exempt native backend files")
        aliases.append(expected)
    by_id = {row["stable_id"]: row for row in records}
    artifacts = []
    reader_ids = {stable_id for group in HISTORICAL_READER_ARTIFACT_IDS.values()
                  for stable_id in group}
    require(len(HISTORICAL_ARTIFACT_BINDINGS) == 31 and len(reader_ids) == 15
            and reader_ids <= HISTORICAL_ARTIFACT_BINDINGS.keys(),
            "Historical artifact whitelist is not exact 31/15")
    for stable_id, (path, size, sha256, record_sha256) in HISTORICAL_ARTIFACT_BINDINGS.items():
        row = by_id.get(stable_id, {})
        canonical_bytes = json.dumps(row, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode("utf-8")
        require(row.get("entity_class") == "artifact" and row.get("path") == path
                and row.get("payload", {}).get("bytes") == size
                and row.get("content_sha256") == sha256
                and hashlib.sha256(canonical_bytes).hexdigest() == record_sha256,
                "Historical full-record pin drifted: " + stable_id)
        artifacts.append({
            "stable_id": stable_id, "path": path, "bytes": size, "sha256": sha256,
            "canonical_record_sha256": record_sha256,
            "classification": ("superseded_generated_reader_alias" if stable_id in reader_ids
                               else "superseded_nonreader_version_alias"),
        })
    return {
        "policy": "exact-31-accepted-historical-artifact-aliases",
        "baseline_manifest_sha256": BASE_MANIFEST_SHA256,
        "baseline_records_sha256": BASE_RECORDS_SHA256,
        "baseline_backend_qa_sha256": BASE_QA_SHA256,
        "accepted_reader_receipt": aliases[0],
        "source_aliases": aliases,
        "historical_artifacts": artifacts,
        "historical_loose_bytes_rehashed": False,
        "evidence": "hash-locked accepted native records, full canonical record pins, manifest and PASS backend QA",
        "current_reader": "independently validated through Unit 30 against current build and QA receipts",
        "current_nonreader_source_and_rights_bindings_exempted": False,
    }


def validate_baseline_binding(
    binding: dict[str, Any], historical_aliases: dict[str, dict[str, Any]]
) -> None:
    historical = historical_aliases.get(binding["path"])
    if historical is not None:
        require(binding == historical, "Historical source alias identity changed: " + binding["path"])
        return
    path = ROOT / binding["path"]
    require(path.is_file() and not path.is_symlink()
            and path.stat().st_size == int(binding["bytes"])
            and digest(path) == binding["sha256"],
            "Accepted BGK baseline binding drifted: " + binding["path"])


def validate_current_reader_outputs(build_receipt: dict[str, Any]) -> None:
    """Keep the current Unit-30 reader gate independent of historical aliases."""
    require(build_receipt.get("through_unit") == 30, "Reader build receipt is not through Unit 30")
    output_bindings = {row["path"]: row for row in build_receipt.get("outputs", [])}
    for path in (READER_HTML, READER_PDF):
        binding = output_bindings.get(rel(path))
        require(path.is_file() and not path.is_symlink() and binding
                and int(binding["bytes"]) == path.stat().st_size
                and binding["sha256"] == digest(path),
                f"Build output binding drifted: {rel(path)}")


def baseline() -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any]]:
    require(digest(BASE_MANIFEST) == BASE_MANIFEST_SHA256, "Accepted BGK Units 1--12 manifest drifted")
    require(digest(BASE_RECORDS) == BASE_RECORDS_SHA256, "Accepted BGK Units 1--12 records drifted")
    require(digest(BASE_QA) == BASE_QA_SHA256, "Accepted BGK Units 1--12 backend QA drifted")
    manifest = read_json(BASE_MANIFEST)
    records = read_jsonl(BASE_RECORDS)
    schema = read_json(BASE / "record.schema.json")
    ids = {row["stable_id"] for row in records}
    require(manifest.get("through_unit") == 12, "Accepted BGK baseline is not through Unit 12")
    require(len(records) == len(ids) == int(manifest["record_count"]), "Baseline stable-ID closure drifted")
    replay = historical_reader_replay(manifest, records, read_json(BASE_QA))
    aliases = {row["path"]: row for row in replay["source_aliases"]}
    for binding in manifest["files"]:
        validate_baseline_binding(binding, {})
    for binding in manifest["source_bindings"]:
        validate_baseline_binding(binding, aliases)
    return manifest, records, schema


def translated_topology(base_ids: set[str], classical_ids: set[str]) -> dict[str, Any]:
    heading_ids: list[str] = []
    per_unit: dict[str, Any] = {}
    for unit in UNITS:
        paths = unit_paths(unit)
        document_ids: list[str] = []
        exercises: set[int] = set()
        solutions: set[int] = set()
        for key in ("lecture", "worksheet", "solutions"):
            path = paths[key]
            require(path.is_file() and not path.is_symlink(), f"Translated source missing: {rel(path)}")
            _, body = split_frontmatter(path.read_text(encoding="utf-8"))
            ids = [match.group(3).strip() for match in HEADING_RE.finditer(body)]
            require(ids, f"No stable heading IDs: {rel(path)}")
            document_ids.extend(ids)
            for stable_id in ids:
                exercise = EXERCISE_RE.search(stable_id)
                solution = SOLUTION_RE.search(stable_id)
                if exercise and int(exercise.group("unit")) == unit:
                    exercises.add(int(exercise.group("number")))
                if solution and int(solution.group("unit")) == unit:
                    solutions.add(int(solution.group("new") or solution.group("old")))
        require(len(document_ids) == len(set(document_ids)), f"Duplicate heading ID inside Unit {unit}")
        require(
            exercises == set(range(1, EXPECTED_EXERCISES[unit] + 1)),
            f"Independent exercise-ID expectation failed for Unit {unit}",
        )
        require(
            solutions == set(EXPECTED_PUBLIC_SOLUTIONS[unit]),
            f"Independent public-solution-ID expectation failed for Unit {unit}",
        )
        heading_ids.extend(document_ids)
        per_unit[f"{unit:02d}"] = {
            "heading_ids": len(document_ids),
            "exercise_ids": len(exercises),
            "public_solution_ids": sorted(solutions),
        }
    require(len(heading_ids) == len(set(heading_ids)) == EXPECTED_NEW_HEADING_IDS,
            "Units 13--30 heading-ID count or uniqueness drifted")
    require(not (set(heading_ids) & base_ids), "Units 13--30 heading ID collides with BGK baseline")
    require(not (set(heading_ids) & classical_ids), "Units 13--30 heading ID collides with classical backend")
    return {"heading_ids": len(heading_ids), "per_unit": per_unit}


def static_check() -> dict[str, Any]:
    base_manifest, base_records, _ = baseline()
    classical_ids = {row["stable_id"] for row in read_jsonl(CLASSICAL_RECORDS)}
    missing: list[str] = []
    nonfinal: list[dict[str, Any]] = []
    unit_matrix: dict[int, dict[str, Path]] = {}
    for unit in UNITS:
        paths = unit_paths(unit)
        unit_matrix[unit] = paths
        for name, path in paths.items():
            if not path.is_file():
                missing.append(f"{unit:02d}:{name}:{rel(path)}")

    # Inventory the entire finite matrix before interpreting available files.
    # This makes expected incompleteness one complete report instead of a
    # misleading first-missing-file exception.
    translated_missing = [
        path for paths in unit_matrix.values()
        for name, path in paths.items() if name in {"lecture", "worksheet", "solutions"}
        and not path.is_file()
    ]
    topology = None if translated_missing else translated_topology(
        {row["stable_id"] for row in base_records}, classical_ids
    )

    for unit, paths in unit_matrix.items():
        if paths["manifest"].is_file():
            manifest = read_json(paths["manifest"])
            if manifest.get("unit_number") != unit:
                nonfinal.append({"unit": unit, "kind": "authority_manifest",
                                 "unit_number": manifest.get("unit_number")})
        if paths["exercise_map"].is_file():
            exercise_map = read_json(paths["exercise_map"])
            solutions = sorted(
                int(row["exercise_number"]) for row in exercise_map.get("entries", [])
                if row.get("has_public_solution")
            )
            if (exercise_map.get("unit") != unit
                    or int(exercise_map.get("exercise_count", -1)) != EXPECTED_EXERCISES[unit]
                    or tuple(solutions) != EXPECTED_PUBLIC_SOLUTIONS[unit]
                    or int(exercise_map.get("solution_count", -1)) != len(solutions)):
                nonfinal.append({"unit": unit, "kind": "exercise_map",
                                 "exercise_count": exercise_map.get("exercise_count"),
                                 "public_solution_numbers": solutions})
        if paths["translation_qa"].is_file():
            qa = read_json(paths["translation_qa"])
            if (qa.get("unit") != unit or qa.get("status") != "PASS"
                    or qa.get("model_provenance") != MODEL_PROVENANCE):
                nonfinal.append({
                    "unit": unit, "kind": "translation_qa",
                    "status": qa.get("status"),
                    "top_level_model_provenance": qa.get("model_provenance"),
                })
        if paths["authority_qa"].is_file():
            qa = read_json(paths["authority_qa"])
            if qa.get("unit") != unit or not str(qa.get("status", "")).startswith("PASS"):
                nonfinal.append({"unit": unit, "kind": "authority_qa",
                                 "status": qa.get("status"), "qa_unit": qa.get("unit")})
        if paths["closure"].is_file():
            closure = read_json(paths["closure"])
            assets = closure.get("assets", [])
            if (closure.get("unit") != unit
                    or int(closure.get("reader_media_positions", -1)) != EXPECTED_READER_MEDIA[unit]
                    or int(closure.get("unique_local_assets", -1)) != len(assets)
                    or len(assets) != EXPECTED_READER_MEDIA[unit]):
                nonfinal.append({"unit": unit, "kind": "asset_closure",
                                 "reader_media_positions": closure.get("reader_media_positions"),
                                 "unique_local_assets": closure.get("unique_local_assets"),
                                 "asset_rows": len(assets)})
    cumulative = [FRONTMATTER, ADDITIVE_TERMINOLOGY, ADDITIVE_CORRECTIONS, READER_GLOSSARY,
                  READER_QA, RESPONSIVE_QA, VISUAL_QA,
                  READER_RECEIPT, READER_HTML, READER_PDF]
    missing.extend(f"cumulative:{rel(path)}" for path in cumulative if not path.is_file())
    intake = {
        kind: read_additive_csv(path, kind) if path.is_file() else None
        for kind, path in (("terminology", ADDITIVE_TERMINOLOGY),
                           ("corrections", ADDITIVE_CORRECTIONS))
    }
    for name, path in (("reader", READER_QA), ("responsive", RESPONSIVE_QA),
                       ("visual", VISUAL_QA)):
        if path.is_file():
            qa = read_json(path)
            if (qa.get("through_unit") != 30 or qa.get("status") != "PASS"
                    or qa.get("model_provenance") != MODEL_PROVENANCE):
                nonfinal.append({"kind": f"cumulative_{name}_qa",
                                 "through_unit": qa.get("through_unit"),
                                 "status": qa.get("status"),
                                 "model_provenance": qa.get("model_provenance")})
    if READER_RECEIPT.is_file():
        receipt = read_json(READER_RECEIPT)
        outputs = {row.get("path"): row for row in receipt.get("outputs", [])}
        output_bindings_ok = True
        for path in (READER_HTML, READER_PDF):
            binding = outputs.get(rel(path))
            if (not path.is_file() or binding is None
                    or int(binding.get("bytes", -1)) != path.stat().st_size
                    or binding.get("sha256") != digest(path)):
                output_bindings_ok = False
        if receipt.get("through_unit") != 30 or not output_bindings_ok:
            nonfinal.append({"kind": "cumulative_reader_build_receipt",
                             "through_unit": receipt.get("through_unit"),
                             "output_bindings_exact": output_bindings_ok})
    if FRONTMATTER.is_file():
        _, body = split_frontmatter(FRONTMATTER.read_text(encoding="utf-8"))
        front_ids = [match.group(3).strip() for match in HEADING_RE.finditer(body)]
        if not front_ids or any(not stable_id.startswith("br-bgk-2019-front-01-30")
                                for stable_id in front_ids):
            nonfinal.append({"kind": "cumulative_frontmatter",
                             "heading_ids": front_ids})
    ready = not missing and not nonfinal and topology is not None
    return {
        "schema": "ag-bridge-bgk-units-01-30-export-static-check-v1",
        "status": "READY" if ready else "INCOMPLETE",
        "static_validation_status": "PASS",
        "ready_for_export": ready,
        "baseline": {
            "through_unit": base_manifest["through_unit"],
            "record_count": len(base_records),
            "manifest_sha256": digest(BASE_MANIFEST),
            "records_sha256": digest(BASE_RECORDS),
            "historical_reader_replay": historical_reader_replay(
                base_manifest, base_records, read_json(BASE_QA)),
        },
        "independent_expectations": {
            "new_heading_ids": topology["heading_ids"] if topology else None,
            "new_exercises": sum(EXPECTED_EXERCISES.values()),
            "new_public_solutions": sum(len(value) for value in EXPECTED_PUBLIC_SOLUTIONS.values()),
            "reader_media_positions": sum(EXPECTED_READER_MEDIA.values()),
            "new_term_records": len(intake["terminology"]) if intake["terminology"] else None,
            "new_correction_records": len(intake["corrections"]) if intake["corrections"] else None,
            "additive_intake_per_unit": {
                f"{unit:02d}": {
                    kind: sum(row["unit"] == str(unit) for row in rows) if rows else None
                    for kind, rows in intake.items()
                } for unit in UNITS
            },
            "per_unit": topology["per_unit"] if topology else {},
            "bgk_baseline_collisions": 0,
            "classical_collisions": 0,
        },
        "missing_inputs": missing,
        "nonfinal_qas": nonfinal,
        "writes_performed": False,
        "credentials_recorded": False,
    }


def record_schema(base_schema: dict[str, Any]) -> dict[str, Any]:
    schema = json.loads(json.dumps(base_schema))
    schema["$id"] = "https://example.invalid/algebraic-geometry-bridge/bgk-backend-record-units-01-30-v1.schema.json"
    schema["title"] = "BGK Indonesian native backend record through Units 1--30"
    return schema


def build_export() -> tuple[dict[str, bytes], dict[str, Any]]:
    base_manifest, base_records, base_schema = baseline()
    entity_classes = list(base_schema["properties"]["entity_class"]["enum"])
    base_ids = {row["stable_id"] for row in base_records}
    classical_ids = {row["stable_id"] for row in read_jsonl(CLASSICAL_RECORDS)}
    translated_topology(base_ids, classical_ids)

    # The accepted central ledgers remain immutable. New per-unit admissions
    # live only in explicit additive sidecars, never guessed from prose.
    baseline_bindings = {row["path"]: row for row in base_manifest["source_bindings"]}
    for ledger in (TERMINOLOGY, CORRECTIONS):
        binding = baseline_bindings.get(rel(ledger))
        require(binding is not None, f"Baseline does not bind {rel(ledger)}")
        require(fact(ledger)["sha256"] == binding["sha256"],
                f"Central ledger changed after Unit 12; explicit Unit 13--30 mapping required: {rel(ledger)}")

    terminology_rows = read_additive_csv(ADDITIVE_TERMINOLOGY, "terminology")
    correction_rows = read_additive_csv(ADDITIVE_CORRECTIONS, "corrections")
    terms_by_unit = {unit: [row for row in terminology_rows if row["unit"] == str(unit)]
                     for unit in UNITS}
    corrections_by_unit = {unit: [row for row in correction_rows if row["unit"] == str(unit)]
                           for unit in UNITS}
    cumulative_inputs = [FRONTMATTER, READER_GLOSSARY, READER_QA, RESPONSIVE_QA, VISUAL_QA,
                         READER_RECEIPT, READER_HTML, READER_PDF]
    for path in cumulative_inputs:
        require(path.is_file() and not path.is_symlink(), f"Required cumulative input absent: {rel(path)}")
    reader_qa, responsive_qa, visual_qa, build_receipt = map(
        read_json, (READER_QA, RESPONSIVE_QA, VISUAL_QA, READER_RECEIPT)
    )
    for name, qa in (("reader", reader_qa), ("responsive", responsive_qa), ("visual", visual_qa)):
        require(qa.get("through_unit") == 30 and qa.get("status") == "PASS",
                f"Cumulative {name} QA is not exact PASS through Unit 30")
        require(qa.get("model_provenance") == MODEL_PROVENANCE,
                f"Cumulative {name} QA lacks exact model provenance")
    validate_current_reader_outputs(build_receipt)

    timestamp = read_json(unit_paths(30)["manifest"])["frozen_utc"]
    new_records: list[dict[str, Any]] = []
    new_ids: set[str] = set()

    def make_record(
        entity_class: str, stable_id: str, *, source_local_id: str | None = None,
        parent_id: str | None = None, order: int | None = None, path: str | None = None,
        resource_id: str | None = None, edition_id: str | None = None,
        source_locator: str | None = None, content_sha256: str | None = None,
        language: str = "und", translation_state: str = "source_frozen",
        provenance: dict[str, Any] | None = None, concept_ids: list[str] | None = None,
        prerequisite_ids: list[str] | None = None, rights_id: str | None = None,
        status: str = "active", supersedes: str | None = None,
        payload: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        require(entity_class in entity_classes, f"Unsupported entity class: {entity_class}")
        actual_provenance = dict(provenance or {})
        actual_provenance["model"] = MODEL_PROVENANCE
        return {
            "schema": SCHEMA_NAME, "schema_version": SCHEMA_VERSION,
            "entity_class": entity_class, "stable_id": stable_id,
            "source_local_id": source_local_id, "parent_id": parent_id, "order": order,
            "path": path, "resource_id": resource_id, "edition_id": edition_id,
            "source_locator": source_locator, "content_sha256": content_sha256,
            "language": language, "translation_state": translation_state,
            "provenance": actual_provenance, "concept_ids": sorted(set(concept_ids or [])),
            "prerequisite_ids": sorted(set(prerequisite_ids or [])), "rights_id": rights_id,
            "status": status, "timestamp": timestamp, "responsible_workflow": WORKFLOW_ID,
            "supersedes": supersedes, "payload": payload or {},
        }

    def add(row: dict[str, Any]) -> None:
        stable_id = row["stable_id"]
        require(stable_id not in base_ids, f"Attempt to mutate accepted ID: {stable_id}")
        require(stable_id not in new_ids, f"Duplicate new stable ID: {stable_id}")
        new_ids.add(stable_id)
        new_records.append(row)

    add(make_record(
        "edition", DERIVATIVE_EDITION, source_local_id="bgk-id-units-01-30",
        parent_id=LOCAL_RESOURCE, resource_id=LOCAL_RESOURCE, edition_id=DERIVATIVE_EDITION,
        source_locator=rel(FRONTMATTER), content_sha256=digest(FRONTMATTER), language="id-ID",
        translation_state="structurally_verified", rights_id=EDITORIAL_RIGHTS,
        payload={"through_unit": 30, "status": "complete source translation and verified cumulative reader/backend",
                 "units_01_12_records_immutable": True, "model_provenance": MODEL_PROVENANCE},
    ))

    concept_keywords = {
        row["stable_id"]: list(row.get("payload", {}).get("matching_keywords", []))
        for row in base_records if row["entity_class"] == "concept"
    }
    concept_order = 1 + sum(row["entity_class"] == "concept" for row in base_records)
    term_order = 1 + sum(row["entity_class"] == "term" for row in base_records)

    def concepts_for(text: str) -> list[str]:
        lowered = text.casefold()
        return sorted(cid for cid, words in concept_keywords.items()
                      if any(word and str(word).casefold() in lowered for word in words))

    artifact_paths: list[Path] = []
    unit_summaries: dict[str, Any] = {}
    all_new_exercises: set[str] = set()
    all_new_solutions: set[str] = set()
    all_new_terms: set[str] = set()
    all_new_corrections: set[str] = set()

    # Register all explicit terms before source segments so matching does not
    # depend on whether a later unit introduced an already-used expression.
    for row in terminology_rows:
        unit = int(row["unit"])
        term_id = row["term_id"]
        concept_id = f"concept.br-bgk-2019.{term_id.casefold()}"
        keywords = [row["source_term"], row["preferred_target"]]
        add(make_record(
            "concept", concept_id, source_local_id=term_id, parent_id=COURSE_ID,
            order=concept_order, resource_id=LOCAL_RESOURCE, edition_id=DERIVATIVE_EDITION,
            source_locator=f"{rel(ADDITIVE_TERMINOLOGY)}#{term_id}",
            content_sha256=text_digest(canonical(row)), language="id-ID",
            translation_state="structurally_verified", rights_id=EDITORIAL_RIGHTS,
            provenance={"source_file_sha256": digest(ADDITIVE_TERMINOLOGY)},
            payload={"preferred_label": row["preferred_target"], "source_label": row["source_term"],
                     "matching_keywords": keywords, "introduced_in_unit": unit,
                     "accepted_variants": row["accepted_variants"]},
        ))
        concept_keywords[concept_id] = keywords
        concept_order += 1
        stable_term_id = f"term.br-bgk-2019.{term_id.casefold()}"
        add(make_record(
            "term", stable_term_id, source_local_id=term_id, parent_id=concept_id,
            order=term_order, resource_id=LOCAL_RESOURCE, edition_id=DERIVATIVE_EDITION,
            source_locator=f"{rel(ADDITIVE_TERMINOLOGY)}#{term_id}",
            content_sha256=text_digest(canonical(row)), language="id-ID",
            translation_state="structurally_verified", rights_id=EDITORIAL_RIGHTS,
            provenance={"source_file_sha256": digest(ADDITIVE_TERMINOLOGY)}, concept_ids=[concept_id],
            payload={**row, "ledger_row": row, "scope": f"BGK Unit {unit}", "unit": unit,
                     "rejected_or_variant": row["accepted_variants"]},
        ))
        all_new_terms.add(stable_term_id)
        term_order += 1

    for unit in UNITS:
        unit_s = f"{unit:02d}"
        paths = unit_paths(unit)
        for path in paths.values():
            require(path.is_file() and not path.is_symlink(), f"Required Unit {unit} input absent: {rel(path)}")
        manifest = read_json(paths["manifest"])
        exercise_map = read_json(paths["exercise_map"])
        authority_qa = read_json(paths["authority_qa"])
        translation_qa = read_json(paths["translation_qa"])
        closure = read_json(paths["closure"])
        require(manifest.get("unit_number") == unit and exercise_map.get("unit") == unit,
                f"Unit {unit} authority/map identity drifted")
        require(str(authority_qa.get("status", "")).startswith("PASS"),
                f"Unit {unit} authority QA is not PASS")
        require(translation_qa.get("status") == "PASS", f"Unit {unit} translation QA is not exact PASS")
        require(translation_qa.get("model_provenance") == MODEL_PROVENANCE,
                f"Unit {unit} translation QA lacks exact top-level model provenance")
        require(int(exercise_map.get("exercise_count", -1)) == EXPECTED_EXERCISES[unit],
                f"Unit {unit} frozen exercise count contradicts independent expectation")
        solution_numbers = tuple(sorted(
            int(row["exercise_number"]) for row in exercise_map.get("entries", [])
            if row.get("has_public_solution")
        ))
        require(solution_numbers == EXPECTED_PUBLIC_SOLUTIONS[unit]
                and int(exercise_map.get("solution_count", -1)) == len(solution_numbers),
                f"Unit {unit} frozen public-solution set contradicts independent expectation")
        require(closure.get("unit") == unit,
                f"Unit {unit} media closure identity drifted")
        assets = list(closure.get("assets", []))
        require(int(closure.get("reader_media_positions", -1)) == EXPECTED_READER_MEDIA[unit],
                f"Unit {unit} reader-media count contradicts independent expectation")
        require(int(closure.get("unique_local_assets", -1)) == len(assets),
                f"Unit {unit} local-asset closure drifted")

        # Revalidate the terminal authority inventory and closure bindings.
        for binding in manifest.get("files", []):
            path = paths["manifest"].parent / binding["file"]
            require(path.is_file() and path.stat().st_size == int(binding["bytes"])
                    and digest(path) == binding["sha256"],
                    f"Unit {unit} authority inventory drifted: {binding['file']}")
        for key, path_key, bytes_key, sha_key in (
            ("authority_manifest", "path", "bytes", "sha256"),
        ):
            binding = closure.get(key, {})
            require(binding.get(path_key) == rel(paths["manifest"])
                    and int(binding.get(bytes_key, -1)) == paths["manifest"].stat().st_size
                    and binding.get(sha_key) == digest(paths["manifest"]),
                    f"Unit {unit} closure does not bind terminal manifest")
        for prefix, path in (("rights", paths["rights"]), ("metadata", paths["commons"]),
                             ("reader_credits", paths["credits"])):
            require(closure.get(f"{prefix}_file") == rel(path)
                    and int(closure.get(f"{prefix}_bytes", -1)) == path.stat().st_size
                    and closure.get(f"{prefix}_sha256") == digest(path),
                    f"Unit {unit} closure binding drifted: {prefix}")
        pdf_witnesses = {row.get("local_path"): row for row in closure.get("official_pdf_component_rights", [])}
        for path in (paths["lecture_pdf"], paths["worksheet_pdf"]):
            row = pdf_witnesses.get(rel(path))
            require(row and int(row["local_bytes"]) == path.stat().st_size
                    and row["local_sha256"] == digest(path),
                    f"Unit {unit} official PDF witness drifted: {rel(path)}")

        frozen_date = str(manifest["frozen_utc"])[:10]
        source_edition = f"edition.brenner.bgk.unit-{unit_s}.freeze-{frozen_date}"
        pdf_resource = f"resource.brenner.bgk.unit-{unit_s}.official-pdf-witnesses"
        pdf_rights = f"rights.bgk.u{unit_s}.official-pdf.component-notices-3.0-and-4.0"
        add(make_record(
            "resource", pdf_resource, source_local_id=f"bgk-unit-{unit_s}-official-pdf-witnesses",
            parent_id=COURSE_ID, source_locator=rel(paths["closure"]),
            content_sha256=digest(paths["closure"]), language="de", rights_id=pdf_rights,
            payload={"unit": unit, "role": "visual and numbering witnesses, not semantic authority",
                     "reader_media_positions": EXPECTED_READER_MEDIA[unit],
                     "blanket_relicensing_claim": False},
        ))
        add(make_record(
            "edition", source_edition, source_local_id=f"bgk-unit-{unit_s}-authority-freeze",
            parent_id=SOURCE_RESOURCE, resource_id=SOURCE_RESOURCE, edition_id=source_edition,
            source_locator=rel(paths["manifest"]), content_sha256=digest(paths["manifest"]),
            language="de", rights_id=SEMANTIC_RIGHTS,
            payload={"unit": unit, "frozen_utc": manifest["frozen_utc"],
                     "lecture_pageid": manifest["lecture"]["pageid"],
                     "lecture_revid": manifest["lecture"]["revid"],
                     "worksheet_pageid": manifest["worksheet"]["pageid"],
                     "worksheet_revid": manifest["worksheet"]["revid"],
                     "exercise_count": EXPECTED_EXERCISES[unit],
                     "public_solution_count": len(solution_numbers)},
        ))
        add(make_record(
            "rights", pdf_rights, parent_id=pdf_resource, resource_id=pdf_resource,
            edition_id=DERIVATIVE_EDITION, source_locator=rel(paths["authority_qa"]),
            content_sha256=digest(paths["authority_qa"]), rights_id=pdf_rights,
            payload={"title": f"Unit {unit} official PDF witness notices",
                     "license": "component notices preserved", "blanket_relicensing_claim": False,
                     "witnesses": closure.get("official_pdf_component_rights", [])},
        ))

        with paths["rights"].open("r", encoding="utf-8-sig", newline="") as stream:
            rights_rows = list(csv.DictReader(stream))
        asset_by_path: dict[str, str] = {}
        asset_rights: dict[str, str] = {}
        closure_by_id = {row["asset_id"]: row for row in assets}
        require({row.get("asset_id") for row in rights_rows} == set(closure_by_id),
                f"Unit {unit} rights/asset ID set drifted")
        for order, row in enumerate(rights_rows, start=1):
            asset_id = row["asset_id"]
            closure_row = closure_by_id[asset_id]
            local_path = ROOT / row["local_path"]
            require(local_path.is_file() and local_path.stat().st_size == int(row["local_bytes"])
                    and digest(local_path) == row["local_sha256"],
                    f"Unit {unit} asset bytes drifted: {asset_id}")
            require(closure_row["local_path"] == row["local_path"]
                    and closure_row["local_sha256"] == row["local_sha256"],
                    f"Unit {unit} asset closure/rights mismatch: {asset_id}")
            license_slug = re.sub(r"[^a-z0-9]+", "-", row["license_short"].casefold()).strip("-")
            rights_id = f"rights.bgk.u{unit_s}.media-{order:03d}.{license_slug}"
            asset_rights[asset_id] = rights_id
            asset_by_path[row["local_path"].replace("\\", "/")] = asset_id
            add(make_record(
                "rights", rights_id, source_local_id=row.get("resource_title"),
                parent_id=SOURCE_RESOURCE, order=order, resource_id=SOURCE_RESOURCE,
                edition_id=source_edition, source_locator=f"{rel(paths['rights'])}#{asset_id}",
                content_sha256=text_digest(canonical(row)), rights_id=rights_id,
                payload={"title": row.get("resource_title"), "license": row.get("license_short"),
                         "usage_terms": row.get("usage_terms"), "license_url": row.get("license_url") or None,
                         "attribution_required": boolish(row.get("attribution_required")),
                         "source_inline_label": row.get("source_course_inline_license_label"),
                         "license_discrepancy_present": boolish(row.get("license_discrepancy_present")),
                         "license_discrepancy_note": row.get("license_discrepancy_note"),
                         "ledger_row": row},
            ))
            add(make_record(
                "asset", asset_id, source_local_id=row.get("resource_title"),
                parent_id=SOURCE_RESOURCE, order=order, path=row["local_path"],
                resource_id=SOURCE_RESOURCE, edition_id=source_edition,
                source_locator=row.get("description_url"), content_sha256=row["local_sha256"],
                rights_id=rights_id,
                payload={"bytes": int(row["local_bytes"]), "mime": row.get("mime"),
                         "width": int(row["local_width"]), "height": int(row["local_height"]),
                         "frame_count": int(row.get("frame_count") or 1),
                         "caption": row.get("reader_caption_id"), "alt": row.get("reader_alt_id"),
                         "repository": row.get("repository"), "license": row.get("license_short"),
                         "html_animation_preserved": boolish(row.get("html_animation_preserved"))},
            ))
            artifact_paths.append(local_path)

        exercise_by_number = {int(row["exercise_number"]): row for row in exercise_map["entries"]}
        unit_heading_ids: list[str] = []
        image_bindings: list[tuple[str, str]] = []
        for document_order, key in enumerate(("lecture", "worksheet", "solutions"), start=1):
            path = paths[key]
            _, body = split_frontmatter(path.read_text(encoding="utf-8"))
            headings = list(HEADING_RE.finditer(body))
            stack: list[tuple[int, str]] = []
            for heading_index, match in enumerate(headings):
                level, title, stable_id = len(match.group(1)), match.group(2).strip(), match.group(3).strip()
                require(stable_id.startswith("br-bgk-2019-") and stable_id not in base_ids
                        and stable_id not in new_ids, f"Duplicate/invalid heading ID: {stable_id}")
                unit_heading_ids.append(stable_id)
                while stack and stack[-1][0] >= level:
                    stack.pop()
                parent_id = stack[-1][1] if stack else DERIVATIVE_EDITION
                stack.append((level, stable_id))
                end = headings[heading_index + 1].start() if heading_index + 1 < len(headings) else len(body)
                local_markdown = body[match.start():end].strip() + "\n"
                local_body = body[match.end():end].strip()
                exercise_match = EXERCISE_RE.search(stable_id)
                solution_match = SOLUTION_RE.search(stable_id)
                solution_number: int | None = None
                if solution_match:
                    entity_class = "solution"
                    solution_number = int(solution_match.group("new") or solution_match.group("old"))
                    parent_id = f"br-bgk-2019-w{unit_s}-ex{solution_number:02d}"
                elif exercise_match:
                    entity_class = "exercise"
                else:
                    entity_class = "unit"
                payload: dict[str, Any] = {
                    "title": title, "heading_level": level, "document_order": document_order,
                    "unit": unit, "local_markdown": local_markdown,
                }
                if exercise_match:
                    number = int(exercise_match.group("number"))
                    mapped = exercise_by_number.get(number)
                    require(mapped is not None, f"Unit {unit} exercise has no frozen map row: {number}")
                    payload.update({"exercise_number": number,
                                    "source_title": mapped["exercise_title"],
                                    "has_public_solution": bool(mapped["has_public_solution"]),
                                    "prompt_markdown": local_body})
                    all_new_exercises.add(stable_id)
                if solution_number is not None:
                    mapped = exercise_by_number.get(solution_number)
                    require(mapped and mapped["has_public_solution"],
                            f"Unit {unit} translated solution is not frozen public source content")
                    payload.update({"exercise_number": solution_number, "exercise_id": parent_id,
                                    "source_solution_title": mapped["solution_title"],
                                    "source_pageid": mapped["pageid"], "source_revid": mapped["revid"],
                                    "source_mediawiki_sha1": mapped["mediawiki_sha1"],
                                    "solution_markdown": local_body, "invented": False})
                    all_new_solutions.add(stable_id)
                add(make_record(
                    entity_class, stable_id, source_local_id=stable_id, parent_id=parent_id,
                    order=heading_index + 1, path=rel(path), resource_id=LOCAL_RESOURCE,
                    edition_id=DERIVATIVE_EDITION, source_locator=f"{rel(path)}#{stable_id}",
                    content_sha256=text_digest(local_markdown), language="id-ID",
                    translation_state="structurally_verified",
                    provenance={"source_edition": source_edition, "source_file_sha256": digest(path)},
                    concept_ids=concepts_for(title + "\n" + local_body), rights_id=EDITORIAL_RIGHTS,
                    payload=payload,
                ))
                blocks = [block.strip() for block in re.split(r"\n[ \t]*\n", local_body) if block.strip()]
                for block_index, block in enumerate(blocks, start=1):
                    block_id = f"{stable_id}-b{block_index:03d}"
                    kind = block_kind(block)
                    block_payload: dict[str, Any] = {
                        "kind": kind, "markdown": block + "\n",
                        "display_math_count": len(re.findall(r"\$\$(.*?)\$\$", block, re.DOTALL)),
                        "inline_math_delimiter_count": len(re.findall(r"(?<!\$)\$(?!\$)", block)),
                    }
                    if kind == "image":
                        matches = [(asset_path, asset_id) for asset_path, asset_id in asset_by_path.items()
                                   if asset_path in block.replace("\\", "/")]
                        require(len(matches) == 1, f"Unbound/ambiguous reader image: {block_id}")
                        asset_id = matches[0][1]
                        block_payload["asset_ids"] = [asset_id]
                        image_bindings.append((block_id, asset_id))
                    add(make_record(
                        "segment", block_id, source_local_id=block_id, parent_id=stable_id,
                        order=block_index, path=rel(path), resource_id=LOCAL_RESOURCE,
                        edition_id=DERIVATIVE_EDITION,
                        source_locator=f"{rel(path)}#{stable_id}:block-{block_index}",
                        content_sha256=text_digest(block + "\n"), language="id-ID",
                        translation_state="structurally_verified",
                        provenance={"source_file_sha256": digest(path)}, concept_ids=concepts_for(block),
                        rights_id=EDITORIAL_RIGHTS, payload=block_payload,
                    ))

        require(len(unit_heading_ids) == len(set(unit_heading_ids)), f"Unit {unit} heading-ID collision")
        expected_exercise_ids = {
            f"br-bgk-2019-w{unit_s}-ex{number:02d}"
            for number in range(1, EXPECTED_EXERCISES[unit] + 1)
        }
        observed_exercise_ids = {
            stable_id for stable_id in all_new_exercises if f"-w{unit_s}-" in stable_id
        }
        require(observed_exercise_ids == expected_exercise_ids,
                f"Unit {unit} exercise closure is not the exact independent set")
        observed_solution_ids = {stable_id for stable_id in all_new_solutions if f"-w{unit_s}-" in stable_id}
        expected_solution_ids = {
            stable_id for stable_id in unit_heading_ids
            if (match := SOLUTION_RE.search(stable_id))
            and int(match.group("unit")) == unit
            and int(match.group("new") or match.group("old")) in EXPECTED_PUBLIC_SOLUTIONS[unit]
        }
        require(observed_solution_ids == expected_solution_ids
                and len(observed_solution_ids) == len(EXPECTED_PUBLIC_SOLUTIONS[unit]),
                f"Unit {unit} public-solution ID closure is not the exact independent set")
        require(len(image_bindings) == EXPECTED_READER_MEDIA[unit]
                and {asset_id for _, asset_id in image_bindings} == set(closure_by_id),
                f"Unit {unit} reader-image/asset closure drifted")
        unit_top = next(stable_id for stable_id in unit_heading_ids
                        if stable_id.startswith(f"br-bgk-2019-l{unit_s}"))
        for order, row in enumerate(corrections_by_unit[unit], start=1):
            correction_id = row["correction_id"]
            stable_correction_id = (
                f"correction.br-bgk-2019.u{unit_s}.{int(correction_id.rsplit('-', 1)[1]):04d}"
            )
            add(make_record(
                "correction", stable_correction_id, source_local_id=correction_id,
                parent_id=unit_top, order=order, resource_id=LOCAL_RESOURCE,
                edition_id=DERIVATIVE_EDITION,
                source_locator=f"{rel(ADDITIVE_CORRECTIONS)}#{correction_id}",
                content_sha256=text_digest(canonical(row)), language="id-ID",
                translation_state="structurally_verified", rights_id=EDITORIAL_RIGHTS,
                provenance={"source_file_sha256": digest(ADDITIVE_CORRECTIONS)},
                payload={**row, "ledger_row": row, "source_issue": row["authority_observation"],
                         "adopted_reading": row["target_action"], "unit": unit,
                         "disclosed_in_reader": True, "silent_change": False},
            ))
            all_new_corrections.add(stable_correction_id)
        for order, (segment_id, asset_id) in enumerate(image_bindings, start=1):
            add(make_record(
                "relation", f"relation.br-bgk-2019.u{unit_s}.depicts-{order:03d}",
                parent_id=COURSE_ID, order=order, resource_id=LOCAL_RESOURCE,
                edition_id=DERIVATIVE_EDITION,
                content_sha256=text_digest(segment_id + "\ndepicts_with\n" + asset_id),
                translation_state="structurally_verified", rights_id=EDITORIAL_RIGHTS,
                payload={"subject_id": segment_id, "predicate": "depicts_with", "object_id": asset_id},
            ))

        unit_artifacts = unique_paths([paths[name] for name in (
            "lecture", "worksheet", "solutions", "manifest", "exercise_map", "candidates",
            "pdf_api", "authority_freeze", "authority_qa", "translation_qa", "rights",
            "closure", "commons", "credits", "lecture_pdf", "worksheet_pdf",
        )] + [ROOT / row["local_path"] for row in assets])
        for order, path in enumerate(unit_artifacts, start=1):
            if path in (paths["lecture_pdf"], paths["worksheet_pdf"]):
                rights_id, language, state = pdf_rights, "de", "source_frozen"
            elif rel(path) in asset_by_path:
                rights_id, language, state = asset_rights[asset_by_path[rel(path)]], "und", "source_frozen"
            elif path in (paths["lecture"], paths["worksheet"], paths["solutions"], paths["credits"],
                           paths["translation_qa"]):
                rights_id, language, state = EDITORIAL_RIGHTS, "id-ID", "structurally_verified"
            else:
                rights_id, language, state = SEMANTIC_RIGHTS, "und", "source_frozen"
            add(make_record(
                "artifact", f"artifact.br-bgk-2019.u{unit_s}.{order:03d}",
                source_local_id=path.name, parent_id=DERIVATIVE_EDITION, order=order,
                path=rel(path), resource_id=LOCAL_RESOURCE, edition_id=DERIVATIVE_EDITION,
                source_locator=rel(path), content_sha256=digest(path), language=language,
                translation_state=state, rights_id=rights_id,
                payload={"bytes": path.stat().st_size, "media_type": media_type(path), "unit": unit},
            ))
            artifact_paths.append(path)
        for order, (suffix, path, payload) in enumerate((
            ("authority-closure", paths["authority_qa"], {"status": authority_qa["status"]}),
            ("translation-closure", paths["translation_qa"],
             {"status": "PASS", "model_provenance": MODEL_PROVENANCE}),
            ("media-closure", paths["closure"],
             {"reader_media_positions": EXPECTED_READER_MEDIA[unit],
              "unique_local_assets": len(assets)}),
        ), start=1):
            add(make_record(
                "qa_event", f"qa.br-bgk-2019.u{unit_s}.{suffix}", source_local_id=path.stem,
                parent_id=DERIVATIVE_EDITION, order=order, path=rel(path),
                resource_id=LOCAL_RESOURCE, edition_id=DERIVATIVE_EDITION,
                source_locator=rel(path), content_sha256=digest(path),
                language="id-ID" if suffix != "authority-closure" else "und",
                translation_state="structurally_verified", rights_id=EDITORIAL_RIGHTS,
                payload=payload,
            ))
        unit_summaries[unit_s] = {
            "exercise_count": EXPECTED_EXERCISES[unit],
            "public_solution_numbers": list(solution_numbers),
            "heading_id_count": len(unit_heading_ids), "term_count": len(terms_by_unit[unit]),
            "correction_count": len(corrections_by_unit[unit]),
            "terminology_ids": [row["term_id"] for row in terms_by_unit[unit]],
            "correction_ids": [row["correction_id"] for row in corrections_by_unit[unit]],
            "reader_media_positions": EXPECTED_READER_MEDIA[unit], "local_asset_count": len(assets),
            "authority_manifest_sha256": digest(paths["manifest"]),
            "translation_qa_sha256": digest(paths["translation_qa"]),
        }

    # Fresh cumulative front matter must not reuse an earlier boundary ID.
    _, front_body = split_frontmatter(FRONTMATTER.read_text(encoding="utf-8"))
    front_headings = list(HEADING_RE.finditer(front_body))
    require(front_headings, "Unit-30 front matter has no stable headings")
    for index, match in enumerate(front_headings):
        level, title, stable_id = len(match.group(1)), match.group(2).strip(), match.group(3).strip()
        require(stable_id.startswith("br-bgk-2019-front-01-30") and stable_id not in base_ids,
                f"Unit-30 front matter must use a fresh boundary ID: {stable_id}")
        end = front_headings[index + 1].start() if index + 1 < len(front_headings) else len(front_body)
        local_markdown = front_body[match.start():end].strip() + "\n"
        local_body = front_body[match.end():end].strip()
        add(make_record(
            "unit", stable_id, source_local_id=stable_id, parent_id=DERIVATIVE_EDITION,
            order=index + 1, path=rel(FRONTMATTER), resource_id=LOCAL_RESOURCE,
            edition_id=DERIVATIVE_EDITION, source_locator=f"{rel(FRONTMATTER)}#{stable_id}",
            content_sha256=text_digest(local_markdown), language="id-ID",
            translation_state="structurally_verified",
            provenance={"source_file_sha256": digest(FRONTMATTER)},
            concept_ids=concepts_for(local_body), rights_id=EDITORIAL_RIGHTS,
            payload={"title": title, "heading_level": level, "document_order": 0,
                     "local_markdown": local_markdown},
        ))
        blocks = [block.strip() for block in re.split(r"\n[ \t]*\n", local_body) if block.strip()]
        for block_index, block in enumerate(blocks, start=1):
            block_id = f"{stable_id}-b{block_index:03d}"
            add(make_record(
                "segment", block_id, source_local_id=block_id, parent_id=stable_id,
                order=block_index, path=rel(FRONTMATTER), resource_id=LOCAL_RESOURCE,
                edition_id=DERIVATIVE_EDITION,
                source_locator=f"{rel(FRONTMATTER)}#{stable_id}:block-{block_index}",
                content_sha256=text_digest(block + "\n"), language="id-ID",
                translation_state="structurally_verified",
                provenance={"source_file_sha256": digest(FRONTMATTER)},
                concept_ids=concepts_for(block), rights_id=EDITORIAL_RIGHTS,
                payload={"kind": block_kind(block), "markdown": block + "\n"},
            ))

    cumulative_artifacts = [FRONTMATTER, TERMINOLOGY, CORRECTIONS, READER_QA,
                            RESPONSIVE_QA, VISUAL_QA, READER_RECEIPT, READER_HTML, READER_PDF]
    # Append rather than renumber the established cumulative artifact slots.
    cumulative_artifacts.extend([ADDITIVE_TERMINOLOGY, ADDITIVE_CORRECTIONS, READER_GLOSSARY])
    for order, path in enumerate(cumulative_artifacts, start=1):
        add(make_record(
            "artifact", f"artifact.br-bgk-2019.u30.cumulative-{order:03d}",
            source_local_id=path.name, parent_id=DERIVATIVE_EDITION, order=order,
            path=rel(path), resource_id=LOCAL_RESOURCE, edition_id=DERIVATIVE_EDITION,
            source_locator=rel(path), content_sha256=digest(path), language="id-ID",
            translation_state="structurally_verified", rights_id=EDITORIAL_RIGHTS,
            payload={"bytes": path.stat().st_size, "media_type": media_type(path), "through_unit": 30},
        ))
        artifact_paths.append(path)
    for order, (suffix, path, payload) in enumerate((
        ("reader-closure", READER_QA, {"status": "PASS", "through_unit": 30,
                                       "html_sha256": digest(READER_HTML), "pdf_sha256": digest(READER_PDF)}),
        ("responsive-closure", RESPONSIVE_QA, {"status": "PASS"}),
        ("visual-closure", VISUAL_QA, {"status": "PASS"}),
    ), start=1):
        add(make_record(
            "qa_event", f"qa.br-bgk-2019.u30.cumulative-{suffix}", source_local_id=path.stem,
            parent_id=DERIVATIVE_EDITION, order=order, path=rel(path), resource_id=LOCAL_RESOURCE,
            edition_id=DERIVATIVE_EDITION, source_locator=rel(path), content_sha256=digest(path),
            language="id-ID", translation_state="structurally_verified", rights_id=EDITORIAL_RIGHTS,
            payload=payload,
        ))

    # Add one append-only containment edge for each new non-relation record.
    non_relations = [row for row in new_records if row["entity_class"] != "relation"]
    for order, row in enumerate(non_relations, start=1):
        if row["parent_id"] is None:
            continue
        add(make_record(
            "relation", f"relation.br-bgk-2019.u13-30.{order:06d}", parent_id=COURSE_ID,
            order=order, resource_id=LOCAL_RESOURCE, edition_id=DERIVATIVE_EDITION,
            content_sha256=text_digest(row["parent_id"] + "\ncontains\n" + row["stable_id"]),
            translation_state="structurally_verified", rights_id=EDITORIAL_RIGHTS,
            payload={"subject_id": row["parent_id"], "predicate": "contains",
                     "object_id": row["stable_id"]},
        ))

    new_sorted = sorted(new_records, key=lambda row: (row["entity_class"], row["stable_id"]))
    records = base_records + new_sorted
    ids = [row["stable_id"] for row in records]
    require(len(ids) == len(set(ids)), "Duplicate cumulative BGK stable ID")
    id_set = set(ids)
    for row in records:
        require(row["parent_id"] is None or row["parent_id"] in id_set, f"Missing parent: {row['stable_id']}")
        require(row["rights_id"] is None or row["rights_id"] in id_set, f"Missing rights: {row['stable_id']}")
        require(row["resource_id"] is None or row["resource_id"] in id_set, f"Missing resource: {row['stable_id']}")
        require(row["edition_id"] is None or row["edition_id"] in id_set, f"Missing edition: {row['stable_id']}")
        require(all(cid in id_set for cid in row["concept_ids"]), f"Missing concept: {row['stable_id']}")
        require(all(pid in id_set for pid in row["prerequisite_ids"]),
                f"Missing prerequisite: {row['stable_id']}")
        require(row["supersedes"] is None or row["supersedes"] in id_set,
                f"Missing superseded record: {row['stable_id']}")
        if row["entity_class"] == "relation":
            require(row["payload"]["subject_id"] in id_set and row["payload"]["object_id"] in id_set,
                    f"Missing relation endpoint: {row['stable_id']}")
    require(not (id_set & classical_ids), "BGK/classical stable-ID collision")
    require(all(row["provenance"].get("model") == MODEL_PROVENANCE for row in new_records),
            "New record lacks exact model provenance")

    new_by_class = {name: [] for name in entity_classes}
    for row in new_sorted:
        new_by_class[row["entity_class"]].append(row)
    output_bytes: dict[str, bytes] = {}
    schema_path = OUT / "record.schema.json"
    output_bytes[rel(schema_path)] = pretty_bytes(record_schema(base_schema))
    output_bytes[rel(OUT / "records.jsonl")] = BASE_RECORDS.read_bytes() + jsonl_bytes(new_sorted)
    for entity_class in entity_classes:
        output_bytes[rel(OUT / f"{entity_class}.jsonl")] = (
            (BASE / f"{entity_class}.jsonl").read_bytes() + jsonl_bytes(new_by_class[entity_class])
        )

    source_bindings = unique_paths([
        BASE_MANIFEST, BASE_QA, BASE / "record.schema.json", BASE_RECORDS,
        *[BASE / f"{name}.jsonl" for name in entity_classes],
        FRONTMATTER, *artifact_paths, CLASSICAL_RECORDS, Path(__file__).resolve(),
        NATIVE_QA_DRIVER, COMMON_QA_DRIVER,
    ])
    for path in source_bindings:
        require(path.is_file(), f"Backend source binding absent: {rel(path)}")
    counts = dict(sorted(Counter(row["entity_class"] for row in records).items()))
    manifest = {
        "schema": MANIFEST_SCHEMA, "schema_version": "1.0.0",
        "record_schema_version": SCHEMA_VERSION, "generated_from_authority_utc": timestamp,
        "through_unit": 30,
        "scope": "BGK cumulative Units 1--30; namespace separate from classical Units 1--30",
        "encoding": "UTF-8",
        "serialization": "append-only canonical JSON Lines with CRLF; exact Units 1--12 files are byte prefixes",
        "record_count": len(records), "units_01_12_baseline_record_count": len(base_records),
        "units_13_30_added_record_count": len(new_records), "counts": counts,
        "source_heading_namespace": "br-bgk-2019-*",
        "units_13_30_source_heading_id_count": EXPECTED_NEW_HEADING_IDS,
        "exercise_count": sum(row["entity_class"] == "exercise" for row in records),
        "units_13_30_exercise_count": sum(EXPECTED_EXERCISES.values()),
        "public_solution_count": sum(row["entity_class"] == "solution" for row in records),
        "units_13_30_public_solution_count": sum(len(value) for value in EXPECTED_PUBLIC_SOLUTIONS.values()),
        "units_13_30_term_count": len(all_new_terms),
        "units_13_30_correction_count": len(all_new_corrections),
        "additive_editorial_intake": {
            "terminology": fact(ADDITIVE_TERMINOLOGY), "corrections": fact(ADDITIVE_CORRECTIONS),
            "reader_glossary": fact(READER_GLOSSARY),
            "central_ledgers_unchanged": True,
            "terminology_ids": [row["term_id"] for row in terminology_rows],
            "correction_ids": [row["correction_id"] for row in correction_rows],
        },
        "units": unit_summaries,
        "files": [fact_from_bytes(ROOT / path, data) for path, data in sorted(output_bytes.items())],
        "source_bindings": [fact(path) for path in source_bindings],
        "units_01_12_immutable_baseline": {
            "manifest_path": rel(BASE_MANIFEST), "manifest_sha256": digest(BASE_MANIFEST),
            "records_path": rel(BASE_RECORDS), "records_sha256": digest(BASE_RECORDS),
            "record_count": len(base_records), "records_byte_prefix_identity": True,
            "class_projection_byte_prefix_identity": True,
            "historical_reader_replay": historical_reader_replay(
                base_manifest, base_records, read_json(BASE_QA)),
        },
        "classical_collision_baseline": {
            "path": rel(CLASSICAL_RECORDS), "bytes": CLASSICAL_RECORDS.stat().st_size,
            "sha256": digest(CLASSICAL_RECORDS), "stable_id_count": len(classical_ids),
            "intersection_count": 0,
        },
        "reader_binding": {
            "qa_path": rel(READER_QA), "qa_sha256": digest(READER_QA),
            "receipt_path": rel(READER_RECEIPT), "receipt_sha256": digest(READER_RECEIPT),
            "html_path": rel(READER_HTML), "html_sha256": digest(READER_HTML),
            "pdf_path": rel(READER_PDF), "pdf_sha256": digest(READER_PDF),
        },
        "responsive_binding": {"path": rel(RESPONSIVE_QA), "sha256": digest(RESPONSIVE_QA), "status": "PASS"},
        "visual_binding": {"path": rel(VISUAL_QA), "sha256": digest(VISUAL_QA), "status": "PASS"},
        "model_provenance": MODEL_PROVENANCE,
        "validation": {
            "unique_stable_ids": True,
            "parent_rights_resource_edition_concept_and_relation_endpoint_closure": True,
            "records_exact_set_union_of_class_projections": True,
            "units_01_12_records_and_class_projections_are_exact_byte_prefixes": True,
            "independent_unit_exercise_solution_and_heading_id_expectations": True,
            "unit_29_three_asset_reader_media_closure": True,
            "all_new_records_carry_exact_model_provenance": True,
            "authority_translation_reader_visual_responsive_and_rights_bound": True,
            "explicit_per_unit_additive_term_and_correction_intake_exact": True,
            "central_terminology_and_correction_ledger_bytes_unchanged": True,
            "deterministic_double_replay_required": True,
        },
    }
    output_bytes[rel(OUT / "MANIFEST.json")] = pretty_bytes(manifest)
    return output_bytes, manifest


def write_export(output_bytes: dict[str, bytes]) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    expected_names = {Path(path).name for path in output_bytes}
    unexpected = sorted(path.name for path in OUT.iterdir() if path.name not in expected_names)
    require(not unexpected, f"Unexpected files already present in output directory: {unexpected}")
    staged: list[tuple[Path, Path, bytes]] = []
    for path_s, data in sorted(output_bytes.items()):
        path = ROOT / path_s
        require(not path.exists() or (path.is_file() and not path.is_symlink()),
                f"Unsafe existing output target: {path_s}")
        temporary = path.with_name(f".{path.name}.unit30-stage")
        require(not temporary.exists(), f"Stale staging target requires inspection: {rel(temporary)}")
        temporary.write_bytes(data)
        require(temporary.read_bytes() == data, f"Staging write/readback mismatch: {path_s}")
        staged.append((temporary, path, data))
    # Commit the manifest last so an interrupted materialization can never
    # advertise a complete boundary before every data projection is present.
    staged.sort(key=lambda row: row[1].name == "MANIFEST.json")
    for temporary, path, data in staged:
        temporary.replace(path)
        require(path.read_bytes() == data, f"Output commit/readback mismatch: {rel(path)}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--static-check", action="store_true",
                      help="Validate baseline/topology and report missing final inputs without writing")
    mode.add_argument("--preflight", "--dry-run", dest="preflight", action="store_true",
                      help="Build the complete export in memory without writing")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    materialization_attempted = False
    try:
        if args.static_check:
            result = static_check()
            print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
            return 0 if result["ready_for_export"] else 2
        output_bytes, manifest = build_export()
        summary = {
            "status": "PASS", "through_unit": 30, "record_count": manifest["record_count"],
            "added_record_count": manifest["units_13_30_added_record_count"],
            "output_files": len(output_bytes), "writes_performed": not args.preflight,
        }
        if not args.preflight:
            materialization_attempted = True
            write_export(output_bytes)
        print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
        return 0
    except Exception as exc:
        print(json.dumps({
            "schema": "ag-bridge-bgk-units-01-30-export-failure-v1",
            "status": "FAIL", "error": str(exc),
            "materialization_attempted": materialization_attempted,
            "complete_boundary_written": False,
            "credentials_recorded": False,
        }, ensure_ascii=False, sort_keys=True, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
