#!/usr/bin/env python3
"""Focused read-only regression tests for complete30 historical baseline replay."""
from __future__ import annotations

import copy
import importlib.util
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]


def load(name: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / "scripts" / (name + ".py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class BaselineReplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.exporter = load("export_backend_bgk_units_01_30")
        cls.qa = load("qa_backend_bgk_units_01_30")
        cls.modules = (cls.exporter, cls.qa)
        cls.manifest = json.loads(cls.exporter.BASE_MANIFEST.read_text(encoding="utf-8"))
        cls.records = cls.exporter.read_jsonl(cls.exporter.BASE_RECORDS)
        cls.base_qa = json.loads(cls.exporter.BASE_QA.read_text(encoding="utf-8"))
        cls.by_id = {row["stable_id"]: row for row in cls.records}
        cls.replay = cls.exporter.historical_reader_replay(
            cls.manifest, cls.records, cls.base_qa)
        cls.historical_ids = {row["stable_id"] for row in cls.replay["historical_artifacts"]}
        cls.aliases = {row["path"]: row for row in cls.replay["source_aliases"]}

    def test_exact_independent_31_record_pins(self):
        self.assertEqual(self.exporter.HISTORICAL_ARTIFACT_BINDINGS,
                         self.qa.HISTORICAL_ARTIFACT_BINDINGS)
        self.assertEqual(self.replay, self.qa.historical_reader_replay(
            self.manifest, self.records, self.base_qa))
        self.assertEqual(len(self.historical_ids), 31)
        self.assertEqual(len(self.aliases), 3)
        self.assertEqual(sum(row["classification"] == "superseded_generated_reader_alias"
                             for row in self.replay["historical_artifacts"]), 15)
        self.assertFalse(self.replay["historical_loose_bytes_rehashed"])

    def test_live_baseline_authentication_and_current_nonreader_bindings(self):
        manifest, records, _ = self.exporter.baseline()
        self.assertEqual(manifest, self.manifest)
        self.assertEqual(records, self.records)

    def test_historical_reader_receipt_anchor_cannot_be_replaced(self):
        manifest = copy.deepcopy(self.manifest)
        qa = copy.deepcopy(self.base_qa)
        manifest["reader_binding"]["receipt_sha256"] = "0" * 64
        qa["reader_binding"] = manifest["reader_binding"]
        for module in self.modules:
            with self.subTest(module=module.__name__), self.assertRaises(RuntimeError):
                module.historical_reader_replay(manifest, self.records, qa)

    def test_historical_source_binding_cannot_drift(self):
        binding = {**next(iter(self.aliases.values())), "sha256": "0" * 64}
        for module in self.modules:
            with self.subTest(module=module.__name__), self.assertRaises(RuntimeError):
                module.validate_baseline_binding(binding, self.aliases)

    def test_native_output_never_uses_alias_exception(self):
        manifest = copy.deepcopy(self.manifest)
        manifest["files"].append(next(iter(self.aliases.values())))
        for module in self.modules:
            with self.subTest(module=module.__name__), self.assertRaises(RuntimeError):
                module.historical_reader_replay(manifest, self.records, self.base_qa)

    def test_every_historical_full_record_is_pinned(self):
        for stable_id in self.historical_ids:
            altered = [({**row, "rights_id": "rights.changed"} if row["stable_id"] == stable_id
                        else row) for row in self.records]
            for module in self.modules:
                with self.subTest(id=stable_id, module=module.__name__):
                    with self.assertRaises(RuntimeError):
                        module.historical_reader_replay(self.manifest, altered, self.base_qa)

    def test_current_source_ledger_rights_bindings_remain_strict(self):
        paths = ("00_control/TERMINOLOGY.csv", "00_control/CORRECTIONS.csv",
                 "source/id-ID/bgk/lecture-09.md",
                 "qa/BGK_UNIT_09_TRANSLATION_QA.json",
                 "backend/bgk-units-01-12/rights.jsonl")
        bindings = {row["path"]: row for row in
                    self.manifest["files"] + self.manifest["source_bindings"]}
        for path in paths:
            damaged = {**bindings[path], "sha256": "0" * 64}
            for module in self.modules:
                with self.subTest(path=path, module=module.__name__):
                    with self.assertRaises(RuntimeError):
                        module.validate_baseline_binding(damaged, self.aliases)

    def test_exact_old_record_classifies_without_reading_shared_alias(self):
        with patch.object(self.qa, "digest", side_effect=AssertionError("live lookup forbidden")):
            for stable_id in self.historical_ids:
                self.assertEqual(self.qa.verify_artifact_binding(
                    self.by_id[stable_id], self.by_id, self.historical_ids), "historical")

    def test_modified_historical_record_is_rejected(self):
        stable_id = "artifact.br-bgk-2019.u07.004"
        row = {**self.by_id[stable_id], "content_sha256": "0" * 64}
        with self.assertRaises(RuntimeError):
            self.qa.verify_artifact_binding(row, self.by_id, self.historical_ids)

    def test_new_artifact_same_path_is_not_exempt(self):
        row = {**self.by_id["artifact.br-bgk-2019.u12.cumulative-009"],
               "stable_id": "artifact.br-bgk-2019.u30.not-whitelisted"}
        with self.assertRaises(RuntimeError):
            self.qa.verify_artifact_binding(row, self.by_id, self.historical_ids)
        row["payload"] = {**row["payload"], "bytes": self.exporter.READER_HTML.stat().st_size}
        row["content_sha256"] = self.exporter.digest(self.exporter.READER_HTML)
        self.assertEqual(self.qa.verify_artifact_binding(
            row, self.by_id, self.historical_ids), "current")

    def test_old_nonwhitelisted_record_is_not_exempt(self):
        row = copy.deepcopy(next(row for row in self.records
                                if row["entity_class"] == "artifact"
                                and row["stable_id"] not in self.historical_ids))
        row["content_sha256"] = "0" * 64
        with self.assertRaises(RuntimeError):
            self.qa.verify_artifact_binding(row, self.by_id, self.historical_ids)

    def test_current_reader_gates_stay_strict(self):
        receipt = self.exporter.read_json(self.exporter.READER_RECEIPT)
        self.exporter.validate_current_reader_outputs(receipt)
        wrong_unit = {**receipt, "through_unit": 12}
        with self.assertRaises(RuntimeError):
            self.exporter.validate_current_reader_outputs(wrong_unit)
        for path in (self.exporter.READER_HTML, self.exporter.READER_PDF):
            damaged = copy.deepcopy(receipt)
            for item in damaged["outputs"]:
                if item["path"] == self.exporter.rel(path):
                    item["sha256"] = "0" * 64
            with self.subTest(path=path.name), self.assertRaises(RuntimeError):
                self.exporter.validate_current_reader_outputs(damaged)

    def test_original_manifest_records_and_qa_are_unmodified(self):
        for module in self.modules:
            for path, expected in ((module.BASE_MANIFEST, module.BASE_MANIFEST_SHA256),
                                   (module.BASE_RECORDS, module.BASE_RECORDS_SHA256),
                                   (module.BASE_QA, module.BASE_QA_SHA256)):
                self.assertEqual(module.digest(path), expected)


if __name__ == "__main__":
    unittest.main(verbosity=2)
