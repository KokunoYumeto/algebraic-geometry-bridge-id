# Kredit media BGK Unit 17 {#br-bgk-2019-media-credits-unit-17}

Sumber kursus: **Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)**, Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 17 dan Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 17.

Unit ini tidak memiliki posisi media substantif untuk pembaca, sehingga tidak ada keterangan gambar atau teks alternatif komponen yang perlu ditambahkan. Dua berkas PDF resmi yang muncul pada permukaan parse dibekukan hanya sebagai saksi authority; identitas, atribusi, lisensi, revisi, ukuran, dan hash keduanya tercatat dalam penutupan aset, bukan sebagai media pembaca.
