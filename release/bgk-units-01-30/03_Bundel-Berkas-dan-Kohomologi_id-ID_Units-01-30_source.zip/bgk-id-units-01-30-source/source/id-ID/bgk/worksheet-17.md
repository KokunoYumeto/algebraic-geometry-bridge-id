---
title: "Lembar Kerja 17 - Bundel Vektor Geometris"
stable_id: br-bgk-2019-w17
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 17"
upstream_pageid: 110224
upstream_revid: 1003886
upstream_timestamp: "2025-06-10T09:38:13Z"
upstream_mediawiki_sha1: 3f58772722e8d02548107ad7a0dde0f0f472f1fa
source_url: "https://de.wikiversity.org/w/index.php?oldid=1003886"
authority_manifest: authority/wikiversity-bgk/unit-17/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: b896a47254cbbea5f77f5eecaa1f8db99fe24c662fc9ba56e10f9db1be186b99
authority_manifest_status: "Bekuan authority terminal lengkap; 31 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
worksheet_xml: authority/wikiversity-bgk/unit-17/worksheet-17.xml
worksheet_xml_sha256: a942e9db3e3cf217c11b4a77727b0b370da99eead57fe69343020f5733622d6b
worksheet_expanded_tex: authority/wikiversity-bgk/unit-17/worksheet-17-expanded.tex
worksheet_expanded_tex_sha256: 85118fdf9a758d52623f12243d5744e1cc4d758342335cf5eea7d2df1eba3906
official_pdf: authority/artifacts/bgk-worksheet-17-official.pdf
official_pdf_sha256: 82fed9c1839a719786d9c79068d30a25259f7090447d7dfee64320b1a0c480a6
official_pdf_status: "Saksi PDF resmi lokal; 65.250 byte, 7 halaman, dan SHA-1 unggahan 2b3b1063d7795c7b063584d0d872d5792105af9f telah diverifikasi."
official_pdf_metadata: authority/wikiversity-bgk/unit-17/official-pdfs-api.json
official_pdf_source_bytes: 65250
official_pdf_source_sha1: 2b3b1063d7795c7b063584d0d872d5792105af9f
older_course_pdf: authority/artifacts/bgk-course-official.pdf
older_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
authority_precedence: "Revisi semantik Wikiversity yang dibekukan mengendalikan teks; PDF seluruh kursus tahun 2020 hanya saksi historis."
ordered_exercise_map: authority/wikiversity-bgk/unit-17/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: b210a02cb2ae3ea8ed86e1dd7bd1cc50fbd50713597869e830c34e295deed531
exercise_count: 24
public_solution_count: 0
public_solution_numbers: "none"
media_credits: source/id-ID/media-credits-bgk-unit-17.md
rights_ledger: authority/RIGHTS-bgk-unit-17.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-17.json
asset_closure_sha256: 1173bbfd2583a146d58bee689a94fdaa143b543da0b3f4dbc89fe869d57037cb
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF adalah saksi authority, bukan teks edisi; metadata Commons CC BY-SA 4.0 dan pemberitahuan tertanam CC-by-sa 3.0 dipertahankan tanpa pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 17: Bundel Vektor Geometris {#br-bgk-2019-w17}

Pada batas authority yang dibekukan, sumber tidak menyediakan halaman solusi
publik untuk satu pun dari 24 soal. Peta soal mencatat hasil kandidat negatif
untuk Soal 17.1--17.24; edisi tidak menciptakan solusi baru.

<!-- upstream_entity: Geometrisches Vektorbündel/Reelles Vektorbündel/Vergleich/Aufgabe -->

## Soal 17.1 {#br-bgk-2019-w17-ex01}

Bandingkan Definisi 17.1 tentang bundel vektor geometris di atas suatu skema
dengan Definisi 1.4 tentang bundel vektor riil di atas ruang topologis.

<!-- upstream_entity: Geometrisches Vektorbündel/Faser/Affiner Raum/Aufgabe -->

## Soal 17.2 {#br-bgk-2019-w17-ex02}

Misalkan $p:V\to X$ bundel vektor geometris ber-rank $r$ di atas skema
$X$. Buktikan bahwa serat $p$ di atas titik $P\in X$ isomorfik dengan
$\mathbb A_{\kappa(P)}^r$.

<!-- upstream_entity: Geometrisches Vektorbündel/Rang 0/Aufgabe -->

## Soal 17.3 {#br-bgk-2019-w17-ex03}

Apakah bundel vektor ber-rank $0$ di atas suatu skema $X$ itu?

<!-- upstream_entity: Affines Geradenbündel/Spek Z/Aufgabe -->

## Soal 17.4 {#br-bgk-2019-w17-ex04}

Bahas bundel garis trivial

$$
\operatorname{Spek}(\mathbb Z[X])
=\mathbb A_{\mathbb Z}^1
\longrightarrow\operatorname{Spek}(\mathbb Z).
$$

Apa yang dapat dikatakan tentang serat-seratnya, tentang seksi-seksinya, dan
tentang subhimpunan tertutup
$Y\subseteq\operatorname{Spek}(\mathbb Z[X])$ beserta citranya dalam
$\operatorname{Spek}(\mathbb Z)$?

<!-- upstream_entity: Affiner Raum/Punktiert/Syzygienbündel/Übergangsabbildungen/Aufgabe -->

## Soal 17.5 {#br-bgk-2019-w17-ex05}

Tentukan secara eksplisit trivialisasi dan pemetaan perubahan basis dalam
Contoh 17.3.

<!-- upstream_entity: Projektiver Raum/Getwistetes Geradenbündel/Geometrische Realisierung/k ist 0/Trivial/Aufgabe -->

## Soal 17.6 {#br-bgk-2019-w17-ex06}

Buktikan bahwa untuk $k=0$ dalam Contoh 17.4 diperoleh bundel garis trivial

$$
\mathbb A_{\mathbb P_K^n}^1
=\mathbb A_K^1\times\mathbb P_K^n
\longrightarrow\mathbb P_K^n.
$$

<!-- upstream_entity: Projektiver Raum/Getwistetes Geradenbündel/Geometrische Realisierung/k ist 1/Projektion weg von Punkt/Aufgabe -->

## Soal 17.7 {#br-bgk-2019-w17-ex07}

Buktikan bahwa untuk $k=1$ dalam Contoh 17.4 diperoleh apa yang disebut
proyeksi menjauhi sebuah titik,

$$
\mathbb P_K^{n+1}
\supset
\mathbb P_K^{n+1}\setminus(0,0,\ldots,0,1)
=V_1
\longrightarrow\mathbb P_K^n.
$$

<!-- upstream_entity: Geometrisches Vektorbündel/Direkte Summe/Aufgabe -->

## Soal 17.8 {#br-bgk-2019-w17-ex08}

Misalkan $X$ skema, dan misalkan $p:V\to X$ serta $W\to X$ bundel vektor
di atas $X$ yang masing-masing ber-rank $r$ dan $s$. Definisikan jumlah
langsung $V\times_XW$ dari kedua bundel vektor dengan merujuk pada
trivialisasi simultan

$$
V|_U\cong\mathbb A_U^r,
\qquad
W|_U\cong\mathbb A_U^s.
$$

Jadi harus berlaku

$$
(V\times_XW)_U
\cong V|_U\times_UW|_U
\cong\mathbb A_U^{r+s}.
$$

<!-- upstream_entity: Geometrisches Vektorbündel/Schema/Lineare Konstruktionen/Definiere/Aufgabe -->

## Soal 17.9 {#br-bgk-2019-w17-ex09}

Definisikan konstruksi-konstruksi dari aljabar linear, seperti jumlah
langsung, dual, hasil kali tensor, dan hasil kali eksterior, untuk bundel
vektor geometris di atas suatu skema.

Gunakan Kuliah 3 sebagai panduan.

<!-- upstream_entity: Geometrisches Vektorbündel/Nullschnitt/Abgeschlossene Teilmenge/Basis/Aufgabe -->

## Soal 17.10 {#br-bgk-2019-w17-ex10}

Buktikan bahwa seksi nol suatu bundel vektor geometris $V\to X$ merupakan
pembenaman tertutup.

<!-- upstream_entity: Geometrisches Vektorbündel/Addition/Eigenschaften/Aufgabe -->

## Soal 17.11 {#br-bgk-2019-w17-ex11}

Misalkan $p:V\to X$ bundel vektor di atas $X$. Buktikan bahwa penjumlahan
$\alpha:V\times_XV\to V$ mempunyai sifat-sifat berikut. Sekaligus buktikan
bahwa morfisme-morfisme yang ditampilkan memang ada.

1. Diagram

   $$
   \begin{CD}
   V @>{\operatorname{Id}\times(N\circ p)}>> V\times_XV\\
   @V{\operatorname{Id}}VV @VV{\alpha}V\\
   V @= V
   \end{CD}
   $$

   komutatif, dengan $N:X\to V$ menyatakan seksi nol.

2. Diagram

   $$
   \begin{CD}
   V\times_XV @>{\pi}>> V\times_XV\\
   @V{\alpha}VV @VV{\alpha}V\\
   V @= V
   \end{CD}
   $$

   komutatif, dengan $\pi$ menyatakan pertukaran kedua faktor.

3. Diagram

   $$
   \begin{CD}
   V\times_XV\times_XV @>{\alpha\times\operatorname{Id}}>> V\times_XV\\
   @V{\operatorname{Id}\times\alpha}VV @VV{\alpha}V\\
   V\times_XV @>{\alpha}>> V
   \end{CD}
   $$

   komutatif.

Untuk soal berikut, bandingkan Soal 1.6.

<!-- upstream_entity: Erzwingende Algebra/ux+vy-1/Kein Vektorbündel/Aufgabe -->

## Soal 17.12 {#br-bgk-2019-w17-ex12}

Misalkan $K$ lapangan. Kita tinjau

$$
A=K[X,Y,U,V]/(XU+YV-1),
$$

pemetaan spektrum

$$
\operatorname{Spek}(A)
\longrightarrow
\operatorname{Spek}(K[X,Y])=\mathbb A_K^2,
$$

dan pembatasan

$$
p:\operatorname{Spek}(A)=D(X,Y)=V
\longrightarrow
U=D(X,Y)\subseteq\mathbb A_K^2.
$$

Kesamaan di sebelah kiri didasarkan pada apa? Buktikan pernyataan-pernyataan
berikut.

1. Pemetaan $p$ pada $D(X)$ dan pada $D(Y)$ isomorfik dengan garis afin di
   atas basis.
2. Pemetaan $p:V\to U$ tidak mempunyai seksi.
3. $V$ bukan bundel garis.

<!-- upstream_entity: Erzwingende Algebra/Gestalt der Fasern/Schema/Aufgabe -->

## Soal 17.13 {#br-bgk-2019-w17-ex13}

Misalkan $R$ aljabar komutatif bertipe hingga di atas lapangan $K$. Misalkan
$f_1,\ldots,f_n,f$ unsur-unsur $R$, dan misalkan

$$
A=R[T_1,\ldots,T_n]/(f_1T_1+\cdots+f_nT_n+f)
$$

aljabar pemaksa untuk data ini. Misalkan

$$
p:\operatorname{Spek}(A)
\supseteq V=D(f_1,\ldots,f_n)
\longrightarrow
U=D(f_1,\ldots,f_n)\subseteq\operatorname{Spek}(R)
$$

pemetaan spektrum yang dibatasi. Buktikan bahwa terdapat penutup terbuka afin

$$
U=\bigcup_{i\in I}U_i
$$

sedemikian sehingga $p^{-1}(U_i)$ isomorfik dengan
$U_i\times\mathbb A^{n-1}$, dan bahwa pemetaan-pemetaan perubahannya bersifat
afin-linear.

<!-- upstream_entity: Geometrisches Vektorbündel/Trivial/Homomorphismus/Matrix/Aufgabe -->

## Soal 17.14 {#br-bgk-2019-w17-ex14}

Buktikan bahwa homomorfisme bundel vektor trivial

$$
\varphi:\mathbb A_{\operatorname{Spek}(R)}^r
\longrightarrow
\mathbb A_{\operatorname{Spek}(R)}^s
$$

di atas skema afin $\operatorname{Spek}(R)$ diberikan oleh matriks berukuran
$s\times r$ di atas $R$.

<!-- upstream_entity: Geometrisches Vektorbündel/Homomorphismus/Nullschnitt/Aufgabe -->

## Soal 17.15 {#br-bgk-2019-w17-ex15}

Buktikan bahwa homomorfisme bundel vektor

$$
\varphi:V\longrightarrow W
$$

di atas $X$ memetakan seksi nol $V$, yang dipandang sebagai subskema
tertutup, ke dalam seksi nol $W$.

<!-- upstream_entity: Geometrisches Vektorbündel/Homomorphismus/Gruppenhomomorphismus/Aufgabe -->

## Soal 17.16 {#br-bgk-2019-w17-ex16}

Misalkan $\varphi:V\to W$ homomorfisme bundel vektor $V,W$ di atas $X$.
Buktikan bahwa diagram

$$
\begin{CD}
V\times_XV @>{\varphi\times\varphi}>> W\times_XW\\
@V{\alpha}VV @VV{\alpha}V\\
V @>{\varphi}>> W
\end{CD}
$$

komutatif. Dengan kata lain, homomorfisme bundel vektor kompatibel dengan
penjumlahan.

<!-- upstream_entity: Geometrisches Vektorbündel/Spek Z/Fasern/Aufgabe -->

## Soal 17.17 {#br-bgk-2019-w17-ex17}

Kita tinjau homomorfisme bundel vektor trivial

$$
\varphi:\mathbb A_{\operatorname{Spek}(\mathbb Z)}^2
\longrightarrow
\mathbb A_{\operatorname{Spek}(\mathbb Z)}^2
$$

di atas $\operatorname{Spek}(\mathbb Z)$ yang diberikan oleh matriks

$$
\begin{pmatrix}
5&6\\
7&4
\end{pmatrix}.
$$

Tentukan titik-titik $P\in\operatorname{Spek}(\mathbb Z)$ tempat pemetaan
serat terkait bersifat injektif, dan tempat pemetaan tersebut bersifat
surjektif.

<!-- upstream_entity: Schema/Geometrisches Vektorbündel/Homomorphismus/Surjektiv/Kern/Fakt/Beweis/Aufgabe -->

## Soal 17.18 {#br-bgk-2019-w17-ex18}

Misalkan $V$ dan $W$ bundel vektor di atas suatu skema $X$, dan misalkan
$\varphi:V\to W$ homomorfisme bundel vektor surjektif. Buktikan bahwa kernel
yang diambil titik demi titik merupakan bundel vektor di atas $X$.

<!-- upstream_entity: Geometrisches Vektorbündel/Direkte Summe/Garbe der Schnitte/Aufgabe -->

## Soal 17.19 {#br-bgk-2019-w17-ex19}

Misalkan $V$ dan $W$ bundel vektor di atas suatu skema $X$. Buktikan bahwa
berkas seksi jumlah langsung $V\times_XW$ sama dengan jumlah langsung berkas
seksi $V$ dan berkas seksi $W$.

<!-- upstream_entity: Projektiver Raum/Getwistetes Geradenbündel/Geometrische Realisierung/Garbe der Schnitte/Aufgabe -->

## Soal 17.20 {#br-bgk-2019-w17-ex20}

Buktikan bahwa berkas seksi bundel garis

$$
V_k\longrightarrow\mathbb P_K^n
$$

dari Contoh 17.4 adalah berkas struktur terpuntir
$\mathcal O_{\mathbb P_K^n}(k)$.

<!-- upstream_entity: Basisschema/Schema/Morphismus/Garbe der Schnitte/Aufgabe -->

## Soal 17.21 {#br-bgk-2019-w17-ex21}

Misalkan $p:Y\to X$ dan $q:Z\to X$ skema-skema di atas suatu skema $X$,
dan misalkan $\varphi:Y\to Z$ morfisme skema di atas $X$. Buktikan bahwa
pemetaan berkas seksi terkait dalam kategori skema

$$
\mathcal S_Y\longrightarrow\mathcal S_Z,
$$

yang memetakan seksi $s:U\to p^{-1}(U)$ ke seksi
$\varphi\circ s:U\to q^{-1}(U)$, merupakan morfisme berkas.

<!-- upstream_entity: Basisschema/Vektorbündel/Homomorphismus/Garbe der Schnitte/Modulhomomorphismus/Aufgabe -->

## Soal 17.22 {#br-bgk-2019-w17-ex22}

Misalkan $\varphi:V\to W$ homomorfisme bundel vektor antara bundel-bundel
vektor $V$ dan $W$ di atas $X$, dan misalkan

$$
\psi:\mathcal S_V\longrightarrow\mathcal S_W
$$

morfisme berkas terkait antara berkas-berkas seksi. Buktikan bahwa $\psi$
merupakan homomorfisme modul-$\mathcal O_X$.

<!-- upstream_entity: Schema/Lokal_freie_Garben_und_Vektorbündel/Äquivalenz/Homomorphismus/Aufgabe -->

## Soal 17.23 {#br-bgk-2019-w17-ex23}

Misalkan $V$ dan $W$ bundel vektor di atas skema $X$, dan misalkan
$\mathcal S_V,\mathcal S_W$ berkas seksi yang terkait. Buktikan bahwa
pemetaan

$$
\operatorname{Hom}(V,W)
\longrightarrow
\operatorname{Hom}(\mathcal S_V,\mathcal S_W),
$$

yang memetakan homomorfisme bundel vektor ke homomorfisme
modul-$\mathcal O_X$ terkait, merupakan bijeksi. Buktikan pula bahwa di bawah
korespondensi ini, isomorfisme bersesuaian dengan isomorfisme.

<!-- upstream_entity: Schema/Vektorbündel/Lokal freie Garben/Surjektiv/Aufgabe -->

## Soal 17.24 {#br-bgk-2019-w17-ex24}

Misalkan $V$ dan $W$ bundel vektor di atas suatu skema $X$, dan misalkan
$\mathcal F$ dan $\mathcal G$ berkas seksi bebas lokal yang terkait. Misalkan
$\varphi:V\to W$ homomorfisme bundel vektor dan
$\psi:\mathcal F\to\mathcal G$ homomorfisme berkas terkait. Buktikan bahwa
pernyataan-pernyataan berikut ekuivalen.

1. $\varphi$ merupakan morfisme skema surjektif.
2. Pada setiap titik $P\in X$, pemetaan serat $V(x)\to W(x)$ bersifat
   surjektif.
3. Homomorfisme $\psi:\mathcal F\to\mathcal G$ bersifat surjektif.
4. Terdapat penutup terbuka $X=\bigcup_{i\in I}U_i$ dan seksi lokal berupa
   homomorfisme bundel vektor

   $$
   s_i:W|_{U_i}\longrightarrow V|_{U_i}
   $$

   untuk $\varphi$.
5. Terdapat penutup terbuka $X=\bigcup_{i\in I}U_i$ dan seksi lokal berupa
   homomorfisme modul

   $$
   t_i:\mathcal G|_{U_i}\longrightarrow\mathcal F|_{U_i}
   $$

   untuk $\psi$.
