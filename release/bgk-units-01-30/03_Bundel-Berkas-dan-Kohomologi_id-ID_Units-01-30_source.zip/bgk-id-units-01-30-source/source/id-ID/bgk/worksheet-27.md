---
title: "Lembar Kerja 27 - Kohomologi pada Skema Projektif"
stable_id: br-bgk-2019-w27
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 27"
upstream_pageid: 110236
upstream_revid: 1070033
upstream_timestamp: "2026-02-06T08:44:17Z"
upstream_mediawiki_sha1: 7e45c57c5d18d8ea176bc77a7b140587dbcc3bc1
source_url: "https://de.wikiversity.org/w/index.php?oldid=1070033"
authority_manifest: authority/wikiversity-bgk/unit-27/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: b6c2a7687ee2fcc20e6f2b5f58f1f97a665a8c1f9201d11308bb84f62a79c089
authority_manifest_status: "Bekuan authority terminal lengkap; 30 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
official_pdf: authority/artifacts/bgk-worksheet-27-official.pdf
official_pdf_sha256: 4c816be8bc38979b50742b9208a15ba1a338ddc46efa07bd5eef222535abccab
official_pdf_source_bytes: 54066
official_pdf_source_sha1: df5362a3e67d6cfb70f5a3656a698aacebd59d3e
official_pdf_pages: 5
authority_precedence: "Revisi semantik Wikiversity yang dibekukan mengendalikan keempat belas soal; PDF resmi adalah saksi historis, bukan pengganti revisi semantik."
pdf_component_rights: "Metadata Commons CC BY-SA 4.0 dan pemberitahuan tertanam CC-by-sa 3.0 dipertahankan tanpa pelisensian ulang menyeluruh."
media_credits: source/id-ID/media-credits-bgk-unit-27.md
media_credits_sha256: dc3afa2d1b2e7c78a604bb54965bc45e4c56058c7585341e927d0e8e4a03f406
rights_ledger: authority/RIGHTS-bgk-unit-27.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-27.json
asset_closure_sha256: 0eb449063c5dab73703a381246847c4deac31a20327bbe2a8a4c17b082e915ab
worksheet_xml: authority/wikiversity-bgk/unit-27/worksheet-27.xml
worksheet_xml_sha256: 64bc4a467abffbf66def5569387dd43b3add014170e99d98f2bfe16eb25ca815
worksheet_expanded_tex: authority/wikiversity-bgk/unit-27/worksheet-27-expanded.tex
worksheet_expanded_tex_sha256: 1d53d6704a6a3d78ad85ed8a0b3a9d355f4e18b8815c245ca3386c9f4192a6b6
ordered_exercise_map: authority/wikiversity-bgk/unit-27/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 9f230b1a85e7ece54442b86ebc3bf7d70c9ea009c44485899be9f9f6dd834c6b
exercise_count: 14
public_solution_count: 0
public_solution_numbers: ""
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 27: Kohomologi pada Skema Projektif {#br-bgk-2019-w27}

Pada batas revisi yang dibekukan, tidak satu pun dari empat belas soal
memiliki solusi publik. Peta kandidat mencatat hasil negatif untuk Soal
27.1--27.14; edisi tidak menciptakan solusi baru.

<!-- upstream_entity: Polynomring/1/Nenneraufnahme an X/Cech-Kohomologie/Aufgabe -->

## Soal 27.1 {#br-bgk-2019-w27-ex01}

Misalkan $A=R[X]$ di atas gelanggang komutatif $R$. Tentukan kompleks Čech
berkas struktur terhadap liputan satu unsur yang terdiri atas $D(X)$ pada
garis tertusuk. Homologi apa yang diperoleh?

<!-- upstream_entity: Polynomring/2/Cech-Komplex/Monom/Aufgabe -->

## Soal 27.2 {#br-bgk-2019-w27-ex02}

Misalkan $A=R[X,Y]$ di atas gelanggang komutatif $R$. Tentukan kompleks Čech
berkas struktur terhadap liputan standar bidang tertusuk untuk monomial

1. $X^2Y^3$,
2. $X^5Y^{-4}$,
3. $X^{-3}Y^{-6}$.

Homologi apa yang diperoleh dalam setiap kasus?

<!-- upstream_entity: Polynomring/3/Cech-Komplex/Monom/1/Aufgabe -->

## Soal 27.3 {#br-bgk-2019-w27-ex03}

Misalkan $A=R[X,Y,Z]$ di atas gelanggang komutatif $R$. Tentukan kompleks
Čech berkas struktur terhadap liputan standar ruang tertusuk pada monomial
$X^3Y^{-2}Z^7$. Homologi apa yang diperoleh?

<!-- upstream_entity: Polynomring/3/Cech-Komplex/Monom/2/Aufgabe -->

## Soal 27.4 {#br-bgk-2019-w27-ex04}

Misalkan $A=R[X,Y,Z]$ di atas gelanggang komutatif $R$. Tentukan kompleks
Čech berkas struktur terhadap liputan standar ruang tertusuk pada monomial
$X^{-5}YZ^{-4}$. Homologi apa yang diperoleh?

<!-- upstream_entity: Polynomring/4/Cech-Komplex/Monom/Aufgabe -->

## Soal 27.5 {#br-bgk-2019-w27-ex05}

Misalkan $A=R[X,Y,Z,W]$ di atas gelanggang komutatif $R$. Tentukan kompleks
Čech berkas struktur terhadap liputan standar ruang tertusuk pada monomial
$X^{-3}YZ^3W^{-2}$. Homologi apa yang diperoleh?

<!-- upstream_entity: Polynomring/Höchste lokale Kohomologie/Modulstruktur/Direkt/Aufgabe -->

## Soal 27.6 {#br-bgk-2019-w27-ex06}

Misalkan $K[X_1,\ldots,X_d]$ gelanggang polinomial di atas lapangan $K$,
dan misalkan $H$ ruang vektor $K$ yang direntang oleh semua monomial
$X^\nu$ dalam variabel $X_1,\ldots,X_d$ dengan $\nu_j\leq-1$ untuk setiap
$j$, yaitu

$$
H=K\left\langle
X_1^{\nu_1}\cdots X_d^{\nu_d},\ \nu_j\leq-1
\right\rangle.
$$

Definisikan struktur modul $K[X_1,\ldots,X_d]$ yang alami pada $H$.

<!-- upstream_entity: Polynomring/Höchste lokale Kohomologie/K-Isomorphie zu Polynomring/Aufgabe -->

## Soal 27.7 {#br-bgk-2019-w27-ex07}

Misalkan $K[Y_1,\ldots,Y_d]$ gelanggang polinomial di atas lapangan $K$,
dan misalkan $H$ ruang vektor $K$ yang direntang oleh semua monomial
$X^\nu$ dalam variabel $X_1,\ldots,X_d$ dengan $\nu_j\leq-1$ untuk setiap
$j$, yaitu

$$
H=K\left\langle
X_1^{\nu_1}\cdots X_d^{\nu_d},\ \nu_j\leq-1
\right\rangle.
$$

Buktikan bahwa pemetaan

$$
K[Y_1,\ldots,Y_d]\longrightarrow H,
\qquad
Y^\mu\longmapsto X^{-\mu-(1,1,\ldots,1)},
$$

merupakan isomorfisme-$K$ antara ruang-ruang vektor $K$.

<!-- upstream_entity: Polynomring/Höchste lokale Kohomologie/Fakultäten/K-Isomorphie zu Polynomring/Aufgabe -->

## Soal 27.8 {#br-bgk-2019-w27-ex08}

Misalkan $K[Y_1,\ldots,Y_d]$ gelanggang polinomial di atas lapangan $K$
berkarakteristik $0$, dan misalkan $H$ ruang vektor $K$ yang direntang oleh
semua monomial $X^\nu$ dalam variabel $X_1,\ldots,X_d$ dengan
$\nu_j\leq-1$ untuk setiap $j$, yaitu

$$
H=K\left\langle
X_1^{\nu_1}\cdots X_d^{\nu_d},\ \nu_j\leq-1
\right\rangle.
$$

Buktikan bahwa pemetaan

$$
\theta:K[Y_1,\ldots,Y_d]\longrightarrow H,
\qquad
Y^\mu\longmapsto\mu!X^{-\mu-(1,1,\ldots,1)},
$$

merupakan isomorfisme-$K$ antara ruang-ruang vektor $K$.

<!-- upstream_entity: Polynomring/Höchste lokale Kohomologie/Differentialoperatoren/Isomorphe Situation/Aufgabe -->

## Soal 27.9 {#br-bgk-2019-w27-ex09}

Misalkan $K$ lapangan berkarakteristik $0$, dan misalkan
$K[X_1,\ldots,X_d]$, $K[Y_1,\ldots,Y_d]$, serta $K[D_1,\ldots,D_d]$
gelanggang-gelanggang polinomial dalam $d$ variabel. Misalkan $H$ ruang
vektor $K$ yang dideskripsikan dalam Soal 27.6, dengan struktur modul
$K[X_1,\ldots,X_d]$ alaminya.

Gelanggang polinomial $K[D_1,\ldots,D_d]$ bertindak pada
$K[Y_1,\ldots,Y_d]$ dengan cara bahwa $D_i$ mengambil peran turunan parsial
ke-$i$, yakni

$$
D_i=\partial_i=\frac{\partial}{\partial Y_i}.
$$

Buktikan bahwa korespondensi $D_i\mapsto X_i$, bersama pemetaan

$$
\theta:K[Y_1,\ldots,Y_d]\longrightarrow H
$$

dari Soal 27.8, memberikan suatu isomorfisme modul.

Untuk soal berikut, perhatikan bahwa dalam kasus mulus, menurut Korolari
19.12, yang dihitung adalah dimensi ruang bentuk diferensial global.

<!-- upstream_entity: Projektive Ebene/Kurve/Getwistete Strukturgabe zu d-3/Globale Schnitte/Aufgabe -->

## Soal 27.10 {#br-bgk-2019-w27-ex10}

Misalkan

$$
C=V_+(f)\subset\mathbb P_K^2
$$

kurva projektif bidang berderajat $d$ di atas lapangan $K$. Dengan
menggunakan barisan kohomologi eksak panjang yang berasal dari barisan pendek
eksak berkas (bandingkan Soal 13.23)

$$
0\longrightarrow\mathcal O_{\mathbb P_K^2}(-3)
\xrightarrow{f}\mathcal O_{\mathbb P_K^2}(d-3)
\longrightarrow\mathcal O_C(d-3)\longrightarrow0
$$

pada bidang projektif dan Teorema 27.4, buktikan bahwa dimensi

$$
H^0(C,\mathcal O_C(d-3))
$$

adalah

$$
\frac{(d-1)(d-2)}2.
$$

Untuk dua soal berikut, bandingkan Teorema 22.12.

<!-- upstream_entity: Projektive Gerade/Einheitengarbe/Cech-Komplex/Erste Kohomologie/Aufgabe -->

## Soal 27.11 {#br-bgk-2019-w27-ex11}

Hitung kompleks Čech berkas satuan $\mathcal O_{\mathbb P_K^1}^{\times}$
terhadap liputan afin standar pada garis projektif $\mathbb P_K^1$ di atas
lapangan $K$, serta kohomologi Čech pertamanya

$$
\check H^1\!\left(
D_+(X),D_+(Y),\mathcal O_{\mathbb P_K^1}^{\times}
\right).
$$

<!-- upstream_entity: Projektive Ebene/Einheitengarbe/Cech-Komplex/Erste Kohomologie/Aufgabe -->

## Soal 27.12 {#br-bgk-2019-w27-ex12}

Hitung kompleks Čech berkas satuan $\mathcal O_{\mathbb P_K^2}^{\times}$
terhadap liputan afin standar pada bidang projektif $\mathbb P_K^2$ di atas
lapangan $K$, serta kohomologi Čech pertamanya

$$
\check H^1\!\left(
D_+(X),D_+(Y),D_+(Z),\mathcal O_{\mathbb P_K^2}^{\times}
\right).
$$

<!-- upstream_entity: Modultheorie/Exakte Komplexe/Kurze exakte Sequenzen/Aufgabe -->

## Soal 27.13 {#br-bgk-2019-w27-ex13}

Misalkan $R$ gelanggang komutatif dan $M_i$, $i\in\mathbb N$, modul-modul
$R$ dengan homomorfisme modul $R$ tetap

$$
\varphi_i:M_i\longrightarrow M_{i+1}.
$$

Barisan

$$
\cdots\longrightarrow M_i\longrightarrow M_{i+1}
\longrightarrow M_{i+2}\longrightarrow M_{i+3}\longrightarrow\cdots
$$

disebut eksak jika, untuk setiap $i$,

$$
\ker(\varphi_i)=\operatorname{im}(\varphi_{i-1}).
$$

1. Buktikan bahwa dalam kasus barisan pendek eksak, definisi ini sama dengan
   [definisi barisan pendek eksak yang dirujuk dalam sumber](https://de.wikiversity.org/wiki/Modultheorie_(kommutative_Algebra)/Kurze_exakte_Sequenz/Definition).

2. Sekarang misalkan $R=K$ suatu lapangan, semua $M_i$ dibangkitkan secara
   hingga, $M_0=0$, dan $M_i=0$ untuk setiap $i\geq n$, dengan suatu $n$
   tertentu.
   Buktikan bahwa

   $$
   \sum_{i=0}^n(-1)^i\dim_KM_i=0.
   $$

> **Catatan edisi - label rujukan yang tidak lengkap.** Pada kalimat
> perbandingan di atas, sumber yang dibekukan menampilkan teks tautan
> "Definition ." tanpa nomor, tetapi target tautannya tersedia. Edisi
> mempertahankan target itu dan memberi label Indonesia yang deskriptif tanpa
> mengarang nomor definisi.

<!-- upstream_entity: Projektiver Raum/Getwistete Strukturgarben/Euler-Charakteristik/Aufgabe -->

## Soal 27.14 {#br-bgk-2019-w27-ex14}

Hitung karakteristik Euler berkas struktur terpuntir
$\mathcal O_{\mathbb P_K^d}(n)$ pada ruang projektif $\mathbb P_K^d$ di atas
lapangan $K$ yang tertutup secara aljabar.
