---
title: "Kuliah 25 - Kohomologi Berkas"
stable_id: br-bgk-2019-l25
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 25"
upstream_pageid: 109029
upstream_revid: 1003754
upstream_timestamp: "2025-06-08T16:38:19Z"
upstream_mediawiki_sha1: ca0f902e2615027938e7edf18cf1641135b671c2
source_url: "https://de.wikiversity.org/w/index.php?oldid=1003754"
authority_manifest: authority/wikiversity-bgk/unit-25/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: f454cb2f8ada795015dcf78d4ad56a54107d9773705b7113a1ef1600b341e26d
authority_manifest_status: "Bekuan authority terminal lengkap; 33 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
lecture_xml: authority/wikiversity-bgk/unit-25/lecture-25.xml
lecture_xml_sha256: 43bf0cf4fea0330c8e10880c0e294f7faa2af3518ebeac27b52acd9c286f9ae6
lecture_expanded_tex: authority/wikiversity-bgk/unit-25/lecture-25-expanded.tex
lecture_expanded_tex_sha256: 6b21b42534b078a965f972c0571de6df58ef903764a6bc99c1dcf0b1f77ef215
official_pdf: authority/artifacts/bgk-lecture-25-official.pdf
official_pdf_sha256: f1de2ae26d338559fc894fdc3334bc62a5d1cf858ae5b96f66dc71b3b331c1af
official_pdf_source_bytes: 85771
official_pdf_source_sha1: 5080f80897bce4afc8bea685e72ef8288e9f559c
official_pdf_metadata: authority/wikiversity-bgk/unit-25/official-pdfs-api.json
official_pdf_metadata_sha256: f49c28f3f600974f8cd7bcf29377dbad5429e789769d0953fc28075adce5c767
older_course_pdf: authority/artifacts/bgk-course-official.pdf
older_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
authority_precedence: "Revisi semantik Wikiversity yang dibekukan mengendalikan teks; PDF resmi dipertahankan sebagai saksi historis tanpa menimpa revisi yang lebih baru."
media_credits: source/id-ID/media-credits-bgk-unit-25.md
media_credits_sha256: c0367344876a648ab7141eb306e6a9a02f14c47b3b57a03012073940f4297037
rights_ledger: authority/RIGHTS-bgk-unit-25.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-25.json
asset_closure_sha256: b897e839fc6999e5c149e1bf065a634b96246b563860d46f0a16ddb82ae1c9d5
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF adalah saksi authority, bukan teks edisi; metadata Commons CC BY-SA 4.0 dan pemberitahuan tertanam CC-by-sa 3.0 dipertahankan tanpa pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 25: Kohomologi Berkas {#br-bgk-2019-l25}

## Kohomologi berkas {#br-bgk-2019-l25-s01}

<!-- upstream_entity: Topologischer Raum/Garbe/Kohomologie/Definition -->

### Definisi 25.1: kohomologi berkas {#br-bgk-2019-l25-def-01}

Misalkan $\mathcal G$ berkas grup komutatif pada ruang topologis $X$. Funktor
turunan kanan ke-$n$ dari funktor evaluasi global $\Gamma(X,-)$ disebut
*kohomologi berkas ke-$n$* dari $\mathcal G$ pada $X$. Funktor ini dilambangkan
dengan

$$
H^n(X,\mathcal G):=R^n\Gamma(X,\mathcal G).
$$

<!-- upstream_entity: Topologischer Raum/Garbe/Kohomologie/Grundlegende Eigenschaften/Fakt -->

### Korolari 25.2: sifat-sifat dasar kohomologi berkas {#br-bgk-2019-l25-cor-01}

Misalkan $X$ ruang topologis. Kohomologi berkas memenuhi sifat-sifat berikut.

1. Untuk setiap $n\in\mathbb N$, $H^n(X,-)$ adalah funktor aditif dari
   kategori berkas grup komutatif pada $X$ ke kategori grup abelian.
2. Terdapat isomorfisme alami
   $H^0(X,\mathcal G)\cong\Gamma(X,\mathcal G)$.
3. Untuk barisan berkas eksak pendek

   $$
   0\longrightarrow\mathcal F\longrightarrow\mathcal G
   \longrightarrow\mathcal H\longrightarrow 0,
   $$

   terdapat barisan kohomologi eksak panjang

   $$
   \begin{aligned}
   0&\longrightarrow\Gamma(X,\mathcal F)
   \longrightarrow\Gamma(X,\mathcal G)
   \longrightarrow\Gamma(X,\mathcal H)
   \longrightarrow H^1(X,\mathcal F)\\
   &\longrightarrow H^1(X,\mathcal G)
   \longrightarrow H^1(X,\mathcal H)
   \longrightarrow H^2(X,\mathcal F)
   \longrightarrow\cdots.
   \end{aligned}
   $$

#### Bukti {#br-bgk-2019-l25-cor-01-proof}

Ini merupakan kasus khusus Teorema 24.7.

Secara umum, grup kohomologi sulit dihitung. Berikut beberapa cara dasar untuk
melakukan perhitungan.

1. *Teorema pelenyapan:* dibuktikan bahwa grup kohomologi bernilai $0$ untuk
   ruang, berkas, dan indeks tertentu. Jika suatu suku dalam barisan
   kohomologi eksak panjang bernilai $0$, maka pemetaan sebelumnya surjektif
   dan pemetaan sesudahnya injektif.
2. Sebagai ganti berkas injektif, kita dapat bekerja dengan berkas asiklik lain,
   misalnya berkas flasid.
3. $H^1$ dapat ditafsirkan sebagai grup pengklasifikasi untuk objek geometris
   tertentu, misalnya grup Picard.
4. Jika berkas-berkas tersebut adalah modul pada ruang berdering, grup
   kohomologinya juga mempunyai struktur modul atas gelanggang seksi global
   $\Gamma(X,\mathcal O_X)$; lihat Lema 25.5. Jika gelanggang ini suatu
   lapangan, sebagaimana khususnya terjadi untuk varietas projektif terhubung,
   grup kohomologi bahkan merupakan ruang vektor. Dalam kasus berdimensi
   hingga, dimensinya merupakan invarian penting.
5. Kohomologi pada $X$ dapat dibandingkan dengan kohomologi pada suatu
   subhimpunan terbuka.
6. Kohomologi berkas dapat dibandingkan dengan teori kohomologi lain:
   kohomologi Čech, kohomologi singular, dan kohomologi simplisial.

<!-- upstream_entity: Topologischer Raum/Welke Garbe/Azyklisch/Fakt -->

### Lema 25.3: berkas flasid bersifat asiklik {#br-bgk-2019-l25-lem-01}

Suatu berkas flasid $\mathcal G$ pada ruang topologis $X$ bersifat asiklik;
artinya,

$$
H^n(X,\mathcal G)=0
$$

untuk $n\geq 1$.

#### Bukti {#br-bgk-2019-l25-lem-01-proof}

Menurut Lema 23.13 terdapat pembenaman $\mathcal G$ ke suatu berkas injektif
$\mathcal I$. Kita meninjau barisan berkas eksak pendek yang terkait,

$$
0\longrightarrow\mathcal G\longrightarrow\mathcal I
\longrightarrow\mathcal I/\mathcal G\longrightarrow 0.
$$

Menurut Lema 23.16, $\mathcal I$ adalah berkas flasid. Kemudian menurut Lema
23.15 (2), berkas hasil bagi $\mathcal I/\mathcal G$ juga flasid. Dengan
menggunakan Teorema 24.8, barisan kohomologi eksak panjang di satu pihak
memberi

$$
0\longrightarrow\Gamma(X,\mathcal G)
\longrightarrow\Gamma(X,\mathcal I)
\longrightarrow\Gamma(X,\mathcal I/\mathcal G)
\longrightarrow H^1(X,\mathcal G)\longrightarrow 0,
$$

dan di pihak lain memberi

$$
0\longrightarrow H^n(X,\mathcal I/\mathcal G)
\xrightarrow{\delta^n}H^{n+1}(X,\mathcal G)
\longrightarrow 0
$$

untuk $n\geq 1$. Karena pemetaan

$$
\Gamma(X,\mathcal I)\longrightarrow\Gamma(X,\mathcal I/\mathcal G)
$$

surjektif menurut Lema 23.15 (1), potongan pertama menunjukkan bahwa
$H^1(X,\mathcal G)=0$. Ini berlaku bagi semua berkas flasid. Dengan menerapkan
potongan kedua, yang menurut sumber diterapkan untuk $n=2$, kita memperoleh
$H^2(X,\mathcal G)=0$, dan seterusnya.

> **Catatan edisi - indeks pada langkah induksi.** Rumus yang ditampilkan
> menghubungkan $H^n(X,\mathcal I/\mathcal G)$ dengan
> $H^{n+1}(X,\mathcal G)$, sehingga kesimpulan tentang $H^2$ secara formal
> memakai $n=1$. Sumber cetak menyebut $n=2$; edisi mempertahankan keterangan
> sumber dan mencatat ketidakcocokan ini secara eksplisit.

<!-- upstream_entity: Topologischer Raum/Topologische Gruppe/Garbe/Welke Auflösung/Bemerkung -->

### Catatan 25.4: kelas kohomologi pertama berkas fungsi kontinu {#br-bgk-2019-l25-rem-01}

Misalkan $G$ grup topologis dan $X$ ruang topologis. Kita meninjau berkas
pemetaan kontinu ke $G$, yaitu $C^0(-,G)$, dengan

$$
C^0(U,G)=\{f:U\longrightarrow G\text{ pemetaan}\mid f\text{ kontinu}\}.
$$

Terdapat inklusi alami berkas

$$
C^0(-,G)\subseteq\operatorname{Abb}(-,G),
$$

dan karena itu terdapat barisan berkas eksak pendek

$$
0\longrightarrow C^0(-,G)
\longrightarrow\operatorname{Abb}(-,G)
\longrightarrow\operatorname{Abb}(-,G)/C^0(-,G)
\longrightarrow 0.
$$

Berkas pemetaan di tengah bersifat flasid, sebab setiap pemetaan dapat
diperluas ke himpunan yang lebih besar. Oleh karena itu, menurut Lema 25.3,

$$
H^1(X,\operatorname{Abb}(-,G))=0,
$$

sehingga barisan kohomologi eksak panjang dimulai dengan

$$
\begin{aligned}
0&\longrightarrow C^0(X,G)
\longrightarrow\operatorname{Abb}(X,G)
\longrightarrow\Gamma\bigl(X,\operatorname{Abb}(-,G)/C^0(-,G)\bigr)\\
&\longrightarrow H^1(X,C^0(-,G))\longrightarrow 0.
\end{aligned}
$$

Jadi setiap kelas kohomologi pertama untuk $C^0(-,G)$ direpresentasikan oleh
suatu unsur global dari berkas hasil bagi
$\operatorname{Abb}(-,G)/C^0(-,G)$. Dua wakil demikian mendefinisikan kelas
yang sama tepat ketika selisihnya berasal dari suatu pemetaan $X\to G$.

Seperti untuk setiap berkas hasil bagi, menurut Lema 5.9 (1), suatu unsur
global direpresentasikan oleh penutup terbuka

$$
X=\bigcup_{i\in I}U_i
$$

dan seksi $f_i\in\Gamma(U_i,\operatorname{Abb}(-,G))$, yakni pemetaan
$f_i:U_i\to G$, sedemikian sehingga selisih

$$
f_i-f_j\big|_{U_i\cap U_j}
$$

berasal dari subberkas, yakni merupakan fungsi kontinu pada $U_i\cap U_j$.
Menurut Lema 5.9 (2), unsur demikian berasal dari sebelah kiri, dan dengan
demikian dipetakan ke kelas kohomologi trivial, tepat ketika terdapat fungsi
$f:X\to G$ sedemikian sehingga

$$
g_i:=f_i-f\big|_{U_i}
$$

kontinu untuk setiap $i$. Dalam hal ini, pada $U_i\cap U_j$ berlaku

$$
g_i-g_j=f_i-f-(f_j-f)=f_i-f_j.
$$

Sebaliknya, jika terdapat keluarga fungsi kontinu $g_i$ pada $U_i$ yang
selisih-selisihnya sama dengan selisih yang diberikan, maka pada $U_i$ kita
dapat mendefinisikan

$$
f:=f_i-g_i.
$$

Karena kondisi ini kompatibel pada irisan, definisi-definisi tersebut
menghasilkan suatu fungsi global pada $X$. Dengan demikian, grup kohomologi
pertama berkas fungsi kontinu trivial tepat ketika untuk setiap keluarga
$(U_i,f_i)$ dengan $f_i-f_j$ kontinu, terdapat keluarga $(U_i,g_i)$ dengan
$g_i$ kontinu dan mempunyai selisih yang sama.

<!-- upstream_entity: Beringter Raum/Modul/Garbenkohomologie/Modulstruktur/Fakt -->

### Lema 25.5: struktur modul pada kohomologi berkas {#br-bgk-2019-l25-lem-02}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal M$ suatu modul
$\mathcal O_X$. Maka kohomologi berkas $H^i(X,\mathcal M)$ secara alami
merupakan modul $\Gamma(X,\mathcal O_X)$.

#### Bukti {#br-bgk-2019-l25-lem-02-proof}

Setiap unsur $f\in\Gamma(X,\mathcal O_X)$ mendefinisikan homomorfisme modul
$\mathcal O_X$

$$
f:\mathcal M\longrightarrow\mathcal M.
$$

Pada setiap himpunan terbuka $U\subseteq X$, pembatasan $f$ ke
$\Gamma(U,\mathcal O_X)$ bekerja melalui perkalian skalar, yakni

$$
\Gamma(U,\mathcal M)\longrightarrow\Gamma(U,\mathcal M),
\qquad s\longmapsto fs.
$$

Perkalian dengan $f$ khususnya merupakan homomorfisme berkas grup komutatif.
Berdasarkan kefunktoran kohomologi berkas dalam Korolari 25.2, homomorfisme ini
menginduksi homomorfisme grup

$$
H^n(f):H^n(X,\mathcal M)\longrightarrow H^n(X,\mathcal M).
$$

Kita harus menunjukkan bahwa pemetaan

$$
\Gamma(X,\mathcal O_X)\times H^n(X,\mathcal M)
\longrightarrow H^n(X,\mathcal M),
\qquad(f,c)\longmapsto H^n(f)(c),
$$

menentukan struktur modul pada $H^n(X,\mathcal M)$. Karena $H^n(f)$ suatu
homomorfisme grup, aditivitas pada modul telah terjamin. Berdasarkan
kefunktoran, $1$ dipetakan ke identitas, mula-mula sebagai homomorfisme berkas
dan kemudian dalam kohomologi. Kompatibilitas dengan komposisi memberi

$$
H^n(fg)=H^n(f)\circ H^n(g).
$$

Untuk unsur gelanggang global $f,g$, perkalian skalar oleh $f+g$ pada tingkat
berkas modul adalah jumlah perkalian skalar oleh $f$ dan oleh $g$. Karena
$H^n$ funktor aditif, berlaku pula

$$
H^n(f+g)=H^n(f)+H^n(g).
$$

## Kohomologi pada skema {#br-bgk-2019-l25-s02}

Sekarang kita meninjau kohomologi berkas pada skema.

<!-- upstream_entity: Schema/Integer/Strukturgarbe/Funktionenkörper/Erste Kohomologie/Fakt -->

### Lema 25.6: kohomologi pertama melalui lapangan fungsi {#br-bgk-2019-l25-lem-03}

Misalkan $(X,\mathcal O_X)$ skema integral dengan lapangan fungsi $K$, yang
kita pandang sebagai berkas konstan $\mathcal K$ pada $X$. Maka

$$
H^1(X,\mathcal O_X)
=\Gamma(X,\mathcal K/\mathcal O_X)
/\operatorname{im}\bigl(K\longrightarrow
\Gamma(X,\mathcal K/\mathcal O_X)\bigr).
$$

#### Bukti {#br-bgk-2019-l25-lem-03-proof}

Karena $X$ khususnya tak tereduksi, praberkas konstan bernilai $K$ merupakan
berkas. Menurut Lema 11.16 terdapat homomorfisme berkas injektif

$$
\mathcal O_X\longrightarrow\mathcal K,
$$

dan dengan demikian barisan berkas eksak pendek

$$
0\longrightarrow\mathcal O_X\longrightarrow\mathcal K
\longrightarrow\mathcal K/\mathcal O_X\longrightarrow 0.
$$

Barisan kohomologi eksak panjang yang terkait adalah

$$
\begin{aligned}
0&\longrightarrow\Gamma(X,\mathcal O_X)
\longrightarrow\Gamma(X,\mathcal K)
\longrightarrow\Gamma(X,\mathcal K/\mathcal O_X)\\
&\longrightarrow H^1(X,\mathcal O_X)
\longrightarrow H^1(X,\mathcal K)\longrightarrow\cdots.
\end{aligned}
$$

Sebagai berkas konstan, $\mathcal K$ flasid dan dengan demikian asiklik
menurut Lema 25.3. Khususnya,

$$
H^1(X,\mathcal K)=0.
$$

Jadi $H^1(X,\mathcal O_X)$ adalah kokernel pemetaan yang mendahuluinya.

<!-- upstream_entity: Affines Schema/Integer/Strukturgarbe/Funktionenkörper/Erste Kohomologie/Fakt -->

### Lema 25.7: pelenyapan pada skema afin integral {#br-bgk-2019-l25-lem-04}

Misalkan $R$ daerah integral dan

$$
\operatorname{Spek}(R)=(X,\mathcal O_X)
$$

skema afin integral yang terkait. Maka

$$
H^1(X,\mathcal O_X)=0.
$$

#### Bukti {#br-bgk-2019-l25-lem-04-proof}

Kita meninjau barisan eksak pendek modul $R$

$$
0\longrightarrow R\longrightarrow K\longrightarrow K/R\longrightarrow 0
$$

dan, menurut Lema 14.9, barisan eksak berkas kuasikoheren yang terkait,

$$
0\longrightarrow\mathcal O_X\longrightarrow\widetilde K
\longrightarrow\widetilde{K/R}\longrightarrow 0.
$$

Khususnya,

$$
\widetilde{K/R}=\widetilde K/\mathcal O_X,
$$

dan $\widetilde K$ adalah berkas konstan untuk lapangan fungsi. Evaluasi
global barisan berkas ini menghasilkan kembali barisan awal. Pernyataan
sekarang mengikuti dari Lema 25.6.

<!-- upstream_entity: Affine punktierte Ebene/Strukturgarbe/Erste Kohomologie/Beispiel -->

### Contoh 25.8: bidang afin berlubang {#br-bgk-2019-l25-exm-01}

Kita meninjau bidang afin berlubang

$$
U=\mathbb A_K^2\setminus\{(0,0)\}
$$

di atas lapangan $K$ dan ingin memahami $H^1(U,\mathcal O_U)$ dengan bantuan
Lema 25.7. Lapangan fungsinya adalah $K(X,Y)$; berkas konstan yang terkait
kita lambangkan dengan $\mathcal Q$. Barisan kohomologi eksak panjang dimulai
dengan

$$
0\longrightarrow K[X,Y]\longrightarrow K(X,Y)
\longrightarrow\Gamma(U,\mathcal Q/\mathcal O_U)
\longrightarrow H^1(X,\mathcal O_U)\longrightarrow 0.
$$

> **Catatan edisi - simbol ruang pada sumber.** Sumber cetak menuliskan
> $H^1(X,\mathcal O_U)$ pada barisan di atas, meskipun contoh, evaluasi, dan
> suku-suku lain membahas $U$. Edisi mempertahankan simbol sumber dan tidak
> menggantinya secara diam-diam.

Kita mempunyai $U=D(X)\cup D(Y)$. Tinjau seksi
$\Gamma(U,\mathcal Q/\mathcal O_U)$ berbentuk

$$
(D(X),X^\alpha Y^\beta;D(Y),0),
\qquad\alpha,\beta\in\mathbb Z.
$$

Jadi seksi itu ditentukan pada $D(X)$ oleh fungsi rasional $X^\alpha Y^\beta$
dan pada $D(Y)$ oleh fungsi rasional $0$. Selisihnya hanyalah
$X^\alpha Y^\beta$, yang termasuk berkas struktur pada irisan
$D(X)\cap D(Y)=D(XY)$. Karena itu kita benar-benar memperoleh suatu seksi
berkas hasil bagi; bandingkan Lema 5.9.

Kita menentukan, bergantung pada $\alpha$ dan $\beta$, apakah seksi ini
terletak dalam citra. Hal itu ekuivalen dengan menanyakan apakah seksi ini
mendefinisikan unsur trivial dalam kohomologi pertama. Berasal dari sebelah
kiri berarti terdapat fungsi rasional $q\in K(X,Y)$ yang bersesuaian dengan
seksi tersebut. Artinya, selisih pada $D(X)$ dan $D(Y)$ berasal dari berkas
struktur, sehingga sekaligus

$$
q-X^\alpha Y^\beta\in\Gamma(D(X),\mathcal O_U)
$$

dan

$$
q-0\in\Gamma(D(Y),\mathcal O_U).
$$

Syarat kedua berarti

$$
q=\frac h{Y^n},
$$

sedangkan syarat pertama berarti

$$
\frac h{Y^n}-X^\alpha Y^\beta=\frac g{X^m}.
$$

Dengan demikian, pertanyaannya adalah apakah persamaan

$$
X^\alpha Y^\beta=\frac h{Y^n}-\frac g{X^m}
$$

mempunyai solusi dengan $g,h\in K[X,Y]$ dan $m,n\in\mathbb N$. Jika
$\alpha\geq 0$ atau $\beta\geq 0$, solusi demikian ada. Jika
$\alpha,\beta<0$, solusi tidak mungkin ada, karena ruas kanan sama dengan

$$
\frac{hX^m-gY^n}{X^mY^n}.
$$

Perkalian dengan $X^mY^n$ memperlihatkan ketidakmungkinan itu: ideal
$(X^m,Y^n)$ hanya memuat monomial yang merupakan kelipatan salah satu
pembangkitnya.

<!-- upstream_entity: Polynomring/Syzygiengarbe zu Variablen/Erste Kohomologie/Beispiel -->

### Contoh 25.9: kohomologi berkas syzygy {#br-bgk-2019-l25-exm-02}

Kita melanjutkan Contoh 16.9. Pada gelanggang polinomial

$$
R=K[X_1,\ldots,X_n],\qquad n\geq 2,
$$

kita meninjau barisan eksak pendek

$$
0\longrightarrow\operatorname{Syz}(X_1,\ldots,X_n)
\longrightarrow R^n\longrightarrow(X_1,\ldots,X_n)
\longrightarrow 0.
$$

Pembatasan barisan berkas yang terkait ke ruang berlubang

$$
U=\mathbb A_K^n\setminus\{(0,\ldots,0)\}
$$

adalah

$$
0\longrightarrow
\mathcal S
=\widetilde{\operatorname{Syz}(X_1,\ldots,X_n)}
\longrightarrow\mathcal O_U^n\longrightarrow\mathcal O_U
\longrightarrow 0.
$$

Evaluasi barisan berkas ini pada $U$ memberi

$$
\begin{aligned}
0&\longrightarrow\operatorname{Syz}(X_1,\ldots,X_n)
\longrightarrow R^n\longrightarrow R
\longrightarrow H^1(U,\mathcal S)\\
&\longrightarrow H^1(U,\mathcal O_U^n)\longrightarrow.
\end{aligned}
$$

> **Catatan edisi - ujung barisan eksak.** Sumber cetak mengakhiri barisan di
> atas dengan sebuah panah tanpa menampilkan suku berikutnya. Edisi
> mempertahankan ujung tercetak itu dan tidak menambahkan elipsis atau suku
> yang tidak dicetak.

Karena citra pemetaan $R^n\to R$ tetap merupakan ideal maksimal, pemetaan ini
tidak surjektif. Oleh sebab itu,

$$
H^1(U,\mathcal S)\ne 0.
$$

<!-- upstream_entity: Schema/Integer/Einheitengarbe/Funktionenkörpergruppe/Erste Kohomologie/Fakt -->

### Lema 25.10: kohomologi pertama berkas satuan {#br-bgk-2019-l25-lem-05}

Misalkan $(X,\mathcal O_X)$ skema integral dengan lapangan fungsi $K$.
Misalkan $\mathcal O_X^\times$ berkas satuan pada $X$, dan misalkan
$\mathcal U$ berkas konstan untuk $K^\times$. Maka

$$
H^1(X,\mathcal O_X^\times)
=\Gamma(X,\mathcal U/\mathcal O_X^\times)
/\operatorname{im}\bigl(K^\times\longrightarrow
\Gamma(X,\mathcal U/\mathcal O_X^\times)\bigr).
$$

#### Bukti {#br-bgk-2019-l25-lem-05-proof}

Lihat Soal 25.10.

Berikut kita sebutkan tanpa bukti beberapa teorema penting.

<!-- upstream_entity: Noethersches Schema/Affin/Kohomologisches Kriterium/Fakt -->

### Teorema 25.11: kriteria kohomologis untuk keafinan {#br-bgk-2019-l25-thm-01}

Misalkan $X$ skema Noether. Sifat-sifat berikut ekuivalen.

1. $X$ adalah skema afin.
2. Untuk setiap berkas kuasikoheren $\mathcal F$ pada $X$ berlaku
   $H^i(X,\mathcal F)=0$.
3. Untuk setiap berkas ideal koheren $\mathcal I$ pada $X$ berlaku
   $H^1(X,\mathcal I)=0$.

<!-- upstream_entity: Noetherscher Raum/Dimension/Kohomologie/Verschwindungssatz/Fakt -->

### Teorema 25.12: pelenyapan di atas dimensi ruang {#br-bgk-2019-l25-thm-02}

Misalkan $X$ ruang topologis Noether berdimensi $d$. Maka

$$
H^i(X,\mathcal G)=0
$$

untuk $i>d$ dan setiap berkas grup komutatif $\mathcal G$.
