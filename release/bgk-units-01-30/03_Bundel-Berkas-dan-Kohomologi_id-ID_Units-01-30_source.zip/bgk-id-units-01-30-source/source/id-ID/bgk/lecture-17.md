---
title: "Kuliah 17 - Bundel Vektor Geometris"
stable_id: br-bgk-2019-l17
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 17"
upstream_pageid: 109021
upstream_revid: 1019984
upstream_timestamp: "2025-08-09T13:37:26Z"
upstream_mediawiki_sha1: b4e1dbede8d862ac8bd1b25d94157448625ff938
source_url: "https://de.wikiversity.org/w/index.php?oldid=1019984"
authority_manifest: authority/wikiversity-bgk/unit-17/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: b896a47254cbbea5f77f5eecaa1f8db99fe24c662fc9ba56e10f9db1be186b99
authority_manifest_status: "Bekuan authority terminal lengkap; 31 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
lecture_xml: authority/wikiversity-bgk/unit-17/lecture-17.xml
lecture_xml_sha256: 91665b82598c78819adc45fbec423266a7fb9bd89ec59eb5cb269d24fb35fa74
lecture_expanded_tex: authority/wikiversity-bgk/unit-17/lecture-17-expanded.tex
lecture_expanded_tex_sha256: 38a95b240a54ec4f26529e06d774fdc3196e3f0d73431e94bea06b4465919d42
official_pdf: authority/artifacts/bgk-lecture-17-official.pdf
official_pdf_sha256: d451a9af49bf0734c3d212a5b07e7152b9b6c067d6b87fe9c9cd3923f7cb4a3b
official_pdf_status: "Saksi PDF resmi lokal; 96.487 byte, 9 halaman, dan SHA-1 unggahan 583a63cef01d8c7ef948f3b69ed860f31de8b6ac telah diverifikasi."
official_pdf_metadata: authority/wikiversity-bgk/unit-17/official-pdfs-api.json
official_pdf_source_bytes: 96487
official_pdf_source_sha1: 583a63cef01d8c7ef948f3b69ed860f31de8b6ac
older_course_pdf: authority/artifacts/bgk-course-official.pdf
older_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
authority_precedence: "Revisi semantik Wikiversity yang dibekukan mengendalikan teks; PDF seluruh kursus tahun 2020 hanya saksi historis."
media_credits: source/id-ID/media-credits-bgk-unit-17.md
rights_ledger: authority/RIGHTS-bgk-unit-17.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-17.json
asset_closure_sha256: 1173bbfd2583a146d58bee689a94fdaa143b543da0b3f4dbc89fe869d57037cb
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF adalah saksi authority, bukan teks edisi; metadata Commons CC BY-SA 4.0 dan pemberitahuan tertanam CC-by-sa 3.0 dipertahankan tanpa pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 17: Bundel Vektor Geometris {#br-bgk-2019-l17}

## Bundel vektor geometris {#br-bgk-2019-l17-s01}

Untuk skema afin

$$
U=\operatorname{Spek}(R),
$$

skema

$$
\mathbb A_U^r:=\operatorname{Spek}(R[T_1,\ldots,T_r])
$$

bersama proyeksi alaminya ke $\operatorname{Spek}(R)$, yakni pemetaan
spektrum yang berasal dari

$$
R\longrightarrow R[T_1,\ldots,T_r],
$$

disebut *bundel trivial ber-rank $r$ di atas $U$*. Untuk titik
$P\in\operatorname{Spek}(R)$ yang bersesuaian dengan homomorfisme gelanggang

$$
R\longrightarrow\kappa(P),
$$

serat $\mathbb A_U^r$ di atas $P$ adalah $\mathbb A_{\kappa(P)}^r$, yaitu
ruang afin berdimensi $r$ di atas lapangan residu $\kappa(P)$.

Untuk skema sembarang $X$ dengan penutup afin

$$
X=\bigcup_{i\in I}U_i,
$$

kita mendefinisikan $\mathbb A_X^r$ dengan mengeleman
$\mathbb A_{U_i}^r$ sebagaimana pengeleman $U_i$ di dalam $X$, menurut
Lema 7.10. Bundel trivial ber-rank $r$ ini dilengkapi proyeksi

$$
\mathbb A_X^r\longrightarrow X.
$$

Objek ini juga disebut *silinder afin ber-rank $r$ di atas $X$* dan ditulis
$X\times\mathbb A^r$. Bundel-bundel trivial tersebut merupakan blok bangunan
lokal bagi konsep bundel vektor geometris di atas suatu skema.

<!-- upstream_entity: Schema/Geometrisches Vektorbündel/Als Schema/Definition -->

### Definisi 17.1: bundel vektor geometris {#br-bgk-2019-l17-def-01}

Misalkan $X$ suatu skema. Skema $V$ bersama morfisme

$$
p:V\longrightarrow X
$$

disebut *bundel vektor geometris ber-rank $r$ di atas $X$* jika terdapat
penutup terbuka

$$
X=\bigcup_{i\in I}U_i
$$

dan isomorfisme-$U_i$

$$
\psi_i:U_i\times\mathbb A^r=\mathbb A_{U_i}^r
\longrightarrow V|_{U_i}=p^{-1}(U_i)
$$

sedemikian sehingga, untuk setiap subhimpunan terbuka afin
$U\subseteq U_i\cap U_j$, pemetaan perubahan basis

$$
\psi_j^{-1}\circ\psi_i:
\mathbb A_{U_i}^r|_U\longrightarrow\mathbb A_{U_j}^r|_U
$$

merupakan automorfisme linear. Pada tingkat gelanggang, pemetaan ini berarti
diinduksi oleh automorfisme gelanggang polinomial
$\Gamma(U,\mathcal O_X)[T_1,\ldots,T_r]$ berbentuk

$$
T_i\longmapsto\sum_{j=1}^r a_{ij}T_j.
$$

Pemetaan $\psi_i$ disebut *trivialisasi* bundel vektor tersebut.

Contoh berikut melanjutkan Contoh 14.6.

<!-- upstream_entity: Ganzheitsring/Wurzel -5/Standardideal/Geometrisches Geradenbündel/Beispiel -->

### Contoh 17.2: bundel garis dari ideal standar {#br-bgk-2019-l17-exm-01}

Kita tinjau daerah bilangan kuadratik

$$
R=\mathbb Z[\sqrt{-5}],
$$

tempat berlaku kesamaan

$$
2\cdot3=6=(1+\sqrt5\,i)(1-\sqrt5\,i),
$$

serta aljabar-$R$

$$
A=R[X,Y]/(3X-(1-i\sqrt5)Y)
$$

dengan pemetaan spektrum terkait
$\operatorname{Spek}(A)\to\operatorname{Spek}(R)$. Kita mengklaim bahwa
objek ini merupakan bundel garis geometris. Untuk itu gunakan penutup terbuka

$$
\operatorname{Spek}(R)=D(2)\cup D(3).
$$

Kita mempunyai

$$
A_2=R_2[X,Y]/(3X-(1-i\sqrt5)Y)\cong R_2[S]
$$

dengan $X\mapsto2S$ dan $Y\mapsto(1+i\sqrt5)S$. Memang,
$S=X/2$, sehingga $X=2S$, dan

$$
Y=\frac{3}{1-i\sqrt5}X
=\frac{1+i\sqrt5}{2}X
=(1+i\sqrt5)S.
$$

Demikian pula,

$$
A_3=R_3[X,Y]/(3X-(1-i\sqrt5)Y)\cong R_3[T]
$$

dengan $X\mapsto(1-i\sqrt5)T$ dan $Y\mapsto3T$. Memang, $T=Y/3$,
sehingga $Y=3T$ dan, sebagaimana tercetak pada sumber,

$$
X=\frac{1-i\sqrt5}{3}Y={1-i\sqrt5|}T.
$$

Pada
$D(6)=D(2)\cap D(3)$, pemetaan perubahannya diberikan oleh

$$
S=\frac X2=\frac{1-i\sqrt5}{2}T,
$$

dan karena itu linear.

<!-- upstream_entity: Affiner Raum/Punktiert/Syzygienbündel/Beispiel -->

### Contoh 17.3: bundel syzygy pada ruang afin tertusuk {#br-bgk-2019-l17-exm-02}

Kita tinjau homomorfisme gelanggang

$$
K[X,Y,Z]\longrightarrow
K[X,Y,Z][U,V,W]/(XU+YV+ZW),
$$

pemetaan spektrum terkait

$$
\operatorname{Spek}
\bigl(K[X,Y,Z][U,V,W]/(XU+YV+ZW)\bigr)
\longrightarrow\mathbb A_K^3,
$$

serta pembatasannya

$$
\begin{aligned}
\varphi:\quad
\operatorname{Spek}
\bigl(K[X,Y,Z][U,V,W]/(XU+YV+ZW)\bigr)
&\supseteq D(X)\cup D(Y)\cup D(Z)\\
&\longrightarrow
\mathbb A_K^3\setminus\{(0,0,0)\}
=D(X)\cup D(Y)\cup D(Z).
\end{aligned}
$$

Pembatasan terakhir ini merupakan bundel vektor geometris ber-rank $2$ di
atas ruang afin tertusuk. Trivialisasi alaminya diberikan pada $D(X)$,
$D(Y)$, dan $D(Z)$; bandingkan Contoh 1.2. Sebagai contoh,

$$
\bigl(K[X,Y,Z][U,V,W]/(XU+YV+ZW)\bigr)_X
\cong K[X,Y,Z]_X[V,W],
$$

karena $U$ dapat dinyatakan sebagai

$$
U=-\frac{YV+ZW}{X}.
$$

<!-- upstream_entity: Projektiver Raum/Getwistetes Geradenbündel/Geometrische Realisierung/Beispiel -->

### Contoh 17.4: realisasi geometris bundel garis terpuntir {#br-bgk-2019-l17-exm-03}

Kita tinjau ruang projektif

$$
\mathbb P_K^n=\operatorname{Proj}(K[X_0,X_1,\ldots,X_n])
$$

dan spektrum projektif

$$
W_k=\operatorname{Proj}(K[X_0,X_1,\ldots,X_n,Y]),
$$

dengan $\deg(X_i)=1$ dan $\deg(Y)=k$. Menurut Teorema 12.11, inklusi
homogen

$$
K[X_0,X_1,\ldots,X_n]
\subset K[X_0,X_1,\ldots,X_n,Y]
$$

menginduksi morfisme skema

$$
p:W_k\supset D_+(X_0,X_1,\ldots,X_n)=V_k
\longrightarrow\mathbb P_K^n.
$$

Di atas $D_+(X_i)$, pemetaan itu berbentuk

$$
D_+(X_i)
\cong\operatorname{Spek}K\left[
\frac{X_j}{X_i},\ j\ne i,\ \frac{Y}{X_i^k}
\right]
\longrightarrow
D_+(X_i)
\cong\operatorname{Spek}K\left[
\frac{X_j}{X_i},\ j\ne i
\right],
$$

jadi merupakan bundel garis trivial. Untuk $D_+(X_i)$ dan $D_+(X_j)$,
pemetaan perubahan di atas

$$
\Gamma(D_+(X_iX_j),\mathcal O_{\mathbb P_K^n})
=K\left[
\frac{X_r}{X_i},\ r\ne i,
\frac{X_s}{X_j},\ s\ne j
\right]
$$

diberikan oleh

$$
\frac{Y}{X_i^k}
\longmapsto
\frac{Y}{X_j^k}\frac{X_j^k}{X_i^k}.
$$

Pemetaan ini linear, sehingga kita memperoleh bundel garis di atas ruang
projektif.

Bundel vektor geometris memiliki struktur-struktur tambahan. Pertama,
perhatikan kasus

$$
\mathbb A_{\operatorname{Spek}(R)}^r
=\operatorname{Spek}(R[T_1,\ldots,T_r])
\longrightarrow\operatorname{Spek}(R).
$$

Homomorfisme aljabar-$R$

$$
R[T_1,\ldots,T_r]\longrightarrow R,
\qquad T_i\longmapsto0,
$$

memberi pemetaan spektrum

$$
\operatorname{Spek}(R)
\longrightarrow\operatorname{Spek}(R[T_1,\ldots,T_r]),
$$

yang merupakan pembenaman tertutup dan disebut *seksi nol*. Homomorfisme
aljabar-$R$

$$
R[T_1,\ldots,T_r]
\longrightarrow R[S_1,\ldots,S_r,T_1,\ldots,T_r],
\qquad T_i\longmapsto S_i+T_i,
$$

memberi pemetaan spektrum

$$
\alpha:\mathbb A_R^{r+r}
\cong\mathbb A_R^r\times_{\operatorname{Spek}(R)}\mathbb A_R^r
\longrightarrow\mathbb A_R^r,
$$

yang disebut penjumlahan pada bundel vektor. Selanjutnya, homomorfisme
aljabar-$R$

$$
R[T_1,\ldots,T_r]\longrightarrow R[Z,T_1,\ldots,T_r],
\qquad T_i\longmapsto ZT_i,
$$

memberi pemetaan spektrum

$$
\mathbb A_R^{r+1}
\cong\mathbb A_R^1\times_{\operatorname{Spek}(R)}\mathbb A_R^r
\longrightarrow\mathbb A_R^r,
$$

yang disebut perkalian skalar.

<!-- upstream_entity: Schema/Geometrisches Vektorbündel/Addition/Fakt -->

### Lema 17.5: operasi pada bundel vektor geometris {#br-bgk-2019-l17-lem-01}

Bundel vektor geometris $p:V\to X$ di atas skema $X$ mempunyai seksi nol

$$
X\longrightarrow V,
$$

pemetaan penjumlahan

$$
V\times_XV\longrightarrow V,
$$

dan perkalian skalar

$$
\mathbb A_X^1\times_XV\longrightarrow V.
$$

#### Bukti {#br-bgk-2019-l17-lem-01-proof}

Pada subhimpunan afin $U=\operatorname{Spek}(R)\subseteq X$ dengan
trivialisasi

$$
V|_U\cong\mathbb A_U^r
\cong\operatorname{Spek}(R[T_1,\ldots,T_r]),
$$

terdapat seksi nol yang diberikan oleh $T_i\mapsto0$. Karena pemetaan
perubahan basis linear, pada irisan $U_i\cap U_j$ seksi ini tidak bergantung
pada subhimpunan afin yang dipilih, sehingga terdefinisi dengan baik.

Keberadaan penjumlahan pada dasarnya mengikuti fakta bahwa, untuk isomorfisme
aljabar-$R$ linear

$$
\theta:R[T_1,\ldots,T_r]\longrightarrow R[U_1,\ldots,U_r],
$$

diagram

$$
\begin{CD}
R[T_1,\ldots,T_r] @>{\alpha^*}>>
R[T_1,\ldots,T_r,S_1,\ldots,S_r]\\
@V{\theta}VV @VV{\theta\times\theta}V\\
R[U_1,\ldots,U_r] @>{\alpha^*}>>
R[U_1,\ldots,U_r,V_1,\ldots,V_r]
\end{CD}
$$

komutatif. Keberadaan perkalian skalar diperoleh dengan cara serupa.

## Homomorfisme bundel vektor {#br-bgk-2019-l17-s02}

<!-- upstream_entity: Schema/Geometrisches Vektorbündel/Homomorphismus/Definition -->

### Definisi 17.6: homomorfisme bundel vektor {#br-bgk-2019-l17-def-02}

Misalkan $V$ dan $W$ bundel vektor di atas suatu skema $X$. *Homomorfisme
bundel vektor* $\varphi:V\to W$ adalah morfisme skema dari $V$ ke $W$ di atas
$X$ dengan sifat berikut. Untuk setiap titik $P\in X$, terdapat lingkungan
terbuka afin $P\in U\subseteq X$ yang memperhalus lingkungan trivialisasi
kedua bundel tersebut, yakni $U\subseteq U_i,U_j'$ untuk beberapa $i,j$, dan
komposisi

$$
\mathbb A_U^r
\xrightarrow{\ \psi_i|_U\ }V|_U
\xrightarrow{\ \varphi|_U\ }W|_U
\xrightarrow{\ \theta_j^{-1}|_U\ }\mathbb A_U^s
$$

pada tingkat gelanggang diberikan oleh homomorfisme substitusi linear.

Dalam pernyataan berikut, kernel harus dipahami sebagai pracitra seksi nol;
jadi, pada setiap serat, sebagai pracitra titik nol. Untuk homomorfisme bundel
vektor, pemetaan serat di atas setiap titik $P\in X$ diberikan oleh matriks di
atas lapangan residu $\kappa(P)$. Akan tetapi, dalam ruang afin di atas
lapangan ini terdapat titik-titik dengan lapangan residu yang sangat beragam,
sehingga konsep-konsep aljabar linear harus diterapkan dengan kehati-hatian.

<!-- upstream_entity: Schema/Geometrisches Vektorbündel/Homomorphismus/Surjektiv/Kern/Fakt -->

### Lema 17.7: kernel homomorfisme surjektif {#br-bgk-2019-l17-lem-02}

Misalkan $V$ dan $W$ bundel vektor di atas skema $X$, dan
$\varphi:V\to W$ homomorfisme bundel vektor surjektif. Maka kernel yang
diambil titik demi titik merupakan bundel vektor di atas $X$.

#### Bukti {#br-bgk-2019-l17-lem-02-proof}

Lihat Soal 17.18.

Tanpa syarat surjektivitas, kernel suatu homomorfisme bundel vektor tidak
perlu menjadi bundel vektor. Dalam Contoh 17.3, kernel yang didefinisikan
titik demi titik hanya merupakan bundel vektor pada spektrum tertusuk;
di titik nol, kernel itu berdegenerasi menjadi ruang vektor berdimensi tiga.

## Bundel vektor dan berkas bebas lokal {#br-bgk-2019-l17-s03}

<!-- upstream_entity: Schema/Geometrisches Vektorbündel/Schnitte/Definition -->

### Definisi 17.8: berkas seksi {#br-bgk-2019-l17-def-03}

Untuk bundel vektor geometris $p:V\to X$ pada suatu skema $X$, berkas
$\mathcal F$ yang pada subhimpunan terbuka $U\subseteq X$ didefinisikan oleh

$$
\Gamma(U,\mathcal F)
=\{s:U\to V|_U\text{ morfisme skema}\mid p\circ s=\operatorname{Id}_U\}
$$

disebut *berkas seksi dalam $V$*.

<!-- upstream_entity: Schema/Geometrisches Vektorbündel/Schnitte/Lokal frei/Fakt -->

### Lema 17.9: berkas seksi bebas lokal {#br-bgk-2019-l17-lem-03}

Untuk bundel vektor geometris $p:V\to X$, berkas seksi $\mathcal F$ adalah
berkas bebas lokal.

#### Bukti {#br-bgk-2019-l17-lem-03-proof}

Karena terdapat penjumlahan

$$
V\times_XV\longrightarrow V,
$$

Soal 17.19 memberi penjumlahan yang terdefinisi dengan baik pada berkas
seksi. Menurut Soal 17.11, hal ini menjadikan $\mathcal F$ berkas grup
komutatif. Perkalian skalar

$$
\mathbb A_X^1\times_XV\longrightarrow V
$$

memberi $\mathcal F$ struktur modul-$\mathcal O_X$. Untuk himpunan terbuka
$U\subseteq X$ dengan $V|_U\cong\mathbb A_U^r$, kita mempunyai

$$
\mathcal F|_U\cong(\mathcal O_X|_U)^r,
$$

sehingga $\mathcal F$ bebas lokal.

Bundel vektor geometris dan berkas bebas lokal pada hakikatnya merupakan
objek-objek yang ekuivalen.

<!-- upstream_entity: Schema/Lokal freie Garben und Vektorbündel/Äquivalenz/Fakt -->

### Teorema 17.10: kesesuaian bundel vektor dan berkas bebas lokal {#br-bgk-2019-l17-thm-01}

Pada suatu skema, bundel vektor geometris bersesuaian dengan berkas bebas
lokal. Selain itu, homomorfisme bundel vektor bersesuaian dengan
homomorfisme modul-$\mathcal O_X$.

Bundel vektor geometris $V$ di atas $X$ dipasangkan dengan berkas seksi
$\mathcal S_V$ yang bebas lokal menurut Lema 17.9. Homomorfisme bundel
vektor $\varphi:V\to W$ dipasangkan dengan homomorfisme modul
$\mathcal S_V\to\mathcal S_W$ yang memetakan seksi $s:U\to V|_U$ ke seksi
$\varphi\circ s:U\to W|_U$.

#### Bukti {#br-bgk-2019-l17-thm-01-proof}

Pertama kita tunjukkan bahwa setiap berkas bebas lokal isomorfik dengan
berkas seksi suatu bundel vektor. Berkas bebas lokal $\mathcal F$ ber-rank
$r$ diberikan oleh penutup terbuka

$$
X=\bigcup_{i\in I}U_i,
$$

dengan $U_i$ dapat dipilih afin, serta isomorfisme

$$
\varphi_i:\mathcal O_{U_i}^r\longrightarrow\mathcal F|_{U_i}.
$$

Menurut Teorema 13.10, komposisi

$$
\mathcal O_{U_i}^r|_{U_i\cap U_j}
=\mathcal O_{U_i\cap U_j}^r
\xrightarrow{\ \varphi_i|_{U_i\cap U_j}\ }
\mathcal F|_{U_i\cap U_j}
\xrightarrow{\ \varphi_j^{-1}|_{U_i\cap U_j}\ }
\mathcal O_{U_i\cap U_j}^r
=\mathcal O_{U_j}^r|_{U_i\cap U_j}
$$

diberikan oleh $e_k\mapsto f_k$ dengan

$$
f_k\in\Gamma(U_i\cap U_j,\mathcal O_{U_i\cap U_j}^r).
$$

Di sini $f_k=(f_{k\ell})_{1\leq\ell\leq r}$ dengan

$$
f_{k\ell}\in\Gamma(U_i\cap U_j,\mathcal O_X).
$$

Determinan matriks $(f_{k\ell})_{k\ell}$ merupakan unit dalam
$\Gamma(U_i\cap U_j,\mathcal O_X)$. Melalui

$$
T_k\longmapsto\sum_{\ell=1}^r f_{k\ell}S_\ell,
$$

data ini mendefinisikan isomorfisme aljabar-$\Gamma(U_i\cap U_j,\mathcal O_X)$
linear

$$
\Gamma(U_i\cap U_j,\mathcal O_X)[T_1,\ldots,T_r]
\longrightarrow
\Gamma(U_i\cap U_j,\mathcal O_X)[S_1,\ldots,S_r]
$$

dan isomorfisme skema

$$
\varphi_{ji}:\mathbb A_{U_i\cap U_j}^r
\longrightarrow\mathbb A_{U_i\cap U_j}^r,
$$

dengan bentuk yang disyaratkan dalam definisi bundel vektor geometris.

Pertimbangkan data pengeleman ruang-ruang berdering

$$
(W_i=\mathbb A_{U_i}^r,
\ W_{ij}=\mathbb A_{U_i}^r|_{U_j}\subseteq W_i,
\ \varphi_{ji}:W_{ij}\longrightarrow W_{ji}).
$$

Syarat kokikel terpenuhi karena data ini berasal dari objek global
$\mathcal F$. Menurut Lema 7.10 terdapat skema $W$ yang merealisasikan data
pengeleman ini. Proyeksi-proyeksi lokal

$$
W_i=\mathbb A_{U_i}^r\longrightarrow U_i
$$

mengeleman menjadi morfisme skema

$$
W\longrightarrow X.
$$

Berdasarkan konstruksinya, ini merupakan bundel vektor geometris di atas
$X$. Misalkan $\mathcal S$ berkas seksi $W$. Kita mengklaim bahwa terdapat
isomorfisme alami

$$
\mathcal F\longrightarrow\mathcal S.
$$

Konstruksi tersebut memberi isomorfisme berkas alami

$$
\mathcal F|_{U_i}\longrightarrow\mathcal S|_{U_i}
$$

untuk setiap $U_i$, dan pembatasannya pada irisan $U_i\cap U_j$ saling
bersesuaian. Menurut Korolari 4.10, terdapat homomorfisme berkas global, dan
menurut Lema 4.6 homomorfisme ini merupakan isomorfisme. Injektivitas
korespondensi mengikuti karena suatu bundel vektor, hingga isomorfisme, dapat
direkonstruksi dari berkas seksinya melalui konstruksi di atas. Untuk
pernyataan mengenai homomorfisme, lihat Soal 17.21, 17.22, dan 17.23.

Di bawah ekuivalensi ini, berkas bebas ber-rank $r$ bersesuaian dengan ruang
afin $\mathbb A_X^r$ di atas $X$.

<!-- upstream_entity: Spektrum/Nichtnullteiler/Triviales Vektorbündel/Strukturgarbe/Beispiel -->

### Contoh 17.11: injektivitas pada bundel dan pada berkas {#br-bgk-2019-l17-exm-04}

Misalkan $R$ gelanggang komutatif dan $f\in R$. Melalui

$$
\operatorname{Spek}(R[T])=\mathbb A_R^1
\longrightarrow
\operatorname{Spek}(R[T])=\mathbb A_R^1,
\qquad T\longmapsto fT,
$$

unsur $f$ mendefinisikan homomorfisme bundel vektor. Pada serat di atas
titik-titik $P\in\operatorname{Spek}(R)$ tempat $f$ merupakan unit, yakni
titik-titik dalam $D(f)$, pemetaan ini bijektif; pada titik-titik lainnya,
pemetaan itu merupakan pemetaan nol. Jadi pemetaan ini injektif—dan sekaligus
surjektif serta bijektif—hanya jika $f$ merupakan unit.

Namun, perkalian oleh $f$ juga mendefinisikan homomorfisme berkas struktur

$$
\mathcal O_X\longrightarrow\mathcal O_X,
\qquad1\longmapsto f.
$$

Dengan demikian, pada setiap subhimpunan terbuka
$U\subseteq X=\operatorname{Spek}(R)$ terdapat homomorfisme modul
$\Gamma(U,\mathcal O_X)$

$$
\Gamma(U,\mathcal O_X)\longrightarrow\Gamma(U,\mathcal O_X),
\qquad r\longmapsto rf.
$$

Homomorfisme berkas ini injektif tepat ketika $f$ bukan pembagi nol di $R$,
dan bijektif tepat ketika $f$ merupakan unit. Jadi pengertian injektivitas
untuk bundel vektor dan berkas bebas lokal tidak berimpit.
