---
title: "Kuliah 16 - Berkas Bebas Lokal"
stable_id: br-bgk-2019-l16
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 16"
upstream_pageid: 109020
upstream_revid: 1003746
upstream_timestamp: "2025-06-08T15:43:34Z"
upstream_mediawiki_sha1: 2be1b6927bfef758198ff94dd1e90dc52c4630f2
source_url: "https://de.wikiversity.org/w/index.php?oldid=1003746"
authority_manifest: null
authority_manifest_status: "Tidak diterbitkan oleh proses capture; pengikatan audit memakai permukaan individual persis di bawah ini."
lecture_api: authority/wikiversity-bgk/unit-16/lecture-16-api.json
lecture_api_sha256: 8fbe4645d52075558a760a25948f289b3e994473e2e858e190baf2c5fab4a8d3
lecture_xml: authority/wikiversity-bgk/unit-16/lecture-16.xml
lecture_xml_sha256: 916136735d3b6f88ae5f92ef73b32bc60d672dbd04883e7d2f1dccc14e786e85
lecture_expanded_tex: authority/wikiversity-bgk/unit-16/lecture-16-expanded.tex
lecture_expanded_tex_sha256: a0cdb7121044eb271b5fed03fe82f84ce95174e4146afcd744547fe68d1dd276
course_authority_manifest: authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json
course_authority_manifest_sha256: ea0bf346e261db8ed80b7565f7746e95c79e0c376d25d9fbce5d96879dff7dd8
official_course_pdf: authority/artifacts/bgk-course-official.pdf
official_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
official_course_pdf_pages: "138-145"
media_credits: source/id-ID/media-credits-bgk-unit-16.md
license: "Teks kursus semantik dan terjemahan ini: CC BY-SA 4.0. Metadata Commons untuk PDF kursus resmi menyatakan CC BY-SA 4.0, sedangkan halaman 265 PDF memuat pemberitahuan CC BY-SA 3.0; keduanya dipertahankan tanpa klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
source_binding_status: "verified_individual_surfaces_and_exact_course_pdf_without_unit_manifest"
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 16: Berkas Bebas Lokal {#br-bgk-2019-l16}

## Berkas bebas lokal {#br-bgk-2019-l16-s01}

<!-- upstream_entity: Beringter Raum/Lokal freie Garbe/Definition -->

### Definisi 16.1: berkas bebas lokal {#br-bgk-2019-l16-def-01}

Suatu $\mathcal O_X$-modul $\mathcal F$ pada ruang berdering $X$ disebut
*bebas lokal* dengan *rank* $r$ jika terdapat liputan terbuka

$$
X=\bigcup_{i\in I}U_i
$$

dan isomorfisme modul $\mathcal O_{U_i}$

$$
\mathcal F|_{U_i}\cong(\mathcal O_{U_i})^r
$$

untuk setiap $i\in I$.

Untuk $r=1$, kita memperoleh berkas invertibel; berkas-berkas ini tepat
merupakan berkas bebas lokal ber-rank $1$. Berkas bebas lokal yang paling
sederhana adalah *berkas bebas*

$$
\mathcal O_X^r,
\qquad r\in\mathbb N.
$$

> **Catatan edisi - variabel rank dalam sumber.** Baik halaman semantik yang
> dibekukan maupun PDF kursus resmi mencetak "rank $r$" pada kalimat setelah
> menetapkan $r=1$. Edisi menuliskan konsekuensi matematisnya, yaitu rank $1$,
> dan mencatat perubahan itu secara terbuka.

Menurut definisinya, berkas bebas lokal bersifat bebas secara lokal, yakni
pada suatu liputan oleh himpunan-himpunan terbuka. Jadi secara lokal berkas
bebas dan berkas bebas lokal tidak dapat dibedakan. Karena itu, berkas bebas
lokal mencerminkan sifat-sifat global ruang berdering $X$.

Kita meninjau berkas bebas lokal pada skema, tempat terdapat hubungan erat
dengan modul projektif dan modul datar. Secara khusus, berkas bebas lokal
merupakan modul koheren. Di atas gelanggang lokal, semua berkas bebas lokal
adalah bebas, sebab spektrumnya hanya mempunyai satu titik tertutup dan titik
ini hanya mempunyai seluruh ruang sebagai lingkungan terbuka. Namun, jika
kita meninjau spektrum tertusuk

$$
U=D(\mathfrak m)=\operatorname{Spek}(R)\setminus\{\mathfrak m\}
$$

dari suatu gelanggang lokal, pada umumnya terdapat banyak berkas bebas lokal
nontrivial (tidak bebas) yang mencerminkan sifat-sifat gelanggang lokal
tersebut, atau singularitasnya. Karena setiap skema diliputi oleh skema-skema
afin, pertama-tama kita terutama harus memahami berkas bebas lokal pada skema
afin.

<!-- upstream_entity: Endlich erzeugter Modul/Lokal freie Garbe/Charakterisierungen von lokal/Fakt -->

### Teorema 16.2: karakterisasi lokal kebebasan lokal {#br-bgk-2019-l16-thm-01}

Misalkan $R$ gelanggang komutatif Noether, $M$ modul $R$ yang dibangkitkan
hingga, dan $r\in\mathbb N$. Sifat-sifat berikut ekuivalen.

1. Pelokalan $M_{\mathfrak p}$ bebas ber-rank $r$ untuk setiap ideal prima
   $\mathfrak p\in\operatorname{Spek}(R)$.
2. Pelokalan $M_{\mathfrak m}$ bebas ber-rank $r$ untuk setiap ideal maksimal
   $\mathfrak m$ dari $R$.
3. Terdapat unsur-unsur $f_1,\ldots,f_k\in R$ yang membangkitkan ideal satuan
   sedemikian sehingga pelokalan $M_{f_j}$ bebas ber-rank $r$ untuk setiap
   $j=1,\ldots,k$.
4. Berkas koheren $\widetilde M$ yang berkaitan dengan $M$ pada
   $\operatorname{Spek}(R)$ bebas lokal ber-rank $r$.

#### Bukti {#br-bgk-2019-l16-thm-01-proof}

$(1)\Rightarrow(2)$. Ini merupakan spesialisasi.

$(2)\Rightarrow(3)$. Tetapkan suatu ideal maksimal $\mathfrak m$. Menurut
asumsi, terdapat isomorfisme modul $R_{\mathfrak m}$

$$
\varphi:(R_{\mathfrak m})^r\longrightarrow M_{\mathfrak m}.
$$

Tuliskan citra vektor standar ke-$i$, $e_i$, sebagai

$$
\varphi(e_i)=\frac{m_i}{g_i},
$$

dengan $m_i\in M$ dan $g_i\in R\setminus\mathfrak m$. Misalkan
$g=g_1\cdots g_r$ hasil kali penyebut-penyebut itu. Kita meninjau situasi di
atas $D(g)$. Isomorfisme $\varphi$ terdefinisi di atas $D(g)$, yakni pada
$R_g$, sehingga kita mempunyai homomorfisme modul $R_g$

$$
\psi:(R_g)^r\longrightarrow M_g
$$

yang menginduksi isomorfisme $\varphi$ setelah dilokalkan pada
$\mathfrak m$. Akan tetapi, secara umum $\psi$ belum tentu merupakan
isomorfisme.

Misalkan $v_1,\ldots,v_s$ suatu sistem pembangkit modul $M$. Karena $\psi$
menginduksi suatu surjeksi pada $R_{\mathfrak m}$, terdapat unsur-unsur

$$
u_j=\frac{a_j}{h_j}\in(R_{\mathfrak m})^r
$$

yang dipetakan ke $v_j$. Penyebut $h_j$ tidak termasuk $\mathfrak m$. Karena
itu, kita dapat mengganti $g$ dengan $h=gh_1\cdots h_s$ dan memperoleh

$$
\psi:(R_h)^r\longrightarrow M_h.
$$

Di sini terdapat unsur-unsur $u_j\in(R_h)^r$ sedemikian sehingga
$\psi(u_j)$ dan pembangkit $v_j$ mempunyai pembatasan yang sama dalam
$M_{\mathfrak m}$. Artinya, terdapat unsur-unsur
$p_j\notin\mathfrak m$ dengan

$$
p_j\psi(u_j)=p_jv_j
$$

dalam $M_h$. Jika $h$ diganti dengan $p=hp_1\cdots p_s$, maka $\psi$ juga
menjadi surjektif.

> **Catatan edisi - tanda relasi dalam sumber.** Sumber mencetak
> $u_j=(R_h)^r$ pada kalimat di atas. Karena $u_j$ adalah unsur dan
> $(R_h)^r$ modul yang memuatnya, edisi menuliskan relasi keanggotaan
> $u_j\in(R_h)^r$ dan mencatat perubahan ini secara terbuka.

Misalkan $N$ kernel $\psi$ yang baru ini. Karena $\varphi$ injektif,
$N_{\mathfrak m}=0$. Karena $R$ Noether, menurut Lema 23.2 (Aljabar
Komutatif), $N$ dibangkitkan hingga. Maka terdapat lagi suatu unsur
$f\notin\mathfrak m$ dengan $N_f=0$. Dengan memperkecil himpunan terbuka
sekali lagi, kita memperoleh isomorfisme

$$
\psi:(R_f)^r\longrightarrow M_f
$$

untuk suatu $f\notin\mathfrak m$.

Jadi, untuk setiap ideal maksimal $\mathfrak m$ terdapat lingkungan terbuka

$$
\mathfrak m\in D(f_{\mathfrak m})
$$

sedemikian sehingga $M_{f_{\mathfrak m}}$ bebas ber-rank $r$. Oleh karena itu,

$$
\bigcup_{\mathfrak m\text{ ideal maksimal}}D(f_{\mathfrak m})
$$

memuat semua ideal maksimal dan juga semua ideal prima, sehingga merupakan
liputan terbuka $\operatorname{Spek}(R)$. Menurut Proposisi 8.4 (4), ideal

$$
(f_{\mathfrak m}:\mathfrak m\text{ ideal maksimal})
$$

adalah ideal satuan, dan ideal ini sudah dibangkitkan oleh sejumlah hingga
unsur $f_{\mathfrak m}$.

$(3)\Rightarrow(4)$. Karena unsur-unsur tersebut membangkitkan ideal satuan,
himpunan terbuka $D(f_j)$, $j=1,\ldots,k$, meliputi
$\operatorname{Spek}(R)$. Karena $M_{f_j}$ adalah modul $R_{f_j}$ bebas
ber-rank $r$, terdapat isomorfisme modul $\mathcal O_X|_{D(f_j)}$

$$
\widetilde M|_{D(f_j)}
\cong\widetilde{(R_{f_j})^r}
\cong\mathcal O_{D(f_j)}^r.
$$

Jadi $\widetilde M$ bebas lokal.

$(4)\Rightarrow(1)$. Misalkan
$\mathfrak p\in\operatorname{Spek}(R)$ suatu ideal prima. Kebebasan lokal
berarti bahwa terdapat liputan terbuka

$$
X=\bigcup_{i\in I}U_i
$$

sedemikian sehingga $\widetilde M|_{U_i}$ bebas ber-rank $r$. Maka terdapat
indeks $i$ dengan $\mathfrak p\in U_i$. Dengan beralih ke lingkungan terbuka
yang mungkin lebih kecil, kita dapat mengambil $U_i=D(f)$ dengan
$f\notin\mathfrak p$. Di sana

$$
\widetilde{M_f}\cong\widetilde M|_{D(f)}
$$

bebas ber-rank $r$. Terlebih lagi, pelokalan $M_{\mathfrak p}$ bebas ber-rank
$r$.

Contoh dalam Soal 14.7 menunjukkan bahwa untuk gelanggang tak-Noether $R$
dapat terdapat modul $M$ dengan

$$
M_{\mathfrak p}=R_{\mathfrak p}
$$

tanpa isomorfisme ini dapat diperluas ke suatu lingkungan terbuka.

Sekarang kita hubungkan modul bebas lokal dengan modul projektif.

<!-- upstream_entity: Kommutativer Ring/Projektiv/Universell/Definition -->

### Definisi 16.3: modul projektif {#br-bgk-2019-l16-def-02}

Misalkan $R$ gelanggang komutatif dan $M$ modul $R$. Modul $M$ disebut
*projektif* jika untuk setiap homomorfisme modul $R$ surjektif

$$
\theta:A\longrightarrow B
$$

dan setiap homomorfisme modul

$$
\varphi:M\longrightarrow B,
$$

terdapat homomorfisme modul

$$
\psi:M\longrightarrow A
$$

dengan

$$
\varphi=\theta\circ\psi.
$$

Suatu modul bersifat projektif jika dan hanya jika modul itu merupakan suku langsung
dari suatu modul bebas.

<!-- upstream_entity: Kommutativer Ring/Lokal/Projektiver Modul/Frei/Fakt -->

### Lema 16.4: modul projektif hingga di atas gelanggang lokal {#br-bgk-2019-l16-lem-01}

Misalkan $R$ gelanggang komutatif lokal dan $M$ modul $R$ yang dibangkitkan
hingga. Maka $M$ bebas jika dan hanya jika $M$ merupakan modul projektif.

#### Bukti {#br-bgk-2019-l16-lem-01-proof}

Bahwa modul bebas bersifat projektif telah dibuktikan dalam Lema 47.2
(Aljabar Komutatif). Jadi misalkan $M$ projektif. Ambil sistem pembangkit
minimal $m_1,\ldots,m_n$ dari $M$, dan misalkan

$$
p:R^n\longrightarrow M
$$

homomorfisme modul surjektif yang bersesuaian. Karena keminimalan tersebut,
pemetaan

$$
(R/\mathfrak m)^n\longrightarrow M/\mathfrak mM
$$

merupakan pemetaan linear $R/\mathfrak m$ yang bijektif. Karena $M$
projektif, terdapat homomorfisme modul $i:M\to R^n$ dengan

$$
p\circ i=\operatorname{Id}_M.
$$

Maka

$$
R^n\cong M\oplus N,
$$

dengan $N=\operatorname{kern}p$, dan kita mengidentifikasi $M$ dengan
$i(M)$. Sekarang tinjau

$$
R^n\xrightarrow{\ \cong\ }M\oplus N\longrightarrow M
$$

serta pemetaan linear $R/\mathfrak m$ yang diinduksinya,

$$
(R/\mathfrak m)^n
\longrightarrow M/\mathfrak mM\oplus N/\mathfrak mN
\longrightarrow M/\mathfrak mM.
$$

Baik pemetaan di kiri maupun komposisi keseluruhannya bijektif. Karena itu
$N/\mathfrak mN=0$. Dari Lema 29.5 (Aljabar Komutatif) diperoleh $N=0$,
sehingga $R^n=M$ bebas.

<!-- upstream_entity: Kommutativer Ring/Noethersch/Lokal frei/Projektiv/Fakt -->

### Lema 16.5: kebebasan lokal dan projektivitas {#br-bgk-2019-l16-lem-02}

Misalkan $R$ gelanggang komutatif Noether dan $M$ modul $R$ yang dibangkitkan
hingga. Maka $M$ bebas lokal jika dan hanya jika $M$ merupakan modul
projektif.

#### Bukti {#br-bgk-2019-l16-lem-02-proof}

Salah satu arah langsung mengikuti dari Lema 16.4 dengan memperhatikan Soal
16.16. Untuk membuktikan arah sebaliknya, misalkan

$$
p:L\longrightarrow M
$$

homomorfisme modul surjektif dengan $L$ suatu modul $R$ bebas yang
dibangkitkan hingga. Kita harus menunjukkan bahwa terdapat homomorfisme
$i:M\to L$ dengan

$$
p\circ i=\operatorname{Id}_M.
$$

Hal ini khususnya terjamin apabila homomorfisme alami

$$
\operatorname{Hom}_R(M,L)
\longrightarrow\operatorname{Hom}_R(M,M),
\qquad
\varphi\longmapsto p\circ\varphi,
$$

surjektif, sebab dengan demikian identitas termasuk dalam citranya. Menurut
Teorema Lampiran 1.4, surjektivitas dapat diuji secara lokal. Di bawah asumsi
keterhinggaan yang diberikan, untuk modul homomorfisme berlaku

$$
(\operatorname{Hom}_R(M,L))_{\mathfrak p}
=\operatorname{Hom}_{R_{\mathfrak p}}
(M_{\mathfrak p},L_{\mathfrak p}).
$$

Untuk setiap ideal prima $\mathfrak p$, surjektivitas pemetaan

$$
\operatorname{Hom}_{R_{\mathfrak p}}
(M_{\mathfrak p},L_{\mathfrak p})
\longrightarrow
\operatorname{Hom}_{R_{\mathfrak p}}
(M_{\mathfrak p},M_{\mathfrak p})
$$

mengikuti dari kebebasan $M_{\mathfrak p}$ dan Lema 47.2 (Aljabar
Komutatif).

> **Catatan edisi - rujukan yang belum terselesaikan.** Tepat sebelum
> identitas pelokalan modul homomorfisme, halaman semantik sumber menampilkan
> rujukan `Fakt *****` ke halaman
> `Nenneraufnahme/Homomorphismenmodul/Fakt`. Edisi mempertahankan identitas
> matematisnya tanpa menciptakan nomor rujukan yang tidak tersedia.

Teorema berikut juga berlaku; kita tidak membuktikannya.

<!-- upstream_entity: Endlich erzeugter Modul/Lokal frei/Projektiv und flach/Fakt -->

### Teorema 16.6: bebas lokal, projektif, dan datar {#br-bgk-2019-l16-thm-02}

Misalkan $R$ gelanggang komutatif Noether dan $M$ modul $R$ yang dibangkitkan
hingga. Pernyataan-pernyataan berikut ekuivalen.

1. $M$ bebas lokal.
2. $M$ merupakan modul projektif.
3. $M$ merupakan modul datar.

Teorema berikut menghasilkan banyak berkas bebas lokal yang pada umumnya
tidak trivial.

<!-- upstream_entity: Schema/Lokal freie Garben/Surjektiv/Kern/Fakt -->

### Teorema 16.7: kernel suatu surjeksi berkas bebas lokal {#br-bgk-2019-l16-thm-03}

Misalkan $X$ skema Noether dan

$$
\theta:\mathcal F\longrightarrow G
$$

homomorfisme berkas surjektif di antara berkas-berkas bebas lokal pada $X$.
Maka kernel $\theta$ juga bebas lokal.

#### Bukti {#br-bgk-2019-l16-thm-03-proof}

Karena kebebasan lokal merupakan sifat lokal, kita dapat langsung
mengasumsikan bahwa

$$
X=\operatorname{Spek}(R)
$$

adalah skema afin dari suatu gelanggang Noether $R$, dan, dengan memperkecil
himpunan terbuka lebih lanjut, bahwa terdapat homomorfisme modul surjektif

$$
\theta:R^r\longrightarrow R^s.
$$

Menurut Teorema 19.11 (Aljabar Komutatif), terdapat
$\varphi:R^s\to R^r$ dengan

$$
\theta\circ\varphi=\operatorname{Id}_{R^s}.
$$

Dengan demikian terdapat dekomposisi jumlah langsung

$$
R^r=\operatorname{kern}\theta\oplus R^s,
$$

dan $\theta$ adalah proyeksi pada suku $R^s$. Jadi, menurut Lema 47.3
(Aljabar Komutatif), $\operatorname{kern}\theta$ merupakan modul $R$
projektif, dan menurut Lema 16.5 modul itu bebas lokal.

<!-- upstream_entity: Affines Schema/Syzygiengarbe zu Idealerzeugern/Bemerkung -->

### Catatan 16.8: berkas sizigi {#br-bgk-2019-l16-rem-01}

Untuk unsur-unsur $f_1,\ldots,f_n\in R$ dalam suatu gelanggang komutatif $R$,
terdapat homomorfisme modul

$$
R^n\longrightarrow R,
\qquad
e_i\longmapsto f_i.
$$

Citranya adalah ideal yang dibangkitkan oleh $f_i$. Secara khusus, pemetaan
ini surjektif hanya jika $f_i$ membangkitkan ideal satuan. Homomorfisme modul
berkas yang bersesuaian

$$
\mathcal O_X^n\longrightarrow\mathcal O_X
$$

secara umum juga tidak surjektif, dan kernelnya secara umum tidak bebas
lokal. Akan tetapi, tinjau pembatasan homomorfisme berkas ini pada subhimpunan
terbuka

$$
U=\bigcup_{i=1}^nD(f_i),
$$

yakni

$$
\mathcal O_U^n\longrightarrow\mathcal O_U.
$$

Kita memperoleh homomorfisme berkas surjektif, sebab pada setiap $D(f_i)$
terdapat

$$
\frac{1}{f_i}e_i\longmapsto1.
$$

Menurut Teorema 16.7, kernelnya merupakan berkas bebas lokal pada skema
kuasiafin $U$. Kernel ini dilambangkan

$$
\operatorname{Syz}(f_1,\ldots,f_n)
$$

dan disebut *berkas sizigi* atau *berkas kernel*. Jika $R$ gelanggang lokal
dan $f_i$ membangkitkan suatu ideal yang primer terhadap ideal maksimal
$\mathfrak m$ - dengan kata lain, secara geometris $f_i$ memotong keluar
titik tertutup - maka berkas sizigi itu merupakan berkas bebas lokal pada
spektrum tertusuk $D(\mathfrak m)$.

<!-- upstream_entity: Polynomring/Syzygiengarbe zu Variablen/Beispiel -->

### Contoh 16.9: berkas sizigi dari variabel {#br-bgk-2019-l16-exm-01}

Variabel

$$
X_1,\ldots,X_n\in K[X_1,\ldots,X_n]=R
$$

mendefinisikan ideal maksimal $(X_1,\ldots,X_n)$ dan barisan eksak pendek

$$
0\longrightarrow\operatorname{Syz}(X_1,\ldots,X_n)
\longrightarrow R^n
\longrightarrow(X_1,\ldots,X_n)
\longrightarrow0
$$

dari modul-modul $R$, dengan vektor standar ke-$i$, $e_i$, dipetakan ke
$X_i$. Menurut Lema 14.9, barisan ini menginduksi barisan eksak pendek
modul-modul kuasikoheren

$$
0\longrightarrow\widetilde{\operatorname{Syz}(X_1,\ldots,X_n)}
\longrightarrow\mathcal O_{\mathbb A_K^n}^n
\longrightarrow\widetilde{(X_1,\ldots,X_n)}
\longrightarrow0
$$

pada ruang afin $\mathbb A_K^n$. Di tengah terdapat berkas bebas, sedangkan
di kiri dan kanan - kecuali untuk $n$ kecil - tidak terdapat berkas bebas
lokal. Namun, jika barisan ini dibatasi pada spektrum tertusuk

$$
U=D(X_1,\ldots,X_n)\subseteq\mathbb A_K^n,
$$

maka menurut Soal 14.1 ideal maksimal di sebelah kanan menjadi berkas
struktur. Jadi kita memperoleh situasi dari Catatan 16.8,

$$
0\longrightarrow\operatorname{Syz}(X_1,\ldots,X_n)
\longrightarrow\mathcal O_U^n
\longrightarrow\mathcal O_U
\longrightarrow0,
$$

dengan berkas sizigi bebas lokal di sebelah kiri. Untuk $n=3$, ini adalah
versi berkas dari Contoh 1.2.

## Berkas determinan {#br-bgk-2019-l16-s02}

<!-- upstream_entity: Lokal freie Garbe/Beringter Raum/Determinantengarbe/Definition -->

### Definisi 16.10: berkas determinan {#br-bgk-2019-l16-def-03}

Misalkan $\mathcal G$ berkas bebas lokal ber-rank $r$ pada ruang berdering
$(X,\mathcal O_X)$. Berkasisasi praberkas

$$
U\longmapsto\bigwedge^r\Gamma(U,\mathcal G)
$$

disebut *berkas determinan* dari $\mathcal G$. Berkas ini dilambangkan

$$
\operatorname{Det}\mathcal G.
$$

<!-- upstream_entity: Beringter Raum/Lokal freie Garben/Kurze exakte Sequenz/Determinantengarbe/Fakt -->

### Teorema 16.11: determinan suatu barisan eksak pendek {#br-bgk-2019-l16-thm-04}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan

$$
0\longrightarrow\mathcal F
\longrightarrow\mathcal G
\longrightarrow\mathcal H
\longrightarrow0
$$

suatu barisan eksak pendek berkas-berkas bebas lokal pada $X$. Maka terdapat
isomorfisme kanonis

$$
\operatorname{Det}G
\cong
\operatorname{Det}F\otimes\operatorname{Det}H.
$$

#### Bukti {#br-bgk-2019-l16-thm-04-proof}

Misalkan $r$ rank $\mathcal F$ dan $s$ rank $\mathcal H$. Tinjau
subhimpunan-subhimpunan terbuka $U\subseteq X$ tempat ketiga berkas yang
terlibat dapat ditrivialkan dan tempat surjeksi berkas
$\mathcal F\to\mathcal H$ mempunyai suatu seksi. Himpunan-himpunan terbuka
seperti ini meliputi $X$. Pada setiap $U$ terdapat situasi

$$
0\longrightarrow\mathcal O_U^r
\longrightarrow\mathcal O_U^{r+s}
\longrightarrow\mathcal O_U^s
\longrightarrow0,
$$

dan misalkan

$$
\theta:\mathcal O_U^s\longrightarrow\mathcal O_U^{r+s}
$$

suatu seksi. Definisikan

$$
\Psi:
\bigwedge^r\mathcal O_U^r\times
\bigwedge^s\mathcal O_U^s
\longrightarrow
\bigwedge^{r+s}\mathcal O_U^{r+s}
$$

dengan

$$
\begin{aligned}
&\Psi(u_1\wedge\cdots\wedge u_r,
w_1\wedge\cdots\wedge w_s)\\
&\qquad:=u_1\wedge\cdots\wedge u_r
\wedge\theta(w_1)\wedge\cdots\wedge\theta(w_s).
\end{aligned}
$$

Pemetaan ini tidak bergantung pada seksi $\theta$ yang dipilih. Untuk seksi
lain $\theta'$, selisih $\theta-\theta'$ bernilai di $\mathcal F$. Maka

$$
\begin{aligned}
&u_1\wedge\cdots\wedge u_r
\wedge\theta'(w_1)\wedge\cdots\wedge\theta'(w_s)\\
&=u_1\wedge\cdots\wedge u_r
\wedge(\theta(w_1)+u_1')\wedge\cdots\wedge(\theta(w_s)+u_s')\\
&=u_1\wedge\cdots\wedge u_r
\wedge\theta(w_1)\wedge\cdots\wedge\theta(w_s),
\end{aligned}
$$

sebab selalu terdapat ketergantungan linear di antara $r+1$ vektor
$u_1,\ldots,u_r,u_j'$, sehingga hasil kali bajinya yang bersesuaian bernilai
$0$. Pemetaan $\Psi$ bilinear dan karena itu mendefinisikan pemetaan linear

$$
\widetilde\Psi:
\bigwedge^r\mathcal O_U^r\otimes
\bigwedge^s\mathcal O_U^s
\longrightarrow
\bigwedge^{r+s}\mathcal O_U^{r+s}.
$$

Karena pemetaan-pemetaan ini kanonis, pembatasannya pada subhimpunan terbuka
yang lebih kecil selalu menghasilkan pemetaan yang sama. Menurut Korolari
4.10, pemetaan-pemetaan tersebut dengan demikian dapat dilem menjadi suatu
homomorfisme berkas

$$
\bigwedge^r\mathcal F\otimes\bigwedge^s\mathcal H
\longrightarrow\bigwedge^{r+s}\mathcal G.
$$

Menurut deskripsi eksplisitnya, homomorfisme ini merupakan isomorfisme secara
lokal, dan karena itu menurut Lema 4.6 juga merupakan isomorfisme secara
global.

> **Catatan edisi - surjeksi dalam bukti sumber.** Kalimat pembuka bukti
> sumber mencetak surjeksi $\mathcal F\to\mathcal H$. Barisan eksak yang
> ditampilkan dan seksi $\theta:\mathcal O_U^s\to\mathcal O_U^{r+s}$
> menunjukkan bahwa surjeksi yang dipakai oleh konstruksi adalah
> $\mathcal G\to\mathcal H$. Edisi mempertahankan cetakan sumber dalam
> kalimatnya dan menyatakan ketidaksesuaian ini secara eksplisit.

<!-- upstream_entity: Beringter Raum/Lokal freie Garbe/Direkte Summe/Invertierbare Garben/Determinantengarbe/Fakt -->

### Korolari 16.12: determinan jumlah langsung berkas invertibel {#br-bgk-2019-l16-cor-01}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan

$$
\mathcal F=\mathcal L_1\oplus\cdots\oplus\mathcal L_r
$$

suatu jumlah langsung berkas-berkas invertibel. Maka

$$
\operatorname{Det}F
\cong
\mathcal L_1\otimes\cdots\otimes\mathcal L_r.
$$

#### Bukti {#br-bgk-2019-l16-cor-01-proof}

Lihat Soal 16.22.
