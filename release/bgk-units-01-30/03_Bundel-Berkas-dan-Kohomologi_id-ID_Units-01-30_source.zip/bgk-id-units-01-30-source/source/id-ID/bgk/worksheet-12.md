---
title: "Lembar Kerja 12 - Spektrum Projektif Gelanggang Bergradasi"
stable_id: br-bgk-2019-w12
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 12"
upstream_pageid: 110219
upstream_revid: 660098
upstream_timestamp: "2020-10-12T13:10:37Z"
upstream_mediawiki_sha1: ed53f8b78bd5729244e9d7576a281721387c234a
source_url: "https://de.wikiversity.org/w/index.php?oldid=660098"
authority_manifest: authority/wikiversity-bgk/unit-12/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 0e83f8718364e1d902dbe961cbf142cc7fb61e4ebfc7537f24488d508334e914
worksheet_xml: authority/wikiversity-bgk/unit-12/worksheet-12.xml
worksheet_xml_sha256: 7e4960f06b955fb3255110735f89020ae9ca348834cd2c5f891977f6b3d4c0b9
worksheet_expanded_tex: authority/wikiversity-bgk/unit-12/worksheet-12-expanded.tex
worksheet_expanded_tex_sha256: d411c9610c0dc133391df2ca2e010a7e42b58cd00e0bc6704a3d129d95d56eaa
official_pdf: authority/artifacts/bgk-worksheet-12-official.pdf
official_pdf_sha256: 5b789ca531394c68352a85464ff7030f5d07ff70276a22e7202a72f15c5e85a8
ordered_exercise_map: authority/wikiversity-bgk/unit-12/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 62678f3ece59348d362ed7bdf32726642957e6e977970fb276238ad2387e610a
exercise_count: 19
public_solution_count: 2
public_solution_numbers: "5, 10"
media_credits: source/id-ID/media-credits-bgk-unit-12.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 12: Spektrum Projektif Gelanggang Bergradasi {#br-bgk-2019-w12}

Tanda bintang menunjukkan tepat dua soal dengan solusi publik yang dibekukan,
yaitu Soal 12.5 dan 12.10. Tujuh belas soal lainnya mempunyai hasil kandidat
negatif; edisi tidak menciptakan solusi baru.

<!-- upstream_entity: Graduierte Algebra/1 in 0ter Stufe/Aufgabe -->

## Soal 12.1 {#br-bgk-2019-w12-ex01}

Misalkan $R$ gelanggang komutatif, $D$ grup komutatif, dan $A$ aljabar
$R$ bergradasi $D$. Buktikan bahwa

$$
1\in A_0,
$$

dan simpulkan bahwa $A_0$ merupakan subaljabar $R$ dari $A$.

<!-- upstream_entity: Graduierter Ring/Stufe mit Einheit/Isomorph/Aufgabe -->

## Soal 12.2 {#br-bgk-2019-w12-ex02}

Misalkan

$$
A=\bigoplus_{d\in D}A_d
$$

gelanggang komutatif bergradasi, dan misalkan komponen $A_e$ memuat suatu
unit. Buktikan bahwa $A_e$, sebagai modul $A_0$, isomorfik dengan $A_0$.

<!-- upstream_entity: Graduierter kommutativer Ring/Homogenes Ideal/Restklassenring/Fakt/Beweis/Aufgabe -->

## Soal 12.3 {#br-bgk-2019-w12-ex03}

Misalkan $R$ gelanggang komutatif, $D$ grup komutatif, dan $A$ aljabar
komutatif $R$ bergradasi $D$. Misalkan $\mathfrak a\subseteq A$ ideal
homogen. Buktikan bahwa gelanggang kelas sisa $A/\mathfrak a$ juga
bergradasi $D$.

<!-- upstream_entity: Homogene Polynome/n Variablen/Monomanzahl/Aufgabe -->

## Soal 12.4 {#br-bgk-2019-w12-ex04}

Buktikan bahwa dalam gelanggang polinomial dengan $n$ variabel terdapat tepat

$$
\binom{d+n-1}{n-1}
$$

monomial berderajat $d$.

<!-- upstream_entity: Monomiales Ideal/Produkt/Erzeugergrad/Aufgabe -->

## Soal 12.5 ★ {#br-bgk-2019-w12-ex05}

Berikan contoh dua ideal monomial $\mathfrak a$ dan $\mathfrak b$ dalam suatu
gelanggang polinomial serta bilangan asli $d$ sedemikian sehingga ideal hasil
kali $\mathfrak a\mathfrak b$ mempunyai sistem pembangkit berupa monomial
berderajat paling tinggi $d$, tetapi masing-masing dari kedua ideal itu tidak
mempunyai sistem pembangkit demikian.

<!-- upstream_entity: Projektives Spektrum/Topologie/Aufgabe -->

## Soal 12.6 {#br-bgk-2019-w12-ex06}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$. Buktikan bahwa subhimpunan

$$
D_+(\mathfrak a)\subseteq\operatorname{Proj}(R),
$$

untuk ideal homogen $\mathfrak a\subseteq R$, memang menentukan suatu
topologi pada spektrum projektif $\operatorname{Proj}(R)$.

<!-- upstream_entity: Projektives Spektrum/Topologie/Basis/Aufgabe -->

## Soal 12.7 {#br-bgk-2019-w12-ex07}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$. Buktikan bahwa himpunan terbuka

$$
D_+(f)\subseteq\operatorname{Proj}(R),
$$

untuk unsur homogen $f\in R_+$, membentuk basis topologi spektrum projektif.

<!-- upstream_entity: Achsenkreuz/Projektives Spektrum/Aufgabe -->

## Soal 12.8 {#br-bgk-2019-w12-ex08}

Tentukan spektrum projektif dari salib sumbu

$$
\operatorname{Spek}(K[X,Y]/(XY))
$$

dengan gradasi standar.

<!-- upstream_entity: Achsenebenen/Projektives Spektrum/Skizze/Aufgabe -->

## Soal 12.9 {#br-bgk-2019-w12-ex09}

Buat sketsa spektrum projektif dari gabungan bidang-bidang koordinat

$$
\operatorname{Spek}(K[X,Y,Z]/(XYZ))
$$

dengan gradasi standar.

<!-- upstream_entity: Projektive Ebene/Zwei Geraden/Schnittpunkt/1/Aufgabe -->

## Soal 12.10 ★ {#br-bgk-2019-w12-ex10}

Tentukan titik potong kedua garis

$$
L=V_+(6X-8Y+3Z)
$$

dan

$$
M=V_+(2X+9Y-5Z)
$$

di bidang projektif.

<!-- upstream_entity: Projektive Ebene/Zwei verschiedene Punkte/Definieren projektive Gerade/Aufgabe -->

## Soal 12.11 {#br-bgk-2019-w12-ex11}

Buktikan bahwa dua titik berbeda $P$ dan $Q$ di bidang projektif menentukan
secara unik sebuah garis projektif yang memuat keduanya. Bagaimana persamaan
garis itu dihitung dari koordinat kedua titik?

<!-- upstream_entity: Projektiver Raum/Grundring/Globale Schnitte/Aufgabe -->

## Soal 12.12 {#br-bgk-2019-w12-ex12}

Buktikan bahwa gelanggang seksi global ruang projektif adalah gelanggang dasar:

$$
\Gamma(\mathbb P_R^n,\mathcal O_{\mathbb P_R^n})=R.
$$

<!-- upstream_entity: Projektive Gerade/Verklebung/Proj/Aufgabe -->

## Soal 12.13 {#br-bgk-2019-w12-ex13}

Buktikan bahwa garis projektif $\mathbb P_K^1$ yang dikonstruksi melalui
pengeleman dalam Contoh 10.7 sama dengan garis projektif dalam pengertian
Contoh 12.10, yakni

$$
\operatorname{Proj}(K[X,Y]).
$$

<!-- upstream_entity: Projektiver Raum/Zariski Topologie/Einschränkung auf affinen Raum/Aufgabe -->

## Soal 12.14 {#br-bgk-2019-w12-ex14}

Misalkan $L$ bentuk linear homogen dalam $K[X_0,\ldots,X_n]$ dan

$$
D_+(L)\cong\mathbb A_K^n\subseteq\mathbb P_K^n.
$$

Buktikan bahwa topologi Zariski pada ruang projektif menginduksi topologi
Zariski pada ruang afin tersebut.

<!-- upstream_entity: Projektiver Raum/Für jeden Punkt affine Umgebung, wo Nullpunkt/Aufgabe -->

## Soal 12.15 {#br-bgk-2019-w12-ex15}

Misalkan

$$
P=(a_0,\ldots,a_n)\in\mathbb P_K^n.
$$

Buktikan bahwa terdapat lingkungan terbuka afin

$$
U\cong\mathbb A_K^n\subset\mathbb P_K^n
$$

sedemikian sehingga $P$, dalam ruang afin ini, bersesuaian dengan titik asal.

<!-- upstream_entity: Projektiver Raum/Übergang zwischen affinen Standardmengen/Aufgabe -->

## Soal 12.16 {#br-bgk-2019-w12-ex16}

Misalkan $\mathbb P_K^n$ ruang projektif berdimensi $n$ di atas lapangan $K$,
dan misalkan

$$
D_+(X_i)\cong\mathbb A_K^n,
\qquad
D_+(X_j)\cong\mathbb A_K^n
$$

dua himpunan terbuka afin di dalam $\mathbb P_K^n$. Deskripsikan pemetaan
transisi, yang tidak terdefinisi di semua titik, dari $D_+(X_i)$ ke
$D_+(X_j)$.

<!-- upstream_entity: Projektive Abbildung/Morphismus durch homogenen Polynome vom gleichen Grad/Auf offener Menge/Aufgabe -->

## Soal 12.17 {#br-bgk-2019-w12-ex17}

Misalkan diberikan $m+1$ polinomial homogen

$$
F_0,\ldots,F_m
$$

dalam $n+1$ variabel, semuanya berderajat sama $d$. Buktikan bahwa terdapat
himpunan terbuka $U\subseteq\mathbb P_K^n$ tempat polinomial-polinomial itu
mendefinisikan morfisme

$$
\mathbb P_K^n\supseteq U\longrightarrow\mathbb P_K^m.
$$

<!-- upstream_entity: Standard-graduierter Ring/Einheit im Grad 1/Homogenes Ideal/n-te Stufe/Aufgabe -->

## Soal 12.18 {#br-bgk-2019-w12-ex18}

Misalkan $S$ gelanggang bergradasi $\mathbb Z$ yang mempunyai unit homogen
pada derajat satu, dan misalkan $\mathfrak a\subseteq S$ ideal homogen.
Buktikan bahwa untuk $n\in\mathbb Z$ berlaku kesamaan modul
$(S/\mathfrak a)_0$

$$
(S/\mathfrak a)_n
=(S/\mathfrak a)_0\otimes_{S_0}S_n.
$$

<!-- upstream_entity: Standard-graduierter Ring/Homogenes Ideal/Nenneraufnahme/n-te Stufe/Aufgabe -->

## Soal 12.19 {#br-bgk-2019-w12-ex19}

Misalkan $R$ gelanggang bergradasi standar,
$\mathfrak a\subseteq R$ ideal homogen, dan $f\in R$ unsur homogen berderajat
$1$. Buktikan bahwa untuk $n\in\mathbb Z$ berlaku kesamaan modul
$(R_f/\mathfrak a_f)_0$

$$
((R/\mathfrak a)_f)_n
=(R_f/\mathfrak a_f)_n
=(R_f/\mathfrak a_f)_0\otimes_{(R_f)_0}(R_f)_n.
$$
