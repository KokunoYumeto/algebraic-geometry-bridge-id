---
title: "Kuliah 13 - Pemetaan Kerucut, Berkas Modul, dan Berkas Invertibel"
stable_id: br-bgk-2019-l13
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 13"
upstream_pageid: 109017
upstream_revid: 1003738
upstream_timestamp: "2025-06-08T15:36:10Z"
upstream_mediawiki_sha1: 8ae09126a06257cf52c0559675523ee4ca2ce0a5
source_url: "https://de.wikiversity.org/w/index.php?oldid=1003738"
authority_manifest: authority/wikiversity-bgk/unit-13/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 792935b01daf0a2ee22decd78d3f9ccb8d95719c628cdd306b66405ea1427282
lecture_xml: authority/wikiversity-bgk/unit-13/lecture-13.xml
lecture_xml_sha256: 976e732961cd1c16637873e881e1ecf1866661a0f7c867d49c6f5fc6b1181641
lecture_expanded_tex: authority/wikiversity-bgk/unit-13/lecture-13-expanded.tex
lecture_expanded_tex_sha256: 3734117da816049f4964293ac0cf02912d82a5f447c279aadc412df286cf4990
official_pdf: authority/artifacts/bgk-lecture-13-official.pdf
official_pdf_sha256: dcf6236638c6f34b253d7fd0fa8a9ec188ce9acef62dc1758f0dbfd7528809c0
media_credits: source/id-ID/media-credits-bgk-unit-13.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 13: Pemetaan Kerucut, Berkas Modul, dan Berkas Invertibel {#br-bgk-2019-l13}

## Pemetaan kerucut {#br-bgk-2019-l13-s01}

<!-- upstream_entity: Graduierter Ring/Z/Homogenisierung zu einem Ideal/Definition -->

### Definisi 13.1: homogenisasi ideal {#br-bgk-2019-l13-def-01}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$. Untuk suatu ideal
$\mathfrak a$, ideal yang dibangkitkan oleh semua unsur homogen dalam
$\mathfrak a$ disebut *homogenisasi* $\mathfrak a$. Homogenisasi ini
dilambangkan dengan $\mathfrak a^h$.

Homogenisasi kembali merupakan ideal dan termuat dalam ideal asal. Homogenisasi
suatu ideal prima merupakan ideal prima.

<!-- upstream_entity: Graduierter Ring/Z/Kegelabbildung/Schema/Definition -->

### Definisi 13.2: pemetaan kerucut {#br-bgk-2019-l13-def-02}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$. *Pemetaan kerucut* adalah
morfisme skema

$$
\begin{aligned}
D(R_+)&\longrightarrow\operatorname{Proj}(R),\\
\mathfrak p&\longmapsto\mathfrak p^h.
\end{aligned}
$$

Pada himpunan terbuka yang berkaitan dengan unsur homogen $f\in R_+$,
pemetaan ini diberikan oleh pemetaan spektrum yang terkait dengan
homomorfisme

$$
(R_f)_0\longrightarrow R_f.
$$

<!-- upstream_entity: Graduierter Ring/Z/Kegelabbildung/Schema/Fakt -->

### Teorema 13.3: pemetaan kerucut merupakan morfisme skema {#br-bgk-2019-l13-thm-01}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$. Maka pemetaan kerucut memang
merupakan morfisme skema.

#### Bukti {#br-bgk-2019-l13-thm-01-proof}

Pemetaan ini terdefinisi dengan baik karena homogenisasi suatu ideal prima
kembali merupakan ideal prima. Untuk unsur homogen $f\in R_+$ dan ideal prima
$\mathfrak p$, berlaku

$$
f\in\mathfrak p
\quad\Longleftrightarrow\quad
f\in\mathfrak p^h.
$$

Karena itu, pracitra $D_+(f)$ adalah $D(f)$ dan pemetaan tersebut kontinu.
Diagram pemetaan

$$
\begin{matrix}
D(f)&\longrightarrow&D_+(f)\\
\downarrow&&\downarrow\\
\operatorname{Spek}(R_f)&\longrightarrow&
\operatorname{Spek}((R_f)_0)
\end{matrix}
$$

komutatif. Di baris atas terdapat restriksi pemetaan kerucut, di baris bawah
pemetaan spektrum alami, di sebelah kiri identifikasi dari Lema 9.13, dan di
sebelah kanan identifikasi dari Lema 12.8.

Untuk membuktikan komutativitas, bagi suatu ideal prima
$\mathfrak p\in D(f)$ perlu ditunjukkan kesamaan

$$
\mathfrak p^h\cap(R_f)_0
=\mathfrak p\cap(R_f)_0,
$$

dengan ideal-ideal prima tersebut dipandang sebagai ideal dalam $R_f$.
Kesamaan ini bertumpu pada argumen untuk Lema 12.8.

Dengan demikian, morfisme tersebut ditentukan secara skematis pada $D(f)$.
Morfisme-morfisme

$$
\operatorname{Spek}(R_f)
\longrightarrow
\operatorname{Spek}((R_f)_0)
$$

untuk berbagai $f$ saling kompatibel dan menentukan suatu morfisme skema
global.

<!-- upstream_entity: Polynomring/Kegelabbildung/Schema/Beispiel -->

### Contoh 13.4: pemetaan kerucut ruang projektif {#br-bgk-2019-l13-exm-01}

Untuk gelanggang polinomial $K[X_0,X_1,\ldots,X_n]$ dalam $n+1$ variabel
dengan gradasi standar di atas suatu lapangan $K$, pemetaan kerucut adalah

$$
\begin{aligned}
\mathbb A_K^{n+1}\supset D(X_0,X_1,\ldots,X_n)
&\longrightarrow\mathbb P_K^n,\\
\mathfrak p&\longmapsto\mathfrak p^h.
\end{aligned}
$$

Pada titik-titik $K$, pemetaan ini diberikan secara sederhana oleh

$$
\begin{aligned}
K^{n+1}\setminus\{0\}&\longrightarrow\mathbb P^n(K),\\
(x_0,x_1,\ldots,x_n)&\longmapsto(x_0,x_1,\ldots,x_n).
\end{aligned}
$$

Pemetaan ini memetakan setiap titik tak nol ke garis yang melalui titik
tersebut dan titik asal.

## Modul pada ruang berdering {#br-bgk-2019-l13-s02}

Sebagaimana penting untuk memahami modul-modul $R$ bagi suatu gelanggang
komutatif $R$, bagi suatu ruang berdering kita harus memahami
modul-modul $\mathcal O_X$ yang diberikan di atasnya.

<!-- upstream_entity: Beringter Raum/Modul/Definition -->

### Definisi 13.5: modul pada ruang berdering {#br-bgk-2019-l13-def-03}

Suatu berkas $\mathcal M$ pada ruang berdering $(X,\mathcal O_X)$ disebut
*$\mathcal O_X$-modul* jika untuk setiap himpunan terbuka $U\subseteq X$
diberikan struktur $\Gamma(U,\mathcal O_X)$-modul pada
$\Gamma(U,\mathcal M)$ yang kompatibel dengan pemetaan-pemetaan restriksi
untuk $U\subseteq V$.

Syarat kompatibilitas berarti bahwa untuk himpunan-himpunan terbuka
$U\subseteq V$, diagram

$$
\begin{matrix}
\Gamma(V,\mathcal O_X)\times\Gamma(V,\mathcal M)
&\longrightarrow&\Gamma(V,\mathcal M)\\
\downarrow&&\downarrow\\
\Gamma(U,\mathcal O_X)\times\Gamma(U,\mathcal M)
&\longrightarrow&\Gamma(U,\mathcal M)
\end{matrix}
$$

komutatif. Secara khusus, berkas struktur $\mathcal O_X$ merupakan
$\mathcal O_X$-modul. Setiap $\mathcal O_X$-modul khususnya merupakan berkas
grup abelian.

<!-- upstream_entity: Beringter Raum/Modul/Untermodul/Definition -->

### Definisi 13.6: submodul berkas {#br-bgk-2019-l13-def-04}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal M$ suatu
$\mathcal O_X$-modul. Suatu subberkas

$$
\mathcal N\subseteq\mathcal M
$$

sedemikian sehingga, untuk setiap subhimpunan terbuka $U\subseteq X$,
$\Gamma(U,\mathcal N)$ merupakan submodul dari $\Gamma(U,\mathcal M)$ atas
gelanggang $\Gamma(U,\mathcal O_X)$ disebut
*$\mathcal O_X$-submodul* dari $\mathcal M$.

<!-- upstream_entity: Beringter Raum/Idealgarbe/Definition -->

### Definisi 13.7: berkas ideal {#br-bgk-2019-l13-def-05}

Misalkan $(X,\mathcal O_X)$ ruang berdering. Suatu
$\mathcal O_X$-submodul

$$
\mathcal I\subseteq\mathcal O_X
$$

disebut *berkas ideal*.

<!-- upstream_entity: Lokal beringter Raum/Modul/Faser/Definition -->

### Definisi 13.8: serat modul pada sebuah titik {#br-bgk-2019-l13-def-06}

Misalkan $(X,\mathcal O_X)$ ruang berdering lokal dan $\mathcal M$ suatu
$\mathcal O_X$-modul. Untuk suatu titik $P\in X$, ruang

$$
\mathcal M(P)
:=\mathcal M_P\otimes_{\mathcal O_{X,P}}\kappa(P)
$$

disebut *serat* $\mathcal M$ di titik $P$.

Secara khusus, serat ini merupakan ruang vektor di atas lapangan residu
$\kappa(P)$.

<!-- upstream_entity: Garbe/Modul/Homomorphismus/Definition -->

### Definisi 13.9: homomorfisme modul berkas {#br-bgk-2019-l13-def-07}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal M,\mathcal N$
merupakan $\mathcal O_X$-modul pada $X$. Suatu homomorfisme berkas

$$
\varphi:\mathcal M\longrightarrow\mathcal N
$$

disebut *homomorfisme $\mathcal O_X$-modul* jika untuk setiap himpunan terbuka
$U\subseteq X$, pemetaan

$$
\Gamma(U,\mathcal M)\longrightarrow\Gamma(U,\mathcal N)
$$

merupakan homomorfisme $\Gamma(U,\mathcal O_X)$-modul.

Suatu homomorfisme $\mathcal O_X$-modul khususnya merupakan homomorfisme
berkas grup abelian.

Pernyataan berikut adalah suatu versi teorema penentuan dari aljabar linear.

<!-- upstream_entity: Beringter Raum/Modulgarbe/Schnitte und Modulgarbenhomomorphismus/Festlegungssatz/Fakt -->

### Teorema 13.10: seksi global menentukan homomorfisme modul {#br-bgk-2019-l13-thm-02}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal M$ suatu
$\mathcal O_X$-modul pada $X$. Seksi-seksi global

$$
s_1,\ldots,s_n\in\Gamma(X,\mathcal M)
$$

menentukan secara unik suatu homomorfisme modul

$$
\begin{aligned}
\varphi:\mathcal O_X^n&\longrightarrow\mathcal M,\\
e_i&\longmapsto s_i.
\end{aligned}
$$

#### Bukti {#br-bgk-2019-l13-thm-02-proof}

Untuk setiap himpunan terbuka $U\subseteq X$, berlaku

$$
\Gamma(U,\mathcal O_X^n)
=\Gamma(U,\mathcal O_X)^n.
$$

Ini adalah modul bebas atas $\Gamma(U,\mathcal O_X)$ dengan basis
$e_1,\ldots,e_n$. Seksi-seksi global $s_i$ memberikan restriksi

$$
s_i|_U\in\Gamma(U,\mathcal M).
$$

Menurut teorema penentuan, restriksi-restriksi tersebut menentukan secara unik
suatu homomorfisme $\Gamma(U,\mathcal O_X)$-modul

$$
\begin{aligned}
\Gamma(U,\mathcal O_X)^n&\longrightarrow\Gamma(U,\mathcal M),\\
e_i&\longmapsto s_i|_U.
\end{aligned}
$$

Homomorfisme-homomorfisme modul ini kompatibel dengan restriksi ke
$V\subseteq U$ dan karena itu menghasilkan suatu homomorfisme berkas modul.

<!-- upstream_entity: Beringter Raum/Modulgarbe/Schnitt und Modulgarbenhomomorphismus/Fakt -->

### Lema 13.11: seksi global sebagai homomorfisme modul {#br-bgk-2019-l13-lem-01}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal M$ suatu
$\mathcal O_X$-modul pada $X$. Maka suatu seksi global

$$
s\in\Gamma(X,\mathcal M)
$$

bersesuaian secara unik dengan homomorfisme modul

$$
\begin{aligned}
\varphi:\mathcal O_X&\longrightarrow\mathcal M,\\
1&\longmapsto s.
\end{aligned}
$$

#### Bukti {#br-bgk-2019-l13-lem-01-proof}

Ini adalah kasus khusus Teorema 13.10.

## Konstruksi untuk berkas modul {#br-bgk-2019-l13-s03}

<!-- upstream_entity: Beringter Raum/Modulgarben/Homomorphismenmodul/Definition -->

### Definisi 13.12: modul homomorfisme global {#br-bgk-2019-l13-def-08}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal M,\mathcal N$
merupakan berkas modul pada $X$. Ruang

$$
\operatorname{Hom}(\mathcal M,\mathcal N)
=\{\varphi:\mathcal M\longrightarrow\mathcal N
\mid \varphi\text{ homomorfisme modul}\},
$$

dengan struktur $\Gamma(X,\mathcal O_X)$-modul alaminya, disebut *modul
homomorfisme global* dari $\mathcal M$ ke $\mathcal N$.

Pada dasarnya, setiap konstruksi untuk modul $R$ mempunyai konstruksi analog
untuk modul $\mathcal O_X$. Gagasan pemandunya adalah bahwa objek-objek yang
dikonstruksi kembali memiliki “sifat-sifat yang tepat” di dalam kategori semua
modul $\mathcal O_X$. Karena itu dapat pula diharapkan bahwa definisi di atas
belum merupakan bentuk terakhir dan perlu diperluas menjadi versi berkas.

<!-- upstream_entity: Beringter Raum/Modulgarben/Homomorphismenmodulgarbe/Definition -->

### Definisi 13.13: berkas homomorfisme {#br-bgk-2019-l13-def-09}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal M,\mathcal N$
merupakan berkas modul pada $X$. Penetapan

$$
U\longmapsto
\operatorname{Hom}(\mathcal M|_U,\mathcal N|_U)
=\{\varphi:\mathcal M|_U\longrightarrow\mathcal N|_U
\mid \varphi\text{ homomorfisme modul}\}
$$

disebut *berkas homomorfisme* dari $\mathcal M$ ke $\mathcal N$. Berkas ini
dilambangkan dengan

$$
\mathcal Hom(\mathcal M,\mathcal N).
$$

Jadi,

$$
\mathcal Hom(\mathcal M,\mathcal N)(U)
=\operatorname{Hom}(\mathcal M|_U,\mathcal N|_U).
$$

<!-- upstream_entity: Beringter Raum/Modulgarben/Homomorphismenmodulgarbe/Garbe/Fakt -->

### Lema 13.14: berkas homomorfisme merupakan berkas modul {#br-bgk-2019-l13-lem-02}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal M,\mathcal N$
merupakan berkas modul pada $X$. Maka berkas homomorfisme

$$
\mathcal Hom(\mathcal M,\mathcal N)
$$

merupakan berkas $\mathcal O_X$-modul pada $X$.

#### Bukti {#br-bgk-2019-l13-lem-02-proof}

Terdapat hubungan

$$
\begin{aligned}
\mathcal Hom(\mathcal M,\mathcal N)(U)
&=\operatorname{Hom}(\mathcal M|_U,\mathcal N|_U)\\
&\subseteq\operatorname{Mor}(\mathcal M|_U,\mathcal N|_U).
\end{aligned}
$$

Menurut Lema 4.9, ruas kanan merupakan suatu berkas. Sifat homomorfisme, yaitu
kompatibilitas dengan penjumlahan dan perkalian skalar, dapat diuji secara
lokal; lihat Soal 13.11. Karena itu ruas kiri merupakan suatu subberkas.
Struktur $\mathcal O_X$ pada
$\mathcal Hom(\mathcal M,\mathcal N)$ diberikan oleh penjumlahan dan
perkalian skalar pada komponen kedua, dan operasi-operasi ini kompatibel dengan
restriksi.

<!-- upstream_entity: Beringter Raum/Modulgarbe/Dualer Modul/Definition -->

### Definisi 13.15: modul dual {#br-bgk-2019-l13-def-10}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal M$ suatu berkas
modul pada $X$. Berkas

$$
\mathcal M^*
=\mathcal Hom(\mathcal M,\mathcal O_X),
$$

dengan struktur $\mathcal O_X$-modul alaminya, disebut *modul dual* dari
$\mathcal M$.

<!-- upstream_entity: Beringter Raum/Modulgarben/Tensorprodukt/Definition -->

### Definisi 13.16: hasil kali tensor berkas modul {#br-bgk-2019-l13-def-11}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal F,\mathcal G$
merupakan berkas modul pada $X$. Berkasisasi praberkas

$$
U\longmapsto
\Gamma(U,\mathcal F)
\otimes_{\Gamma(U,\mathcal O_X)}
\Gamma(U,\mathcal G)
$$

disebut *hasil kali tensor* kedua modul tersebut. Hasil kali tensor ini
dilambangkan dengan

$$
\mathcal F\otimes_{\mathcal O_X}\mathcal G.
$$

Berdasarkan sifat universal berkasisasi, terdapat pemetaan kanonik

$$
\Gamma(U,\mathcal F)
\otimes_{\Gamma(U,\mathcal O_X)}
\Gamma(U,\mathcal G)
\longrightarrow
\Gamma\bigl(U,\mathcal F\otimes_{\mathcal O_X}\mathcal G\bigr)
$$

yang merupakan isomorfisme pada tangkai. Tangkai tersebut adalah hasil kali
tensor kedua tangkai; lihat Soal 13.13.

## Berkas invertibel {#br-bgk-2019-l13-s04}

<!-- upstream_entity: Beringter Raum/Invertierbare Garbe/Definition -->

### Definisi 13.17: berkas invertibel {#br-bgk-2019-l13-def-12}

Suatu $\mathcal O_X$-modul $\mathcal L$ pada ruang berdering
$(X,\mathcal O_X)$ disebut *invertibel* jika terdapat penutup terbuka

$$
X=\bigcup_{i\in I}U_i
$$

sedemikian sehingga restriksi-restriksi

$$
\mathcal L|_{U_i}
$$

isomorfik dengan $\mathcal O_X|_{U_i}$.

Suatu berkas invertibel $\mathcal L$ pada ruang berdering
$(X,\mathcal O_X)$ disebut *trivial* jika isomorfik dengan berkas struktur
$\mathcal O_X$.

<!-- upstream_entity: Topologischer Raum/Reelles Geradenbündel/Stetige Schnitte/Invertierbar/Beispiel -->

### Contoh 13.18: berkas seksi suatu bundel garis {#br-bgk-2019-l13-exm-02}

Misalkan $X$ ruang topologis yang dilengkapi berkas fungsi kontinu
$C(-,\mathbb R)$, dan

$$
L\longrightarrow X
$$

suatu bundel garis real pada $X$. Maka berkas $S$ dari seksi-seksi kontinu
dalam pengertian Contoh 3.12 merupakan $C(-,\mathbb R)$-modul invertibel.
Untuk suatu himpunan terbuka $U\subseteq X$ dengan trivialisasi

$$
L|_U\cong\mathbb R\times U,
$$

memang berlaku

$$
S(U,L|_U)\cong C(U,\mathbb R),
$$

<!-- upstream_entity: Projektiver Raum/Invertierbare Garbe/Untergarbe/Beispiel -->

### Contoh 13.19: berkas invertibel pada ruang projektif {#br-bgk-2019-l13-exm-03}

Misalkan $K$ lapangan dan $\mathbb P_K^n$ ruang projektif di atas $K$. Untuk
setiap subhimpunan terbuka $U$, berkas struktur merupakan subhimpunan lapangan
fungsi

$$
\Gamma(U,\mathcal O_{\mathbb P_K^n})
\subseteq
K\left(\frac{X_1}{X_0},\ldots,\frac{X_n}{X_0}\right).
$$

Karena gelanggang polinomial bersifat faktorial, untuk setiap ideal homogen
$\mathfrak a$ terdapat polinomial homogen $f$ berderajat maksimal tanpa faktor
berulang, yang ditentukan secara unik hingga perkalian dengan suatu skalar,
sedemikian sehingga

$$
D_+(\mathfrak a)\subseteq D_+(f).
$$

Di sini $f=1$ diperbolehkan, tetapi dalam hal itu notasi $D_+(f)$ tidak
digunakan. Menurut Teorema 9.8, gelanggang seksi global sama dengan

$$
\begin{aligned}
\Gamma(U,\mathcal O_{\mathbb P_K^n})
&=\Gamma(D_+(f),\mathcal O_{\mathbb P_K^n})\\
&=(K[X_0,X_1,\ldots,X_n]_f)_0\\
&\subseteq
K\left(\frac{X_1}{X_0},\ldots,\frac{X_n}{X_0}\right).
\end{aligned}
$$

Tetapkan $\ell\in\mathbb Z$. Kita mendefinisikan suatu berkas
$\mathcal O_{\mathbb P_K^n}(\ell)$ melalui

$$
\begin{aligned}
\Gamma\bigl(U,\mathcal O_{\mathbb P_K^n}(\ell)\bigr)
&=\Gamma\bigl(D_+(f),\mathcal O_{\mathbb P_K^n}(\ell)\bigr)\\
&:=(K[X_0,X_1,\ldots,X_n]_f)_\ell.
\end{aligned}
$$

Ini merupakan suatu berkas invertibel. Pada $D_+(X_0)$, dan demikian pula
pada $D_+(X_i)$, pemetaan

$$
\begin{aligned}
(K[X_0,X_1,\ldots,X_n]_{X_0})_0
&\longrightarrow
(K[X_0,X_1,\ldots,X_n]_{X_0})_\ell,\\
\frac FG&\longmapsto X_0^\ell\frac FG
\end{aligned}
$$

merupakan isomorfisme modul atas
$(K[X_0,X_1,\ldots,X_n]_{X_0})_0$ yang terbawa ke subhimpunan-subhimpunan
terbuka yang lebih kecil. Evaluasi global pada ruang projektif hanyalah

$$
(K[X_0,X_1,\ldots,X_n])_\ell.
$$

Ini menunjukkan bahwa, untuk $n\geq 1$, berkas-berkas invertibel tersebut
tidak saling isomorfik bagi $\ell\geq 0$. Hal ini berlaku untuk semua
$\ell$.

<!-- upstream_entity: Lokal beringter Raum/Invertierbare Garbe/Schnitt/Invertierbarkeitsort/Definition -->

### Definisi 13.20: lokus keterbalikan suatu seksi {#br-bgk-2019-l13-def-13}

Misalkan $(X,\mathcal O_X)$ ruang berdering lokal, $\mathcal L$ suatu berkas
invertibel pada $X$, dan

$$
s\in\Gamma(X,\mathcal L)
$$

suatu seksi global. Himpunan

$$
X_s
:=\{P\in X\mid s_P\notin\mathfrak m_P\mathcal L_P\}
$$

disebut *lokus keterbalikan* dari $s$.

Komplemennya,

$$
X\setminus X_s,
$$

yaitu lokus nol seksi tersebut, dilambangkan dengan $Z(s)$.

<!-- upstream_entity: Lokal beringter Raum/Invertierbare Garbe/Schnitt/Invertierbarkeit/Offen/Fakt -->

### Lema 13.21: lokus keterbalikan bersifat terbuka {#br-bgk-2019-l13-lem-03}

Misalkan $(X,\mathcal O_X)$ ruang berdering lokal, $\mathcal L$ suatu berkas
invertibel pada $X$, dan

$$
s\in\Gamma(X,\mathcal L)
$$

suatu seksi global. Maka lokus keterbalikan

$$
X_s\subseteq X
$$

bersifat terbuka.

#### Bukti {#br-bgk-2019-l13-lem-03-proof}

Pernyataan ini mengikuti dari Lema 7.16 melalui pertimbangan lokal.

<!-- upstream_entity: Lokal beringter Raum/Invertierbare Garbe/Schnitt/Invertierbarkeit/Trivial/Fakt -->

### Lema 13.22: trivialisasi pada lokus keterbalikan {#br-bgk-2019-l13-lem-04}

Misalkan $(X,\mathcal O_X)$ ruang berdering lokal dan $\mathcal L$ suatu berkas
invertibel pada $X$. Misalkan

$$
s\in\Gamma(X,\mathcal L)
$$

seksi global dengan lokus keterbalikan $X_s$. Maka restriksi

$$
\mathcal L|_{X_s}
$$

bersifat trivial.

#### Bukti {#br-bgk-2019-l13-lem-04-proof}

Menurut Lema 13.11, seksi global $s$ menentukan suatu homomorfisme modul

$$
\begin{aligned}
\mathcal O_X&\longrightarrow\mathcal L,\\
1&\longmapsto s,
\end{aligned}
$$

dan khususnya suatu homomorfisme modul

$$
\varphi:
\mathcal O_X|_{X_s}
\longrightarrow
\mathcal L|_{X_s}.
$$

Untuk setiap titik $P\in X_s$, pemetaan ini merupakan isomorfisme. Karena itu,
menurut Lema 4.6, $\varphi$ juga merupakan isomorfisme.
