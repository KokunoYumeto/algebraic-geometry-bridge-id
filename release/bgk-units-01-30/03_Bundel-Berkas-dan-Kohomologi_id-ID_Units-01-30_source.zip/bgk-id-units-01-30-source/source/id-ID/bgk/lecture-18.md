---
title: "Kuliah 18 - Diferensial Kähler"
stable_id: br-bgk-2019-l18
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 18"
upstream_pageid: 109022
upstream_revid: 1069569
upstream_timestamp: "2026-02-06T07:06:24Z"
upstream_mediawiki_sha1: 2278e6ac498280b0903b3eb4d27293a2647401b5
source_url: "https://de.wikiversity.org/w/index.php?oldid=1069569"
authority_manifest: authority/wikiversity-bgk/unit-18/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: f0014846fe068d3b1bfd4488c1db66fdd6039fa2d70ff7b8a213875a56d39495
authority_manifest_status: "Bekuan authority terminal lengkap; 41 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
lecture_xml: authority/wikiversity-bgk/unit-18/lecture-18.xml
lecture_xml_sha256: 6258ac16b73eb1dbf8c25cd6147c37f4cbab4cc5fe10319c5214951f7d54574e
lecture_expanded_tex: authority/wikiversity-bgk/unit-18/lecture-18-expanded.tex
lecture_expanded_tex_sha256: 36090ca8661261017db8076345b22126ae1d99c4df8efbc6480533775264b955
official_pdf: authority/artifacts/bgk-lecture-18-official.pdf
official_pdf_sha256: 95c36781fe3c5df56320e7cc7992ddff2a9c548e4099d811c768bc29c37ebfc9
official_pdf_status: "Saksi PDF resmi lokal; 99.940 byte, 9 halaman, dan SHA-1 unggahan eabef241ecf776d80e72491645cd93bfd5fcca1e telah diverifikasi."
official_pdf_metadata: authority/wikiversity-bgk/unit-18/official-pdfs-api.json
official_pdf_source_bytes: 99940
official_pdf_source_sha1: eabef241ecf776d80e72491645cd93bfd5fcca1e
older_course_pdf: authority/artifacts/bgk-course-official.pdf
older_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
authority_precedence: "Revisi semantik Wikiversity yang dibekukan mengendalikan teks; PDF seluruh kursus tahun 2020 hanya saksi historis."
media_credits: source/id-ID/media-credits-bgk-unit-18.md
rights_ledger: authority/RIGHTS-bgk-unit-18.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-18.json
asset_closure_sha256: 33d6804e99934e11b06f7d05a732646e9371a51dd6fbbb35d642da28080caa77
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF adalah saksi authority, bukan teks edisi; metadata Commons CC BY-SA 4.0 dan pemberitahuan tertanam CC-by-sa 3.0 dipertahankan tanpa pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 18: Diferensial Kähler {#br-bgk-2019-l18}

## Modul diferensial Kähler {#br-bgk-2019-l18-s01}

Pada suatu manifold $M$ terdapat bundel tangen

$$
TM\longrightarrow M.
$$

Di atas sebuah titik $P\in M$, bundel ini terdiri atas ruang tangen $T_PM$,
yang diberikan oleh kelas-kelas ekuivalensi kurva terdiferensialkan

$$
[-\epsilon,\epsilon]\longrightarrow M
$$

yang melalui $P$. Bundel tangen adalah bundel vektor real di atas $M$ yang
mencirikan manifold tersebut dan memungkinkan kita mendefinisikan banyak
invarian manifold. Kita hendak mendefinisikan objek yang bersesuaian untuk
suatu skema, katakanlah skema bertipe hingga di atas sebuah lapangan.
Pemindahan langsung konsep analitik tidak mungkin dilakukan karena tidak ada
pengganti langsung bagi kurva terdiferensialkan. Oleh karena itu, kita
bertolak dari sudut pandang lain terhadap bundel tangen.

Sebuah seksi kontinu atau terdiferensialkan dalam bundel tangen, di atas suatu
himpunan terbuka $U\subseteq M$, disebut medan vektor kontinu atau
terdiferensialkan. Medan vektor $F$ memasangkan kepada setiap titik $P\in U$
sebuah vektor tangen

$$
F(P)\in T_PM.
$$

Fungsi terdiferensialkan pada $M$ dapat diturunkan sepanjang medan vektor
$F$, dan hasilnya kembali merupakan sebuah fungsi. Kita menetapkan

$$
(D_F(f))(P):=(D_{F(P)}f)(P),
$$

dengan $(D_{F(P)}f)(P)$ menyatakan turunan berarah $f$ pada $P$ ke arah
$F(P)$. Turunan berarah ini dapat dihitung dalam setiap peta; berkat aturan
rantai, hasilnya tidak bergantung pada peta yang dipilih. Jika $M$
terdiferensialkan tak hingga kali, kita memperoleh pemetaan

$$
D_F:C^\infty(U,\mathbb R)\longrightarrow C^\infty(U,\mathbb R),
\qquad f\longmapsto D_F(f).
$$

Pemetaan ini merupakan derivasi linear-$\mathbb R$ dalam pengertian definisi
aljabar murni berikut. Berangkat dari derivasi, kita akan memperkenalkan
modul diferensial Kähler dan, secara dual, mengembangkan berkas tangen dalam
konteks teori skema. Berkas tersebut bebas lokal apabila skemanya tidak
mempunyai singularitas. Dalam kuliah ini kita meninjau situasi afin dan tidak
menyajikan bukti.

<!-- upstream_entity: Algebraische Derivation/Definition -->

### Definisi 18.1: derivasi aljabar {#br-bgk-2019-l18-def-01}

Misalkan $R$ gelanggang komutatif, $A$ aljabar komutatif $R$, dan $M$ modul
$A$. Suatu pemetaan linear-$R$

$$
\delta:A\longrightarrow M
$$

yang memenuhi

$$
\delta(ab)=a\delta(b)+b\delta(a)
$$

untuk semua $a,b\in A$ disebut *derivasi $R$* dengan nilai dalam $M$.

Aturan yang digunakan di sini disebut *aturan Leibniz*. Sering kali $M=A$.
Sebagai contoh, untuk gelanggang polinomial

$$
A=R[X_1,\ldots,X_n],
$$

turunan parsial formal ke-$i$

$$
\frac{\partial}{\partial X_i}
$$

merupakan derivasi $R$ dari $A$ ke $A$. Himpunan derivasi dari $A$ ke $M$
secara alami merupakan modul $A$ dan dilambangkan

$$
\operatorname{Der}_R(A,M).
$$

<!-- upstream_entity: Kähler Differentiale/Universeller Modul/Definition -->

### Definisi 18.2: modul diferensial Kähler {#br-bgk-2019-l18-def-02}

Misalkan $R$ gelanggang komutatif dan $A$ aljabar komutatif $R$. Modul $A$
yang dibangkitkan oleh semua simbol $d(a)$, $a\in A$, dengan mengidentifikasi

$$
d(ab)=ad(b)+bd(a)\qquad\text{untuk semua }a,b\in A
$$

dan

$$
d(ra+sb)=rd(a)+sd(b)
\qquad\text{untuk semua }r,s\in R\text{ dan }a,b\in A,
$$

disebut *modul diferensial Kähler* dari $A$ di atas $R$. Modul ini
dilambangkan

$$
\Omega_{A/R}.
$$

Dalam konstruksi ini, kita mulai dengan modul $A$ bebas $F$ yang mempunyai
$da$, $a\in A$, sebagai basis, lalu membentuk modul kelas sisanya terhadap
submodul yang dibangkitkan oleh unsur-unsur

$$
d(ab)-ad(b)-bd(a)\qquad(a,b\in A)
$$

dan

$$
d(ra+sb)-rd(a)-sd(b)
\qquad(r,s\in R\text{ dan }a,b\in A).
$$

Pemetaan

$$
d:A\longrightarrow\Omega_{A/R},
\qquad a\longmapsto d(a)=da,
$$

disebut *derivasi universal*. Pemeriksaan langsung menunjukkan bahwa ini
memang suatu derivasi $R$. Unsur-unsur $\Omega_{A/R}$ disebut *bentuk
diferensial aljabar*.

<!-- upstream_entity: Kähler-Differentiale/Universelle Eigenschaft/Fakt -->

### Lema 18.3: sifat universal {#br-bgk-2019-l18-lem-01}

Misalkan $R$ gelanggang komutatif dan $A$ aljabar komutatif $R$. Modul
diferensial Kähler $\Omega_{A/R}$ mempunyai sifat universal berikut. Untuk
setiap modul $A$ $M$ dan setiap derivasi $R$

$$
\delta:A\longrightarrow M,
$$

terdapat tepat satu pemetaan linear-$A$

$$
\epsilon:\Omega_{A/R}\longrightarrow M
$$

yang memenuhi $\epsilon\circ d=\delta$.

#### Bukti {#br-bgk-2019-l18-lem-01-proof}

Bukti ini tidak disajikan dalam kuliah.

Untuk setiap $da$, $a\in A$, harus berlaku
$\epsilon(da)=\delta(a)$. Karena unsur-unsur $da$ membangkitkan
$\Omega_{A/R}$ sebagai modul $A$, paling banyak terdapat satu homomorfisme
seperti itu.

Misalkan $F$ modul bebas dengan basis $da$, $a\in A$. Penetapan

$$
\widetilde\epsilon(da)=\delta(a)
$$

menentukan suatu homomorfisme modul $A$

$$
\widetilde\epsilon:F\longrightarrow M.
$$

Kita mempunyai $\Omega_{A/R}=F/U$, dengan $U$ submodul yang dibangkitkan
oleh unsur-unsur yang menyatakan aturan Leibniz dan linearitas. Karena
$\delta$ suatu derivasi, $\widetilde\epsilon$ memetakan $U$ ke $0$. Maka
teorema homomorfisme memberi satu-satunya pemetaan linear-$A$

$$
\epsilon:\Omega_{A/R}\cong F/U\longrightarrow M
$$

dengan

$$
\epsilon(da)=\widetilde\epsilon(da)=\delta(a).
$$

Pernyataan ini dapat pula dinyatakan sebagai isomorfisme modul $A$ alami

$$
\operatorname{Der}_R(A,M)
\cong\operatorname{Hom}_A(\Omega_{A/R},M).
$$

Khususnya,

$$
\operatorname{Der}_R(A,A)
\cong\operatorname{Hom}_A(\Omega_{A/R},A)
=\Omega_{A/R}^*,
$$

dengan ruas kanan merupakan modul dual.

<!-- upstream_entity: Kähler-Differentiale/Elementare Eigenschaften/Fakt -->

### Lema 18.4: sifat-sifat elementer {#br-bgk-2019-l18-lem-02}

Misalkan $R$ gelanggang komutatif, $A$ aljabar komutatif $R$, dan
$\Omega_{A/R}$ modul diferensial Kähler. Maka sifat-sifat berikut berlaku.

1. $dr=0$ untuk semua $r\in R$.

2. $\Omega_{A/R}$ dapat dideskripsikan sebagai modul kelas sisa modul $A$
   bebas dengan basis $da$, $a\in A$, terhadap submodul yang dibangkitkan
   oleh relasi-relasi Leibniz dan oleh $dr$, $r\in R$.

3. Jika $A=R[x_1,\ldots,x_n]$, maka $dx_i$, $i=1,\ldots,n$, merupakan
   sistem pembangkit modul $A$ bagi $\Omega_{A/R}$.

4. Misalkan

   $$
   A=R[x_1,\ldots,x_n]
   =R[X_1,\ldots,X_n]/\mathfrak a.
   $$

   Untuk polinomial $F\in R[X_1,\ldots,X_n]$ dan unsur terkait
   $f=F(x_1,\ldots,x_n)\in A$, di dalam $\Omega_{A/R}$ berlaku

   $$
   df=
   \frac{\partial F}{\partial x_1}(x_1,\ldots,x_n)dx_1
   +\cdots+
   \frac{\partial F}{\partial x_n}(x_1,\ldots,x_n)dx_n,
   $$

   dengan $\partial F/\partial x_i$ menyatakan derivasi parsial ke-$i$.

5. Untuk diagram komutatif

   $$
   \begin{matrix}
   R&\longrightarrow&S\\
   \downarrow&&\downarrow\\
   A&\xrightarrow{\ \varphi\ }&B,
   \end{matrix}
   $$

   dengan panah-panahnya homomorfisme gelanggang, terdapat tepat satu
   pemetaan linear-$A$

   $$
   \Omega_{A/R}\longrightarrow\Omega_{B/S},
   \qquad da\longmapsto d\varphi(a).
   $$

#### Bukti {#br-bgk-2019-l18-lem-02-proof}

Bukti ini tidak disajikan dalam kuliah.

1. Misalkan $r\in R$. Berdasarkan linearitas $R$,
   $d(r1)=rd(1)$. Berdasarkan aturan hasil kali,

   $$
   d(1)=d(1\cdot1)=1d(1)+1d(1),
   $$

   sehingga pengurangan memberi $d(1)=0$.

2. Kita buktikan bahwa submodul $V$ yang dimaksud sama dengan submodul $U$
   yang dibangkitkan oleh semua relasi Leibniz dan relasi linearitas.
   Berdasarkan bagian (1), inklusi $V\subseteq U$ jelas. Untuk $a,b\in A$
   dan $r,s\in R$, modulo $V$ berlaku

   $$
   \begin{aligned}
   d(ra+sb)
   &=d(ra)+d(sb)\\
   &=rda+adr+sdb+bds\\
   &=rda+sdb,
   \end{aligned}
   $$

   sehingga relasi-relasi linearitas juga termasuk dalam $V$.

3. Ini mengikuti dari linearitas dan aturan Leibniz.

4. Kedua ruas linear-$R$, sehingga cukup membuktikan pernyataan untuk
   monomial. Untuk monomial, pernyataan dibuktikan dengan induksi pada
   derajat total monomial.

5. Karena $B$ merupakan aljabar $A$ melalui $\varphi:A\to B$,
   $\Omega_{B/S}$ juga merupakan modul $A$. Komposisi

   $$
   A\xrightarrow{\ \varphi\ }B
   \xrightarrow{\ d\ }\Omega_{B/S}
   $$

   adalah derivasi $R$, sebagaimana dapat diperiksa langsung. Berdasarkan
   sifat universal $\Omega_{A/R}$, terdapat tepat satu pemetaan linear-$A$

   $$
   \widetilde\varphi:\Omega_{A/R}\longrightarrow\Omega_{B/S}
   $$

   dengan $d\varphi(a)=\widetilde\varphi(da)$.

<!-- upstream_entity: Polynomring/Kählermodul und Derivation/Beschreibung/Fakt -->

### Lema 18.5: modul diferensial gelanggang polinomial {#br-bgk-2019-l18-lem-03}

Misalkan $R$ gelanggang komutatif dan

$$
A=R[X_1,\ldots,X_n]
$$

gelanggang polinomial dalam $n$ variabel di atas $R$. Maka modul diferensial
Kähler merupakan modul $A$ bebas dengan basis

$$
dX_1,dX_2,\ldots,dX_n.
$$

Terhadap basis ini, derivasi universal diberikan oleh

$$
\begin{aligned}
A&\longrightarrow AdX_1\oplus\cdots\oplus AdX_n,\\
F&\longmapsto dF
=\frac{\partial F}{\partial X_1}dX_1
+\cdots+
\frac{\partial F}{\partial X_n}dX_n.
\end{aligned}
$$

#### Bukti {#br-bgk-2019-l18-lem-03-proof}

Bukti ini tidak disajikan dalam kuliah.

Misalkan $G$ modul $A$ bebas yang dibangkitkan oleh simbol-simbol $dX_i$.
Pemetaan

$$
\varphi:G\longrightarrow\Omega_{A/R}
$$

yang memetakan unsur basis $dX_i$ ke diferensial $dX_i$ surjektif menurut
Lema 18.4(3). Turunan parsial ke-$i$

$$
\frac{\partial}{\partial X_i}:A\longrightarrow A,
\qquad F\longmapsto\frac{\partial F}{\partial X_i},
$$

merupakan derivasi $R$. Sifat universal modul bentuk diferensial karena itu
memberi pemetaan linear-$A$

$$
p_i:\Omega_{A/R}\longrightarrow A
$$

dengan $p_i\circ d=\partial/\partial X_i$. Di sini $p_i(dX_i)=1$ dan
$p_i(dX_j)=0$ untuk $j\ne i$. Bersama-sama, pemetaan ini memberi pemetaan
linear-$A$

$$
p=p_1\times\cdots\times p_n:
\Omega_{A/R}\longrightarrow A^n\cong G
$$

yang memenuhi $p\circ\varphi=\operatorname{Id}_G$. Jadi $\varphi$ juga
injektif.

Secara umum, modul diferensial Kähler tidak bebas.

<!-- upstream_entity: Kähler-Differentiale/Nenneraufnahme/Fakt -->

### Lema 18.6: diferensial dan pelokalan {#br-bgk-2019-l18-lem-04}

Misalkan $R$ gelanggang komutatif, $A$ aljabar komutatif $R$, dan
$S\subseteq A$ suatu sistem multiplikatif. Maka

$$
\Omega_{A_S/R}\cong(\Omega_{A/R})_S.
$$

#### Bukti {#br-bgk-2019-l18-lem-04-proof}

Lihat Soal 18.19.

<!-- upstream_entity: Kähler-Differentiale/Relative Differentialsequenz/Fakt -->

### Lema 18.7: barisan diferensial relatif {#br-bgk-2019-l18-lem-05}

Misalkan $R$ gelanggang komutatif, $A$ dan $B$ aljabar komutatif $R$, dan

$$
\varphi:A\longrightarrow B
$$

homomorfisme aljabar $R$. Maka barisan modul $B$

$$
\Omega_{A/R}\otimes_AB
\longrightarrow\Omega_{B/R}
\longrightarrow\Omega_{B/A}
\longrightarrow0
$$

eksak. Di sini $da\otimes b$ dipetakan ke $bd\varphi(a)$, sedangkan $db$
di $\Omega_{B/R}$ dipetakan ke $db$ di $\Omega_{B/A}$.

#### Bukti {#br-bgk-2019-l18-lem-05-proof}

Bukti ini tidak disajikan dalam kuliah.

Surjektivitas di sebelah kanan jelas. Untuk menunjukkan eksak di posisi
kedua, kita gunakan deskripsi dari Lema 18.4(2). Kedua modul
$\Omega_{B/A}$ dan $\Omega_{B/R}$ mempunyai sistem pembangkit yang sama,
dan relasi Leibniznya juga sama. Modul $\Omega_{B/A}$ diperoleh dari
$\Omega_{B/R}$ tepat dengan menjadikan submodul $B$ yang dibangkitkan oleh
$da$, $a\in A$, sama dengan $0$. Submodul ini persis citra pemetaan di
sebelah kiri.

## Diferensial Kähler dan matriks Jacobi {#br-bgk-2019-l18-s02}

<!-- upstream_entity: Kähler-Differentiale/Konormalensequenz/Fakt -->

### Lema 18.8: barisan konormal {#br-bgk-2019-l18-lem-06}

Misalkan $R$ gelanggang komutatif, $A$ aljabar komutatif $R$, dan
$I\subseteq A$ suatu ideal dengan gelanggang kelas sisa $B=A/I$. Maka
barisan modul $B$

$$
I/I^2\longrightarrow
\Omega_{A/R}\otimes_AB\longrightarrow
\Omega_{B/R}\longrightarrow0
$$

eksak. Di sini $a\in I$ dipetakan ke $da\otimes1$, sedangkan
$da\otimes b$ dipetakan ke $bda$.

#### Bukti {#br-bgk-2019-l18-lem-06-proof}

Bukti ini tidak disajikan dalam kuliah.

Pemetaan linear-$R$

$$
A\longrightarrow\Omega_{A/R},\qquad a\longmapsto da,
$$

dapat dibatasi pada ideal $I\subseteq A$. Dengan menensor bersama $A/I$
dan menggunakan Proposisi 16.9 (Teori Invarian (Osnabrück 2025--2026)),
bagian (2), kita memperoleh pemetaan linear-$A/I$

$$
I/I^2\cong I\otimes_AA/I
\longrightarrow\Omega_{A/R}\otimes_AA/I.
$$

Surjektivitas pemetaan di sebelah kanan jelas karena modul $B$
$\Omega_{B/R}$ dibangkitkan oleh $db$, $b\in B$, dan unsur-unsur ini berasal
dari $da$, $a\in A$. Suatu unsur $a\in I$ dipetakan ke $da$, lalu ke $0$ di
$\Omega_{B/R}$, sebab unsur $a$ sendiri menjadi $0$ dalam $B$.

Sekarang misalkan

$$
\omega\in\Omega_{A/R}\otimes_AB
$$

dipetakan ke $0$ dalam $\Omega_{B/R}$. Kita dapat menulis

$$
\omega
=\sum_{i=1}^n da_i\otimes b_i
=\sum_{i=1}^n da_i\otimes\bar c_i
$$

dengan $a_i,c_i\in A$. Karena unsur ini dipetakan ke $0$ dalam
$\Omega_{B/R}$, di dalam modul $B$ bebas yang dibangkitkan oleh simbol
$db$, $b\in B$, berlaku relasi

$$
\sum_{i=1}^n c_i\,da_i
=\sum_{j=1}^m h_j\omega_j,
$$

dengan $h_j\in B$ dan $\omega_j$ pembangkit relasi modul diferensial
Kähler, yakni relasi berbentuk

$$
d(fg)=f\,dg+g\,df
$$

untuk $f,g\in B$, atau

$$
d(rf+sg)=r\,df+s\,dg
$$

untuk $r,s\in R$ dan $f,g\in B$. Modul $B$ bebas tersebut diperoleh dari
modul $A$ bebas yang dibangkitkan oleh $da$, $a\in A$, dengan menjadikan
koefisien-koefisien dari $I$ dan semua $dI$ sama dengan $0$. Karena itu, di
dalam modul $A$ bebas ini berlaku

$$
\sum_{i=1}^n c_i\,da_i-
\sum_{j=1}^m h_j\omega_j
=\sum_{k=1}^{\ell}m_k\,dn_k+du
$$

dengan $m_k\in I$, $n_k\in B$, dan $u\in I$. Dalam
$\Omega_{A/R}\otimes_RB$, suku $\sum_{k=1}^{\ell}m_k\,dn_k$ menjadi $0$
karena tensorisasi. Jadi di sana memang berlaku

$$
\sum_{i=1}^n c_i\,da_i=du.
$$

<!-- upstream_entity: Kähler-Differentiale/Von endlichem Typ/Restklassendarstellung/Fakt -->

### Korolari 18.9: penyajian kelas sisa {#br-bgk-2019-l18-cor-01}

Misalkan $R$ gelanggang komutatif dan $A$ aljabar komutatif $R$ yang
dibangkitkan hingga, disajikan sebagai

$$
A=R[X_1,\ldots,X_n]/(F_1,\ldots,F_k).
$$

Maka

$$
\Omega_{A/R}
=\bigoplus_{i=1}^nAdX_i/(dF_1,\ldots,dF_k).
$$

#### Bukti {#br-bgk-2019-l18-cor-01-proof}

Bukti ini tidak disajikan dalam kuliah.

Pernyataan ini mengikuti dari Lema 18.5 dan Lema 18.8.

<!-- upstream_entity: Kähler-Differentiale/Jacobi-Matrix/Kokern-Darstellung/Bemerkung -->

### Catatan 18.10: penyajian sebagai kokernel matriks Jacobi {#br-bgk-2019-l18-rem-01}

Misalkan $R$ gelanggang komutatif dan $A$ aljabar komutatif $R$ yang
dibangkitkan hingga, disajikan sebagai

$$
A=R[X_1,\ldots,X_n]/(F_1,\ldots,F_k).
$$

Menurut Lema 18.4(4),

$$
dF_j=
\frac{\partial F_j}{\partial X_1}dX_1
+\cdots+
\frac{\partial F_j}{\partial X_n}dX_n,
$$

dan menurut Korolari 18.9 terdapat barisan eksak

$$
A^k\xrightarrow{\ M\ }A^n
\longrightarrow\Omega_{A/R}\longrightarrow0,
$$

dengan

$$
M=
\begin{pmatrix}
\dfrac{\partial F_1}{\partial X_1}&\cdots&
\dfrac{\partial F_k}{\partial X_1}\\
\vdots&\ddots&\vdots\\
\dfrac{\partial F_1}{\partial X_n}&\cdots&
\dfrac{\partial F_k}{\partial X_n}
\end{pmatrix}
$$

matriks Jacobi yang ditranspos, tanpa evaluasi pada suatu titik. Vektor
standar $e_j$ dipetakan ke $dX_j$, dan vektor-vektor kolom

$$
\begin{pmatrix}
\dfrac{\partial F_j}{\partial X_1}\\
\vdots\\
\dfrac{\partial F_j}{\partial X_n}
\end{pmatrix},
$$

yang menyatakan unsur nol $dF_j$, merupakan citra-citra pemetaan yang
diberikan oleh matriks tersebut.

## Kehalusan dan kereguleran {#br-bgk-2019-l18-s03}

<!-- upstream_entity: Affin-algebraische Menge/Punkt/Lokale Dimension/Glatt/Partielle Ableitungen/Definition -->

### Definisi 18.11: titik halus {#br-bgk-2019-l18-def-03}

Misalkan $K$ lapangan tertutup aljabar dan

$$
F_1,\ldots,F_s\in K[X_1,\ldots,X_n]
$$

polinomial-polinomial dengan himpunan aljabar afin terkait

$$
Y=V(F_1,\ldots,F_s)\subseteq\mathbb A_K^n.
$$

Misalkan $P\in Y$ suatu titik sehingga $Y$ mempunyai dimensi $d$ pada $P$.
Titik $P$ disebut *titik halus* $Y$ apabila peringkat matriks

$$
\left(\frac{\partial F_i}{\partial X_j}\right)_{i,j}
$$

pada $P$ paling sedikit $n-d$. Jika tidak, titik tersebut disebut
*singular*.

Untuk aljabar $K$

$$
A=K[X_1,\ldots,X_n]/(f_1,\ldots,f_m)
$$

dan titik

$$
P=(a_1,\ldots,a_n)\in V=V(f_1,\ldots,f_m)
$$

dengan ideal maksimal terkait $\mathfrak m_P\subseteq A$ dan pelokalan

$$
R=A_{\mathfrak m_P}=\mathcal O_{V,P},
$$

kita mempunyai

$$
\Omega_{R/K}=\Omega_{A/K}\otimes_AR.
$$

Tensorisasi

$$
\Omega_{R/K}\otimes_RK
=\Omega_{A/K}\otimes_AK
$$

untuk evaluasi lapangan residu

$$
A\longrightarrow A_{\mathfrak m}
\longrightarrow A_{\mathfrak m}/\mathfrak mA_{\mathfrak m}=K
$$

memainkan peranan khusus. Terdapat hubungan langsung dengan ruang dual dari
ruang tangen ekstrinsik $V$ pada $P$. Dengan kata lain,
$\Omega_{R/K}\otimes_RK$ secara alami adalah ruang kotangen di titik $P$.

<!-- upstream_entity: Kähler-Differentiale/Gleichungen/Extrinsischer Kotangentialraum/Fakt -->

### Lema 18.12: ruang kotangen ekstrinsik {#br-bgk-2019-l18-lem-07}

Misalkan $K$ lapangan,

$$
A=K[X_1,\ldots,X_n]/(f_1,\ldots,f_m)
$$

aljabar $K$ yang dibangkitkan hingga, dan

$$
P=(a_1,\ldots,a_n)\in V=V(f_1,\ldots,f_m)
$$

suatu titik dari himpunan nol terkait, dengan ideal maksimal
$\mathfrak m_P\subseteq A$ dan pelokalan

$$
R=A_{\mathfrak m}.
$$

Maka ruang tangen $V$ pada $P$ secara kanonik merupakan ruang vektor dual
dari $\Omega_{R/K}\otimes_RK$.

#### Bukti {#br-bgk-2019-l18-lem-07-proof}

Bukti ini tidak disajikan dalam kuliah.

Menurut Catatan 18.10, terdapat barisan eksak

$$
A^m\xrightarrow{\ M\ }A^n
\longrightarrow\Omega_{A/K}\longrightarrow0,
$$

dengan $M$ matriks Jacobi yang ditranspos dari $f_i$. Kita menensor dengan
lapangan residu $K$ dan memperoleh barisan eksak ruang vektor $K$
berdimensi hingga

$$
K^m\xrightarrow{\ M(P)\ }K^n
\longrightarrow\Omega_{A/K}\otimes_AK
\longrightarrow0.
$$

Barisan dualnya ialah

$$
0\longrightarrow
(\Omega_{A/K}\otimes_AK)^*
\longrightarrow K^n
\xrightarrow{\ \operatorname{Jac}(P)\ }K^m,
$$

dan juga eksak. Menurut definisi ruang tangen, kernel matriks Jacobi pada
$P$ adalah ruang tangen $V$ pada $P$.

<!-- upstream_entity: Lokaler Ring/Regulär/Erzeugeranzahl/Definition -->

### Definisi 18.13: gelanggang lokal regular {#br-bgk-2019-l18-def-04}

Suatu gelanggang lokal Noether $(R,\mathfrak m)$ berdimensi $n$ disebut
*regular* apabila terdapat $n$ unsur

$$
f_1,\ldots,f_n\in\mathfrak m
$$

yang membangkitkan ideal maksimal $\mathfrak m$.

<!-- upstream_entity: Kähler-Differentiale/Lokaler Ring/Kotangentialraum/Fakt -->

### Lema 18.14: ideal maksimal dan ruang kotangen {#br-bgk-2019-l18-lem-08}

Misalkan $K$ lapangan dan $R$ aljabar komutatif lokal $K$, serta pemetaan
komposit

$$
K\longrightarrow R\longrightarrow R/\mathfrak m
$$

merupakan isomorfisme. Maka pemetaan

$$
\mathfrak m/\mathfrak m^2
\longrightarrow\Omega_{R/K}\otimes_RR/\mathfrak m,
\qquad[f]\longmapsto df\otimes1,
$$

merupakan isomorfisme modul $R/\mathfrak m$.

#### Bukti {#br-bgk-2019-l18-lem-08-proof}

Bukti ini tidak disajikan dalam kuliah.

Menurut Lema 18.8, terdapat barisan eksak homomorfisme modul
$R/\mathfrak m$

$$
\mathfrak m/\mathfrak m^2
\longrightarrow\Omega_{R/K}\otimes_RR/\mathfrak m
\longrightarrow\Omega_{(R/\mathfrak m)/K}
\longrightarrow0.
$$

Menurut asumsi, $R/\mathfrak m=K$, sehingga
$\Omega_{(R/\mathfrak m)/K}=0$. Jadi pemetaan yang diberikan surjektif.
Untuk membuktikan injektivitas, kita tinjau pemetaan dual
$R/\mathfrak m$, yaitu

$$
\begin{aligned}
&\operatorname{Hom}_{R/\mathfrak m}
(\Omega_{R/K}\otimes_RR/\mathfrak m,R/\mathfrak m)\\
&\qquad\longrightarrow
\operatorname{Hom}_{R/\mathfrak m}
(\mathfrak m/\mathfrak m^2,R/\mathfrak m),
\qquad\varphi\longmapsto\varphi\circ d,
\end{aligned}
$$

dan kita harus menunjukkan bahwa pemetaan ini surjektif, sebab yang dibahas
adalah ruang-ruang vektor.

Menurut Lema 32.9 (Aljabar Komutatif) dan Lema 18.3, modul homomorfisme di
sebelah kiri isomorfik dengan

$$
\operatorname{Hom}_R(\Omega_{R/K},R/\mathfrak m)
\cong\operatorname{Der}_K(R,R/\mathfrak m).
$$

Pemetaan komposit tersebut memasangkan kepada suatu derivasi $K$
$\delta:R\to R/\mathfrak m$ pemetaan

$$
\mathfrak m/\mathfrak m^2\longrightarrow R/\mathfrak m,
\qquad[f]\longmapsto\delta(f).
$$

Sekarang misalkan

$$
\mathfrak m/\mathfrak m^2\longrightarrow R/\mathfrak m,
\qquad[f]\longmapsto\epsilon(f)
$$

suatu homomorfisme modul $R/\mathfrak m$. Kita harus menunjukkan bahwa ini
berasal dari suatu derivasi. Untuk itu, tinjau pemetaan

$$
\delta:R\longrightarrow R/\mathfrak m,
\qquad f\longmapsto\epsilon(f-\bar f),
$$

dengan $\bar f$ nilai $f$ di dalam lapangan residu $R/\mathfrak m$, yang
dipandang kembali sebagai unsur $R$ melalui identifikasi
$K=R/\mathfrak m$. Karena itu, $f-\bar f\in\mathfrak m$ dan pemetaan
terdefinisi dengan baik. Pemeriksaan langsung, serupa dengan bukti Teorema
23.2 (Kurva Aljabar (Osnabrück 2025--2026)), menunjukkan bahwa pemetaan ini
suatu derivasi. Pemetaan tersebut menghasilkan $\epsilon$.

Tanpa asumsi bahwa pemetaan alami antara lapangan dasar dan lapangan residu
merupakan isomorfisme, pernyataan ini tidak berlaku; lihat Soal 18.23.

<!-- upstream_entity: Kähler-Differentiale/Gleichungen/Maximales Ideal/Extrinsischer Kotangentialraum/Bemerkung -->

### Catatan 18.15: ruang tangen dan ideal maksimal {#br-bgk-2019-l18-rem-02}

Dalam situasi Lema 18.12, kita dapat membangun secara langsung hubungan
antara ruang tangen ekstrinsik, yang diberikan sebagai kernel matriks Jacobi,
dan ruang dual dari $\mathfrak m_P/\mathfrak m_P^2$. Misalkan

$$
v=
\begin{pmatrix}
v_1\\
\vdots\\
v_n
\end{pmatrix}
\in T_PV
=\ker\bigl(\operatorname{Jac}(f_1,\ldots,f_m)_P\bigr).
$$

Vektor ini mendefinisikan pemetaan

$$
\begin{aligned}
\mathfrak m_P&\longrightarrow K,\\
g&\longmapsto
(dg)_P
\begin{pmatrix}
v_1\\
\vdots\\
v_n
\end{pmatrix}
=v_1\partial_1g(P)+\cdots+v_n\partial_ng(P).
\end{aligned}
$$

Dalam bahasa analitik, kepada fungsi $g$ dipasangkan nilai pada $P$ dari
turunan berarahnya ke arah $v$. Syarat kernel memastikan bahwa fungsi-fungsi
dalam ideal $(f_1,\ldots,f_m)$ dipetakan ke $0$, sehingga pemetaan
terdefinisi dengan baik pada ideal maksimal gelanggang kelas sisa. Menurut
aturan hasil kali, $\mathfrak m_P^2$ juga dipetakan ke $0$. Jadi kita
memperoleh pemetaan linear-$K$

$$
\mathfrak m_P/\mathfrak m_P^2\longrightarrow K.
$$

<!-- upstream_entity: Affine Varietät/Punkt/Jacobi-Matrix und regulär/Fakt -->

### Teorema 18.16: titik halus dan gelanggang lokal regular {#br-bgk-2019-l18-thm-01}

Misalkan $K$ lapangan tertutup aljabar dan

$$
P\in V(\mathfrak a)\subseteq\mathbb A_K^n
$$

suatu titik himpunan aljabar afin untuk ideal
$\mathfrak a=(f_1,\ldots,f_m)$, dengan gelanggang lokal

$$
R=\bigl(K[X_1,\ldots,X_n]/\mathfrak a\bigr)_{\mathfrak m_P}.
$$

Maka $P$ halus jika dan hanya jika $R$ regular.

#### Bukti {#br-bgk-2019-l18-thm-01-proof}

Bukti ini tidak disajikan dalam kuliah.

Tanpa mengurangi keumuman, misalkan $P$ titik asal. Ideal maksimal yang
bersesuaian dalam gelanggang polinomial ialah

$$
\mathfrak n=(X_1,\ldots,X_n),
$$

ideal maksimal terkait di $K[X_1,\ldots,X_n]/\mathfrak a$ ialah

$$
\mathfrak r=\mathfrak n/\mathfrak a,
$$

dan ideal maksimal terkait dalam $R$ ialah

$$
\mathfrak m=\mathfrak m_P
=\mathfrak r\bigl(K[X_1,\ldots,X_n]/\mathfrak a\bigr)_{\mathfrak r}.
$$

Tinjau pemetaan linear-$K$

$$
K[X_1,\ldots,X_n]\longrightarrow K^n,
\qquad
g\longmapsto
\bigl((\partial_1g)(P),\ldots,(\partial_ng)(P)\bigr).
$$

Variabel $X_i$ dipetakan ke vektor standar $e_i$, sehingga pemetaan ini
surjektif. Unsur

$$
g=c_0+c_1X_1+\cdots+c_nX_n+\text{suku-suku berderajat lebih tinggi}
$$

dipetakan ke $(c_1,\ldots,c_n)$. Unsur homogen

$$
g\in\mathfrak n^2=K[X_1,\ldots,X_n]_{\geq2}
$$

mempunyai derajat sekurang-kurangnya $2$, sehingga dipetakan ke $0$:
turunan parsial mengurangi derajat sebesar $1$, jadi menghasilkan unsur
berderajat positif yang bernilai $0$ setelah titik asal disubstitusikan.
Dengan demikian, diperoleh pemetaan linear-$K$

$$
\mathfrak n/\mathfrak n^2\longrightarrow K^n
$$

yang bijektif karena kedua ruang mempunyai dimensi vektor yang sama.

Menurut Lema 22.4 (Kurva Aljabar (Osnabrück 2025--2026)), kita mempunyai

$$
\mathfrak r/\mathfrak r^2
\cong\mathfrak m/\mathfrak m^2.
$$

Di bawah pemetaan surjektif

$$
\mathfrak n\longrightarrow\mathfrak r
\longrightarrow\mathfrak r/\mathfrak r^2,
$$

$\mathfrak n^2$ dan $\mathfrak a$ dipetakan ke $0$, dan kernelnya tepat
$\mathfrak n^2+\mathfrak a$. Karena itu terdapat bijeksi linear-$K$

$$
\mathfrak n/(\mathfrak n^2+\mathfrak a)
\longrightarrow\mathfrak r/\mathfrak r^2.
$$

Tinjau pemetaan-pemetaan

$$
K^m\xrightarrow{\ \operatorname{Jac}\ }K^n
\cong\mathfrak n/\mathfrak n^2
\longrightarrow\mathfrak n/(\mathfrak n^2+\mathfrak a).
$$

Suatu unsur $[g]\in\mathfrak n/\mathfrak n^2$ dipetakan ke $0$ di sebelah
kanan tepat apabila bagian linear $g$ termasuk
$\mathfrak n^2+\mathfrak a$. Ini berarti bahwa, modulo $\mathfrak n^2$,
terdapat persamaan

$$
g=\sum_{i=1}^m h_if_i.
$$

Hanya suku konstan $h_i$ yang relevan, sehingga ini ekuivalen dengan
persamaan linear

$$
\begin{pmatrix}
(\partial_1g)(P)\\
\vdots\\
(\partial_ng)(P)
\end{pmatrix}
=\sum_{i=1}^m h_i
\begin{pmatrix}
(\partial_1f_i)(P)\\
\vdots\\
(\partial_nf_i)(P)
\end{pmatrix}.
$$

Hal ini berlaku tepat apabila vektor di ruas kiri berada dalam citra matriks
Jacobi. Jadi citra matriks Jacobi sama dengan kernel pemetaan surjektif di
sebelah kanan. Rumus dimensi kemudian memberi

$$
\begin{aligned}
n
&=\operatorname{rank}(\operatorname{Jac})
+\dim_K\bigl(\mathfrak n/(\mathfrak n^2+\mathfrak a)\bigr)\\
&=\operatorname{rank}(\operatorname{Jac})
+\dim_K(\mathfrak m/\mathfrak m^2).
\end{aligned}
$$

Misalkan $d$ dimensi $V(\mathfrak a)$ pada $P$, yang sama dengan dimensi
gelanggang lokal $R$. Menurut definisi, $P$ tak singular tepat apabila

$$
n=\operatorname{rank}(\operatorname{Jac})+d.
$$

Karena itu, kondisi tersebut ekuivalen dengan

$$
\dim_K(\mathfrak m/\mathfrak m^2)=d,
$$

dan ini adalah definisi gelanggang regular.

<!-- upstream_entity: Lokaler Ring/Restkörperbedingung/Regulär und Freier Kählermodul/Fakt -->

### Teorema 18.17: kereguleran dan kebebasan modul diferensial {#br-bgk-2019-l18-thm-02}

Misalkan $K$ lapangan sempurna dan $R$ pelokalan suatu aljabar $K$ yang
dibangkitkan hingga. Misalkan lapangan residu $R/\mathfrak m$ isomorfik
dengan $K$. Maka $R$ regular jika dan hanya jika modul diferensial Kähler
$\Omega_{R/K}$ bebas dan peringkatnya sama dengan dimensi gelanggang.

#### Bukti {#br-bgk-2019-l18-thm-02-proof}

Bukti ini tidak disajikan dalam kuliah.

Kita gunakan isomorfisme alami $R/\mathfrak m$ dari Lema 18.14,

$$
\mathfrak m/\mathfrak m^2
\longrightarrow\Omega_{R/K}\otimes_RR/\mathfrak m,
\qquad[f]\longmapsto df\otimes1.
$$

Jika $\Omega_{R/K}$ merupakan modul $R$ bebas dan peringkatnya sama dengan
dimensi $d$, maka hal yang sama berlaku bagi modul $R/\mathfrak m$
$\Omega_{R/K}\otimes_RR/\mathfrak m$. Khususnya,
$\mathfrak m/\mathfrak m^2$ adalah ruang vektor $R/\mathfrak m$
berdimensi $d$. Menurut definisi, ini berarti bahwa $R$ regular.

Sebaliknya, kereguleran menyiratkan bahwa $\mathfrak m/\mathfrak m^2$, dan
karena itu $\Omega_{R/K}\otimes_RR/\mathfrak m$, merupakan ruang vektor
berdimensi $d$. Menurut lema Nakayama, $\Omega_{R/K}$ dibangkitkan sebagai
modul $R$ oleh $d$ unsur. Menurut Teorema 21.5 (Teori Singularitas
(Osnabrück 2019)), gelanggang $R$ merupakan daerah integral; nyatakan
lapangan pecahannya dengan $Q(R)$. Derajat transendensi $Q(R)$ di atas $K$
sama dengan dimensi $R$ menurut Teorema 19.7 (Teori Singularitas (Osnabrück
2019)). Karena modul diferensial Kähler kompatibel dengan pelokalan,

$$
\Omega_{R/K}\otimes_RQ(R)=\Omega_{Q(R)/K}.
$$

Karena $K$ sempurna, perluasan lapangan $K\subseteq Q(R)$ dibangkitkan
secara separabel, meskipun tidak hingga. Jadi $\Omega_{Q(R)/K}$ merupakan
modul $Q(R)$ bebas yang peringkatnya sama dengan derajat transendensi.

Secara keseluruhan, modul $R$ $\Omega_{R/K}$ dibangkitkan oleh $d$ unsur
$\omega_1,\ldots,\omega_d$, dan tensorisasinya dengan $Q(R)$ merupakan
ruang vektor $Q(R)$ berdimensi $d$. Karena unsur-unsur tersebut bebas linear
di atas $Q(R)$, mereka juga bebas linear di atas $R$. Jadi unsur-unsur itu
membentuk basis, dan $\Omega_{R/K}$ bebas berperingkat $d$.

Tanpa asumsi bahwa lapangan dasar sempurna, pernyataan ini tidak benar; lihat
Soal 18.24.

<!-- upstream_entity: Varietät/Glatt/Kählermodul/Lokal frei/Fakt -->

### Korolari 18.18: diferensial pada varietas halus {#br-bgk-2019-l18-cor-02}

Misalkan $V\subseteq\mathbb A_K^n$ varietas halus terhubung di atas
lapangan sempurna $K$, dan misalkan $R$ gelanggang koordinat afin $V$. Maka
modul diferensial Kähler $\Omega_{R/K}$ bebas lokal dengan peringkat konstan
$\dim(R)$ dan, khususnya, merupakan modul projektif.

#### Bukti {#br-bgk-2019-l18-cor-02-proof}

Bukti ini tidak disajikan dalam kuliah.

Pernyataan ini mengikuti dari Teorema 18.16, Teorema 18.17, Lema 18.6, dan
Lema 16.5.

<!-- upstream_entity: Zweidimensionale Sphäre/Kählermodul/Lokal frei/Nicht frei/Beispiel -->

### Contoh 18.19: bola dua dimensi {#br-bgk-2019-l18-exm-01}

Kita tinjau bola real

$$
S^2=\{(x,y,z)\mid x^2+y^2+z^2=1\}\subseteq\mathbb R^3
$$

dengan gelanggang koordinat afin

$$
R=\mathbb R[X,Y,Z]/(X^2+Y^2+Z^2-1).
$$

Menurut Korolari 18.9, modul diferensial Kähler $R$ adalah

$$
\Omega_{R/\mathbb R}
=RdX\oplus RdY\oplus RdZ/(XdX+YdY+ZdZ).
$$

Pemeriksaan langsung menunjukkan bahwa bola real ini halus. Menurut Teorema
18.17, $\Omega_{R/\mathbb R}$ karena itu bebas lokal dengan peringkat konstan
$2$. Hal ini juga dapat disimpulkan langsung dari penyajian di atas; lihat
Soal 18.25. Akan tetapi, $\Omega_{R/\mathbb R}$ tidak bebas. Ini adalah versi
aljabar teorema bola berbulu: bulu-bulu bola tidak dapat disisir secara mulus
hingga semuanya terletak tangensial pada bola tanpa membentuk pusaran.

Untuk pemetaan polinomial

$$
f:\mathbb A_K^n\longrightarrow\mathbb A_K^m
$$

dengan himpunan nol

$$
V=V(f_1,\ldots,f_m)\subseteq\mathbb A_K^n,
$$

ruang tangen pada titik $P\in V$ adalah

$$
\begin{aligned}
T_PV
&:=\ker\bigl(\operatorname{Jac}(f_1,\ldots,f_m)_P\bigr)\\
&=\{v\in\mathbb A_K^n\mid
\operatorname{Jac}(f_1,\ldots,f_m)_P(v)=0\}.
\end{aligned}
$$

Jika $P$ titik regular pemetaan tersebut dan teorema fungsi implisit dapat
diterapkan, ini merupakan subruang linear yang dimensinya sama dengan
dimensi manifold $V$. Konstruksi ini ekstrinsik: ia bergantung pada
pembenaman $V$ ke dalam ruang afin. Kita menginginkan versi intrinsik ruang
tangen yang hanya bergantung pada $V$, atau secara ekuivalen pada gelanggang
koordinat afinnya. Untuk itu kita memperkenalkan modul diferensial Kähler,
yang menyediakan versi dual ruang tangen untuk setiap aljabar $R$ $A$.
