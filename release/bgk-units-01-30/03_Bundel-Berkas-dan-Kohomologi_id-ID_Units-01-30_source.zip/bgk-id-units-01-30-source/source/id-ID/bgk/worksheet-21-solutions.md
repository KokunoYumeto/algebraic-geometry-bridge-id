---
title: "Solusi Publik dan Cakupan Lembar Kerja 21"
stable_id: br-bgk-2019-w21-solutions
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
upstream_map: authority/wikiversity-bgk/unit-21/ORDERED_EXERCISE_MAP.json
upstream_map_sha256: 69b9ecd0120626c3e4c8dc018862869b13316fa3e6c76edf5954807dcff6af65
course_authority_manifest: authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json
course_authority_manifest_sha256: ea0bf346e261db8ed80b7565f7746e95c79e0c376d25d9fbce5d96879dff7dd8
authority_manifest: authority/wikiversity-bgk/unit-21/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 684637decc945c94137670f7c4238110b4a4c395287cf985b3f69adceedd9ef7
authority_manifest_status: "Bekuan authority terminal lengkap; 35 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
unit_capture_identity: authority/wikiversity-bgk/unit-21/CAPTURE_IDENTITY.json
unit_capture_identity_sha256: 869931efce9e3df0e42984b2db28fc367f93f113a8d632175ac0f9d7414cb791
candidate_evidence: authority/wikiversity-bgk/unit-21/worksheet-solution-candidates-api.json
candidate_evidence_sha256: 19b8384f8a3e37828a2b5ae32f2e58809b7ac6169c6bff1b8f1649b4e4880782
solution_ex03_xml: authority/wikiversity-bgk/unit-21/solution-ex03.xml
solution_ex03_xml_sha256: 60fe2ce05a77cb26b8a5162a83d84a19730d7c3a047a8dfe3669a1f3f04b173f
solution_ex03_html: authority/wikiversity-bgk/unit-21/solution-ex03.html
solution_ex03_html_sha256: 78c5585f8e37afd8ad778659c80e8c0660a030a120c83c66c385ceda173996ec
solution_ex03_upstream_pageid: 168446
solution_ex03_upstream_revid: 1068126
solution_ex03_mediawiki_sha1: 2d751f629b7f48f92fc66b6815e702cb8293fd55
solution_ex03_frozen_revision_contributor: "Bocardodarapti"
solution_ex09_xml: authority/wikiversity-bgk/unit-21/solution-ex09.xml
solution_ex09_xml_sha256: 200f8252ec7abdbfa21215b1c20a0831046313dc323c2c47a93a8c076ffede3c
solution_ex09_html: authority/wikiversity-bgk/unit-21/solution-ex09.html
solution_ex09_html_sha256: 0d7f1aacadc6e39aed85e68f89217d7c78783f040dbd7ecb5612e67cb5cd4ca8
solution_ex09_upstream_pageid: 16847
solution_ex09_upstream_revid: 1113184
solution_ex09_mediawiki_sha1: 605715141b55061b2efc433f9bd039e84ec8fde0
solution_ex09_frozen_revision_contributor: "Arbota"
solution_ex10_xml: authority/wikiversity-bgk/unit-21/solution-ex10.xml
solution_ex10_xml_sha256: 9143a82da55b84ca3a4e3fdb436657ff0f60f8ff80eb01671bc0403771b74a41
solution_ex10_html: authority/wikiversity-bgk/unit-21/solution-ex10.html
solution_ex10_html_sha256: 9edb9f6dfee387bc9a8d04ab6933942c0839f10756eef96cf6b4905b7e4aa151
solution_ex10_upstream_pageid: 133994
solution_ex10_upstream_revid: 708101
solution_ex10_mediawiki_sha1: 35379260e96277d6323ce216cff7ac09a7a72b7f
solution_ex10_frozen_revision_contributor: "Bocardodarapti"
exercise_count: 13
public_solution_count: 3
public_solution_numbers: "3, 9, 10"
negative_public_solution_count: 10
negative_solution_numbers: "1-2, 4-8, 11-13"
media_credits: source/id-ID/media-credits-bgk-unit-21.md
media_credits_sha256: 07ef5ecaa38890028ebbc245b3511bfb3eb8a29b174c8802dd84a3492496d814
rights_ledger: authority/RIGHTS-bgk-unit-21.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-21.json
asset_closure_sha256: 5fd26087ca516efbb8cbc6823c3622338bd9272eb7ab1452c87ba41c6e28afdd
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

```{=latex}
\clearpage
```

# Solusi Publik dan Cakupan Lembar Kerja 21 {#br-bgk-2019-w21-solutions}

Pada batas revisi yang dibekukan, sumber menyediakan tepat tiga solusi publik
di antara 13 soal, yaitu solusi Soal 21.3, 21.9, dan 21.10. Peta soal dan bukti
kandidat mencatat hasil negatif untuk Soal 21.1--21.2, 21.4--21.8, dan
21.11--21.13. Ketiadaan halaman solusi publik tidak diubah menjadi solusi
buatan.

<!-- upstream_solution: Diskreter Bewertungsring/Zwischenringe im Quotientenkörper/Aufgabe/Lösung; pageid=168446; revid=1068126 -->
<!-- upstream_solution_url: https://de.wikiversity.org/w/index.php?oldid=1068126 -->

## Solusi Soal 21.3 {#br-bgk-2019-w21-sol-ex03}

Misalkan ideal maksimal $R$ adalah

$$
\mathfrak m=(\pi).
$$

Lapangan pecahan $R$ adalah

$$
Q(R)=R_\pi,
$$

dan di dalam lapangan ini setiap unsur tak nol berbentuk

$$
u\pi^n,
\qquad
u\in R^\times,
\quad
n\in\mathbb Z.
$$

Misalkan

$$
R\subset T\subseteq Q(R).
$$

Maka terdapat unsur

$$
u\pi^n\in T
$$

dengan $n<0$. Akan tetapi, kita juga mempunyai $\pi^n\in T$ dan

$$
\pi^{-1}=\pi^{-n-1}\pi^n\in T.
$$

Jadi $T=Q(R)$.

[Kembali ke Soal 21.3](worksheet-21.md#br-bgk-2019-w21-ex03).

<!-- upstream_solution: Bewertungstheorie/Körper mit diskreter Bewertung/Diskreter Bewertungsring/Aufgabe/Lösung; pageid=16847; revid=1113184 -->
<!-- upstream_solution_url: https://de.wikiversity.org/w/index.php?oldid=1113184 -->

## Solusi Soal 21.9 {#br-bgk-2019-w21-sol-ex09}

Pertama-tama kita buktikan bahwa $R$ merupakan subgelanggang dari lapangan
$K$. Kita mempunyai

$$
0\in R.
$$

Karena $\nu$ homomorfisme grup, harus berlaku

$$
\nu(1)=0.
$$

Untuk unsur $f,g\in R$, berlaku

$$
\nu(f),\nu(g)\geq0,
$$

dan karena $\nu$ homomorfisme grup,

$$
\nu(f\cdot g)=\nu(f)+\nu(g)\geq0,
$$

serta, menurut asumsi,

$$
\nu(f+g)\geq\min\{\nu(f),\nu(g)\}\geq0.
$$

Jadi $R$ tertutup terhadap perkalian dan penjumlahan. Selain itu,

$$
\nu(-1)+\nu(-1)
=\nu((-1)^2)
=\nu(1)
=0,
$$

sehingga $\nu(-1)=0$ dan $-1\in R$. Dengan demikian, $R$ juga tertutup
terhadap pengambilan negatif dan merupakan gelanggang komutatif.

Selanjutnya, $R$ harus merupakan gelanggang lokal. Kita klaim bahwa

$$
\mathfrak m
:=\{f\in K^\times\mid\nu(f)\geq1\}\cup\{0\}
\subseteq R.
$$

merupakan satu-satunya ideal maksimal. Himpunan ini memuat $0$, dan karena

$$
\nu(f+g)\geq\min\{\nu(f),\nu(g)\}\geq1,
$$

himpunan ini tertutup terhadap penjumlahan. Untuk $f\in\mathfrak m$ dan
$g\in R$, berlaku

$$
\nu(f)\geq1
\qquad\text{dan}\qquad
\nu(g)\geq0,
$$

dan karena itu

$$
\nu(gf)=\nu(g)+\nu(f)\geq1,
$$

sehingga himpunan ini tertutup terhadap perkalian oleh unsur $R$. Jadi
$\mathfrak m$ merupakan ideal.

Komplemen $R\setminus\mathfrak m$ terdiri tepat atas unsur
$h\in K$ dengan

$$
\nu(h)=0.
$$

Untuk unsur seperti itu,

$$
\nu(h^{-1})=-\nu(h)=0,
$$

sehingga $h^{-1}\in R$. Jadi semua unsur dalam
$R\setminus\mathfrak m$ merupakan satuan. Oleh karena itu, $\mathfrak m$
merupakan ideal maksimal.

Masih harus dibuktikan bahwa $R$ merupakan gelanggang valuasi diskret.
Ambil $p\in K$ dengan

$$
\nu(p)=1.
$$

Unsur seperti ini ada karena $\nu$ diasumsikan surjektif. Kita buktikan bahwa
$p$ merupakan unsur prima. Secara umum, untuk $x,y\in R$, unsur $y$
merupakan kelipatan $x$ tepat ketika

$$
\nu(y)\geq\nu(x),
$$

sebab kondisi itu ekuivalen dengan $y/x\in R$. Sekarang misalkan
$p\mid xy$ untuk $x,y\in R$. Maka

$$
1=\nu(p)\leq\nu(xy)=\nu(x)+\nu(y).
$$

Karena itu, $\nu(x)\geq1$ atau $\nu(y)\geq1$, sehingga salah satu dari $x$
atau $y$ merupakan kelipatan $p$. Jadi $p$ merupakan unsur prima.

Dengan argumen yang sama, setiap unsur tak nol $x\in R$ dengan

$$
n=\nu(x)
$$

berasosiasi dengan $p^n$. Dengan demikian, $R$ merupakan domain ideal utama
dengan tepat ideal-ideal

$$
0
\qquad\text{dan}\qquad
(p^n),
\quad n\in\mathbb N.
$$

> **Catatan edisi - domain valuasi.** Sumber mendefinisikan $\nu$ hanya pada
> $K^\times$, tetapi di dalam solusi mengevaluasi $\nu(f)$, $\nu(f+g)$,
> $\nu(gf)$, dan $\nu(xy)$ untuk unsur yang hanya dinyatakan berada di $R$,
> padahal $0\in R$. Edisi mempertahankan bukti sumber tanpa menambahkan
> konvensi $\nu(0)=\infty$ atau pemisahan kasus nol.

[Kembali ke Soal 21.9](worksheet-21.md#br-bgk-2019-w21-ex09).

<!-- upstream_solution: Ebene algebraische Kurve/Glatter Punkt/Lokaler Ring ist diskreter Bewertungsring/Fakt/Beweis/Aufgabe/Lösung; pageid=133994; revid=708101 -->
<!-- upstream_solution_url: https://de.wikiversity.org/w/index.php?oldid=708101 -->

## Solusi Soal 21.10 {#br-bgk-2019-w21-sol-ex10}

Pertama, $R$ merupakan gelanggang lokal dan Noether yang, menurut
[fakta sumber tentang komponen pada titik mulus](https://de.wikiversity.org/wiki/Ebene_algebraische_Kurve/Glatter_Punkt/Liegt_nur_auf_einer_Komponente/Fakt),
merupakan domain integral. Karena itu, ideal primanya hanyalah ideal nol dan
ideal maksimal $\mathfrak m_P$. Kita akan membuktikan bahwa ideal maksimal
tersebut merupakan ideal utama.

Kita boleh mengandaikan bahwa $P$ adalah titik asal dan menulis $F$ sebagai

$$
F=F_d+\cdots+F_1
$$

dengan $F_1\ne0$. Bentuk ini tersedia karena $P$ merupakan titik mulus.
Melalui suatu transformasi variabel, kita dapat membuat

$$
F_1=Y.
$$

Di dalam $F$, kita dapat mengumpulkan semua pangkat $X$ yang berdiri sendiri,
yaitu monomial-monomial yang tidak memuat $Y$, dan mengeluarkan faktor $Y$
dari suku-suku lainnya. Persamaan $F=0$ kemudian dapat ditulis sebagai

$$
Y(1+G)=XH(X),
$$

dengan

$$
G\in(X,Y).
$$

Unsur $1+G$ merupakan satuan dalam $K[X,Y]_{(X,Y)}$, dan terlebih lagi
dalam gelanggang lokal kurva di titik asal,

$$
R=K[X,Y]_{(X,Y)}/(F).
$$

Karena itu, di dalam $R$ berlaku hubungan

$$
Y=\frac{H}{1+G}X.
$$

Jadi ideal maksimal dalam gelanggang lokal $R$ dibangkitkan oleh $X$ saja.
Menurut [Teorema 21.8](lecture-21.md#br-bgk-2019-l21-thm-01), $R$ merupakan
gelanggang valuasi diskret.

[Kembali ke Soal 21.10](worksheet-21.md#br-bgk-2019-w21-ex10).

## Hasil negatif yang dibekukan {#br-bgk-2019-w21-solutions-negative}

Tidak ada halaman solusi publik pada revisi yang dibekukan untuk Soal 21.1,
21.2, 21.4, 21.5, 21.6, 21.7, 21.8, 21.11, 21.12, atau 21.13. Pernyataan ini
adalah hasil pemeriksaan kandidat, bukan klaim bahwa solusi matematis tidak
ada.
