---
title: "Solusi Publik dan Cakupan Lembar Kerja 19"
stable_id: br-bgk-2019-w19-solutions
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
upstream_map: authority/wikiversity-bgk/unit-19/ORDERED_EXERCISE_MAP.json
upstream_map_sha256: 93905796d627d6ce9fe5926808e2589c25c4513ca38d14c9099ca91693805af6
authority_manifest: authority/wikiversity-bgk/unit-19/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: ffd4e79d12cd6fd63836cb6d7fd17e5dc6481f3befaeb50efeb9a47c4cc70512
authority_manifest_status: "Bekuan authority terminal lengkap; 33 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
candidate_evidence: authority/wikiversity-bgk/unit-19/worksheet-solution-candidates-api.json
candidate_evidence_sha256: d9b99cc424669d15e6f102d9686c35671bc38e41b29038df005917e521b03818
solution_ex10_xml: authority/wikiversity-bgk/unit-19/solution-ex10.xml
solution_ex10_xml_sha256: fe7f9ec06548c912ca89c776efd32da8e8b69dfe7c74dfebe09ea4f2d809c7c5
solution_ex10_html: authority/wikiversity-bgk/unit-19/solution-ex10.html
solution_ex10_html_sha256: b2719ae26824d23d3cedeadd2eaa364dd32f6e952d8cde8ee5a4db154e56ce7b
solution_ex10_upstream_pageid: 116008
solution_ex10_upstream_revid: 1094743
solution_ex10_mediawiki_sha1: e3b3f8d7c95285e6d294f385eda15f3a5d27ec6c
solution_ex10_frozen_revision_contributor: "Arbota"
exercise_count: 12
public_solution_count: 1
public_solution_numbers: "10"
negative_public_solution_count: 11
negative_solution_numbers: "1-9, 11-12"
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

```{=latex}
\clearpage
```

# Solusi Publik dan Cakupan Lembar Kerja 19 {#br-bgk-2019-w19-solutions}

Pada batas sumber yang dibekukan, terdapat tepat satu solusi publik di antara
12 soal, yaitu solusi Soal 19.10. Peta soal dan bukti kandidat mencatat hasil
negatif untuk Soal 19.1--19.9, 19.11, dan 19.12. Ketiadaan halaman solusi
publik tidak diubah menjadi solusi buatan.

## Solusi Soal 19.10 {#br-bgk-2019-w19-sol-ex10}

Dengan menggunakan persamaan kurva dan relasi

$$
X^2\,dX+Y^2\,dY+Z^2\,dZ=0,
$$

kita memperoleh

$$
\begin{aligned}
\frac{X^2}{Y^2}\,d\!\left(\frac ZX\right)
&=\frac{X^2}{Y^2}\cdot\frac{X\,dZ-Z\,dX}{X^2}\\
&=\frac{X^3Z^2\,dZ-X^2Z^3\,dX}{X^2Y^2Z^2}\\
&=\frac{-X^3(X^2\,dX+Y^2\,dY)+X^2(X^3+Y^3)\,dX}
{X^2Y^2Z^2}\\
&=\frac{-X^3Y^2\,dY+X^2Y^3\,dX}{X^2Y^2Z^2}\\
&=\frac{Y^2}{Z^2}\cdot\frac{-X\,dY+Y\,dX}{Y^2}\\
&=\frac{Y^2}{Z^2}\,d\!\left(\frac XY\right).
\end{aligned}
$$

Karena simetri, kesamaan-kesamaan lainnya juga berlaku.

## Hasil negatif yang dibekukan {#br-bgk-2019-w19-solutions-negative}

Tidak ada halaman solusi publik pada batas sumber yang dibekukan untuk Soal
19.1, 19.2, 19.3, 19.4, 19.5, 19.6, 19.7, 19.8, 19.9, 19.11, atau 19.12.
Pernyataan ini adalah hasil pemeriksaan kandidat, bukan klaim bahwa solusi
matematis tidak ada.
