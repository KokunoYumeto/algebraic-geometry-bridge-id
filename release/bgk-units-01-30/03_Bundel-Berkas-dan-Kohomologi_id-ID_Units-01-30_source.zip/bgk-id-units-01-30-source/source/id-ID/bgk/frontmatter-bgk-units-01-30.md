---
title: "Bundel, Berkas, dan Kohomologi - Unit 1-30"
subtitle: "Tiga puluh kuliah dan lembar kerja, edisi Bahasa Indonesia"
author:
  - "Holger Brenner (karya sumber)"
date: "2026-08-31"
lang: id-ID
license: "CC BY-SA 4.0 for the frozen semantic course text and this translation; official PDFs and media retain their recorded component notices"
---

# Tentang edisi ini {#br-bgk-2019-front-01-30}

Ini adalah edisi Bahasa Indonesia yang independen dari mata kuliah
*Bündel, Garben und Kohomologie (Osnabrück 2019-2020)* karya Holger Brenner.
Cakupannya adalah tepat 30 kuliah dan 30 lembar kerja, Unit 1--30, dalam
urutan sumber. Seluruh 495 soal dipertahankan. Dua puluh lima solusi yang
tersedia untuk umum diterjemahkan; untuk 470 soal lainnya, edisi menyimpan
hasil penelusuran negatif dan tidak mengarang solusi yang tidak ada pada
sumber.

Penerjemahan, pemeriksaan, dan produksi edisi dibantu oleh
**OpenAI Codex gpt-5.6-sol, Ultra.** Pekerjaan dilakukan atas arahan
pengguna. Provenans model ini tidak menggantikan kredit kepada penulis sumber
atau kontributor manusia. Edisi ini bukan terbitan resmi Holger Brenner,
Universitas Osnabrück, Wikiversity, Wikimedia Foundation, atau OpenAI, dan
tidak menyiratkan dukungan dari pihak-pihak tersebut.

## Otoritas sumber yang dibekukan {#br-bgk-2019-front-01-30-authority}

Otoritas tekstualnya adalah revisi semantik Wikiversity yang dibekukan. Akar
kursus mempunyai `pageid` 108997, revisi 1052895 bertanggal
2025-08-27T20:02:50Z, dan SHA-1 MediaWiki
`e881e7c53531765849865454d4d0c643c2066c6d`. Indeks kursus yang dibekukan
mencatat 30 identitas kuliah dan 30 identitas lembar kerja. Manifes kursus
`authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json` berukuran
34.279 byte dengan SHA-256
`ea0bf346e261db8ed80b7565f7746e95c79e0c376d25d9fbce5d96879dff7dd8`.
PDF resmi dipakai sebagai saksi visual dan penomoran, bukan sebagai pengganti
otoritas semantik yang lebih mutakhir.

Seluruh Unit 1--30 mempunyai terjemahan kuliah, lembar kerja, dan cakupan
solusi yang lengkap, dengan manifes otoritas, PDF resmi unit, serta catatan
hak komponennya. Penutupan sumber memeriksa ulang identitas berkas, urutan
soal, solusi publik, dan hasil kandidat negatif. Laporan pemeriksaan pembaca,
bangunan yang dapat diulang, serta identitas berkas terbitan disertakan dalam
paket rilis; laporan tersebut dibedakan dari bukti otoritas sumber.

# Struktur dan rute belajar {#br-bgk-2019-front-01-30-routes}

Urutan berikut adalah urutan kuliah dan lembar kerja sumber, bukan jalur yang
boleh dinomori ulang. Setiap rentang membentuk satu rute baca yang koheren.

| Rute | Unit dan topik | Soal | Solusi publik | Hasil negatif |
|---|---|---:|---:|---:|
| Bahasa bundel dan berkas | 1 **Bundel Vektor dan Bundel Tangen**; 2 **Seksi dan Data Pengeleman**; 3 **Konstruksi Linear, Praberkas, dan Tangkai**; 4 **Berkas dan Morfisme Berkas** | 71 | 2 | 69 |
| Operasi berkas dan spektrum | 5 **Berkasisasi dan Berkas Hasil Bagi**; 6 **Ruang Penutup, Eksak, serta Tarik dan Dorong Berkas**; 7 **Ruang Berdering dan Gelanggang Lokal**; 8 **Spektrum dan Pemetaan Spektrum** | 73 | 5 | 68 |
| Skema afin dan projektif | 9 **Skema Afin**; 10 **Skema dan Morfisme Skema**; 11 **Ruang Tak Tereduksi dan Skema Noether**; 12 **Spektrum Projektif Gelanggang Bergradasi** | 57 | 5 | 52 |
| Modul, berkas invertibel, dan diferensial | 13 **Pemetaan Kerucut, Berkas Modul, dan Berkas Invertibel**; 14 **Modul Kuasikoheren**; 15 **Modul pada Skema Projektif**; 16 **Berkas Bebas Lokal**; 17 **Bundel Vektor Geometris**; 18 **Diferensial Kähler** | 141 | 4 | 137 |
| Bundel tangen dan kelas pembagi | 19 **Bundel Tangen**; 20 **Grup Picard**; 21 **Gelanggang Valuasi Diskret**; 22 **Grup Kelas Pembagi** | 58 | 5 | 53 |
| Alat homologi dan kohomologi | 23 **Modul Injektif**; 24 **Funktor Turunan Kanan**; 25 **Kohomologi Berkas**; 26 **Kohomologi Čech**; 27 **Kohomologi pada Skema Projektif** | 61 | 1 | 60 |
| Kurva projektif dan Riemann–Roch | 28 **Morfisme ke Ruang Projektif**; 29 **Genus Kurva**; 30 **Teorema Riemann–Roch** | 34 | 3 | 31 |
| **Jumlah** | **30 kuliah dan 30 lembar kerja** | **495** | **25** | **470** |

# Soal dan solusi {#br-bgk-2019-front-01-30-solutions}

Solusi publik terdapat pada Unit 2 (Soal 2.4), Unit 3 (3.1), Unit 5 (5.5),
Unit 7 (7.14), Unit 8 (8.3, 8.4, dan 8.11), Unit 11 (11.9, 11.13, dan
11.14), Unit 12 (12.5 dan 12.10), Unit 16 (16.12), Unit 18 (18.6, 18.17,
dan 18.18), Unit 19 (19.10), Unit 21 (21.3, 21.9, dan 21.10), Unit 22
(22.19), Unit 25 (25.1), Unit 28 (28.6), serta Unit 29 (29.5 dan 29.12).

Tidak ditemukan solusi publik pada batas sumber untuk Unit 1, 4, 6, 9, 10,
13, 14, 15, 17, 20, 23, 24, 26, 27, dan 30. Untuk unit yang mempunyai
sebagian solusi, setiap soal lain juga mempunyai hasil negatif tersendiri.
Dengan demikian, angka 470 menyatakan hasil penelusuran negatif yang
didokumentasikan, bukan halaman solusi kosong dan bukan bukti bahwa solusi
tidak pernah ada di tempat lain.

# Media dan aksesibilitas {#br-bgk-2019-front-01-30-media}

Delapan posisi media pembaca dengan biner komponen yang tersedia terdapat pada
Unit 1, 2, 4, dan 29. Setiap aset itu mempertahankan kredit, pencipta, sumber,
teks alternatif, dan lisensi komponennya sendiri. Unit 8 mempunyai satu posisi
media yang mendeklarasikan `File:Spektrum_von_Z._xcf`, tetapi biner sumber itu
hilang. Edisi mempertahankan nama pencipta dan label lisensi sebaris sumber,
makna keterangan, teks alternatif, serta fakta kehilangan tersebut; edisi
tidak mengklaim pemulihan dan tidak membuat aset sumber pengganti.

Unit 3, 5--7, 9--28, serta Unit 30 tidak mempunyai posisi media
pembaca. PDF resmi unit dan PDF kursus adalah saksi otoritas, bukan media
pembaca, sehingga tidak dihitung sebagai aset ilustrasi. Ketiadaan posisi
media pada unit-unit itu bukan kehilangan isi.

# Lisensi, atribusi, dan batas hak {#br-bgk-2019-front-01-30-rights}

Teks semantik mata kuliah yang dibekukan dan terjemahan ini dibagikan dengan
[Creative Commons Attribution-ShareAlike 4.0
International](https://creativecommons.org/licenses/by-sa/4.0/). Metadata
Commons untuk PDF resmi kursus saat ini menyatakan CC BY-SA 4.0, sedangkan
pemberitahuan yang tampak pada halaman 265 PDF tersebut menyatakan CC BY-SA
3.0. Edisi mempertahankan kedua catatan itu dan tidak membuat klaim
pelisensian ulang secara menyeluruh.

Media dan komponen lain tetap berada di bawah pemberitahuan hak masing-masing;
lisensi teks tidak otomatis melisensikan ulang semuanya. Atribusi, kewajiban
berbagi-serupa, catatan komponen, dan pernyataan non-dukungan harus tetap
disertakan bila edisi ini disalin, diubah, atau didistribusikan.

# Cara memakai pembaca ini {#br-bgk-2019-front-01-30-use}

Baca setiap kuliah sebelum mengerjakan lembar kerja bernomor sama. Kerjakan
rute secara berurutan: bahasa bundel dan berkas; operasi berkas dan spektrum;
skema afin serta projektif; modul dan diferensial; bundel tangen, Picard, dan
kelas pembagi; alat homologi dan kohomologi; lalu geometri kurva projektif
hingga Riemann–Roch. Gunakan catatan edisi di dekat tempatnya untuk
membedakan isi sumber dari koreksi yang dapat diverifikasi, keputusan
terjemahan, catatan notasi, atau provenans media. Jangan menafsirkan hasil
negatif solusi sebagai isi yang hilang. Panduan istilah sesudah bagian ini
membantu mengenali padanan yang berbeda antarsatuan tanpa mengaburkan
pembedaan matematisnya.
