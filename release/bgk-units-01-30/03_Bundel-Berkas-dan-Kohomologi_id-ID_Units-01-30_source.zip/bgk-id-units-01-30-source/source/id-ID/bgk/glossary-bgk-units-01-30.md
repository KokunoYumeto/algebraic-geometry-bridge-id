---
title: "Panduan Istilah Bundel, Berkas, dan Kohomologi"
stable_id: br-bgk-2019-glossary-01-30
language: id-ID
source_course: "Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
editorial_scope: "Glosarium penghubung untuk Unit 1-30; bukan tambahan pada teks sumber"
license: "CC BY-SA 4.0 untuk glosarium dan catatan penghubung ini; lisensi komponen sumber tetap berlaku sebagaimana dicatat dalam kredit edisi"
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
non_endorsement: "Edisi dan glosarium independen; tidak menyiratkan dukungan Holger Brenner, Wikiversity, Wikimedia Foundation, atau lembaga sumber."
---

# Panduan istilah {#br-bgk-2019-glossary-01-30}

Panduan ini menghubungkan istilah Jerman dengan pemakaiannya dalam Unit 1--30.
Beberapa unit menggunakan sinonim Indonesia yang berbeda. Bentuk-bentuk itu
tidak menyatakan objek matematis baru: bacalah bersama definisi, hipotesis,
dan notasi pada unit bersangkutan. Bentuk pilihan di sini membantu pencarian
lintas unit, tanpa mengganti rumus atau istilah dalam kutipan sumber.

## Objek yang perlu dibedakan {#br-bgk-2019-glossary-01-30-objek}

| Istilah sumber | Padanan Indonesia | Petunjuk membaca |
|---|---|---|
| *Bündel*; *Garbe*; *Prägarbe* | bundel; berkas; praberkas | Bundel dan berkas bukan satu kata sumber. Berkas seksi suatu bundel menghubungkan kedua sudut pandang. |
| *Halm*; *Faser* | tangkai; serat | Untuk berkas modul, tangkai di titik dan serat yang diperoleh setelah memakai lapangan residu adalah objek berbeda. |
| *Schnitt*; *Durchschnitt* | seksi; irisan | Seksi berkas atau bundel bukan irisan himpunan. Dalam pembelahan surjeksi, seksi berarti invers kanan. |
| *Strukturgarbe*; *Modulgarbe* | berkas struktur; berkas modul | Struktur skalar tetap penting: suatu $\mathcal O_X$-modul adalah modul atas berkas struktur. |
| *Homomorphismenmodul*; *Homomorphismengarbe* | modul homomorfisme; berkas homomorfisme | Unit 13 juga menulis **modul homomorfisme global** untuk membedakan $\operatorname{Hom}$ dari berkas $\mathcal Hom$. |
| *Garbenmorphismus*; *Garbenhomomorphismus* | morfisme berkas; homomorfisme berkas | Kata kedua menonjolkan struktur grup atau modul yang dilestarikan; jangan menghapus struktur itu dari pernyataan. |
| *quasikohärent*; *kohärent* | kuasikoheren; koheren | Koherensi memuat syarat kehinggaan tambahan sesuai definisi unit; kedua sifat tidak dipertukarkan. |
| *Hyperebene*; *Hyperfläche* | hiperbidang; hipermuka | Hiperbidang bersifat linear, sedangkan hipermuka dapat mempunyai derajat lebih besar dari satu. |

## Padanan lintas unit {#br-bgk-2019-glossary-01-30-varian}

| Istilah sumber | Bentuk pilihan dan varian yang dijumpai | Batas makna |
|---|---|---|
| *Vergarbung* | **berkasisasi**; pembentukan berkas | Pembentukan berkas yang diasosiasikan dengan suatu praberkas (*sheafification*). Bukan sembarang konstruksi berkas. |
| *Einheit*; *Einheitengarbe* | **satuan**; unit; **berkas satuan**; berkas unit | Satuan adalah unsur yang mempunyai invers perkalian, bukan hanya unsur identitas $1$. “Unit 20” adalah nomor bagian kursus. |
| *Rang* | **rank**; peringkat | Dalam konteks berkas bebas lokal atau bundel, menyatakan rank objek tersebut; bukan derajatnya. |
| *Einschränkung*; *Restriktion* | **restriksi**; pembatasan | Pembatasan objek atau peta ke subruang yang dinyatakan. Untuk $\mathcal F|_U$, kata “terbatas” tidak berarti sifat *bounded*. |
| *Restriktionsabbildung* | **pemetaan restriksi**; pemetaan pembatasan | Jika sumber menekankan struktur aljabar, gunakan keluarga **homomorfisme restriksi** / homomorfisme pembatasan. |
| *Integritätsbereich* | **domain integral**; daerah integral | Gelanggang komutatif tak nol tanpa pembagi nol; kata “integral” di sini bukan operasi pengintegralan. |
| *Restklassenring* | **gelanggang faktor**; gelanggang hasil bagi; gelanggang kelas sisa | Gelanggang hasil bagi oleh ideal. Jangan menyamakannya dengan *Quotientenkörper*, yaitu **lapangan pecahan**. |
| *Restklassenmodul*; *Restklassengruppe* | **modul faktor**; **grup faktor** | “Kelas sisa” dan “hasil bagi” juga muncul untuk konstruksi yang sama. Objek modul, grup, dan gelanggang tetap dibedakan. |
| *Funktionenkörper* | **lapangan fungsi**; medan fungsi | “Medan fungsi” pada unit tertentu menyebut lapangan yang sama; **medan vektor** adalah istilah berbeda. |
| *Twist*; *getwistete Strukturgarbe* | **puntiran**; twist; **berkas struktur terpuntir**; berkas struktur terpilin | Puntiran derajat atau oleh berkas invertibel; bukan rotasi geometris atau dualisasi. |
| *glatt* | **mulus**; halus | Sifat kemulusan geometris. Tidak otomatis sama dengan *regulär* (**reguler**) tanpa hipotesis dasar yang sesuai. |
| *feine Monomgraduierung* | **gradasi monomial halus** | “Halus” di sini berarti gradasi yang lebih rinci, bukan kemulusan geometris. |
| *welk*; *welke Garbe* | **flasid**; flasque; flabby; **berkas flasid** | Semua peta restriksi bersifat surjektif. *Azyklisch* berarti **asiklik**; sifat asiklik bukan sinonim sifat flasid. |
| *Überdeckung* | **penutup**; liputan | Keluarga subhimpunan yang menutupi ruang. “Terbuka”, “afin”, dan “hingga” tetap merupakan kualifikasi matematis. |
| *affine Standardüberdeckung* | **liputan afin standar**; penutup afin standar | Bentuk yang telah dipakai dalam pembahasan ruang projektif; penutup standar tidak sama dengan penutup sembarang. |
| *Überlagerung* | **pemetaan ruang penutup** | Pemetaan ruang penutup berbeda dari keluarga himpunan terbuka yang disebut penutup. |
| *projektiv* | **projektif**; proyektif | BGK memakai keluarga “projektif”; bagian klasik juga memakai “proyektif”. Perbedaan ejaan ini tidak mengubah objek. |
| *Einbettung* | **pembenaman**; penyematan; embedding | Baca kategori dan sifat peta. Penyematan grup atau modul tidak boleh otomatis diberi sifat pembenaman skema. |
| *beringter Raum* | **ruang bergelanggang** | Ruang topologis yang dilengkapi berkas gelanggang. Teks terdahulu memakai “ruang berdering”; bentuk warisan itu dibaca dengan definisi ini, bukan sebagai istilah pilihan. |

## Istilah pada bagian akhir {#br-bgk-2019-glossary-01-30-lanjutan}

| Istilah sumber | Padanan dan petunjuk |
|---|---|
| *Kähler-Differentiale*; *Tangentialgarbe*; *Kotangentialgarbe* | **diferensial Kähler**; **berkas tangen**; **berkas kotangen**. Pertahankan pembedaan berkas, modul, dan bundel. |
| *kanonische Garbe*; *antikanonische Garbe* | **berkas kanonis** / berkas kanonik; **berkas antikanonis** / berkas antikanonik. Awalan anti- tidak boleh dihilangkan. |
| *Syzygiengarbe* | **berkas syzygy** / berkas sizigi; dua ejaan untuk konstruksi relasi yang sama. |
| *Weildivisor*; *Hauptdivisor* | **pembagi Weil** / divisor Weil; **pembagi utama** / divisor utama. “Pembagi” di sini adalah objek geometri, bukan pembagi bilangan. |
| *Nullstellendivisor*; *Polstellendivisor* | **divisor nol**; **divisor kutub** suatu fungsi. Yang pertama adalah divisor titik-titik nol, bukan berarti divisor tersebut sama dengan nol. |
| *injektive Auflösung*; *rechtsabgeleiteter Funktor* | **resolusi injektif**; **funktor turunan kanan**. Resolusi adalah seluruh kompleks, bukan satu pemetaan injektif. |
| *Čech-Kohomologie*; *Čech-Kozykel*; *Čech-Koränder* | **kohomologi Čech**; **kokikel Čech**; **kobatas Čech**. Kelas kohomologi adalah kokikel modulo kobatas. |
| *lange exakte Kohomologiesequenz* | **barisan kohomologi eksak panjang** / barisan eksak panjang kohomologi. Kedua urutan kata mempertahankan syarat **eksak**. |
| *kurze exakte Sequenz* | **barisan eksak pendek** / barisan pendek eksak. “Barisan” tidak sama dengan *Ordnung*, yaitu urutan dalam teori urutan. |
| *lineares System*; *volles lineares System*; *basispunktfrei* | **sistem linear**; **sistem linear lengkap**; **bebas titik basis** / bebas titik dasar. Lengkap dan bebas titik basis adalah dua sifat berbeda. |
| *Verzweigungsindex*; *Verzweigungsordnung* | **indeks ramifikasi**; **orde ramifikasi**. Unit 29 menjelaskan perbedaan pemakaian nama antarsaksi; keduanya menunjuk eksponen ramifikasi lokal yang sama di sana. |
| *Serre-Dualität*; *Euler-Charakteristik*; *Satz von Riemann-Roch* | **dualitas Serre**; **karakteristik Euler**; **Teorema Riemann-Roch**. Nama tidak menggantikan hipotesis dan cakupan hasil yang dinyatakan sumber. |

## Notasi dan asal panduan {#br-bgk-2019-glossary-01-30-notasi}

Istilah prosa tidak mengubah notasi sumber. Misalnya, **citra** tetap dapat
ditulis dengan operator sumber `bild`, dan nama **spektrum** tidak mengharuskan
penggantian `Spek` oleh `Spec` di dalam rumus. Perbedaan indeks, tanda
kesetaraan, isomorfisme, serta hipotesis bukan varian kosakata.

Panduan penghubung ini disusun dari kursus Holger Brenner dan keputusan
terminologi edisi Indonesia. Penyusunan berbantuan AI:
**OpenAI Codex gpt-5.6-sol, Ultra.** Teks penghubung ini berlisensi
**CC BY-SA 4.0**; kredit dan lisensi setiap komponen sumber tetap dipertahankan.
Ini bukan panduan resmi dari penulis atau lembaga sumber dan tidak menyiratkan
dukungan mereka.
