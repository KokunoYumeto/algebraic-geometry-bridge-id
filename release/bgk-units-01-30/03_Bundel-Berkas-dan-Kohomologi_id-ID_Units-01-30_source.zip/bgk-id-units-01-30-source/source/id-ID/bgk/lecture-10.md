---
title: "Kuliah 10 - Skema dan Morfisme Skema"
stable_id: br-bgk-2019-l10
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 10"
upstream_pageid: 109014
upstream_revid: 1003733
upstream_timestamp: "2025-06-08T15:32:21Z"
upstream_mediawiki_sha1: 4dfde713fd1b38ebf77c1be9a8717dbde34c76ba
source_url: "https://de.wikiversity.org/w/index.php?oldid=1003733"
authority_manifest: authority/wikiversity-bgk/unit-10/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: a8b6384c316086dde5825b6c776289f93a1a2c4a4654bac57148f9e25a6f197f
lecture_xml: authority/wikiversity-bgk/unit-10/lecture-10.xml
lecture_xml_sha256: 556c26db6a7eb22b32d9fbbfb0bf1c04e6d769a7738b3f5f14ed21410059e15c
lecture_expanded_tex: authority/wikiversity-bgk/unit-10/lecture-10-expanded.tex
lecture_expanded_tex_sha256: 8b05be7634ca7c81f3aca9a8c7c3cad93637563d7341fb9987a29541043c9d6e
official_pdf: authority/artifacts/bgk-lecture-10-official.pdf
official_pdf_sha256: 4f30cd25b1460fe216019e36529d80b3880b9ba7c7ee85ee6246f9454b51411a
media_credits: source/id-ID/media-credits-bgk-unit-10.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 10: Skema dan Morfisme Skema {#br-bgk-2019-l10}

## Skema {#br-bgk-2019-l10-s01}

<!-- upstream_entity: Schema/Beringter Raum/Definition -->

### Definisi 10.1: skema {#br-bgk-2019-l10-def-01}

Sebuah *skema* adalah ruang berdering $(X,\mathcal O_X)$ sedemikian sehingga
terdapat penutup terbuka

$$
X=\bigcup_{i\in I}U_i
$$

yang untuk setiap $i$ menjadikan

$$
(U_i,\mathcal O_X|_{U_i})
$$

sebuah skema afin.

<!-- upstream_entity: Schema/Punkt/Offene Umgebung/Affin/Fakt -->

### Lema 10.2: lingkungan afin di dalam lingkungan terbuka {#br-bgk-2019-l10-lem-01}

Misalkan $(X,\mathcal O_X)$ sebuah skema dan $P\in X$ sebuah titik. Untuk
setiap lingkungan terbuka $P\in U$, terdapat lingkungan afin terbuka

$$
P\in V\subseteq U.
$$

#### Bukti {#br-bgk-2019-l10-lem-01-proof}

Ambil sebuah lingkungan afin terbuka

$$
P\in W=\operatorname{Spec}(R).
$$

Maka

$$
P\in U\cap W\subseteq\operatorname{Spek}(R)
$$

merupakan himpunan terbuka di $\operatorname{Spek}(R)$, sehingga berbentuk

$$
U\cap W=D(\mathfrak a)
$$

untuk suatu ideal $\mathfrak a\subseteq R$. Karena

$$
D(\mathfrak a)=\bigcup_{f\in\mathfrak a}D(f),
$$

ada $f\in\mathfrak a$ dengan

$$
P\in D(f)\subseteq D(\mathfrak a)\subseteq U.
$$

Menurut Lema 9.13, $D(f)$ afin.

> **Catatan edisi - notasi operator sumber.** Pernyataan bukti memakai
> $W=\operatorname{Spec}(R)$, lalu kembali ke $\operatorname{Spek}(R)$.
> Kedua ejaan operator dipertahankan dan menunjuk pada spektrum gelanggang
> yang sama.

<!-- upstream_entity: Schema/Offene Teilmenge/Affine Überdeckung/Fakt -->

### Lema 10.3: himpunan terbuka sebuah skema adalah skema {#br-bgk-2019-l10-lem-02}

Setiap himpunan terbuka $U\subseteq X$ dari sebuah skema
$(X,\mathcal O_X)$ mempunyai penutup oleh himpunan-himpunan terbuka afin dan,
karena itu, merupakan sebuah skema.

#### Bukti {#br-bgk-2019-l10-lem-02-proof}

Sebagai himpunan terbuka dari ruang berdering, $U$ juga merupakan ruang
berdering. Keberadaan penutup afin langsung mengikuti Lema 10.2.

<!-- upstream_entity: Schema/Quasiaffin/Definition -->

### Definisi 10.4: skema kuasiafin {#br-bgk-2019-l10-def-02}

Sebuah himpunan terbuka

$$
U\subseteq X=\operatorname{Spek}(R)
$$

dari skema afin $X$ disebut *skema kuasiafin*.

<!-- upstream_entity: Lokaler Ring/Spektrum/Punktiert/Definition -->

### Definisi 10.5: spektrum tertusuk {#br-bgk-2019-l10-def-03}

Untuk gelanggang lokal $(R,\mathfrak m)$, ruang

$$
\operatorname{Spek}(R)\setminus\{\mathfrak m\}
$$

disebut *spektrum tertusuk* dari $R$.

Sebagai ruang berdering, skema dapat direkatkan sepanjang himpunan terbuka
sebagaimana dalam Lema 7.10. Berikut dua contoh.

<!-- upstream_entity: Affine Geraden/Punktiert/Verklebung/Verdoppelte Gerade/Beispiel -->

### Contoh 10.6: garis dengan satu titik yang digandakan {#br-bgk-2019-l10-exa-01}

Ambil dua salinan garis afin,

$$
U=\mathbb A^1_K=\operatorname{Spek}(K[S]),
\qquad
V=\mathbb A^1_K=\operatorname{Spek}(K[T]),
$$

dengan himpunan-himpunan terbuka

$$
U'=\mathbb A^1_K\setminus\{(S)\}
=\operatorname{Spek}(K[S,S^{-1}])\subset\mathbb A^1_K
$$

dan

$$
V'=\mathbb A^1_K\setminus\{(T)\}
=\operatorname{Spek}(K[T,T^{-1}])\subset\mathbb A^1_K.
$$

Pertimbangkan isomorfisme

$$
\varphi:U'\longrightarrow V'
$$

yang ditentukan oleh $S\mapsto T$, lalu rekatkan $U$ dan $V$ dalam arti
Lema 7.10. Ruang yang dihasilkan adalah sebuah skema $X$ yang disebut garis
dengan satu titik yang digandakan. Titik-titik yang ditentukan oleh $(S)$
dan $(T)$ pada $X$ masing-masing kita namai $P$ dan $Q$.

Terdapat diagram komutatif homomorfisme restriksi

$$
\begin{matrix}
\Gamma(X,\mathcal O_X)&\longrightarrow&\Gamma(U,\mathcal O_X)=K[S]\\
\downarrow&&\downarrow\\
\Gamma(V,\mathcal O_X)=K[S]&\longrightarrow&
\Gamma(U',\mathcal O_X)=K[S,S^{-1}],
\end{matrix}
$$

di mana identifikasi $S=T$ telah digunakan. Dari syarat berkas diperoleh

$$
\Gamma(X,\mathcal O_X)=K[S],
$$

dan fungsi-fungsi global mempunyai nilai yang sama di $P$ dan $Q$. Dengan
argumen serupa, tangkai-tangkainya juga berimpit:

$$
\mathcal O_{X,P}=\mathcal O_{X,Q}=K[S]_{(S)}.
$$

Seluruh perhitungan berlangsung di dalam lapangan fungsi $K(S)$.

<!-- upstream_entity: Affine Geraden/Punktiert/Verklebung/Projektive Gerade/Beispiel -->

### Contoh 10.7: garis projektif melalui perekatan {#br-bgk-2019-l10-exa-02}

Sekali lagi ambil dua salinan garis afin

$$
U=\mathbb A^1_K=\operatorname{Spek}(K[S]),
\qquad
V=\mathbb A^1_K=\operatorname{Spek}(K[T])
$$

beserta himpunan terbuka tertusuk $U'$ dan $V'$ seperti pada Contoh 10.6.
Sekarang gunakan isomorfisme

$$
\varphi:U'\longrightarrow V',
\qquad S\longmapsto T^{-1},
$$

untuk merekatkan $U$ dan $V$. Ruang yang dihasilkan,

$$
X=\mathbb P^1_K,
$$

merupakan model garis projektif di atas $K$. Titik-titik yang ditentukan oleh
$(S)$ dan $(T)$ masing-masing dinamai $P$ dan $Q$. Jika $K=\mathbb R$ atau
$K=\mathbb C$ dengan topologi metrik, barisan di $U'$ yang konvergen menuju
$P\in U$ tentu menuju tak hingga ketika dilihat di $V$.

Diagram komutatif homomorfisme restriksinya adalah

$$
\begin{matrix}
\Gamma(\mathbb P^1_K,\mathcal O_{\mathbb P^1_K})&\longrightarrow&
\Gamma(U,\mathcal O_{\mathbb P^1_K})=K[S]\\
\downarrow&&\downarrow\\
\Gamma(V,\mathcal O_{\mathbb P^1_K})=K[T]=K[S^{-1}]&\longrightarrow&
\Gamma(U',\mathcal O_{\mathbb P^1_K})=K[S,S^{-1}],
\end{matrix}
$$

dengan identifikasi $S=T^{-1}$. Syarat berkas memberi

$$
\Gamma(X,\mathcal O_X)=K,
$$

karena hanya fungsi konstan yang sekaligus berada dalam $K[S]$ dan
$K[S^{-1}]$; irisannya diambil di dalam lapangan fungsi $K(S)$. Selain itu,

$$
\mathcal O_{X,P}=K[S]_{(S)},
\qquad
\mathcal O_{X,Q}=K[S^{-1}]_{(S^{-1})}.
$$

## Morfisme skema {#br-bgk-2019-l10-s02}

<!-- upstream_entity: Schema/Morphismus/Definition -->

### Definisi 10.8: morfisme skema {#br-bgk-2019-l10-def-04}

Sebuah *morfisme skema*

$$
\varphi:X\longrightarrow Y
$$

antara skema $X$ dan $Y$ adalah morfisme ruang berdering lokal.

Kita terlebih dahulu hendak menjadikan pemetaan spektrum yang terkait dengan
homomorfisme gelanggang $\theta:R\to S$,

$$
\operatorname{Spek}(S)\longrightarrow\operatorname{Spek}(R),
$$

sebagai morfisme skema. Hal itu merupakan kasus khusus teorema berikut.

<!-- upstream_entity: Lokal beringter Raum/Affines Schema/Morphismus/Fakt -->

### Teorema 10.9: morfisme ke skema afin {#br-bgk-2019-l10-thm-01}

Misalkan $(X,\mathcal O_X)$ ruang berdering lokal dan
$Y=\operatorname{Spek}(R)$ skema afin. Untuk setiap homomorfisme gelanggang

$$
\theta:R\longrightarrow\Gamma(X,\mathcal O_X),
$$

terdapat tepat satu morfisme ruang berdering lokal $X\to Y$ yang mempunyai
$\theta$ sebagai homomorfisme globalnya.

#### Bukti {#br-bgk-2019-l10-thm-01-proof}

Menurut Lema 7.18, untuk setiap $x\in X$ harus berlaku

$$
\varphi(x)
=\{f\in R\mid x\notin X_{\theta(f)}\}
=(\rho_x\circ\theta)^{-1}(\mathfrak m_x),
$$

di mana

$$
\rho_x:\Gamma(X,\mathcal O_X)\longrightarrow\mathcal O_{X,x}
$$

adalah homomorfisme restriksi ke tangkai $\mathcal O_{X,x}$ dan
$\mathfrak m_x\subseteq\mathcal O_{X,x}$ adalah ideal maksimalnya. Rumus ini
menentukan pemetaan kontinu, sebab

$$
\varphi^{-1}(D(f))=X_{\theta(f)};
$$

himpunan-himpunan $D(f)$ membentuk basis menurut Proposisi 8.4(8), sedangkan
$X_{\theta(f)}$ terbuka menurut Lema 7.16.

Untuk setiap $f\in R$ terdapat homomorfisme gelanggang

$$
R\mathrel{\mathop{\longrightarrow}^{\theta}}
\Gamma(X,\mathcal O_X)
\longrightarrow\Gamma(X_{\theta(f)},\mathcal O_X),
$$

dan $\theta(f)$ menjadi satuan di gelanggang paling kanan. Menurut Teorema
11.13 pada kursus Aljabar Komutatif, terdapat tepat satu homomorfisme

$$
R_f\longrightarrow\Gamma(X_{\theta(f)},\mathcal O_X)
$$

yang kompatibel dengan homomorfisme di atas. Karena sifat berkas, untuk setiap
himpunan terbuka $D(\mathfrak a)$ juga diperoleh tepat satu homomorfisme

$$
\Gamma(D(\mathfrak a),\mathcal O_Y)
\longrightarrow
\Gamma(\varphi^{-1}(D(\mathfrak a)),\mathcal O_X).
$$

Memang, jika

$$
D(\mathfrak a)=\bigcup_{i\in I}D(f_i),
$$

maka

$$
\Gamma(D(\mathfrak a),\mathcal O_Y)
=\left\{
(s_i)_{i\in I}\in\prod_{i\in I}R_{f_i}
\ \middle|\
s_i=s_j\text{ di }R_{f_if_j}
\right\}
$$

dan

$$
\Gamma(\varphi^{-1}(D(\mathfrak a)),\mathcal O_X)
=\left\{
(t_i)_{i\in I}\in
\prod_{i\in I}\Gamma(X_{\theta(f_i)},\mathcal O_X)
\ \middle|\
t_i=t_j\text{ di }\Gamma(X_{\theta(f_if_j)},\mathcal O_X)
\right\}.
$$

Homomorfisme-homomorfisme yang telah didefinisikan pada $R_{f_i}$ dan
$R_{f_if_j}$ menghormati persamaan kompatibilitas, sehingga memberi
homomorfisme dari gelanggang pada tampilan pertama ke gelanggang pada tampilan
kedua. Seluruh penetapan ini memang menghasilkan morfisme ruang berdering
lokal.

> **Catatan edisi - dua permukaan sumber.** Saksi semantik menulis
> $\Gamma(X,\mathcal O)$ pada peta $\rho_x$, sementara konteks dan semua peta
> di sekitarnya memakai $\mathcal O_X$; edisi menulis subskrip $X$ secara
> eksplisit. Saksi semantik juga merujuk ke Teorema 11.13 pada Aljabar
> Komutatif, sedangkan PDF resmi lama mencetak Teorema 15.13. Edisi mengikuti
> nomor authority semantik dan mencatat perbedaan itu tanpa menyatukan edisi
> kursus yang dirujuk.

<!-- upstream_entity: Ringhomomorphismus/Spektrumsabbildung/Morphismus/Fakt -->

### Korolari 10.10: homomorfisme gelanggang memberi morfisme spektrum {#br-bgk-2019-l10-cor-01}

Misalkan $R$ dan $S$ gelanggang komutatif dan
$\theta:R\to S$ homomorfisme gelanggang. Terdapat tepat satu morfisme skema

$$
\operatorname{Spek}(S)\longrightarrow\operatorname{Spek}(R)
$$

yang mempunyai $\theta$ sebagai homomorfisme globalnya. Secara topologis,
morfisme ini adalah pemetaan spektrum.

#### Bukti {#br-bgk-2019-l10-cor-01-proof}

Pernyataan langsung mengikuti Teorema 10.9. Bagian awal bukti teorema itu
menunjukkan bahwa pemetaan topologisnya adalah pemetaan spektrum.

<!-- upstream_entity: Lokal beringter Raum/Spek Z/Kanonischer Morphismus/Fakt -->

### Korolari 10.11: morfisme kanonik ke spektrum bilangan bulat {#br-bgk-2019-l10-cor-02}

Untuk setiap ruang berdering lokal $(X,\mathcal O_X)$ terdapat morfisme
kanonik ruang berdering lokal

$$
X\longrightarrow\operatorname{Spek}(\mathbb Z).
$$

Morfisme ini memetakan suatu titik $x\in X$ ke karakteristik lapangan
residunya $\kappa(x)$.

#### Bukti {#br-bgk-2019-l10-cor-02-proof}

Homomorfisme gelanggang kanonik

$$
\mathbb Z\longrightarrow\Gamma(X,\mathcal O_X)
$$

menentukan tepat satu morfisme ruang berdering lokal

$$
X\longrightarrow\operatorname{Spek}(\mathbb Z)
$$

menurut Teorema 10.9.

<!-- upstream_entity: Lokal beringter Raum/Globale Funktion/Affine Gerade/Morphismus/Fakt -->

### Korolari 10.12: fungsi global memberi morfisme ke garis afin {#br-bgk-2019-l10-cor-03}

Misalkan $(X,\mathcal O_X)$ ruang berdering lokal. Setiap fungsi global

$$
f\in\Gamma(X,\mathcal O_X)
$$

menentukan tepat satu morfisme ruang berdering lokal

$$
X\longrightarrow\mathbb A^1_{\mathbb Z},
$$

yang memetakan variabel garis afin ke $f$. Jika
$\Gamma(X,\mathcal O_X)$ merupakan aljabar-$K$ atas lapangan $K$, fungsi
$f$ juga menentukan morfisme ruang berdering lokal

$$
X\longrightarrow\mathbb A^1_K.
$$

Dalam hal ini, titik $x\in X$ dipetakan ke kernel homomorfisme gelanggang

$$
K[T]\longrightarrow\kappa(x),
\qquad T\longmapsto f(x).
$$

#### Bukti {#br-bgk-2019-l10-cor-03-proof}

Unsur gelanggang $f\in\Gamma(X,\mathcal O_X)$ menentukan tepat satu
homomorfisme substitusi

$$
\mathbb Z[T]\longrightarrow\Gamma(X,\mathcal O_X).
$$

Menurut Teorema 10.9, homomorfisme ini menentukan tepat satu morfisme ruang
berdering lokal

$$
(X,\mathcal O_X)\longrightarrow
\operatorname{Spek}(\mathbb Z[T])=\mathbb A^1_{\mathbb Z}.
$$

Pernyataan tambahan diperoleh dengan cara yang sama.

<!-- upstream_entity: Lokal beringter Raum/Affiner Raum/Morphismus/Fakt -->

### Korolari 10.13: tupel fungsi memberi morfisme ke ruang afin {#br-bgk-2019-l10-cor-04}

Misalkan $(X,\mathcal O_X)$ ruang berdering lokal. Setiap tupel fungsi

$$
f_1,\ldots,f_n\in\Gamma(X,\mathcal O_X)
$$

menentukan tepat satu morfisme ruang berdering lokal

$$
X\longrightarrow\mathbb A^n_{\mathbb Z},
$$

yang memetakan variabel $T_i$ dari ruang afin ke $f_i$. Jika
$\Gamma(X,\mathcal O_X)$ merupakan aljabar-$R$ atas gelanggang komutatif
$R$, fungsi-fungsi $f_1,\ldots,f_n$ juga menentukan morfisme ruang berdering
lokal

$$
X\longrightarrow\mathbb A^n_R.
$$

Dalam hal ini, titik $x\in X$ dipetakan ke kernel homomorfisme gelanggang

$$
R[T_1,\ldots,T_n]\longrightarrow\kappa(x),
\qquad T_i\longmapsto f_i(x).
$$

#### Bukti {#br-bgk-2019-l10-cor-04-proof}

Lihat Soal 10.3.

Jadi, morfisme ke ruang afin tidak lain adalah sebuah tupel fungsi global.

Jika $\varphi:X\to Y$ sebuah morfisme, maka untuk setiap himpunan terbuka
$V\subseteq Y$, pemetaan terinduksi

$$
\varphi^{-1}(V)\longrightarrow V
$$

juga merupakan morfisme. Jika $V$ selain itu afin, menurut Teorema 10.9
morfisme tersebut secara lokal terhadap $Y$ diberikan oleh homomorfisme
gelanggang. Artinya, dengan penutup afin

$$
Y=\bigcup_{i\in I}V_i
=\bigcup_{i\in I}\operatorname{Spek}(R_i),
$$

morfisme skema $\varphi:X\to Y$ pada hakikatnya ditentukan oleh
homomorfisme-homomorfisme gelanggang

$$
R_i\longrightarrow\Gamma(\varphi^{-1}(V_i),\mathcal O_X).
$$

## Skema di atas skema basis {#br-bgk-2019-l10-s03}

Untuk aljabar-$K$ komutatif $A$ di atas lapangan $K$, homomorfisme gelanggang
kanonik $K\to A$ menentukan pemetaan spektrum kanonik

$$
\operatorname{Spek}(A)\longrightarrow\operatorname{Spek}(K).
$$

Secara topologis, pemetaan ini hanyalah pemetaan konstan, tetapi tetap
menentukan bagaimana konstanta dari $K$ harus ditafsirkan. Dalam konteks
skema, peran gelanggang dasar diambil alih oleh skema basis.

<!-- upstream_entity: Schema/Basisschema/Definition -->

### Definisi 10.14: skema di atas suatu basis {#br-bgk-2019-l10-def-05}

Sebuah skema $X$ bersama morfisme tetap

$$
p:X\longrightarrow S
$$

ke skema lain $S$ disebut *skema di atas $S$*. Skema $S$ disebut *skema
basis*.

Skema basis sering kali hanya spektrum sebuah lapangan. Menurut Korolari
10.11, setiap skema secara unik merupakan skema di atas
$\operatorname{Spek}(\mathbb Z)$. Skema di atas
$\operatorname{Spek}(R)$ juga disebut skema di atas $R$. Peran homomorfisme
aljabar diambil alih oleh morfisme yang kompatibel dengan basis.

<!-- upstream_entity: Schemata/Basisschema/Morphismus/Definition -->

### Definisi 10.15: morfisme skema di atas basis {#br-bgk-2019-l10-def-06}

Misalkan $X$ dan $Y$ skema di atas skema basis $S$. Morfisme skema

$$
\varphi:X\longrightarrow Y
$$

disebut *morfisme skema di atas $S$* jika diagram

$$
\begin{matrix}
X&\mathrel{\mathop{\longrightarrow}^{\varphi}}&Y\\
&\searrow&\downarrow\\
&&S
\end{matrix}
$$

komutatif.

<!-- upstream_entity: Schemamorphismus/Von endlichem Typ/Definition -->

### Definisi 10.16: morfisme bertipe hingga {#br-bgk-2019-l10-def-07}

Sebuah morfisme skema

$$
\varphi:X\longrightarrow Y
$$

disebut *bertipe hingga* jika terdapat penutup terbuka afin

$$
Y=\bigcup_{i\in I}V_i
$$

sedemikian sehingga, untuk setiap $i\in I$, terdapat penutup afin berhingga

$$
\varphi^{-1}(V_i)=\bigcup_{j\in J_i}U_{ij}
$$

dan untuk setiap $j\in J_i$, homomorfisme gelanggang

$$
\Gamma(V_i,\mathcal O_Y)
\longrightarrow
\Gamma(U_{ij},\mathcal O_X)
$$

bertipe hingga.

> **Catatan edisi - benturan indeks pada sumber.** Sumber menulis penutup
> $Y=\bigcup_{i\in I}V_i$, tetapi kemudian memakai
> $\varphi^{-1}(V_i)=\bigcup_{i\in I_j}U_i$, syarat $i\in I_j$, dan peta dari
> $\Gamma(V_j,\mathcal O_Y)$. Edisi mengganti indeks boneka itu secara
> terlihat dengan $j\in J_i$ dan $U_{ij}$, sehingga basis $V_i$ tetap sama;
> definisi matematis tidak diperluas.

## Pembenaman {#br-bgk-2019-l10-s04}

<!-- upstream_entity: Schema/Morphismus/Offene Einbettung/Definition -->

### Definisi 10.17: pembenaman terbuka {#br-bgk-2019-l10-def-08}

Morfisme skema $f:Y\to X$ disebut *pembenaman terbuka* jika $f$ menginduksi
isomorfisme dengan suatu himpunan terbuka dari $X$.

<!-- upstream_entity: Schema/Morphismus/Abgeschlossene Einbettung/Definition -->

### Definisi 10.18: pembenaman tertutup {#br-bgk-2019-l10-def-09}

Morfisme skema $f:Y\to X$ disebut *pembenaman tertutup* jika $f(Y)$ adalah
himpunan tertutup dari $X$, terdapat homeomorfisme

$$
Y\longrightarrow f(Y),
$$

dan homomorfisme berkas terkait

$$
\mathcal O_X\longrightarrow f_*\mathcal O_Y
$$

surjektif.

<!-- upstream_entity: Schema/Morphismus/Einbettung/Offen und abgeschlossen/Definition -->

### Definisi 10.19: pembenaman {#br-bgk-2019-l10-def-10}

Morfisme skema $f:Y\to X$ disebut *pembenaman* jika terdapat faktorisasi

$$
Y\mathrel{\mathop{\longrightarrow}^{g}}
Z\mathrel{\mathop{\longrightarrow}^{h}}X
$$

dengan $g$ pembenaman terbuka dan $h$ pembenaman tertutup.
