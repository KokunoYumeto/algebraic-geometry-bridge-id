---
title: "Lembar Kerja 11 - Ruang Tak Tereduksi dan Skema Noether"
stable_id: br-bgk-2019-w11
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Marymay0609"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 11"
upstream_pageid: 110218
upstream_revid: 612137
upstream_timestamp: "2020-01-24T13:09:14Z"
upstream_mediawiki_sha1: 0d36ef9ba0541058aa2bb8cc7bcfa015382e3106
source_url: "https://de.wikiversity.org/w/index.php?oldid=612137"
authority_manifest: authority/wikiversity-bgk/unit-11/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: c55c715d0a1bd3ef5b13ac96ccf38f9b5c261e87124c6da5ccc5984cb61deb09
worksheet_xml: authority/wikiversity-bgk/unit-11/worksheet-11.xml
worksheet_xml_sha256: 9d73692e385b17a84901ed9e15baeeb0c9793929c5a8263777f69554b6ca6de5
worksheet_expanded_tex: authority/wikiversity-bgk/unit-11/worksheet-11-expanded.tex
worksheet_expanded_tex_sha256: 3361e7036c8432a1a14adcf8ac3fb859ddf999e3b5f44007caefa33e8e320a4b
official_pdf: authority/artifacts/bgk-worksheet-11-official.pdf
official_pdf_sha256: 83ef811e6047d4e23643881048dc614d58d7e8e328b55173a2e67fd09a65e6cd
ordered_exercise_map: authority/wikiversity-bgk/unit-11/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 44c6b2f4a86976163360cf7d0b0b60e39334ec54336e8483249431039365c161
exercise_count: 19
public_solution_count: 3
public_solution_numbers: "9, 13, 14"
media_credits: source/id-ID/media-credits-bgk-unit-11.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 11: Ruang Tak Tereduksi dan Skema Noether {#br-bgk-2019-w11}

Tanda bintang menunjukkan tepat tiga soal dengan solusi publik yang dibekukan,
yaitu Soal 11.9, 11.13, dan 11.14. Enam belas soal lainnya mempunyai hasil
kandidat negatif; edisi tidak menciptakan solusi baru.

<!-- upstream_entity: Irreduzibler Raum/Offene Teilmenge/Dicht/Aufgabe -->

## Soal 11.1 {#br-bgk-2019-w11-ex01}

Buktikan bahwa dalam ruang topologis tak tereduksi $X$, setiap himpunan
terbuka tak kosong $U\subseteq X$ padat.

<!-- upstream_entity: Metrischer Raum/Irreduzible Teilmengen/Aufgabe -->

## Soal 11.2 {#br-bgk-2019-w11-ex02}

Buktikan bahwa ruang metrik $X$ hanya mungkin tak tereduksi jika terdiri atas
satu titik.

<!-- upstream_entity: Topologischer Raum/Irreduzible Teilmenge/Abschluss/Aufgabe -->

## Soal 11.3 {#br-bgk-2019-w11-ex03}

Misalkan $X$ ruang topologis dan $Y\subseteq X$ subhimpunan dengan topologi
terinduksi. Buktikan bahwa $Y$ tak tereduksi jika dan hanya jika penutupannya
$\overline Y$ tak tereduksi.

Sebuah ruang topologis dikatakan memenuhi *sifat pemisahan $T_0$* jika untuk
setiap dua titik $x\ne y$, terdapat himpunan terbuka $U$ dengan
$x\in U$ dan $y\notin U$, atau terdapat himpunan terbuka $V$ dengan
$x\notin V$ dan $y\in V$.

Sebuah ruang topologis dikatakan memenuhi *sifat pemisahan $T_1$* jika setiap
titik $x\in X$ tertutup.

<!-- upstream_entity: Schema/T0/Aufgabe -->

## Soal 11.4 {#br-bgk-2019-w11-ex04}

Buktikan bahwa sebuah skema memenuhi sifat pemisahan $T_0$.

<!-- upstream_entity: Affines Schema/T1/Hausdorffsch/Nulldimensional/Aufgabe -->

## Soal 11.5 {#br-bgk-2019-w11-ex05}

Buktikan bahwa untuk skema afin $X=\operatorname{Spek}(R)$, sifat-sifat
berikut ekuivalen.

1. Setiap ideal prima di $R$ maksimal.
2. Setiap titik di $X$ tertutup.
3. $X$ merupakan ruang Hausdorff.

<!-- upstream_entity: Affines Schema/Nulldimensional/Nicht diskret/Aufgabe -->

## Soal 11.6 {#br-bgk-2019-w11-ex06}

Berikan contoh skema afin berdimensi nol
$X=\operatorname{Spek}(R)$ yang tidak diskret.

<!-- upstream_entity: Topologischer Raum/Irreduzible Teilmenge/Generischer Punkt/Abschluss/Aufgabe -->

## Soal 11.7 {#br-bgk-2019-w11-ex07}

Misalkan $Y\subseteq X$ subhimpunan tak tereduksi dari ruang topologis $X$
dan $\eta\in Y$. Buktikan bahwa $\eta$ merupakan titik generik $Y$ jika dan
hanya jika

$$
\overline{\{\eta\}}=Y.
$$

<!-- upstream_entity: Affines Schema/Irreduzible Teilmenge/Generischer Punkt/Aufgabe -->

## Soal 11.8 {#br-bgk-2019-w11-ex08}

Misalkan $X=\operatorname{Spek}(R)$ spektrum gelanggang komutatif $R$ dan

$$
Y=V(\mathfrak p)\subseteq X
$$

himpunan tertutup yang terkait dengan ideal prima $\mathfrak p$. Buktikan
bahwa $\mathfrak p$ adalah titik generik $V(\mathfrak p)$.

<!-- upstream_entity: Differenzierbare Mannigfaltigkeit/Kette von abgeschlossenen Untermannigfaltigkeiten/Aufgabe -->

## Soal 11.9* {#br-bgk-2019-w11-ex09}

Misalkan $M\ne\varnothing$ manifold terdiferensial berdimensi $n$. Buktikan
bahwa terdapat rantai submanifold tertutup

$$
M_0\subseteq M_1\subseteq M_2\subseteq\cdots
\subseteq M_{n-1}\subseteq M_n=M
$$

sedemikian sehingga submanifold tertutup $M_i$ berdimensi $i$.

<!-- upstream_entity: Noetherscher Raum/Unterraum/Aufgabe -->

## Soal 11.10 {#br-bgk-2019-w11-ex10}

Misalkan $X$ ruang topologis Noether. Buktikan bahwa setiap subhimpunan
$Y\subseteq X$ dengan topologi terinduksi juga Noether.

<!-- upstream_entity: Noetherscher Raum/Jede Teilmenge quasikompakt/Aufgabe -->

## Soal 11.11 {#br-bgk-2019-w11-ex11}

Misalkan $X$ ruang topologis Noether. Buktikan bahwa setiap subhimpunan
$Y\subseteq X$ dengan topologi terinduksi kuasikompak.

<!-- upstream_entity: Reelle Zahlen/Kein noetherscher Raum/Aufgabe -->

## Soal 11.12 {#br-bgk-2019-w11-ex12}

Buktikan bahwa bilangan real $\mathbb R$ dengan topologi metrik bukan ruang
topologis Noether.

<!-- upstream_entity: Kommutativer Ring/Ideal/Endlich erzeugt/Überdeckungstest/Aufgabe -->

## Soal 11.13* {#br-bgk-2019-w11-ex13}

Misalkan $R$ gelanggang komutatif dan

$$
\operatorname{Spek}(R)=\bigcup_{i\in I}D(f_i),
\qquad f_i\in R.
$$

Misalkan $\mathfrak a$ ideal di $R$ sedemikian sehingga setiap ideal perluasan
$\mathfrak aR_{f_i}$ dibangkitkan secara berhingga. Buktikan bahwa
$\mathfrak a$ dibangkitkan secara berhingga.

<!-- upstream_entity: Kommutativer Ring/Spektrum/Noethersches Schema/Aufgabe -->

## Soal 11.14* {#br-bgk-2019-w11-ex14}

Misalkan $R$ gelanggang komutatif dan
$X=\operatorname{Spek}(R)$ skema afin terkait. Buktikan bahwa $X$ merupakan
skema Noether jika dan hanya jika $R$ gelanggang Noether.

<!-- upstream_entity: Noetherscher Ring/Minimale Primideale/Endlich/Fakt/Beweis/Aufgabe -->

## Soal 11.15 {#br-bgk-2019-w11-ex15}

Buktikan bahwa dalam gelanggang komutatif Noether hanya terdapat berhingga
banyak ideal prima minimal.

<!-- upstream_entity: Nicht-noethersche Ringe/Beispiel/Reduktion ist Körper/Aufgabe -->

## Soal 11.16 {#br-bgk-2019-w11-ex16}

Berikan contoh gelanggang non-Noether yang reduksinya merupakan lapangan.

Misalkan $R$ gelanggang komutatif. Sistem multiplikatif $F\subseteq R$ disebut
*ultrafilter* jika $0\notin F$ dan $F$ maksimal dengan sifat tersebut.

<!-- upstream_entity: Kommutative Ringtheorie/Multiplikatives System/Maximal ohne 1/Komplement ist minimales Primideal/Aufgabe -->

## Soal 11.17 {#br-bgk-2019-w11-ex17}

Misalkan $R$ gelanggang komutatif dan $F\subset R$ sebuah ultrafilter.
Buktikan bahwa komplemen $F$ merupakan ideal prima minimal di $R$.

<!-- upstream_entity: Beringter Raum/Reduziert/Lokale Eigenschaft/Fakt/Beweis/Aufgabe -->

## Soal 11.18 {#br-bgk-2019-w11-ex18}

Misalkan $(X,\mathcal O_X)$ ruang berdering. Buktikan bahwa pernyataan berikut
ekuivalen.

1. $(X,\mathcal O_X)$ adalah ruang berdering tereduksi.
2. Untuk setiap titik $P\in X$, tangkai $\mathcal O_{X,P}$ tereduksi.

<!-- upstream_entity: Schema/Integrität/Keine lokale Eigenschaft/Aufgabe -->

## Soal 11.19 {#br-bgk-2019-w11-ex19}

Buktikan bahwa keintegralan sebuah skema pada umumnya bukan sifat lokal.
