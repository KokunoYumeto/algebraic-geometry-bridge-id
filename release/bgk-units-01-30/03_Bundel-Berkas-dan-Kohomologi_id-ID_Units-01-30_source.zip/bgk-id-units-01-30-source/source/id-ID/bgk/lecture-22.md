---
title: "Kuliah 22 - Grup Kelas Pembagi"
stable_id: br-bgk-2019-l22
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 22"
upstream_pageid: 109026
upstream_revid: 1003751
upstream_timestamp: "2025-06-08T15:48:32Z"
upstream_mediawiki_sha1: c81e7984c77ecb9624a5aa799029d3bbd3e80823
source_url: "https://de.wikiversity.org/w/index.php?oldid=1003751"
authority_manifest: authority/wikiversity-bgk/unit-22/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 98e1716c4a8e95d42a19fd6a8b9efb04e222687e5bb6dc296ae42496baab1e39
lecture_xml: authority/wikiversity-bgk/unit-22/lecture-22.xml
lecture_xml_sha256: d231b1260ad47b265cd975cbc9205b213b3562a51bc1d36082d81ebdf2cb9146
lecture_expanded_tex: authority/wikiversity-bgk/unit-22/lecture-22-expanded.tex
lecture_expanded_tex_sha256: 28cca51595ca349e6ff98df7abe3ea45e51344ddfe55603b7f46d64ef88169ac
official_pdf: authority/artifacts/bgk-lecture-22-official.pdf
official_pdf_sha256: 710a732e3683593615ad9a6a005504e207b173248f06b46539e20b9018dd886e
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete_semantic_authority_bound
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
rights_ledger: authority/RIGHTS-bgk-unit-22.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-22.json
asset_closure_sha256: e7bf39c238717349b7d2e02a8f05eb252fe6aa39199bce82a8c9f60d1b5ea718
---

# Kuliah 22: Grup Kelas Pembagi {#br-bgk-2019-l22}

## Pembagi Weil {#br-bgk-2019-l22-s01}

Kita menyebut suatu subhimpunan tertutup tak tereduksi
$Y\subset X$ berkodimensi $1$ dalam skema integral $X$ sebagai *pembagi
prima*. Jika $X$ normal dan Noether, gelanggang lokal
$\mathcal O_{X,\eta}$ di titik generik $\eta$ dari $Y$ merupakan gelanggang
valuasi diskret. Oleh karena itu, setiap unsur

$$
f\ne 0
$$

dari lapangan fungsi $K(X)$ mempunyai orde yang terdefinisi dengan baik di
sepanjang $Y$, yang kita lambangkan dengan
$\operatorname{ord}_Y(f)$. Jika $\pi$ menyatakan uniformisator, yaitu
pembangkit ideal maksimal, dalam gelanggang valuasi diskret
$\mathcal O_{X,\eta}$, kita dapat menulis

$$
f=u\pi^n
$$

dengan suatu satuan $u$ dari gelanggang tersebut dan $n\in\mathbb Z$.
Eksponen $n$ ini disebut orde $f$ di sepanjang $Y$. Orde positif berarti
nol, sedangkan orde negatif berarti kutub. Jika

$$
U=\operatorname{Spek}(R)\subseteq X
$$

merupakan subhimpunan terbuka afin dengan $U\cap Y\ne\varnothing$, maka
$Y$ bersesuaian dengan ideal prima $\mathfrak p$ bertinggi $1$ dalam $R$,
dan untuk gelanggang lokal berlaku

$$
\mathcal O_{X,\eta}=R_{\mathfrak p}.
$$

<!-- upstream_entity: Noethersches normales integres Schema/Hauptdivisor/Definition -->

### Definisi 22.1: pembagi utama {#br-bgk-2019-l22-def-01}

Misalkan $X$ skema integral normal dan Noether dengan lapangan fungsi $K$,
dan misalkan $f\in K$, $f\ne 0$. Jumlah formal

$$
\operatorname{div}(f)
=\sum_{Y\text{ pembagi prima}}\operatorname{ord}_Y(f)\cdot Y,
$$

dengan $\operatorname{ord}_Y(f)$ menyatakan orde $f$ dalam gelanggang
lokal pada $Y$, disebut *pembagi utama* yang ditentukan oleh $f$.

Jadi, pembagi utama mendeskripsikan perilaku nol dan kutub fungsi $f$.
Pertama-tama kita tunjukkan bahwa pembagi utama merupakan jumlah hingga.

<!-- upstream_entity: Noethersches normales integres Schema/Hauptdivisor/Endlich/Fakt -->

### Lema 22.2: dukungan pembagi utama berhingga {#br-bgk-2019-l22-lem-01}

Misalkan $X$ skema integral normal dan Noether dengan lapangan fungsi $K$,
dan misalkan $f\in K$, $f\ne 0$. Maka hanya ada berhingga banyak pembagi
prima $Y$ dengan

$$
\operatorname{ord}_Y(f)\ne 0.
$$

#### Bukti {#br-bgk-2019-l22-lem-01-proof}

Misalkan $U\subseteq X$ suatu subhimpunan terbuka afin tak kosong dengan

$$
f\in R=\Gamma(U,\mathcal O_X).
$$

Karena titik generik $X$ termasuk dalam $U$, pembagi-pembagi prima yang
tidak berpotongan dengan $U$ merupakan komponen-komponen tak tereduksi dari
$X\smallsetminus U$. Himpunan $X\smallsetminus U$ tertutup dalam $X$ dan
karena itu Noether, sehingga hanya mempunyai berhingga banyak komponen.
Jadi, tinggal dipertimbangkan pembagi-pembagi prima yang berpotongan dengan
$U$. Titik-titik generiknya bersesuaian dengan ideal prima bertinggi $1$
dalam $R$. Kita mempunyai

$$
\operatorname{ord}_Y(f)=\operatorname{ord}_{\mathfrak p}(f)\geq 0,
$$

dan nilainya positif hanya jika $f\in\mathfrak p$. Ideal-ideal prima
$\mathfrak p$ bertinggi $1$ yang terletak di atas $f$ adalah ideal-ideal
prima minimal dari $R/(f)$; karena gelanggangnya Noether, hanya ada
berhingga banyak ideal demikian.

<!-- upstream_entity: Noethersches normales integres Schema/Weildivisor/Definition -->

### Definisi 22.3: pembagi Weil {#br-bgk-2019-l22-def-02}

Misalkan $X$ skema integral normal dan Noether. Jumlah formal

$$
\sum_Y n_Y\cdot Y,
$$

dengan $Y$ menjelajahi pembagi-pembagi prima $X$ dan hanya berhingga banyak
$n_Y$ yang bukan nol, disebut *pembagi Weil* pada $X$.

Pembagi Weil merupakan penetapan bebas atas perilaku nol atau kutub yang
"secara teoretis mungkin" bagi suatu fungsi rasional. Akan tetapi, penetapan
seperti itu tidak harus dapat diwujudkan oleh suatu fungsi. Pembagi yang
semua bilangannya $a_Y\geq 0$ disebut *efektif*. Pada kurva normal tak
tereduksi (jadi mulus) $X$, pembagi prima hanyalah sebuah titik tertutup.
Dalam hal ini, pembagi Weil adalah jumlah hingga

$$
\sum_{P\in X}n_P\cdot P.
$$

<!-- upstream_entity: Noethersches normales integres Schema/Weildivisorengruppe/Definition -->

### Definisi 22.4: grup pembagi Weil {#br-bgk-2019-l22-def-03}

Misalkan $X$ skema integral normal dan Noether. Grup semua pembagi Weil,
dengan penjumlahan per komponen, disebut *grup pembagi Weil* dari $X$.
Grup ini dilambangkan dengan

$$
\operatorname{Div}(X).
$$

<!-- upstream_entity: Noethersches normales integres Schema/Hauptdivisor/Gruppenhomomorphismus/Fakt -->

### Lema 22.5: pembagi utama membentuk homomorfisme grup {#br-bgk-2019-l22-lem-02}

Misalkan $X$ skema integral normal dan Noether dengan lapangan fungsi $K$.
Maka pemetaan

$$
K^\times\longrightarrow\operatorname{Div}(X),
\qquad f\longmapsto\operatorname{div}(f),
$$

merupakan homomorfisme grup.

#### Bukti {#br-bgk-2019-l22-lem-02-proof}

Menurut Lema 22.2, pembagi utama dari $f$ memang merupakan pembagi Weil.
Untuk pembagi prima tetap $Y$ beserta gelanggang valuasi diskret
$\mathcal O_Y$ yang terkait, sifat homomorfisme mengikuti dari Lema 21.7
(1).

## Grup kelas pembagi {#br-bgk-2019-l22-s02}

<!-- upstream_entity: Noethersches normales integres Schema/Divisorenklassengruppe/Definition -->

### Definisi 22.6: grup kelas pembagi {#br-bgk-2019-l22-def-04}

Misalkan $X$ skema integral normal dan Noether dengan lapangan fungsi $K$.
Grup faktor

$$
\operatorname{DKG}(X)
=\operatorname{Div}(X)/\operatorname{HDiv}(X)
$$

disebut *grup kelas pembagi* dari $X$.

Untuk domain integral normal dan Noether $R$, secara serupa

$$
\operatorname{DKG}(R)
=\operatorname{DKG}(\operatorname{Spek}(R))
$$

disebut grup kelas pembagi gelanggang $R$. Dalam konteks teori bilangan,
ketika $R$ adalah gelanggang bilangan bulat dalam suatu perluasan hingga
dari $\mathbb Q$, grup ini juga disebut *grup kelas ideal*. Pembagi-pembagi
yang menentukan kelas pembagi yang sama disebut *ekuivalen secara linear*.

<!-- upstream_entity: Normaler noetherscher Bereich/Divisorenklassengruppe/Faktoriell/Fakt -->

### Teorema 22.7: kriteria faktorisasi tunggal melalui pembagi {#br-bgk-2019-l22-thm-01}

Misalkan $R$ domain integral normal dan Noether, dan misalkan
$\operatorname{DKG}(R)$ menyatakan grup kelas pembagi $R$. Pernyataan
berikut ekuivalen.

1. $R$ adalah domain faktorisasi tunggal.
2. Setiap ideal prima bertinggi $1$ merupakan ideal utama.
3. Setiap pembagi merupakan pembagi utama.
4. $\operatorname{DKG}(R)=0$.

#### Bukti {#br-bgk-2019-l22-thm-01-proof}

Andaikan (1) berlaku dan $\mathfrak p$ adalah ideal prima bertinggi $1$.
Ada $f\in\mathfrak p$, $f\ne 0$. Unsur ini mempunyai faktorisasi prima

$$
f=p_1\cdots p_n.
$$

Karena $\mathfrak p$ prima, kita harus mempunyai
$p_i\in\mathfrak p$ untuk suatu $i$. Syarat tinggi kemudian memberi

$$
(p_i)=\mathfrak p.
$$

Sekarang andaikan setiap ideal prima bertinggi $1$ merupakan ideal utama.
Dengan

$$
\mathfrak p=(p),
$$

kita mempunyai relasi pembagi

$$
\operatorname{div}(p)=1\cdot\mathfrak p,
$$

sebab $p$ tidak termuat dalam ideal prima bertinggi $1$ yang lain dan,
dalam $R_{\mathfrak p}$, unsur $p$ juga membangkitkan
$\mathfrak pR_{\mathfrak p}$. Dengan demikian, pembangkit-pembangkit grup
kelas pembagi merupakan pembagi utama, sehingga semua pembagi merupakan
pembagi utama. Ekuivalensi (3) dan (4) jelas.

> **Catatan edisi - nama grup dalam sumber.** Pada langkah ini, sumber
> mencetak *Divisorenklassengruppe* (grup kelas pembagi), meskipun argumen
> memakai pembagi-pembagi prima sebagai pembangkit. Edisi mempertahankan
> nama grup yang dicetak dan tidak menggantinya secara diam-diam dengan grup
> pembagi.

Selanjutnya andaikan setiap pembagi merupakan pembagi utama. Untuk setiap
ideal prima $\mathfrak p$ bertinggi $1$, terdapat
$f\in Q(R)$, $f\ne 0$, dengan

$$
\operatorname{div}(f)=1\cdot\mathfrak p.
$$

Karena pembagi utama ini tak negatif, Teorema 21.12 memberi $f\in R$.
Jadi, di antara ideal-ideal prima bertinggi $1$, $f$ hanya termuat dalam
$\mathfrak p$. Misalkan

$$
\mathfrak p=(g_1,\ldots,g_n).
$$

Maka

$$
\operatorname{div}(g_i)\geq\operatorname{div}(f),
$$

sehingga $g_i/f\in R$, yakni $g_i\in(f)$, dan karena itu
$\mathfrak p=(f)$.

Terakhir, andaikan (2) berlaku dan ambil $f\in R$, $f\ne 0$. Misalkan
$\mathfrak p_1,\ldots,\mathfrak p_s$ adalah ideal-ideal prima minimal di
atas $f$. Menurut teorema ideal utama Krull, semuanya bertinggi $1$.
Misalkan $\mathfrak p_i=(p_i)$ dengan unsur prima $p_1$. Kita
mempunyai

$$
\operatorname{div}(f)=\sum_{i=1}^s n_i\mathfrak p_i.
$$

Unsur $\prod_{i=1}^s p_i^{n_i}$ mempunyai pembagi utama yang sama. Oleh
karena itu, hasil bagi

$$
f\bigg/\prod_{i=1}^s p_i^{n_i}
$$

adalah satuan, dan

$$
f=u\prod_{i=1}^s p_i^{n_i}
$$

dengan suatu satuan $u$. Jadi $R$ adalah domain faktorisasi tunggal.

> **Catatan edisi - subskrip unsur prima.** Pada langkah terakhir, sumber
> menuliskan $\mathfrak p_i=(p_i)$ tetapi kemudian menyebut unsur prima
> $p_1$. Edisi mempertahankan subskrip yang dicetak; hasil kali berikutnya
> kembali memakai $p_i$.

<!-- upstream_entity: Projektiver Raum/Körper/Divisorenklassengruppe/Beispiel -->

### Contoh 22.8: grup kelas pembagi ruang projektif {#br-bgk-2019-l22-exm-01}

Kita akan memahami pembagi Weil dan grup kelas pembagi ruang projektif
$\mathbb P_K^d$ di atas suatu lapangan $K$, dengan $d\geq 1$. Perhatikan
dekomposisi saling lepas

$$
\mathbb P_K^d
=D_+(X_0)\cup V_+(X_0)
=\mathbb A_K^d\cup\mathbb P_K^{d-1}.
$$

Dengan kata lain, kita menetapkan hiperbidang

$$
H=V_+(X_0)\cong\mathbb P_K^{d-1}
$$

"di tak hingga". Maka suatu pembagi prima ruang projektif sama dengan
hiperbidang di kanan, atau berpotongan tak kosong dengan ruang afin di kiri
dan dapat dipandang sebagai ideal prima bertinggi $1$ dalam gelanggang
polinomial

$$
K\left[\frac{X_1}{X_0},\ldots,\frac{X_d}{X_0}\right].
$$

Setiap fungsi $f$ dalam lapangan fungsi dapat ditulis secara unik, hingga
penskalaan dan pencoretan faktor persekutuan, sebagai

$$
f=\frac PQ,
$$

dengan

$$
P,Q\in K\left[\frac{X_1}{X_0},\ldots,\frac{X_d}{X_0}\right].
$$

Dengan faktorisasi prima $P$ dan $Q$, kita dapat langsung menulis

$$
f=\prod_{i=1}^n cP_i^{\nu_i},
$$

dengan konstanta $c\ne 0$ dan $\nu_i\in\mathbb Z$, lalu membaca pembagi
utama $f$ sejauh menyangkut komponen-komponen dalam ruang afin. Orde
"di tak hingga" dari $f$ pada $V_+(X_0)$ diperoleh sebagai berikut.
Gelanggang lokal pada pembagi prima ini adalah

$$
\begin{aligned}
K[X_0,X_1,\ldots,X_n]_{((X_0))}
&=\left(
K[X_0,X_1,\ldots,X_n]_{
(K[X_0,X_1,\ldots,X_n]\smallsetminus(X_0))
\cap\{\text{unsur homogen}\}}
\right)_0\\
&=K\left(\frac{X_2}{X_1},\ldots,\frac{X_d}{X_1}\right)
\left[\frac{X_0}{X_1}\right]_{(\frac{X_0}{X_1})}.
\end{aligned}
$$

Kita menulis $P$ (dan demikian pula $Q$ atau $f$) dengan mengganti setiap
$X_i/X_0$ oleh

$$
\frac{X_i}{X_1}\cdot\frac{X_1}{X_0}.
$$

Ekspresi ini dipandang sebagai fungsi rasional dalam satu variabel
$X_0/X_1$ di atas lapangan

$$
K\left(\frac{X_2}{X_1},\ldots,\frac{X_d}{X_1}\right).
$$

Derajatnya terhadap $X_0/X_1$, yang biasanya negatif, adalah ordenya.
Sebagai contoh,

$$
\begin{aligned}
P
&=\frac{X_1}{X_0}+\left(\frac{X_2}{X_0}\right)^3\\
&=\frac{X_1}{X_0}
+\left(\frac{X_2}{X_1}\right)^3
\left(\frac{X_1}{X_0}\right)^3\\
&=\left(
\left(\frac{X_0}{X_1}\right)^2
+\left(\frac{X_2}{X_1}\right)^3
\right)
\left(\frac{X_0}{X_1}\right)^{-3},
\end{aligned}
$$

sehingga ordenya adalah $-3$.

Karena gelanggang polinomial adalah domain faktorisasi tunggal, pada ruang
afin setiap pembagi Weil sama dengan suatu pembagi utama. Jadi setiap
pembagi Weil ekuivalen secara linear dengan pembagi berbentuk

$$
nV_+(X_0),\qquad n\in\mathbb Z.
$$

Kelas $V_+(X_0)$ juga disebut *kelas hiperbidang*. Jika $n\ne 0$, pembagi
tersebut bukan pembagi utama: pembagi utama seperti itu trivial pada ruang
afin dan karenanya harus berasal dari suatu konstanta, sedangkan konstanta
juga mempunyai orde $0$ di tak hingga. Dengan demikian, grup kelas pembagi
ruang projektif adalah $\mathbb Z$, dan sebarang hiperbidang dapat dipilih
sebagai pembangkit.

> **Catatan edisi - indeks pada tampilan gelanggang lokal.** Sumber memakai
> $d$ untuk dimensi ruang projektif, tetapi menuliskan
> $K[X_0,X_1,\ldots,X_n]$ dalam tampilan gelanggang lokal. Edisi
> mempertahankan kedua indeks itu sebagaimana dicetak.

## Grup kelas pembagi dan grup Picard {#br-bgk-2019-l22-s03}

Sekarang kita membahas hubungan antara pembagi dan subberkas invertibel dari
berkas lapangan fungsi $\mathcal K$, serta hubungan antara grup kelas
pembagi dan grup Picard. Suatu subberkas invertibel

$$
\mathcal L\subseteq\mathcal K
$$

menentukan, untuk setiap titik $x\in X$, suatu submodul
$\mathcal O_{X,x}$ yang bebas berank $1$,

$$
\mathcal L_x\subseteq\mathcal K_x=K.
$$

Jika $\mathcal O_{X,x}$ merupakan gelanggang valuasi diskret dengan
uniformisator $\pi$, seperti yang terjadi pada skema normal untuk setiap
titik generik pembagi prima, maka

$$
\mathcal L_x=\pi^n\mathcal O_{X,x}
$$

untuk suatu $n\in\mathbb Z$ yang unik. Bilangan ini kita lambangkan dengan
$\operatorname{ord}_Y(\mathcal L)$ jika $Y$ adalah pembagi prima tersebut.

<!-- upstream_entity: Lokal faktorielles integres Schema/Invertierbare Untergarben/Weildivisoren/Fakt -->

### Teorema 22.9: subberkas invertibel dan pembagi Weil {#br-bgk-2019-l22-thm-02}

Misalkan $X$ skema integral Noether yang faktorial lokal. Submodul-submodul
$\mathcal O_X$ yang invertibel dari berkas lapangan fungsi konstan
$\mathcal K$ dan pembagi-pembagi Weil saling bersesuaian melalui

$$
\mathcal L\longmapsto
\sum_Y\operatorname{ord}_Y(\mathcal L)
$$

dan

$$
D=\sum_Y a_YY\longmapsto\mathcal L_D,
$$

dengan

$$
\mathcal L_D(U)
=\{f\in K\mid \operatorname{ord}_Y(f)\geq D
\text{ untuk semua }Y\in U\}
$$

untuk subhimpunan terbuka $U\subseteq X$. Korespondensi ini kompatibel
dengan struktur grup; subberkas trivial bersesuaian dengan pembagi utama.
Ideal invertibel

$$
\mathcal L\subseteq\mathcal O_X\subseteq\mathcal K
$$

bersesuaian dengan pembagi efektif.

> **Catatan edisi - dua tampilan sumber.** Pada pemetaan pertama, sumber
> tidak mencetak faktor $Y$ setelah
> $\operatorname{ord}_Y(\mathcal L)$, walaupun bukti kemudian menulis
> $D=\sum_Y\operatorname{ord}_Y(\mathcal L)Y$. Dalam definisi
> $\mathcal L_D(U)$, sumber membandingkan
> $\operatorname{ord}_Y(f)$ langsung dengan pembagi $D$, tanpa menamai
> koefisiennya. Kedua tampilan dipertahankan apa adanya.

#### Bukti {#br-bgk-2019-l22-thm-02-proof}

Ada liputan afin terbuka hingga

$$
X=\bigcup_{i\in I}U_i
$$

dengan

$$
\mathcal L=(f_i)\mathcal O_X|_{U_i},
$$

di mana $f_i\in K$ dan $f_i\ne 0$. Menurut Lema 22.2, untuk setiap $i$
hanya berhingga banyak pembagi Weil tak tereduksi dalam $U_i$ yang memenuhi

$$
\operatorname{ord}_Y(f_i)\ne 0.
$$

Karena itu,

$$
D=\sum_Y\operatorname{ord}_Y(\mathcal L)Y
$$

memang merupakan pembagi Weil.

Sebaliknya, misalkan $D$ pembagi Weil dan $\mathcal L$ subberkas terkait
dari berkas konstan untuk lapangan fungsi. Kita harus menunjukkan bahwa
$\mathcal L$ invertibel. Ambil titik $x\in X$ dan lingkungan terbuka afin

$$
x\in U\subseteq X.
$$

Menurut hipotesis, gelanggang lokal $\mathcal O_{X,x}$ adalah domain
faktorisasi tunggal. Menurut Teorema 22.7, pembagi $D_x$ yang terdiri atas
semua komponen tak tereduksi $D$ yang melalui $x$ merupakan pembagi utama.
Dengan membuang komponen-komponen $D$ yang tidak melalui $x$, kita dapat
mengganti $U$ dengan lingkungan afin lebih kecil $V$ dari $x$ tempat
pembagi tersebut merupakan pembagi utama. Jadi, di sana berlaku

$$
D|_V=\operatorname{div}(f)|_V
$$

untuk suatu $f\in K$, dan kemudian

$$
\mathcal L_D|_V=(f)\mathcal O_X|_V.
$$

Sekarang kita harus menunjukkan bahwa kedua korespondensi ini saling invers.
Mulailah dengan suatu subberkas invertibel dan gunakan notasi di atas. Pada
$U_i$ berlaku

$$
D|_{U_i}=\operatorname{div}(f_i)|_{U_i}.
$$

Oleh karena itu, untuk $g\in K$, keanggotaan

$$
g\in\{f\in K\mid\operatorname{ord}_Y(f)\geq D
\text{ untuk semua }Y\in U\}
$$

berlaku tepat ketika relasi pembagi utama

$$
\operatorname{div}(g)\geq\operatorname{div}(f_i)
$$

berlaku pada $U$. Menurut Teorema 21.12, ini ekuivalen dengan

$$
g\in f\cdot\Gamma(X,\mathcal O_X).
$$

Jika kita mulai dengan pembagi Weil, secara lokal pembagi itu sama dengan
pembagi utama. Unsur lapangan fungsi yang mempunyai pembagi utama tersebut
kemudian membangkitkan secara lokal berkas invertibel terkait, dan unsur
yang sama dipakai untuk menghitung kembali pembagi terkait.

> **Catatan edisi - notasi pada akhir bukti sumber.** Setelah memakai
> pembangkit $f_i$ pada $U_i$, sumber mencetak
> $g\in f\cdot\Gamma(X,\mathcal O_X)$. Edisi tidak mengganti indeks atau
> himpunan terbukanya secara diam-diam.

Dalam korespondensi di atas, ideal bersesuaian dengan pembagi efektif, dan
ideal utama $(f)$ bersesuaian dengan pembagi utama
$\operatorname{div}(f)$. Ada pula alasan yang baik untuk mengubah
korespondensi tersebut dengan memasukkan negasi. Dengan konvensi itu,
pembagi efektif bersesuaian dengan suatu seksi global dalam berkas invertibel
terkait.

<!-- upstream_entity: Schema/Lokal faktoriell/Picardgruppe und Divisorenklassengruppe/Fakt -->

### Teorema 22.10: grup kelas pembagi dan grup Picard {#br-bgk-2019-l22-thm-03}

Misalkan $X$ skema integral Noether yang faktorial lokal. Maka grup kelas
pembagi $X$ sama dengan grup Picard $X$.

#### Bukti {#br-bgk-2019-l22-thm-03-proof}

Pernyataan ini mengikuti dari Lema 20.6 dan Teorema 22.9.

<!-- upstream_entity: Glattes Schema/Picardgruppe und Divisorenklassengruppe/Fakt -->

### Korolari 22.11: kasus skema mulus {#br-bgk-2019-l22-cor-01}

Misalkan $X$ skema mulus di atas lapangan tertutup secara aljabar $K$. Maka
grup kelas pembagi $X$ sama dengan grup Picard $X$.

#### Bukti {#br-bgk-2019-l22-cor-01-proof}

Pada skema mulus, gelanggang-gelanggang lokalnya reguler menurut Teorema
18.16, dan gelanggang-gelanggang tersebut adalah domain faktorisasi tunggal
menurut Teorema 25.12 dari *Teori Singularitas (Osnabrück 2019)*. Karena
itu, pernyataan mengikuti dari Teorema 22.10.

<!-- upstream_entity: Projektiver Raum/Körper/Picardgruppe/Z/Fakt -->

### Teorema 22.12: grup Picard ruang projektif {#br-bgk-2019-l22-thm-04}

Grup Picard ruang projektif $\mathbb P_K^d$, dengan $d\geq 1$, di atas
lapangan $K$ adalah $\mathbb Z$. Berkas-berkas invertibel pada ruang
projektif direpresentasikan oleh berkas struktur terpilin

$$
\mathcal O_{\mathbb P_K^d}(\ell),
\qquad \ell\in\mathbb Z.
$$

#### Bukti {#br-bgk-2019-l22-thm-04-proof}

Pernyataan ini mengikuti dari Teorema 22.10 dan Contoh 22.8. Berdasarkan
korespondensi eksplisit dalam Teorema 22.9, negatif dari kelas hiperbidang
bersesuaian dengan bundel tautologis
$\mathcal O_{\mathbb P_K^d}(1)$.
