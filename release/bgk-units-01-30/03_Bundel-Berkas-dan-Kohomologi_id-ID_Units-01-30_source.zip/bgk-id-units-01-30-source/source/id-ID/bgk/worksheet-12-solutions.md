---
title: "Solusi Publik dan Cakupan Lembar Kerja 12"
stable_id: br-bgk-2019-w12-solutions
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
upstream_map: authority/wikiversity-bgk/unit-12/ORDERED_EXERCISE_MAP.json
upstream_map_sha256: 62678f3ece59348d362ed7bdf32726642957e6e977970fb276238ad2387e610a
authority_manifest: authority/wikiversity-bgk/unit-12/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 0e83f8718364e1d902dbe961cbf142cc7fb61e4ebfc7537f24488d508334e914
candidate_evidence: authority/wikiversity-bgk/unit-12/worksheet-solution-candidates-api.json
candidate_evidence_sha256: 70dbb446f6644d217cb0174353440857d7f8a5ffb9ae87407d3183a14851f502
solution_ex05_xml: authority/wikiversity-bgk/unit-12/solution-ex05.xml
solution_ex05_xml_sha256: 8454e0426944e6d14c5f339ce3b875751a04a1b4ca04aeae22ad7126adba336b
solution_ex05_html: authority/wikiversity-bgk/unit-12/solution-ex05.html
solution_ex05_html_sha256: b33965fd35360230a9361b0120bb0d17087296b7f68b12f6f78da30f674191ae
solution_ex05_upstream_pageid: 125458
solution_ex05_upstream_revid: 1090081
solution_ex05_mediawiki_sha1: 69678e5b8e9c6a32781db41971073d44112924b5
solution_ex05_frozen_revision_contributor: "Arbota"
solution_ex10_xml: authority/wikiversity-bgk/unit-12/solution-ex10.xml
solution_ex10_xml_sha256: 6ad56024ad635141265df8ceafed0dd744ec511a2ea08e3edc91415b6513c527
solution_ex10_html: authority/wikiversity-bgk/unit-12/solution-ex10.html
solution_ex10_html_sha256: 62cea581b91fc684fe2ddd1f2ba6197d4a7d87e4860a9dfa44e6546f05a16294
solution_ex10_upstream_pageid: 96565
solution_ex10_upstream_revid: 1095409
solution_ex10_mediawiki_sha1: bdcc1f4516848ddd7123f5bcd61aec649513f946
solution_ex10_frozen_revision_contributor: "Arbota"
exercise_count: 19
public_solution_count: 2
public_solution_numbers: "5, 10"
negative_public_solution_count: 17
negative_solution_numbers: "1-4, 6-9, 11-19"
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

```{=latex}
\clearpage
```

# Solusi Publik dan Cakupan Lembar Kerja 12 {#br-bgk-2019-w12-solutions}

Pada batas revisi yang dibekukan, sumber menyediakan tepat dua solusi publik
di antara 19 soal, yaitu solusi Soal 12.5 dan 12.10. Peta soal dan bukti
kandidat mencatat hasil negatif untuk Soal 12.1--12.4, 12.6--12.9, dan
12.11--12.19. Ketiadaan halaman solusi publik tidak diubah menjadi solusi
buatan.

## Solusi Soal 12.5 {#br-bgk-2019-w12-sol-ex05}

Kita pilih gelanggang polinomial

$$
K[X_1,X_2,X_3,X_4,X_5,Y_1,Y_2,Y_3,Y_4,Y_5]
$$

di atas sembarang lapangan dasar (atau, lebih umum, gelanggang dasar tak nol).
Pertimbangkan ideal

$$
\mathfrak a=
(X_1X_2X_3X_4X_5,
\ \text{semua monomial berderajat }2
\text{ kecuali }X_iX_j\text{ dengan }i\ne j)
$$

dan

$$
\mathfrak b=
(Y_1Y_2Y_3Y_4Y_5,
\ \text{semua monomial berderajat }2
\text{ kecuali }Y_iY_j\text{ dengan }i\ne j).
$$

Kedua kelompok variabel saling dipertukarkan. Untuk masing-masing ideal,
derajat maksimum suatu pembangkit adalah $5$, karena
$X_1X_2X_3X_4X_5$ (dan, secara simetris, hasil kali semua $Y_i$) tidak dapat
dinyatakan melalui monomial pembangkit lainnya.

Kita klaim bahwa ideal hasil kali dibangkitkan oleh monomial berderajat

$$
d=4.
$$

Karena simetri situasinya, hal ini mengikuti dari faktorisasi berikut, dengan
$Q$ setiap kali dipilih sebagai monomial hasil bagi yang sesuai:

$$
X_1\cdots X_5Y_1\cdots Y_5
=(X_1Y_1)(X_2Y_2)Q,
$$

$$
X_i^2Y_1\cdots Y_5
=(X_iY_1)(X_iY_2)Q,
$$

$$
X_iY_jY_1\cdots Y_5
=(Y_1Y_2)(X_iY_j)Q,
$$

dan


$$
Y_iY_jY_1\cdots Y_5
=(Y_i^2)(Y_j^2)Q.
$$

Setiap pasangan faktor di ruas kanan terdiri atas satu pembangkit dari
$\mathfrak a$ dan satu pembangkit dari $\mathfrak b$, keduanya berderajat
$2$. Jadi $\mathfrak a\mathfrak b$ mempunyai pembangkit berderajat paling
tinggi $4$, sedangkan $\mathfrak a$ dan $\mathfrak b$ sendiri memerlukan
pembangkit berderajat $5$.

## Solusi Soal 12.10 {#br-bgk-2019-w12-sol-ex10}

Kita harus mencari solusi tak trivial sistem persamaan linear

$$
6X-8Y+3Z=0,
$$

$$
2X+9Y-5Z=0.
$$

Dengan mengeliminasi $X$, kita memperoleh syarat

$$
-35Y+18Z=0.
$$

Ambil $Z=1$. Maka

$$
Y=\frac{18}{35}
$$

dan

$$
\begin{aligned}
X
&=-\frac92Y+\frac52Z\\
&=-\frac92\cdot\frac{18}{35}+\frac52\\
&=\frac{-162+175}{70}\\
&=\frac{13}{70}.
\end{aligned}
$$

Dengan demikian

$$
\left(\frac{13}{70},\frac{18}{35},1\right)
$$

merupakan titik potong kedua garis di bidang projektif.

## Hasil negatif yang dibekukan {#br-bgk-2019-w12-solutions-negative}

Tidak ada halaman solusi publik pada revisi yang dibekukan untuk Soal 12.1,
12.2, 12.3, 12.4, 12.6, 12.7, 12.8, 12.9, 12.11, 12.12, 12.13, 12.14,
12.15, 12.16, 12.17, 12.18, atau 12.19. Pernyataan ini adalah hasil
pemeriksaan kandidat, bukan klaim bahwa solusi matematis tidak ada.
