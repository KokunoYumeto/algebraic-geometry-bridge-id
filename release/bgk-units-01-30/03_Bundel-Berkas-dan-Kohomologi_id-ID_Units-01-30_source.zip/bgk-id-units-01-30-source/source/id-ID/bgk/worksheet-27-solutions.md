---
title: "Solusi Publik dan Cakupan Lembar Kerja 27"
stable_id: br-bgk-2019-w27-solutions
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
authority_manifest: authority/wikiversity-bgk/unit-27/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: b6c2a7687ee2fcc20e6f2b5f58f1f97a665a8c1f9201d11308bb84f62a79c089
authority_manifest_status: "Bekuan authority terminal lengkap; 30 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
media_credits: source/id-ID/media-credits-bgk-unit-27.md
media_credits_sha256: dc3afa2d1b2e7c78a604bb54965bc45e4c56058c7585341e927d0e8e4a03f406
rights_ledger: authority/RIGHTS-bgk-unit-27.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-27.json
asset_closure_sha256: 0eb449063c5dab73703a381246847c4deac31a20327bbe2a8a4c17b082e915ab
upstream_map: authority/wikiversity-bgk/unit-27/ORDERED_EXERCISE_MAP.json
upstream_map_sha256: 9f230b1a85e7ece54442b86ebc3bf7d70c9ea009c44485899be9f9f6dd834c6b
candidate_evidence: authority/wikiversity-bgk/unit-27/worksheet-solution-candidates-api.json
candidate_evidence_sha256: 1e185fdb272439e4375aa4ed3168e976720ba66b992bc3e3f32e4213ce24e88b
worksheet_api: authority/wikiversity-bgk/unit-27/worksheet-27-api.json
worksheet_api_sha256: 7bee8a343841d4205782ffb3dbae30a32bf3dfbc59aa97a5d4863f21cfb75ced
worksheet_upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 27"
worksheet_upstream_pageid: 110236
worksheet_upstream_revid: 1070033
worksheet_upstream_parentid: 619281
worksheet_upstream_timestamp: "2026-02-06T08:44:17Z"
worksheet_upstream_mediawiki_sha1: 7e45c57c5d18d8ea176bc77a7b140587dbcc3bc1
worksheet_upstream_mediawiki_sha1_base36: er01y624tyjw2fjvidqz69t7fxsccsh
worksheet_frozen_revision_contributor: "Arbota"
worksheet_url: "https://de.wikiversity.org/wiki/Kurs:B%C3%BCndel,_Garben_und_Kohomologie_(Osnabr%C3%BCck_2019-2020)/Arbeitsblatt_27"
worksheet_revision_url: "https://de.wikiversity.org/w/index.php?oldid=1070033"
selection_rule: "Setiap judul halaman soal yang tepat dari wikitext lembar kerja diperiksa pada judul resmi <soal>/Lösung yang tepat; bintang dan ketiadaan tautan bukan bukti."
exercise_count: 14
candidate_solution_count: 14
public_solution_count: 0
public_solution_numbers: ""
negative_public_solution_count: 14
negative_solution_numbers: "1-14"
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

```{=latex}
\clearpage
```

# Solusi Publik dan Cakupan Lembar Kerja 27 {#br-bgk-2019-w27-solutions}

Pada revisi lembar kerja yang dibekukan, sumber memuat tepat 14 soal dan tidak
menyediakan satu pun halaman solusi publik. Setiap kandidat diperiksa
berdasarkan judul halaman soal yang tepat dengan menambahkan akhiran
`/Lösung`. Bukti kandidat resmi menetapkan bahwa keempat belas halaman itu
tidak ada. Hasil ini tidak disimpulkan dari bintang ataupun dari ada atau
tidaknya tautan solusi pada lembar kerja.

## Kandidat resmi yang diperiksa {#br-bgk-2019-w27-solutions-candidates}

1. Soal 27.1

   - Halaman soal: `Polynomring/1/Nenneraufnahme an X/Cech-Kohomologie/Aufgabe`
   - Kandidat solusi: [`Polynomring/1/Nenneraufnahme an X/Cech-Kohomologie/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Polynomring/1/Nenneraufnahme_an_X/Cech-Kohomologie/Aufgabe/L%C3%B6sung)
   - Hasil resmi: halaman tidak ada.

2. Soal 27.2

   - Halaman soal: `Polynomring/2/Cech-Komplex/Monom/Aufgabe`
   - Kandidat solusi: [`Polynomring/2/Cech-Komplex/Monom/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Polynomring/2/Cech-Komplex/Monom/Aufgabe/L%C3%B6sung)
   - Hasil resmi: halaman tidak ada.

3. Soal 27.3

   - Halaman soal: `Polynomring/3/Cech-Komplex/Monom/1/Aufgabe`
   - Kandidat solusi: [`Polynomring/3/Cech-Komplex/Monom/1/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Polynomring/3/Cech-Komplex/Monom/1/Aufgabe/L%C3%B6sung)
   - Hasil resmi: halaman tidak ada.

4. Soal 27.4

   - Halaman soal: `Polynomring/3/Cech-Komplex/Monom/2/Aufgabe`
   - Kandidat solusi: [`Polynomring/3/Cech-Komplex/Monom/2/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Polynomring/3/Cech-Komplex/Monom/2/Aufgabe/L%C3%B6sung)
   - Hasil resmi: halaman tidak ada.

5. Soal 27.5

   - Halaman soal: `Polynomring/4/Cech-Komplex/Monom/Aufgabe`
   - Kandidat solusi: [`Polynomring/4/Cech-Komplex/Monom/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Polynomring/4/Cech-Komplex/Monom/Aufgabe/L%C3%B6sung)
   - Hasil resmi: halaman tidak ada.

6. Soal 27.6

   - Halaman soal: `Polynomring/Höchste lokale Kohomologie/Modulstruktur/Direkt/Aufgabe`
   - Kandidat solusi: [`Polynomring/Höchste lokale Kohomologie/Modulstruktur/Direkt/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Polynomring/H%C3%B6chste_lokale_Kohomologie/Modulstruktur/Direkt/Aufgabe/L%C3%B6sung)
   - Hasil resmi: halaman tidak ada.

7. Soal 27.7

   - Halaman soal: `Polynomring/Höchste lokale Kohomologie/K-Isomorphie zu Polynomring/Aufgabe`
   - Kandidat solusi: [`Polynomring/Höchste lokale Kohomologie/K-Isomorphie zu Polynomring/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Polynomring/H%C3%B6chste_lokale_Kohomologie/K-Isomorphie_zu_Polynomring/Aufgabe/L%C3%B6sung)
   - Hasil resmi: halaman tidak ada.

8. Soal 27.8

   - Halaman soal: `Polynomring/Höchste lokale Kohomologie/Fakultäten/K-Isomorphie zu Polynomring/Aufgabe`
   - Kandidat solusi: [`Polynomring/Höchste lokale Kohomologie/Fakultäten/K-Isomorphie zu Polynomring/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Polynomring/H%C3%B6chste_lokale_Kohomologie/Fakult%C3%A4ten/K-Isomorphie_zu_Polynomring/Aufgabe/L%C3%B6sung)
   - Hasil resmi: halaman tidak ada.

9. Soal 27.9

   - Halaman soal: `Polynomring/Höchste lokale Kohomologie/Differentialoperatoren/Isomorphe Situation/Aufgabe`
   - Kandidat solusi: [`Polynomring/Höchste lokale Kohomologie/Differentialoperatoren/Isomorphe Situation/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Polynomring/H%C3%B6chste_lokale_Kohomologie/Differentialoperatoren/Isomorphe_Situation/Aufgabe/L%C3%B6sung)
   - Hasil resmi: halaman tidak ada.

10. Soal 27.10

    - Halaman soal: `Projektive Ebene/Kurve/Getwistete Strukturgabe zu d-3/Globale Schnitte/Aufgabe`
    - Kandidat solusi: [`Projektive Ebene/Kurve/Getwistete Strukturgabe zu d-3/Globale Schnitte/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Projektive_Ebene/Kurve/Getwistete_Strukturgabe_zu_d-3/Globale_Schnitte/Aufgabe/L%C3%B6sung)
    - Hasil resmi: halaman tidak ada.

11. Soal 27.11

    - Halaman soal: `Projektive Gerade/Einheitengarbe/Cech-Komplex/Erste Kohomologie/Aufgabe`
    - Kandidat solusi: [`Projektive Gerade/Einheitengarbe/Cech-Komplex/Erste Kohomologie/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Projektive_Gerade/Einheitengarbe/Cech-Komplex/Erste_Kohomologie/Aufgabe/L%C3%B6sung)
    - Hasil resmi: halaman tidak ada.

12. Soal 27.12

    - Halaman soal: `Projektive Ebene/Einheitengarbe/Cech-Komplex/Erste Kohomologie/Aufgabe`
    - Kandidat solusi: [`Projektive Ebene/Einheitengarbe/Cech-Komplex/Erste Kohomologie/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Projektive_Ebene/Einheitengarbe/Cech-Komplex/Erste_Kohomologie/Aufgabe/L%C3%B6sung)
    - Hasil resmi: halaman tidak ada.

13. Soal 27.13

    - Halaman soal: `Modultheorie/Exakte Komplexe/Kurze exakte Sequenzen/Aufgabe`
    - Kandidat solusi: [`Modultheorie/Exakte Komplexe/Kurze exakte Sequenzen/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Modultheorie/Exakte_Komplexe/Kurze_exakte_Sequenzen/Aufgabe/L%C3%B6sung)
    - Hasil resmi: halaman tidak ada.

14. Soal 27.14

    - Halaman soal: `Projektiver Raum/Getwistete Strukturgarben/Euler-Charakteristik/Aufgabe`
    - Kandidat solusi: [`Projektiver Raum/Getwistete Strukturgarben/Euler-Charakteristik/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Projektiver_Raum/Getwistete_Strukturgarben/Euler-Charakteristik/Aufgabe/L%C3%B6sung)
    - Hasil resmi: halaman tidak ada.

## Hasil negatif yang dibekukan {#br-bgk-2019-w27-solutions-negative}

Tidak ada halaman solusi publik pada revisi yang dibekukan untuk Soal 27.1
sampai 27.14. Karena itu, tidak ada teks solusi sumber yang dapat diterjemahkan.
Pernyataan ini adalah hasil pemeriksaan setiap kandidat resmi, bukan klaim
bahwa solusi matematis tidak ada.
