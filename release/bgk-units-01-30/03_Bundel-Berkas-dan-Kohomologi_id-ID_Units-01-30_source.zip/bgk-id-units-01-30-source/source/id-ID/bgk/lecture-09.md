---
title: "Kuliah 9 - Skema Afin"
stable_id: br-bgk-2019-l09
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 9"
upstream_pageid: 109013
upstream_revid: 793634
upstream_timestamp: "2022-08-25T06:26:48Z"
upstream_mediawiki_sha1: e8ee1bb24612aeb7a7b059301e772f069cfa487b
source_url: "https://de.wikiversity.org/w/index.php?oldid=793634"
authority_manifest: authority/wikiversity-bgk/unit-09/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 553255a52a560f0c4e14cf761409077d2b6788f2f8c9ace3e65b52743bfa3254
lecture_xml: authority/wikiversity-bgk/unit-09/lecture-09.xml
lecture_xml_sha256: 0efcc67ed9799e4941d199ac7f4fbab2d8b80334600b1c12f6c1437025d52fc2
lecture_expanded_tex: authority/wikiversity-bgk/unit-09/lecture-09-expanded.tex
lecture_expanded_tex_sha256: 96e87e8b5a9d845a14e47d2b6c1941cf349cad0c35f417f3979d255a9214c656
official_pdf: authority/artifacts/bgk-lecture-09-official.pdf
official_pdf_sha256: 83f58ee5ec71549c5fb5c2ccb7e119bd697ac3e3e04ca6f6c88f2ae0b379cc14
media_credits: source/id-ID/media-credits-bgk-unit-09.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 9: Skema Afin {#br-bgk-2019-l09}

Misalkan

$$
X=\operatorname{Spek}(R)
$$

adalah spektrum suatu gelanggang komutatif $R$, dilengkapi dengan topologi
Zariski. Jika $R$ adalah lapangan, spektrumnya hanya terdiri atas satu titik,
yaitu ideal nol, yang sekaligus merupakan ideal maksimal. Dalam arti ini,
spektrum saja memuat sangat sedikit informasi. Jadi funktor kontravarian

$$
\begin{aligned}
\{\text{gelanggang komutatif}\}&\longrightarrow
\{\text{ruang topologis}\},\\
R&\longmapsto\operatorname{Spek}(R)
\end{aligned}
$$

kehilangan informasi. Kita akan memperkaya spektrum dengan struktur tambahan
agar gelanggang asal dapat direkonstruksi darinya. Untuk itu, kita
mendefinisikan suatu berkas struktur pada spektrum. Spektrum bersama berkas
struktur tersebut merupakan geometrisasi gelanggang yang bermakna, yakni
sebuah ruang berdering.

> **Catatan edisi — dua salah ketik pada pengantar sumber.** Sumber menulis
> padanan `dass Spektrum` dan `zusätztlichen`. Terjemahan menormalkan keduanya
> menjadi “spektrum” dan “tambahan”; tidak ada isi matematis yang diubah.

## Berkas struktur pada spektrum {#br-bgk-2019-l09-s01}

<!-- upstream_entity: Spektrum/Prägarbe/Beispiel -->

### Contoh 9.1: praberkas pelokalan {#br-bgk-2019-l09-exa-01}

Misalkan $X=\operatorname{Spek}(R)$ adalah spektrum gelanggang komutatif
$R$. Pada $X$ kita mendefinisikan suatu praberkas gelanggang komutatif dengan
menetapkan, untuk setiap himpunan terbuka $U\subseteq X$,

$$
\mathcal P(U):=\operatorname*{colim}_{U\subseteq D(f)}R_f,
$$

dengan homomorfisme gelanggang alami

$$
R_f\longrightarrow R_g
$$

untuk

$$
U\subseteq D(g)\subseteq D(f).
$$

Bersama homomorfisme-homomorfisme alami tersebut, penetapan ini merupakan
sebuah praberkas. Berlaku

$$
\mathcal P(D(f))=R_f,
\qquad
\mathcal P(X)=R.
$$

Pada kesamaan kedua, sistem terarah mempunyai objek terminal
$X=D(1)$, sehingga gelanggang yang diperoleh adalah $R_1=R$.

> **Catatan edisi — objek terminal pada sumber.** Sumber menulis objek terminal
> sebagai `D(f)` ketika menyimpulkan $\mathcal P(X)=R$. Di sini objek akhirnya
> ditulis eksplisit sebagai $X=D(1)$; konstruksi kolimit tidak diubah.

Tangkai praberkas ini di titik $\mathfrak p\in X$ adalah

$$
\begin{aligned}
\operatorname*{colim}_{\mathfrak p\in U}\mathcal P(U)
&=\operatorname*{colim}_{\mathfrak p\in D(f)}\mathcal P(D(f))\\
&=\operatorname*{colim}_{f\notin\mathfrak p}R_f\\
&=R_{\mathfrak p}.
\end{aligned}
$$

Praberkas ini bukan berkas. Berkasisasinya adalah berkas struktur pada
spektrum.

<!-- upstream_entity: Affines Schema/Spektrum/Strukturgarbe/Definition -->

### Definisi 9.2: berkas struktur {#br-bgk-2019-l09-def-01}

Misalkan $X=\operatorname{Spek}(R)$ adalah spektrum suatu gelanggang
komutatif $R$. *Berkas struktur* pada $X$ adalah penetapan yang kepada setiap
himpunan terbuka $U\subseteq X$ memasangkan gelanggang komutatif

$$
\Gamma(U,\mathcal O_X)
=\left\{
(s_{\mathfrak p})_{\mathfrak p\in U}
\in\prod_{\mathfrak p\in U}R_{\mathfrak p}
\ \middle|\
\begin{array}{l}
\text{untuk setiap }\mathfrak p\in U\text{ ada }a,b\in R\text{ dengan}\\
\mathfrak p\in D(b)\subseteq U\text{ dan }
s_{\mathfrak q}=\dfrac{a}{b}\text{ di }R_{\mathfrak q}\\
\text{untuk semua }\mathfrak q\in D(b)
\end{array}
\right\}.
$$

Untuk setiap inklusi $U\subseteq U'$, homomorfisme restriksinya adalah
proyeksi alami dari keluarga yang diindeks oleh $U'$ ke keluarga yang
diindeks oleh $U$.

<!-- upstream_entity: Spektrum/Strukturgarbe/Garbe/Fakt -->

### Lema 9.3: berkas struktur memang suatu berkas {#br-bgk-2019-l09-lem-01}

Berkas struktur $\mathcal O_X$ pada spektrum
$X=\operatorname{Spek}(R)$ suatu gelanggang komutatif $R$ adalah berkas
gelanggang komutatif.

#### Bukti {#br-bgk-2019-l09-lem-01-proof}

Definisi di atas tepat merupakan berkasisasi praberkas pada Contoh 9.1.
Satu-satunya perbedaan penyajian ialah bahwa syarat kompatibilitas dirumuskan
dengan lingkungan basis $D(b)$, bukan dengan lingkungan terbuka sebarang.

<!-- upstream_entity: Spektrum/Strukturgarbe/Definition -->

### Definisi 9.4: skema afin {#br-bgk-2019-l09-def-02}

Spektrum

$$
X=\operatorname{Spek}(R)
$$

suatu gelanggang komutatif $R$, bersama berkas strukturnya $\mathcal O_X$,
disebut *skema afin* yang terkait dengan $R$.

Suatu unsur

$$
q\in\Gamma(U,\mathcal O_X)
$$

disebut fungsi aljabar yang terdefinisi pada $U$. Istilah *fungsi rasional*
atau *fungsi reguler* juga digunakan dalam konteks ini.

## Seksi sebagai fungsi lokal {#br-bgk-2019-l09-s02}

<!-- upstream_entity: Integritätsbereich/Spektrum/Strukturgarbe direkt/Bemerkung -->

### Catatan 9.5: kasus domain integral {#br-bgk-2019-l09-rem-01}

Jika $R$ adalah domain integral, berkas struktur mempunyai deskripsi yang
sangat sederhana. Untuk himpunan terbuka $U\subseteq X$,

$$
\Gamma(U,\mathcal O_X)
=\bigcap_{\mathfrak p\in U}R_{\mathfrak p},
$$

dengan irisan diambil di dalam lapangan pecahan $Q(R)$, tempat semua
pelokalan $R_{\mathfrak p}$ merupakan subgelanggang. Jadi fungsi-fungsi pada
$U$ tepat merupakan unsur-unsur rasional dalam $Q(R)$ yang terdefinisi di
setiap titik $U$. Menurut Lema 12.4 pada kursus Aljabar Komutatif,

$$
\Gamma(X,\mathcal O_X)
=\bigcap_{\mathfrak p\in X}R_{\mathfrak p}
=R.
$$

Demikian pula,

$$
\Gamma(D(f),\mathcal O_X)
=\bigcap_{\mathfrak p\in D(f)}R_{\mathfrak p}
=R_f.
$$

Jika terdapat penutup terbuka

$$
U=\bigcup_{i\in I}D(f_i),
$$

maka

$$
\Gamma(U,\mathcal O_X)
=\bigcap_{\mathfrak p\in U}R_{\mathfrak p}
=\bigcap_{i\in I}\left(
\bigcap_{\mathfrak p\in D(f_i)}R_{\mathfrak p}
\right)
=\bigcap_{i\in I}R_{f_i}.
$$

> **Catatan edisi — nomor silang antarsaksi.** Saksi semantik yang dibekukan
> merujuk ke Lema 12.4 pada Aljabar Komutatif, sedangkan PDF terminal lama
> mencetak Lema 16.4. Edisi mengikuti revisi semantik yang menjadi authority
> dan mencatat perbedaan itu tanpa menyatukan kedua saksi.

<!-- upstream_entity: Achsenkreuz/Punktiert/Globale Funktion/Beispiel -->

### Contoh 9.6: fungsi pada dua garis tertusuk {#br-bgk-2019-l09-exa-02}

Pertimbangkan

$$
R=K[X,Y]/(XY)
$$

di atas suatu lapangan $K$. Pada himpunan terbuka

$$
U=D(X,Y)=D(X)\cup D(Y)
=\operatorname{Spec}(R)\setminus\{(X,Y)\},
$$

fungsi yang bernilai $0$ pada garis tertusuk

$$
V(X)\cap U=D(Y)
$$

dan bernilai $1$ pada garis tertusuk

$$
V(Y)\cap U=D(X)
$$

adalah fungsi aljabar. Penetapan ini memberikan suatu
$s_{\mathfrak p}\in R_{\mathfrak p}$ untuk setiap ideal prima
$\mathfrak p\in U$. Jika

$$
\mathfrak p\in V(X)\cap U=D(Y),
$$

maka representasi pecahannya adalah

$$
0=\frac{0}{Y};
$$

sedangkan jika

$$
\mathfrak p\in V(Y)\cap U=D(X),
$$

representasinya adalah

$$
1=\frac{X}{X}.
$$

Sumber beralih dari operator $\operatorname{Spek}$ ke
$\operatorname{Spec}$ pada tampilan ini; kedua bentuk tersebut dipertahankan
sebagai notasi sumber untuk spektrum gelanggang.

<!-- upstream_entity: Integritätsbereich/Affines Schema/Rationale Funktion/Nennerideal/Bemerkung -->

### Catatan 9.7: ideal penyebut {#br-bgk-2019-l09-rem-02}

Misalkan $R$ domain integral dengan lapangan pecahan $Q(R)$ dan
$q\in Q(R)$ suatu fungsi rasional. Ada himpunan terbuka terbesar
$U\subseteq\operatorname{Spek}(R)$ tempat $q$ terdefinisi. Himpunan ini
adalah

$$
U=D(\mathfrak a),
$$

dengan *ideal penyebut*

$$
\mathfrak a=\{r\in R\mid rq\in R\}.
$$

Jika $q\in R_{\mathfrak p}$, maka

$$
q=\frac{s}{r}
$$

dengan $r\notin\mathfrak p$. Karena $r$ termasuk ideal penyebut, kita
mendapatkan $\mathfrak p\in D(\mathfrak a)$. Membaca argumen ini secara
terbalik memberi implikasi sebaliknya. Secara khusus, $D(f)$ adalah lokus
definisi terbesar untuk $1/f$.

<!-- upstream_entity: Spektrum/Faktorieller Bereich/Prägarbe/Strukturgarbe/Fakt -->

### Teorema 9.8: domain faktorisasi tunggal {#br-bgk-2019-l09-thm-01}

Misalkan $R$ domain faktorisasi tunggal. Maka, untuk himpunan terbuka
$U\subseteq\operatorname{Spek}(R)$, penetapan

$$
U\longmapsto\operatorname*{colim}_{U\subseteq D(f)}R_f
$$

sama dengan berkas struktur pada $\operatorname{Spek}(R)$.

#### Bukti {#br-bgk-2019-l09-thm-01-proof}

Penetapan tersebut adalah praberkas gelanggang komutatif yang berkasisasinya
sama dengan berkas struktur. Jadi cukup dibuktikan bahwa, dalam kasus
faktorial, praberkas itu sendiri sudah merupakan berkas.

Ambil unsur tak nol

$$
q\in\Gamma(U,\mathcal O_X)\subseteq Q(R).
$$

Karena $R$ faktorial, ada representasi tereduksi

$$
q=\frac{a}{f}.
$$

Kita klaim $U\subseteq D(f)$. Ambil $\mathfrak p\in U$. Karena $q$
terdefinisi pada $U$, menurut Catatan 9.5 ada representasi

$$
q=\frac{b}{g}=\frac{a}{f}
$$

dengan $g\notin\mathfrak p$. Jadi

$$
fb=ag
$$

di $R$. Setiap faktor prima $f$ membagi $ag$ tetapi tidak membagi $a$;
karena itu faktor tersebut harus membagi $g$. Maka radikal $(f)$ memuat
radikal $(g)$ dan

$$
\mathfrak p\in D(g)\subseteq D(f).
$$

Jadi seksi $q$ sudah berasal dari $R_f$ pada suatu himpunan terbuka utama
yang memuat $U$, sebagaimana disyaratkan.

Pernyataan ini khususnya berlaku untuk gelanggang polinomial, dan karena itu
untuk ruang afin.

<!-- upstream_entity: Standardquadrik/Globale Funktion/Beispiel -->

### Contoh 9.9: seksi yang baru muncul setelah berkasisasi {#br-bgk-2019-l09-exa-03}

Pertimbangkan domain integral

$$
R=K[X,Y,Z,W]/(WX-ZY)
$$

di atas suatu lapangan $K$, dan tetapkan

$$
U:=D(X,Y)\subseteq\operatorname{Spek}(R).
$$

Menurut Catatan 9.5,

$$
q=\frac{Z}{X}=\frac{W}{Y}
$$

adalah fungsi aljabar yang terdefinisi pada $U$, sehingga
$q\in\Gamma(U,\mathcal O_X)$. Namun, selain satuan, tidak ada unsur
$f\in R$ dengan

$$
(X,Y)\subseteq(f),
$$

karena $X$ dan $Y$ irreduksibel. Karena itu $q$ bukan seksi praberkas pada
Contoh 9.1 di atas $U$, tetapi merupakan seksi berkasisasinya.

> **Catatan edisi — simbol terbuka pada sumber.** Sumber memperkenalkan
> $D(X,Y)$ sebagai himpunan terbuka, lalu memakai simbol $U$ tanpa menetapkan
> kesamaannya. Edisi menulis $U:=D(X,Y)$ secara eksplisit; tidak ada objek
> matematis baru yang ditambahkan.

## Sifat lokal dan himpunan terbuka utama {#br-bgk-2019-l09-s03}

<!-- upstream_entity: Affines Schema/Punkt/Halm/Lokalisierung/Fakt -->

### Lema 9.10: tangkai adalah pelokalan {#br-bgk-2019-l09-lem-02}

Misalkan $(X,\mathcal O_X)$ adalah skema afin yang terkait dengan gelanggang
komutatif $R$, dan misalkan $x\in X$ adalah titik yang bersesuaian dengan
ideal prima $\mathfrak p$. Maka tangkai berkas struktur adalah

$$
\mathcal O_x=R_{\mathfrak p}.
$$

#### Bukti {#br-bgk-2019-l09-lem-02-proof}

Pernyataan ini mengikuti dari Contoh 9.1 dan Lema 5.2(2).

<!-- upstream_entity: Affines Schema/Lokal beringt/Fakt -->

### Korolari 9.11: skema afin berdering lokal {#br-bgk-2019-l09-cor-01}

Setiap skema afin adalah ruang berdering lokal.

#### Bukti {#br-bgk-2019-l09-cor-01-proof}

Ini langsung mengikuti dari Lema 9.10 dan Teorema 12.3 pada kursus Aljabar
Komutatif.

> **Catatan edisi — nomor silang antarsaksi.** Saksi semantik merujuk ke
> Teorema 12.3 pada Aljabar Komutatif, sedangkan PDF terminal lama mencetak
> Teorema 16.3. Seperti pada Catatan 9.5, edisi mengikuti authority semantik.

<!-- upstream_entity: Affines Schema/Hauptmenge/Nenneraufnahme/Fakt -->

### Lema 9.12: seksi pada himpunan terbuka utama {#br-bgk-2019-l09-lem-03}

Misalkan $(X,\mathcal O_X)$ adalah skema afin yang terkait dengan gelanggang
komutatif $R$, dan misalkan $f\in R$. Maka

$$
\Gamma(D(f),\mathcal O_X)=R_f.
$$

Secara khusus,

$$
\Gamma(X,\mathcal O_X)=R.
$$

#### Bukti {#br-bgk-2019-l09-lem-03-proof}

Kita terlebih dahulu membuktikan kasus khusus $X$. Ada homomorfisme
gelanggang alami

$$
R\longrightarrow\Gamma(X,\mathcal O_X).
$$

Homomorfisme ini injektif karena nolnya suatu unsur dapat diuji secara lokal;
bandingkan Lema Lampiran 1.1. Untuk membuktikan surjektivitas, ambil
$q\in\Gamma(X,\mathcal O_X)$. Ada penutup terbuka

$$
X=\bigcup_{i\in I}U_i=\bigcup_{i\in I}D(f_i)
$$

dan unsur-unsur

$$
q_i=\frac{a_i}{f_i^{k_i}}
$$

yang, sebagai seksi pada

$$
D(f_i)\cap D(f_j)=D(f_if_j),
$$

berimpit sebagai unsur $R_{f_if_j}$. Menurut Korolari 8.6, kita dapat
menganggap $I$ berhingga. Kita juga dapat mengganti semua $k_i$ dengan nilai
maksimumnya $k$; tentu saja pembilang lokal $a_i$ ikut berubah.

Kompatibilitas

$$
\frac{a_i}{f_i^k}=\frac{a_j}{f_j^k}
$$

berarti bahwa terdapat persamaan

$$
(f_if_j)^m a_i f_j^k=(f_if_j)^m a_j f_i^k
$$

di $R$, dengan $m$ dipilih sebagai maksimum yang berlaku untuk semua
pasangan. Menurut Proposisi 8.4(2),(4), unsur-unsur $f_i$, $i\in I$,
membangkitkan ideal satuan. Hal yang sama berlaku bagi
$f_i^{m+k}$, sehingga ada $g_i\in R$ dengan

$$
1=\sum_{i\in I}g_if_i^{m+k}.
$$

Tetapkan

$$
a:=\sum_{i\in I}g_ia_if_i^m.
$$

Maka

$$
\begin{aligned}
af_j^{m+k}
&=\left(\sum_{i\in I}g_ia_if_i^m\right)f_j^{m+k}\\
&=\sum_{i\in I}g_i(f_if_j)^m a_i f_j^k\\
&=\sum_{i\in I}g_i(f_if_j)^m a_j f_i^k\\
&=a_jf_j^m\left(\sum_{i\in I}g_if_i^{m+k}\right)\\
&=a_jf_j^m.
\end{aligned}
$$

Dengan demikian

$$
a=\frac{a_j}{f_j^k}=q_j
$$

di $R_{f_j}$. Jadi seksi tersebut direpresentasikan oleh satu unsur
gelanggang $a\in R$.

Situasi pada $D(f)$ adalah kasus yang sama setelah $R_f$ dipakai sebagai
gelanggang baru. Karena itu $\Gamma(D(f),\mathcal O_X)=R_f$.

<!-- upstream_entity: Affines Schema/Hauptmenge/Affin/Fakt -->

### Lema 9.13: himpunan terbuka utama adalah skema afin {#br-bgk-2019-l09-lem-04}

Misalkan $(X,\mathcal O_X)$ adalah skema afin yang terkait dengan gelanggang
komutatif $R$, dan misalkan $f\in R$. Maka, melalui pemetaan spektrum
kanonik,

$$
D(f)=\operatorname{Spec}(R_f)
$$

sebagai ruang berdering.

#### Bukti {#br-bgk-2019-l09-lem-04-proof}

Menurut Proposisi 8.11(3), homomorfisme gelanggang kanonik

$$
R\longrightarrow R_f
$$

menginduksi pembenaman terbuka

$$
\operatorname{Spek}(R_f)longrightarrow
D(f)\subseteq\operatorname{Spek}(R).
$$

Menurut Lema 9.12, gelanggang seksi di kedua sisi adalah $R_f$. Pernyataan
yang sama berlaku pada setiap himpunan terbuka $D(g)\subseteq D(f)$.
Dengan demikian berkas struktur di kedua sisi teridentifikasi, sehingga
diperoleh isomorfisme ruang berdering.

> **Catatan edisi — kesamaan melalui identifikasi kanonik.** Pernyataan sumber
> menulis $D(f)=\operatorname{Spec}(R_f)$, sedangkan buktinya membangun
> pembenaman terbuka dan isomorfisme ruang berdering. Edisi mempertahankan
> tampilan sumber serta menyatakan secara eksplisit bahwa kesamaan itu memakai
> identifikasi kanonik. Pergantian `Spek`/`Spec` juga dipertahankan.
