---
title: "Lembar Kerja 13 - Pemetaan Kerucut, Berkas Modul, dan Berkas Invertibel"
stable_id: br-bgk-2019-w13
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 13"
upstream_pageid: 110220
upstream_revid: 1003881
upstream_timestamp: "2025-06-10T09:35:07Z"
upstream_mediawiki_sha1: aaf88e277115448a7cfc6398010a8083696cbd70
source_url: "https://de.wikiversity.org/w/index.php?oldid=1003881"
authority_manifest: authority/wikiversity-bgk/unit-13/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 792935b01daf0a2ee22decd78d3f9ccb8d95719c628cdd306b66405ea1427282
worksheet_xml: authority/wikiversity-bgk/unit-13/worksheet-13.xml
worksheet_xml_sha256: 2e8528baca276e3669a92a38fff9e097dbe5954d3bf133e5657fea90865fb3fa
worksheet_expanded_tex: authority/wikiversity-bgk/unit-13/worksheet-13-expanded.tex
worksheet_expanded_tex_sha256: 6b6e308777adf2c2f3791cdde6581b45b7da8d4e3431ab3eee6bcf52608e1b6e
official_pdf: authority/artifacts/bgk-worksheet-13-official.pdf
official_pdf_sha256: da5afab54c1ae5035074d5254b3d91a980c436609e83961705ec55701fe0cecb
ordered_exercise_map: authority/wikiversity-bgk/unit-13/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: e62a98e5f5e0ac45138bce8ba904a90e869332d0e6321811fc06b6126b2dfcf1
exercise_count: 23
public_solution_count: 0
public_solution_numbers: ""
media_credits: source/id-ID/media-credits-bgk-unit-13.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 13: Pemetaan Kerucut, Berkas Modul, dan Berkas Invertibel {#br-bgk-2019-w13}

Sumber yang dibekukan tidak menandai satu pun soal dengan bintang. Secara
terpisah, bukti kandidat yang dibekukan mencatat hasil negatif untuk seluruh
23 soal. Edisi ini tidak menciptakan solusi baru.

<!-- upstream_entity: Projektiver Raum/Kegelabbildung/Ist nicht abgeschlossen/Aufgabe -->

## Soal 13.1 {#br-bgk-2019-w13-ex01}

Berikan sebuah contoh yang menunjukkan bahwa pemetaan kerucut

$$
\mathbb A_K^{n+1}\setminus\{0\}\longrightarrow\mathbb P_K^n
$$

tidak harus merupakan pemetaan tertutup.

<!-- upstream_entity: Graduierter Ring/Primideal/Homogenisierung/Aufgabe -->

## Soal 13.2 {#br-bgk-2019-w13-ex02}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$ dan $\mathfrak p$ ideal prima
dalam $R$. Buktikan bahwa homogenisasi $\mathfrak p^h$ juga merupakan ideal
prima.

<!-- upstream_entity: Kegelabbildung/Schema/Affiner Raum/Abgeschlossene Teilmenge/Aufgabe -->

## Soal 13.3 {#br-bgk-2019-w13-ex03}

Misalkan $K$ lapangan dan

$$
R=K[X_0,X_1,\ldots,X_n]/\mathfrak a
$$

suatu aljabar $K$ bergradasi standar. Buktikan bahwa diagram

$$
\begin{matrix}
\operatorname{Spek}(R)\supseteq D(R_+)
&\longrightarrow&
V(\mathfrak a)\cap D(X_0,X_1,\ldots,X_n)
&\longrightarrow&
\mathbb A_K^{n+1}\supseteq D(X_0,X_1,\ldots,X_n)
\\
\downarrow&&\downarrow&&\downarrow
\\
\operatorname{Proj}(R)
&\longrightarrow&
V_+(\mathfrak a)
&\longrightarrow&
\mathbb P_K^n
\end{matrix}
$$

yang terdiri atas morfisme skema bersifat komutatif. Di sini pemetaan vertikal
di kiri dan kanan adalah pemetaan kerucut, sedangkan pemetaan horizontal
adalah isomorfisme dan pembenaman tertutup alami.

<!-- upstream_entity: Kegelabbildung/C/Hopf-Faserung/Aufgabe -->

## Soal 13.4 {#br-bgk-2019-w13-ex04}

Bahas hubungan antara pemetaan kerucut

$$
\mathbb A_{\mathbb C}^{2}
\supset \mathbb A_{\mathbb C}^{2}\setminus\{(0,0)\}
\longrightarrow\mathbb P_{\mathbb C}^{1}
$$

dan fibrasi Hopf

$$
S^3\longrightarrow S^2.
$$

<!-- upstream_entity: Beringter Raum/Modul/Halm/Aufgabe -->

## Soal 13.5 {#br-bgk-2019-w13-ex05}

Misalkan $\mathcal F$ suatu $\mathcal O_X$-modul pada ruang berdering
$(X,\mathcal O_X)$. Buktikan bahwa untuk setiap titik $P\in X$, tangkai
$\mathcal F_P$ merupakan $\mathcal O_{X,P}$-modul.

<!-- upstream_entity: Beringter Raum/Modul/Direkte Summe/Aufgabe -->

## Soal 13.6 {#br-bgk-2019-w13-ex06}

Misalkan $\mathcal F$ dan $\mathcal G$ adalah $\mathcal O_X$-modul pada ruang
berdering $(X,\mathcal O_X)$. Buktikan bahwa jumlah langsung

$$
\mathcal F\oplus\mathcal G
$$

juga merupakan $\mathcal O_X$-modul.

<!-- upstream_entity: Beringter Raum/Modul/Untermodul/Restklassenmodul/Aufgabe -->

## Soal 13.7 {#br-bgk-2019-w13-ex07}

Misalkan $\mathcal F$ suatu $\mathcal O_X$-modul pada ruang berdering
$(X,\mathcal O_X)$ dan

$$
\mathcal G\subseteq\mathcal F
$$

suatu $\mathcal O_X$-submodul. Buktikan bahwa berkas hasil bagi

$$
\mathcal F/\mathcal G
$$

secara alami merupakan $\mathcal O_X$-modul.

<!-- upstream_entity: Beringter Raum/Strukturgarbe/Festlegungssatz/Einheit und Isomorphismus/Aufgabe -->

## Soal 13.8 {#br-bgk-2019-w13-ex08}

Misalkan $(X,\mathcal O_X)$ ruang berdering. Buktikan bahwa

$$
s\in\Gamma(X,\mathcal O_X)
$$

merupakan satuan jika dan hanya jika homomorfisme $\mathcal O_X$-modul yang
terkait

$$
\mathcal O_X\longrightarrow\mathcal O_X
$$

merupakan isomorfisme.

<!-- upstream_entity: Beringter Raum/Freie Garbe/Strukturgarbe/Festlegungssatz/Surjektiv/Aufgabe -->

## Soal 13.9 {#br-bgk-2019-w13-ex09}

Misalkan $(X,\mathcal O_X)$ ruang berdering. Misalkan

$$
s_1,\ldots,s_n\in\Gamma(X,\mathcal O_X)
$$

seksi-seksi global yang membangkitkan ideal satuan dalam
$\Gamma(X,\mathcal O_X)$. Buktikan bahwa homomorfisme
$\mathcal O_X$-modul yang terkait,

$$
\begin{aligned}
\mathcal O_X^n&\longrightarrow\mathcal O_X,\\
e_i&\longmapsto s_i,
\end{aligned}
$$

bersifat surjektif.

Kebalikan pernyataan di atas tidak berlaku; lihat Soal 14.10.

<!-- upstream_entity: Beringter Raum/Freier Modul/Festlegungssatz/Determinante/Isomorphismus/Aufgabe -->

## Soal 13.10 {#br-bgk-2019-w13-ex10}

Misalkan $(X,\mathcal O_X)$ ruang berdering. Misalkan

$$
s_1,\ldots,s_n\in\Gamma(X,\mathcal O_X)^n
$$

seksi-seksi global dengan

$$
s_i=(s_{i1},\ldots,s_{in}).
$$

Buktikan bahwa determinan matriks

$$
(s_{ij})_{1\leq i,j\leq n}
$$

merupakan satuan dalam $\Gamma(X,\mathcal O_X)$ jika dan hanya jika
homomorfisme $\mathcal O_X$-modul yang terkait,

$$
\begin{aligned}
\mathcal O_X^n&\longrightarrow\mathcal O_X^n,\\
e_i&\longmapsto s_i,
\end{aligned}
$$

merupakan isomorfisme.

<!-- upstream_entity: Beringter Raum/Modulgarben/Homomorphismenmodulgarbe/Lokaler Homomorphietest/Aufgabe -->

## Soal 13.11 {#br-bgk-2019-w13-ex11}

Misalkan $(X,\mathcal O_X)$ ruang berdering, $\mathcal M$ dan $\mathcal N$
berkas modul pada $X$, serta

$$
\varphi:\mathcal M\longrightarrow\mathcal N
$$

suatu morfisme berkas. Misalkan pula

$$
X=\bigcup_{i\in I}U_i
$$

suatu penutup terbuka. Buktikan pernyataan-pernyataan berikut.

1. Jika untuk setiap $i$ pemetaan

   $$
   \varphi_{U_i}:\Gamma(U_i,\mathcal M)
   \longrightarrow\Gamma(U_i,\mathcal N)
   $$

   kompatibel dengan penjumlahan, maka hal yang sama berlaku bagi

   $$
   \varphi_X:\Gamma(X,\mathcal M)\longrightarrow\Gamma(X,\mathcal N).
   $$

2. Jika untuk setiap $i$ pemetaan

   $$
   \varphi_{U_i}:\Gamma(U_i,\mathcal M)
   \longrightarrow\Gamma(U_i,\mathcal N)
   $$

   kompatibel dengan perkalian skalar oleh $\Gamma(U_i,\mathcal O_X)$, maka
   hal yang sama berlaku bagi $\varphi_X$.

3. Jika untuk setiap $i$ pemetaan

   $$
   \varphi|_{U_i}:\mathcal M|_{U_i}\longrightarrow\mathcal N|_{U_i}
   $$

   merupakan homomorfisme
   $\mathcal O_X|_{U_i}$-modul, maka $\varphi$ juga merupakan homomorfisme
   $\mathcal O_X$-modul.

<!-- upstream_entity: Beringter Raum/Modulgarbe/Bidual/Aufgabe -->

## Soal 13.12 {#br-bgk-2019-w13-ex12}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal F$ suatu berkas
modul pada $X$. Buktikan bahwa terdapat homomorfisme
$\mathcal O_X$-modul alami

$$
\mathcal F\longrightarrow\mathcal F^{**}.
$$

<!-- upstream_entity: Beringter Raum/Modulgarben/Tensorprodukt/Prägarbe/Halm/Aufgabe -->

## Soal 13.13 {#br-bgk-2019-w13-ex13}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal F,\mathcal G$
berkas modul pada $X$. Buktikan bahwa tangkai di titik $P\in X$ dari
praberkas

$$
U\longmapsto
\Gamma(U,\mathcal F)
\otimes_{\Gamma(U,\mathcal O_X)}
\Gamma(U,\mathcal G)
$$

sama dengan

$$
\begin{aligned}
&\operatorname{colim}_{
  \Gamma(U,\mathcal F)\otimes_{\Gamma(U,\mathcal O_X)}
  \Gamma(U,\mathcal G)}\,P\in U
\\
&\qquad=
\left(\operatorname{colim}_{\Gamma(U,\mathcal F)}\,P\in U\right)
\otimes_{
  \left(\operatorname{colim}_{\Gamma(U,\mathcal O_X)}\,P\in U\right)}
\left(\operatorname{colim}_{\Gamma(U,\mathcal G)}\,P\in U\right)
\\
&\qquad=\mathcal F_P\otimes_{\mathcal O_{X,P}}\mathcal G_P.
\end{aligned}
$$

<!-- upstream_entity: Beringter Raum/Modulgarbe/Duale Garbe/Tensorierung/Auswertung/Aufgabe -->

## Soal 13.14 {#br-bgk-2019-w13-ex14}

Misalkan $\mathcal F$ berkas modul pada ruang berdering $(X,\mathcal O_X)$,
dan misalkan $\mathcal F^*$ berkas dualnya. Buktikan bahwa terdapat
homomorfisme $\mathcal O_X$-modul alami

$$
\mathcal F\otimes_{\mathcal O_X}\mathcal F^*
\longrightarrow\mathcal O_X.
$$

<!-- upstream_entity: Lokal beringter Raum/Invertierbare Garbe/Invertierbarkeitsort/Aufgabe -->

## Soal 13.15 {#br-bgk-2019-w13-ex15}

Misalkan $(X,\mathcal O_X)$ ruang berdering lokal dan $\mathcal L$ berkas
invertibel pada $X$. Misalkan $U\subseteq X$ himpunan terbuka sedemikian
sehingga restriksi $\mathcal L|_U$ trivial, dan misalkan

$$
\varphi:\mathcal L|_U\longrightarrow\mathcal O_X|_U
$$

suatu isomorfisme. Misalkan

$$
s\in\Gamma(X,\mathcal L)
$$

seksi global dengan lokus keterbalikan $X_s$. Buktikan bahwa

$$
X_s\cap U=U_{\varphi(s)},
$$

dengan ruas kanan menyatakan lokus keterbalikan bagi
$\varphi(s)\in\Gamma(U,\mathcal O_X|_U)$.

<!-- upstream_entity: Beringter Raum/Invertierbare Garben/Duale Garbe/Invertierbar/Aufgabe -->

## Soal 13.16 {#br-bgk-2019-w13-ex16}

Misalkan $\mathcal L$ berkas invertibel pada ruang berdering
$(X,\mathcal O_X)$. Buktikan bahwa berkas dual

$$
\mathcal L^*
$$

juga invertibel.

<!-- upstream_entity: Beringter Raum/Invertierbare Garben/Tensorierung/Aufgabe -->

## Soal 13.17 {#br-bgk-2019-w13-ex17}

Misalkan $\mathcal L$ dan $\mathcal M$ berkas invertibel pada ruang berdering
$(X,\mathcal O_X)$. Buktikan bahwa hasil kali tensor

$$
\mathcal L\otimes_{\mathcal O_X}\mathcal M
$$

juga invertibel.

<!-- upstream_entity: Lokal beringter Raum/Invertierbare Garben/Tensorierung/Invertierbarkeitsort/Aufgabe -->

## Soal 13.18 {#br-bgk-2019-w13-ex18}

Misalkan $\mathcal L$ dan $\mathcal M$ berkas invertibel pada ruang berdering
lokal $(X,\mathcal O_X)$. Misalkan

$$
s\in\Gamma(X,\mathcal L),
\qquad
t\in\Gamma(X,\mathcal M),
$$

dan

$$
st\in\Gamma(X,\mathcal L\otimes\mathcal M).
$$

Buktikan bahwa lokus-lokus keterbalikannya memenuhi

$$
X_{st}=X_s\cap X_t.
$$

<!-- upstream_entity: Beringter Raum/Invertierbare Garbe/Bidual/Aufgabe -->

## Soal 13.19 {#br-bgk-2019-w13-ex19}

Buktikan bahwa berkas invertibel $\mathcal L$ pada ruang berdering
$(X,\mathcal O_X)$ secara alami isomorfik dengan bidualnya
$\mathcal L^{**}$.

<!-- upstream_entity: Beringter Raum/Invertierbare Garben/Duale Garbe/Tensorierung/Aufgabe -->

## Soal 13.20 {#br-bgk-2019-w13-ex20}

Misalkan $\mathcal L$ berkas invertibel pada ruang berdering
$(X,\mathcal O_X)$ dan $\mathcal L^*$ berkas dualnya. Buktikan bahwa terdapat
isomorfisme $\mathcal O_X$-modul alami

$$
\mathcal L\otimes_{\mathcal O_X}\mathcal L^*
\longrightarrow\mathcal O_X.
$$

<!-- upstream_entity: Projektiver Raum/Getwistete Strukturgarben/Positiver Twist/Invertierbarkeitsort/Aufgabe -->

## Soal 13.21 {#br-bgk-2019-w13-ex21}

Pertimbangkan ruang projektif di atas lapangan $K$ dan berkas invertibel

$$
\mathcal O_{\mathbb P_K^n}(m)
$$

untuk $m>0$. Misalkan

$$
f\in\Gamma\!\left(\mathbb P_K^n,
\mathcal O_{\mathbb P_K^n}(m)\right)
=K[X_0,X_1,\ldots,X_n]_m.
$$

Buktikan kesamaan berikut untuk lokus keterbalikan:

$$
(\mathbb P_K^n)_f=D_+(f).
$$

<!-- upstream_entity: Projektiver Raum/Getwistete  Strukturgarben/Tensorierung/Aufgabe -->

## Soal 13.22 {#br-bgk-2019-w13-ex22}

Pertimbangkan ruang projektif di atas lapangan $K$ dan berkas-berkas
invertibel $\mathcal O_{\mathbb P_K^n}(\ell)$. Buktikan bahwa

$$
\mathcal O_{\mathbb P_K^n}(\ell)
\otimes\mathcal O_{\mathbb P_K^n}(m)
\cong\mathcal O_{\mathbb P_K^n}(\ell+m).
$$

<!-- upstream_entity: Projektive Hyperebene/Kurze exakte Sequenz/Aufgabe -->

## Soal 13.23 {#br-bgk-2019-w13-ex23}

Misalkan

$$
0\ne F\in K[X_0,X_1,\ldots,X_n]
$$

polinomial homogen berderajat $d$. Buktikan bahwa polinomial tersebut
menentukan barisan eksak pendek berkas

$$
0\longrightarrow
\mathcal O_{\mathbb P_K^n}(-d)
\xrightarrow{\,\cdot F\,}
\mathcal O_{\mathbb P_K^n}
\longrightarrow
\mathcal O_{V_+(F)}
\longrightarrow 0
$$

pada ruang projektif. Di sini berkas struktur pada hipermuka projektif
$V_+(F)$ dipandang sebagai berkas pada ruang projektif.
