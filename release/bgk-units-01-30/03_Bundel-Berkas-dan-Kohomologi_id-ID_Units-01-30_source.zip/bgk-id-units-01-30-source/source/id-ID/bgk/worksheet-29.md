---
title: "Lembar Kerja 29 - Genus Kurva"
stable_id: br-bgk-2019-w29
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 29"
upstream_pageid: 110238
upstream_revid: 1069438
upstream_timestamp: "2026-02-05T20:36:09Z"
upstream_mediawiki_sha1: fe4fc776bdfd80cb3337cfb807de3168abe73d09
source_url: "https://de.wikiversity.org/w/index.php?oldid=1069438"
authority_manifest: authority/wikiversity-bgk/unit-29/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 376380a874b545579d61c100d1f66eac11bad854d76f7e586b10cd621e7a54f7
worksheet_xml: authority/wikiversity-bgk/unit-29/worksheet-29.xml
worksheet_xml_sha256: b298ec1566a1a1c1a3ba3bbc2606679ffba8ad2dfe9c8cd3d1269fc0c96e2ce4
worksheet_expanded_tex: authority/wikiversity-bgk/unit-29/worksheet-29-expanded.tex
worksheet_expanded_tex_sha256: 2243dc1483422ccc3747f4d924abf46f29e1d67cd6cd66ed06a3b9587ae79429
official_pdf: authority/artifacts/bgk-worksheet-29-official.pdf
official_pdf_sha256: 112cba176b947010eb3e4ff2123b7b04756f06c579b61bb3826c284cff3533f0
ordered_exercise_map: authority/wikiversity-bgk/unit-29/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 1ee8ba36620cda1bb7b7da82f277d42c0284c0c3858f368d517fc0206c00889c
exercise_count: 15
public_solution_count: 2
public_solution_numbers: "5, 12"
official_course_pdf: authority/artifacts/bgk-course-official.pdf
media_credits: source/id-ID/media-credits-bgk-unit-29.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponennya sendiri; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 29: Genus Kurva {#br-bgk-2019-w29}

<!-- upstream_entity: Projektive Gerade/Quotient aus Linearformen/Schnitte/Lineare Transformation/Aufgabe -->
### Soal 29.1 {#br-bgk-2019-w29-ex01}

Buktikan bahwa data atau konstruksi berikut menentukan morfisme yang sama
$\mathbb P^1_K\to\mathbb P^1_K$, dengan
$(a,b),(c,d)\in K^2$ bebas linear.

1. Morfisme yang diinduksi menurut Teorema 12.11 oleh homomorfisme gelanggang
   homogen $K[X,Y]\to K[S,T]$ dengan
   $X\mapsto aS+bT$ dan $Y\mapsto cS+dT$.
2. Morfisme menurut Lema 28.1 yang diberikan oleh dua seksi
   $$
   as+bt,\ cs+dt\in
   \Gamma(\mathbb P^1_K,\mathcal O_{\mathbb P^1_K}(1)).
   $$
3. Morfisme menurut Lema 29.7 yang diberikan oleh fungsi rasional
   $$
   \frac{as+bt}{cs+dt}\in K\!\left(\frac st\right).
   $$

<!-- upstream_entity: Kuspe/Affine Gerade/Keine Fortsetzung/Aufgabe -->
### Soal 29.2 {#br-bgk-2019-w29-ex02}

Buktikan bahwa terdapat morfisme

$$
V(X^2-Y^3)\supseteq
U=V(X^2-Y^3)\setminus\{(0,0)\}
\longrightarrow\mathbb A^1
$$

yang tidak dapat diperluas ke seluruh $V(X^2-Y^3)$.

<!-- upstream_entity: Projektion weg vom Punkt/Auf Kurve/Sekanten/Aufgabe -->
### Soal 29.3 {#br-bgk-2019-w29-ex03}

Misalkan $K$ lapangan, $C\subseteq\mathbb P^2_K$ kurva bidang projektif,
$P\in C$, dan

$$
\varphi:C\setminus\{P\}\longrightarrow\mathbb P^1_K
$$

morfisme yang didefinisikan oleh proyeksi menjauhi $P$. Jadi titik
$Q\in C$, $Q\ne P$, dipetakan ke garis sekan melalui $Q$ dan $P$.

1. Misalkan $K=\mathbb C$ dan $(Q_n)$ barisan pada $C$ yang konvergen ke $P$
   dalam topologi kompleks. Apakah $\varphi(Q_n)$ konvergen?
2. Apakah $\varphi(Q_n)$ mempunyai titik akumulasi?
3. Misalkan $P$ titik mulus. Buktikan bahwa morfisme dapat diperluas ke
   seluruh $C$.

<!-- upstream_entity: Projektion weg vom Punkt/Auf Kurve/Sekanten/Achsenkreuz/Aufgabe -->
### Soal 29.4 {#br-bgk-2019-w29-ex04}

Diskusikan situasi Soal 29.3 untuk persilangan sumbu

$$
V_+(YZ)\subseteq\mathbb P^2
$$

dan titik persilangannya $(1,0,0)$.

<!-- upstream_entity: Projektion weg von Punkt/Ebene/Generischer Grad/Aufgabe -->
### Soal 29.5 ★ {#br-bgk-2019-w29-ex05}

Misalkan $K$ lapangan tertutup aljabar berkarakteristik $0$, misalkan
$C\subseteq\mathbb P^2_K$ kurva bidang projektif tak tereduksi berderajat
$d$, dan misalkan

$$
\varphi:C\longrightarrow\mathbb P^1_K
$$

morfisme yang diberikan oleh proyeksi menjauhi titik $P\notin C$. Buktikan
bahwa, dengan paling banyak berhingga banyak pengecualian, serat di atas
setiap $t\in\mathbb P^1_K$ terdiri atas tepat $d$ titik.

<!-- upstream_entity: Projektive ebene glatte Kurve/Grad d/Morphismus mit d-1 Faserpunkte/Aufgabe -->
### Soal 29.6 {#br-bgk-2019-w29-ex06}

Misalkan $K$ lapangan tertutup aljabar dan
$C\subseteq\mathbb P^2_K$ kurva mulus berderajat $d\ge2$. Buktikan bahwa
terdapat morfisme $C\to\mathbb P^1_K$ sedemikian sehingga setiap serat
terdiri atas paling banyak $d-1$ titik.

<!-- upstream_entity: Ebene projektive Kurven/Fermat-Kubik auf P^1/2 zu 1/Aufgabe -->
### Soal 29.7 {#br-bgk-2019-w29-ex07}

Misalkan

$$
C=V_+(X^3+Y^3+Z^3)\subseteq\mathbb P^2_K
$$

kurva kubik Fermat di atas lapangan tertutup aljabar berkarakteristik bukan
$3$. Jelaskan secara eksplisit suatu morfisme $C\to\mathbb P^1_K$ yang
mempunyai paling banyak dua titik di atas setiap titik.

<!-- upstream_entity: Glatte projektive Kurve/q nach P^1/Konstante/Transformation/Aufgabe -->
### Soal 29.8 {#br-bgk-2019-w29-ex08}

Misalkan $C$ kurva projektif mulus tak tereduksi dengan lapangan fungsi
$Q(C)$, dan $q\in Q(C)$ dengan morfisme terkait
$q:C\to\mathbb P^1_K$. Misalkan $a\in K$. Buktikan bahwa terdapat
automorfisme

$$
\theta:\mathbb P^1_K\longrightarrow\mathbb P^1_K
$$

sedemikian sehingga diagram

$$
\begin{CD}
C @>{q}>> \mathbb P^1_K\\
@V{q-a}VV @VV{\theta}V\\
\mathbb P^1_K @= \mathbb P^1_K
\end{CD}
$$

komutatif.

> **Catatan edisi (sumber).** Revisi semantik beku dan saksi PDF resmi 2020
> menampilkan $Q(C)=$ dengan ruas kanan kosong. Edisi ini memperbaiki cacat
> tampak itu menjadi “dengan lapangan fungsi $Q(C)$” tanpa menambahkan asumsi
> matematis.

<!-- upstream_entity: Glatte projektive Kurve/q nach P^1/Fasern/Linear äquivalent/Aufgabe -->
### Soal 29.9 {#br-bgk-2019-w29-ex09}

Misalkan $C$ kurva projektif mulus tak tereduksi di atas lapangan tertutup
aljabar dan $q\in Q(C)$ unsur tak konstan dengan morfisme terkait
$q:C\to\mathbb P^1_K$. Buktikan bahwa untuk setiap
$P\in\mathbb P^1_K$, divisor-divisor tarik balik $q^*(P)$ saling ekuivalen
linear. Gunakan Soal 29.8.

<!-- upstream_entity: Projektive Gerade/t^n/Divisor/Aufgabe -->
### Soal 29.10 {#br-bgk-2019-w29-ex10}

Misalkan $\mathbb P^1_K=\operatorname{Proj}(K[X,Y])$ dengan lapangan fungsi
$K(t)$, $t=Y/X$. Jelaskan morfisme skema terkait

$$
\mathbb P^1_K\longrightarrow\mathbb P^1_K,
\qquad t\longmapsto t^n,
$$

untuk $n\in\mathbb N_+$. Apa pracitra titik nol? Apa pracitra titik di tak
hingga? Bagaimana orde ramifikasinya?

<!-- upstream_entity: Projektive Gerade/Polynom/Verzweigungsordnung im Unendlichen/Aufgabe -->
### Soal 29.11 {#br-bgk-2019-w29-ex11}

Misalkan $\mathbb P^1_K=\operatorname{Proj}(K[X,Y])$ dengan lapangan fungsi
$K(t)$, $t=Y/X$, dan misalkan $P\in K[t]$ polinomial berderajat $e\ge1$.
Jelaskan orde ramifikasi di $\infty$ untuk morfisme skema terkait

$$
\mathbb P^1_K\longrightarrow\mathbb P^1_K,
\qquad t\longmapsto P.
$$

<!-- upstream_entity: Projektive Gerade/Rationale Funktion/u+u invers/Aufgabe -->
### Soal 29.12 ★ {#br-bgk-2019-w29-ex12}

Misalkan
$\mathbb P^1_K=\operatorname{Proj}(K[X,Y])$ dan
$\mathbb P^1_K=\operatorname{Proj}(K[W,Z])$ dua garis projektif dengan
lapangan fungsi $K(t)$, $t=Y/X$, dan $K(u)$, $u=Z/W$, di atas lapangan
tertutup aljabar $K$ berkarakteristik bukan $2$. Pada garis projektif kedua,
tinjau sistem linear yang diberikan oleh

$$
WZ,\ W^2+Z^2\in
\Gamma(\mathbb P^1_K,\mathcal O_{\mathbb P^1_K}(2))
$$

dengan pemetaan terkait

$$
\varphi:\mathbb P^1_K\longrightarrow\mathbb P^1_K,
\qquad (w,z)\longmapsto(wz,w^2+z^2).
$$

1. Apakah sistem linear ini lengkap?
2. Tentukan pracitra $D_+(X)$ dan $D_+(Y)$ serta jelaskan pemetaan yang
   diinduksi antara bagian-bagian terbuka afin.
3. Apakah sistem linear ini bebas titik dasar?
4. Jelaskan perluasan lapangan fungsi $K(t)\subseteq K(u)$ yang terkait.
   Berapa derajatnya?
5. Untuk setiap $(x,y)\in\mathbb P^1_K$, tentukan pracitranya di bawah
   $\varphi$ serta orde ramifikasi masing-masing.
6. Jelaskan divisor tarik balik
   $\varphi^*(0-\infty)=\varphi^*((Y)-(X))$.

<!-- upstream_entity: Normales integres Schema/Rationale Funktion/Morphismus/Aufgabe -->
### Soal 29.13 {#br-bgk-2019-w29-ex13}

Misalkan $X$ skema noetherian normal integral di atas lapangan $K$ dan
$q\in Q(X)$. Buktikan bahwa $q$ mendefinisikan suatu morfisme

$$
q:U\longrightarrow\mathbb P^1
$$

pada suatu himpunan terbuka $U\subseteq X$, dengan kodimensi
$X\setminus U$ sedikitnya $2$.

<!-- upstream_entity: Glatte projektive Kurve/Invertierbare Garbe/Negativer Grad/Schnitte/Aufgabe -->
### Soal 29.14 {#br-bgk-2019-w29-ex14}

Misalkan $\mathcal L$ berkas invertibel berderajat negatif pada kurva
projektif mulus tak tereduksi $C$ di atas lapangan tertutup aljabar. Buktikan

$$
\Gamma(C,\mathcal L)=0.
$$

<!-- upstream_entity: Glatte projektive Kurve/Invertierbare Garbe/Tensorierung/Grad/Aufgabe -->
### Soal 29.15 {#br-bgk-2019-w29-ex15}

Buktikan bahwa untuk kurva projektif mulus $C$ di atas lapangan tertutup
aljabar, derajat berkas invertibel memberikan homomorfisme grup surjektif

$$
\operatorname{Pic}(C)\longrightarrow\mathbb Z,
\qquad\mathcal L\longmapsto\deg(\mathcal L).
$$
