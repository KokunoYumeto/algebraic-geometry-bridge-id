---
title: "Lembar Kerja 21 - Gelanggang Valuasi Diskret"
stable_id: br-bgk-2019-w21
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 21"
upstream_pageid: 109894
upstream_revid: 707217
upstream_timestamp: "2021-10-07T06:20:57Z"
upstream_mediawiki_sha1: 30e9bf77922d6344a0429d26cb5c6a345a3ab994
source_url: "https://de.wikiversity.org/w/index.php?oldid=707217"
course_authority_manifest: authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json
course_authority_manifest_sha256: ea0bf346e261db8ed80b7565f7746e95c79e0c376d25d9fbce5d96879dff7dd8
authority_manifest: authority/wikiversity-bgk/unit-21/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 684637decc945c94137670f7c4238110b4a4c395287cf985b3f69adceedd9ef7
authority_manifest_status: "Bekuan authority terminal lengkap; 35 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
unit_capture_identity: authority/wikiversity-bgk/unit-21/CAPTURE_IDENTITY.json
unit_capture_identity_sha256: 869931efce9e3df0e42984b2db28fc367f93f113a8d632175ac0f9d7414cb791
worksheet_api: authority/wikiversity-bgk/unit-21/worksheet-21-api.json
worksheet_api_sha256: 4fa632b214a3e01723e4f5476f49a7979478f2b3ab58472f141ad928f2a06638
worksheet_xml: authority/wikiversity-bgk/unit-21/worksheet-21.xml
worksheet_xml_sha256: 11a812b26d055ff01728d5e12131d6de6b5018d7e7049e84b2bf18ac9f2c707f
worksheet_html: authority/wikiversity-bgk/unit-21/worksheet-21.html
worksheet_html_sha256: 76165c35fdb7d9bf2abec6db5852157154206581651566671bd050a1e0927243
worksheet_expanded_tex: authority/wikiversity-bgk/unit-21/worksheet-21-expanded.tex
worksheet_expanded_tex_sha256: 932d693b313802ad89fc5c6adcfed45fe631146defd05a5f5d17586f2b5a2f97
official_pdf: authority/artifacts/bgk-worksheet-21-official.pdf
official_pdf_pages: 5
official_pdf_sha256: 20491699d1583220c62fd69d54b9d4d14f4fc3fee492d3bed72afa1f2f849e1e
official_pdf_metadata: authority/wikiversity-bgk/unit-21/official-pdfs-api.json
official_pdf_metadata_sha256: 4be79ab72566114ba54376bbb902cb00346bc9237e4d8ac988345b78cfc2a2ca
official_pdf_source_bytes: 51605
official_pdf_source_sha1: 47a6cb1eba71d82f9135d5bcc27a64b3e5572e48
older_course_pdf: authority/artifacts/bgk-course-official.pdf
older_course_pdf_pages: "189-191"
older_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
authority_precedence: "Revisi semantik Wikiversity yang dibekukan mengendalikan teks; PDF resmi tahun 2020 hanya saksi historis."
ordered_exercise_map: authority/wikiversity-bgk/unit-21/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 69b9ecd0120626c3e4c8dc018862869b13316fa3e6c76edf5954807dcff6af65
candidate_evidence: authority/wikiversity-bgk/unit-21/worksheet-solution-candidates-api.json
candidate_evidence_sha256: 19b8384f8a3e37828a2b5ae32f2e58809b7ac6169c6bff1b8f1649b4e4880782
exercise_count: 13
public_solution_count: 3
public_solution_numbers: "3, 9, 10"
media_credits: source/id-ID/media-credits-bgk-unit-21.md
media_credits_sha256: 07ef5ecaa38890028ebbc245b3511bfb3eb8a29b174c8802dd84a3492496d814
rights_ledger: authority/RIGHTS-bgk-unit-21.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-21.json
asset_closure_sha256: 5fd26087ca516efbb8cbc6823c3622338bd9272eb7ab1452c87ba41c6e28afdd
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF adalah saksi authority, bukan teks edisi; metadata Commons CC BY-SA 4.0 dan pemberitahuan tertanam CC-by-sa 3.0 dipertahankan tanpa pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 21: Gelanggang Valuasi Diskret {#br-bgk-2019-w21}

Tanda bintang menunjukkan tepat tiga soal yang mempunyai solusi publik pada
batas revisi yang dibekukan, yaitu Soal 21.3, 21.9, dan 21.10. Sepuluh soal
lainnya mempunyai hasil kandidat negatif; edisi tidak menciptakan solusi baru.

<!-- upstream_entity: Diskreter Bewertungsring/Beschreibung des Spektrums/Aufgabe -->

## Soal 21.1 {#br-bgk-2019-w21-ex01}

Deskripsikan spektrum suatu gelanggang valuasi diskret.

<!-- upstream_entity: Diskreter Bewertungsring/Hauptideal/Potenzen/Restklassenmodul/Aufgabe -->

## Soal 21.2 {#br-bgk-2019-w21-ex02}

Misalkan $R$ gelanggang valuasi diskret dan $\mathfrak m=(\pi)$. Misalkan
pula

$$
K=R/(\pi)
$$

lapangan residu $R$. Buktikan bahwa untuk setiap $n\in\mathbb N$ terdapat
isomorfisme modul-$R$

$$
(\pi^n)/(\pi^{n+1})\longrightarrow K.
$$

<!-- upstream_entity: Diskreter Bewertungsring/Zwischenringe im Quotientenkörper/Aufgabe -->

## Soal 21.3 ★ {#br-bgk-2019-w21-ex03}

Misalkan $R$ gelanggang valuasi diskret dengan lapangan pecahan $Q$.
Buktikan bahwa tidak ada gelanggang antara sejati antara $R$ dan $Q$.

<!-- upstream_entity: Diskreter Bewertungsring/Endlich erzeugte Untermodul im Quotientenkörper/Charakterisiere/Aufgabe -->

## Soal 21.4 {#br-bgk-2019-w21-ex04}

Misalkan $R$ gelanggang valuasi diskret dengan lapangan pecahan $Q$.
Karakterisasikan submodul-$R$ dari $Q$ yang dibangkitkan secara hingga. Ke
bentuk apakah suatu sistem pembangkit dapat dibawa?

<!-- upstream_entity: Polynomring/1/K/Verschwindungsordnung/Aufgabe -->

## Soal 21.5 {#br-bgk-2019-w21-ex05}

Misalkan $K$ lapangan berkarakteristik $0$, $f\in K[X]$ dengan $f\ne0$,
dan $a\in K$. Buktikan bahwa ketiga "orde" $f$ di titik $a$ berikut
bertepatan.

1. Orde pelenyapan $f$ di titik $a$, yaitu orde minimum suatu turunan formal
   yang memenuhi

   $$
   f^{(k)}(a)\ne0.
   $$

2. Eksponen faktor linear $X-a$ dalam faktorisasi $f$.
3. Orde $f$ di dalam pelokalan

   $$
   K[X]_{(X-a)}
   $$

   dari $K[X]$ pada ideal maksimal $(X-a)$.

> **Catatan edisi - perbedaan dengan saksi PDF kursus.** Entitas Web semantik
> yang dibekukan menyatakan "orde minimum" turunan formal yang tidak nol,
> seperti pada bagian 1 di atas. Saksi PDF kursus pada halaman 189 memuat
> rumusan lama "orde maksimum" turunan dengan $f^{(k)}(a)=0$. Edisi mengikuti
> entitas Web beku dan mencatat perbedaan substantif ini tanpa menggabungkan
> kedua rumusan secara diam-diam.

<!-- upstream_entity: Diskreter Bewertungsring/In K(T)/Schnitt mit K T ist K/Aufgabe -->

## Soal 21.6 {#br-bgk-2019-w21-ex06}

Misalkan $K$ lapangan dan $K(T)$ lapangan fungsi rasional di atas $K$.
Carilah gelanggang valuasi diskret

$$
R\subseteq K(T)
$$

yang memenuhi

$$
Q(R)=K(T)
\qquad\text{dan}\qquad
R\cap K[T]=K.
$$

<!-- upstream_entity: Diskreter Bewertungsring/Ordnungsfunktion/Erste Eigenschaften/Fakt/Beweis/Aufgabe -->

## Soal 21.7 {#br-bgk-2019-w21-ex07}

Misalkan $R$ gelanggang valuasi diskret dengan ideal maksimal
$\mathfrak m=(p)$. Buktikan bahwa pemetaan orde

$$
R\setminus\{0\}\longrightarrow\mathbb N,
\qquad
f\longmapsto\operatorname{ord}(f),
$$

mempunyai sifat-sifat berikut.

1. Berlaku

   $$
   \operatorname{ord}(fg)
   =\operatorname{ord}(f)+\operatorname{ord}(g).
   $$

2. Berlaku

   $$
   \operatorname{ord}(f+g)
   \geq\min\{\operatorname{ord}(f),\operatorname{ord}(g)\}.
   $$

3. Berlaku $f\in\mathfrak m$ jika dan hanya jika
   $\operatorname{ord}(f)\geq1$.
4. Berlaku $f\in R^\times$ jika dan hanya jika
   $\operatorname{ord}(f)=0$.

> **Catatan edisi - domain fungsi orde.** Sumber mendefinisikan
> $\operatorname{ord}$ pada $R\setminus\{0\}$, tetapi bagian 2 tidak
> mengecualikan $f+g=0$. Pernyataan sumber dipertahankan; apabila
> $\operatorname{ord}(0)$ tidak didefinisikan, pertaksamaan itu hanya bermakna
> untuk $f+g\ne0$.

<!-- upstream_entity: Zahlentheorie/p-Bewertung/Aufgabe -->

## Soal 21.8 {#br-bgk-2019-w21-ex08}

Tetapkan suatu bilangan prima $p$. Untuk setiap bilangan bulat $n\ne0$,
misalkan $\nu_p(n)$ menyatakan eksponen kemunculan bilangan prima $p$ dalam
faktorisasi prima $n$.

1. Buktikan bahwa pemetaan

   $$
   \nu_p:\mathbb Z\setminus\{0\}\longrightarrow\mathbb N
   $$

   surjektif.
2. Buktikan bahwa

   $$
   \nu_p(nm)=\nu_p(n)+\nu_p(m).
   $$

3. Carilah perpanjangan

   $$
   \nu_p:\mathbb Q\setminus\{0\}\longrightarrow\mathbb Z
   $$

   dari pemetaan yang diberikan yang merupakan homomorfisme grup; di sini
   $\mathbb Q^\times=\mathbb Q\setminus\{0\}$ dilengkapi perkalian dan
   $\mathbb Z$ dilengkapi penjumlahan.
4. Deskripsikan kernel homomorfisme grup pada bagian 3.

<!-- upstream_entity: Bewertungstheorie/Körper mit diskreter Bewertung/Diskreter Bewertungsring/Aufgabe -->

## Soal 21.9 ★ {#br-bgk-2019-w21-ex09}

Misalkan $K$ lapangan dan

$$
\nu:(K^\times,\cdot,1)\longrightarrow(\mathbb Z,+,0)
$$

homomorfisme grup surjektif yang memenuhi

$$
\nu(f+g)\geq\min\{\nu(f),\nu(g)\}
$$

untuk semua $f,g\in K^\times$. Buktikan bahwa

$$
R=\{f\in K^\times\mid\nu(f)\geq0\}\cup\{0\}
$$

merupakan gelanggang valuasi diskret.

> **Catatan edisi - domain valuasi.** Sumber mendefinisikan $\nu$ hanya pada
> $K^\times$, tetapi menuliskan $\nu(f+g)$ tanpa mengecualikan $f+g=0$.
> Pernyataan sumber dipertahankan; pertaksamaan tersebut hanya bermakna ketika
> $f+g\ne0$ kecuali $\nu$ diperpanjang ke nol.

<!-- upstream_entity: Ebene algebraische Kurve/Glatter Punkt/Lokaler Ring ist diskreter Bewertungsring/Fakt/Beweis/Aufgabe -->

## Soal 21.10 ★ {#br-bgk-2019-w21-ex10}

Misalkan

$$
P\in C=V(F)\subset\mathbb A_K^2
$$

titik mulus pada suatu kurva bidang tak tereduksi. Buktikan bahwa gelanggang
lokal yang bersesuaian merupakan gelanggang valuasi diskret.

<!-- upstream_entity: Einheitskreis/Lokalisierung/Diskreter Bewertungsring/Aufgabe -->

## Soal 21.11 {#br-bgk-2019-w21-ex11}

Misalkan

$$
V=V(x^2+y^2-1)\subseteq\mathbb A_K^2
$$

lingkaran satuan di atas suatu lapangan $K$, dan misalkan
$P=(a,b)\in V$ suatu titik.

1. Buktikan bahwa gelanggang lokal $R$ dari $V$ di titik $P$ merupakan
   gelanggang valuasi diskret.
2. Simpulkan bahwa gelanggang koordinat

   $$
   K[X,Y]/(X^2+Y^2-1)
   $$

   normal. Sumber menyatakan bahwa $K$ boleh dianggap tertutup secara
   aljabar.
3. Buktikan bahwa

   $$
   K[X,Y]/(X^2+Y^2-1)
   $$

   bukan domain faktorisasi tunggal.
4. Tentukan orde $X$ dan $Y-1$ di dalam gelanggang lokal pada titik
   $(0,1)$.

> **Catatan edisi - hipotesis lapangan dalam sumber.** Sumber tidak membatasi
> karakteristik $K$ dan sekaligus mengizinkan $K$ dianggap tertutup secara
> aljabar pada bagian 2, sedangkan klaim sebagai domain faktorisasi tunggal
> pada bagian 3 bergantung
> pada lapangan dasar; dalam karakteristik $2$, persamaan yang ditampilkan
> bahkan merupakan kuadrat. Edisi mempertahankan soal sebagaimana tersedia
> dan tidak memasukkan hipotesis baru.

<!-- upstream_entity: Diskreter Bewertungsring/Potenzreihenring in einer Variablen/Grundlegender Nachweis/Aufgabe -->

## Soal 21.12 {#br-bgk-2019-w21-ex12}

Misalkan $K$ lapangan. Suatu *deret pangkat dalam satu variabel* di atas
$K$ adalah ekspresi formal berbentuk

$$
a_0+a_1T+a_2T^2+a_3T^3+\cdots,
\qquad a_i\in K.
$$

Jadi, dapat terdapat tak hingga banyak koefisien $a_i$ yang tidak nol.
Definisikan struktur gelanggang pada himpunan semua deret pangkat yang
memperluas struktur gelanggang pada gelanggang polinomial dalam satu
variabel. Buktikan bahwa gelanggang ini merupakan gelanggang valuasi diskret.

<!-- upstream_entity: Modultheorie/Torsionsfrei/Definition -->

Suatu modul yang tidak mempunyai unsur torsi selain $0$ disebut *bebas
torsi*.

<!-- upstream_entity: Diskreter Bewertungsring/Endlich erzeugt/Torsionsfrei/Frei/Aufgabe -->

## Soal 21.13 {#br-bgk-2019-w21-ex13}

Buktikan bahwa setiap modul $M$ yang bebas torsi dan dibangkitkan secara
hingga di atas suatu gelanggang valuasi diskret merupakan modul bebas.
