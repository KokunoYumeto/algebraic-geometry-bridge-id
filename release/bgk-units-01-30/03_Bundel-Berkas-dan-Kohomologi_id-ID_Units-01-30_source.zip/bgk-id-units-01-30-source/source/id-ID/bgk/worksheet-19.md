---
title: "Lembar Kerja 19 - Bundel Tangen"
stable_id: br-bgk-2019-w19
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 19"
upstream_pageid: 110228
upstream_revid: 617377
upstream_timestamp: "2020-02-11T17:14:48Z"
upstream_mediawiki_sha1: e8bfe61141c279e01d73db7311fbd7842378f7ee
source_url: "https://de.wikiversity.org/w/index.php?oldid=617377"
authority_manifest: authority/wikiversity-bgk/unit-19/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: ffd4e79d12cd6fd63836cb6d7fd17e5dc6481f3befaeb50efeb9a47c4cc70512
authority_manifest_status: "Bekuan authority terminal lengkap; 33 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
worksheet_xml: authority/wikiversity-bgk/unit-19/worksheet-19.xml
worksheet_xml_sha256: c5237f3f8c6ccca68151c05caede35449f1737da3a7cfe0986900b2c8072f186
worksheet_expanded_tex: authority/wikiversity-bgk/unit-19/worksheet-19-expanded.tex
worksheet_expanded_tex_sha256: 3e7da405f0b52b7e2c5a3831ce99214a3a3fed9221fc54d2b55f247a0cd101fc
official_pdf: authority/artifacts/bgk-worksheet-19-official.pdf
official_pdf_sha256: 7b9a60924fac5d61d119a9a6156a7c22ce767a10a0dc645c4ff188a53c900283
official_pdf_status: "Saksi PDF resmi lokal; 54.883 byte, 5 halaman, dan SHA-1 unggahan 1b67f5b59317b2e082f112250a2612d7a4e22ac8 telah diverifikasi."
official_pdf_metadata: authority/wikiversity-bgk/unit-19/official-pdfs-api.json
official_pdf_metadata_sha256: a37c74918c2fea4dd11a6ce3f9aee6d903596250bf8471c3d089d1c162fbb2af
official_pdf_source_bytes: 54883
official_pdf_source_sha1: 1b67f5b59317b2e082f112250a2612d7a4e22ac8
older_course_pdf: authority/artifacts/bgk-course-official.pdf
older_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
authority_precedence: "Revisi semantik Wikiversity yang dibekukan mengendalikan teks; PDF seluruh kursus tahun 2020 hanya saksi historis."
ordered_exercise_map: authority/wikiversity-bgk/unit-19/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 93905796d627d6ce9fe5926808e2589c25c4513ca38d14c9099ca91693805af6
exercise_count: 12
public_solution_count: 1
public_solution_numbers: "10"
media_credits: source/id-ID/media-credits-bgk-unit-19.md
rights_ledger: authority/RIGHTS-bgk-unit-19.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-19.json
asset_closure_sha256: 0adbc2e593bd9dab369022c73e8d4e69e988ce95bc57e7b1414147c8eb0e03fd
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF adalah saksi authority, bukan teks edisi; metadata Commons CC BY-SA 4.0 dan pemberitahuan tertanam CC-by-sa 3.0 dipertahankan tanpa pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 19: Bundel Tangen {#br-bgk-2019-w19}

Tanda bintang menunjukkan tepat satu soal dengan solusi publik yang
dibekukan, yaitu Soal 19.10. Kesebelas soal lainnya mempunyai hasil kandidat
negatif; edisi ini tidak menciptakan solusi baru.

<!-- upstream_entity: Achsenkreuz/Kähler-Differentiale/Nicht frei im Nullpunkt/Aufgabe -->

## Soal 19.1 {#br-bgk-2019-w19-ex01}

Misalkan

$$
R=K[X,Y]/(XY).
$$

Tunjukkan bahwa modul diferensial Kähler $\Omega_{R\mid K}$ tidak bebas di
titik asal.

<!-- upstream_entity: Glattes Schema/Nichtzusammenhängend/Kählermodul/Rang/Aufgabe -->

## Soal 19.2 {#br-bgk-2019-w19-ex02}

Tunjukkan bahwa terdapat skema mulus bertipe hingga di atas suatu lapangan
sedemikian sehingga rank modul diferensial Kähler-nya tidak konstan.

<!-- upstream_entity: Kommutativer Ring/Modul/Derivation/Spektrum/Aufgabe -->

## Soal 19.3 {#br-bgk-2019-w19-ex03}

Misalkan $R$ gelanggang komutatif, $A$ aljabar komutatif atas $R$, $M$ modul
$A$, dan $\delta:A\to M$ suatu derivasi-$R$. Tunjukkan bahwa pada setiap
himpunan terbuka $U\subseteq\operatorname{Spek}(A)$ terdapat derivasi-$R$

$$
\delta_U:\Gamma(U,\mathcal O_U)
\longrightarrow\Gamma(U,\widetilde M)
$$

yang berkomutasi dengan $\delta$.

> **Petunjuk.** Tinjau terlebih dahulu himpunan-himpunan terbuka $D(f)$.

<!-- upstream_entity: Integres Schema/Basischema/Derivation/Funktionenkörper/Aufgabe -->

## Soal 19.4 {#br-bgk-2019-w19-ex04}

Misalkan $X$ skema integral di atas skema basis integral $S$. Tunjukkan bahwa
suatu derivasi atas $p^{-1}\mathcal O_S$ yang terdefinisi pada himpunan
terbuka $U\subseteq X$,

$$
\delta:\mathcal O_U\longrightarrow\mathcal O_U,
$$

mendefinisikan derivasi-$Q(S)$

$$
Q(X)\longrightarrow Q(X).
$$

<!-- upstream_entity: Schema/Endlicher Typ/Kohärente Garbe/Aufgabe -->

## Soal 19.5 {#br-bgk-2019-w19-ex05}

Misalkan $X$ skema bertipe hingga di atas skema basis $S$. Tunjukkan bahwa
$\Omega_{X\mid S}$ merupakan modul-$\mathcal O_X$ koheren.

<!-- upstream_entity: Schema/Kähler-Differentiale/Prägarbe/Aufgabe -->

## Soal 19.6 {#br-bgk-2019-w19-ex06}

Misalkan $p:X\to S$ sebuah skema di atas skema $S$. Tunjukkan bahwa berkas
diferensial Kähler $\Omega_{X\mid S}$ pada $X$ merupakan berkasisasi dari
praberkas

$$
U\longmapsto
\operatorname*{colim}_{\substack{V\subseteq S\text{ terbuka}\\
U\subseteq p^{-1}(V)}}
\Omega_{\Gamma(U,\mathcal O_X)\mid\Gamma(V,\mathcal O_S)}.
$$

<!-- upstream_entity: Projektive Gerade/Kählermodul/Aufgabe -->

## Soal 19.7 {#br-bgk-2019-w19-ex07}

Tunjukkan bahwa modul diferensial Kähler
$\Omega_{\mathbb P_R^1\mid R}$ pada garis projektif $\mathbb P_R^1$ di atas
gelanggang komutatif $R$ isomorfik dengan berkas struktur terpuntir
$\mathcal O_{\mathbb P_R^1}(-2)$.

<!-- upstream_entity: Projektive Gerade/Tangentialgarbe/Globale Vektorfelder/Aufgabe -->

## Soal 19.8 {#br-bgk-2019-w19-ex08}

Tinjau berkas tangen $\mathcal T_{\mathbb P_R^1,R}$ pada garis projektif
$\mathbb P_R^1$ di atas gelanggang komutatif $R$, dengan isomorfisme

$$
\mathcal T_{\mathbb P_R^1,R}
\cong\mathcal O_{\mathbb P_R^1}(2).
$$

Tentukan seksi-seksi global $\mathcal O_{\mathbb P_R^1}(2)$ yang bersesuaian
dengan derivasi-derivasi global

$$
X\frac{\partial}{\partial X},\qquad
Y\frac{\partial}{\partial X},\qquad
X\frac{\partial}{\partial Y},\qquad
Y\frac{\partial}{\partial Y}.
$$

<!-- upstream_entity: Projektive Ebene/Globale Vektorfelder/Rationale Auswertung/Aufgabe -->

## Soal 19.9 {#br-bgk-2019-w19-ex09}

Pada bidang projektif

$$
\mathbb P_K^2=\operatorname{Proj}(K[X,Y,Z]),
$$

tentukan turunan

$$
Y\frac{\partial f}{\partial X}
$$

dari fungsi rasional

$$
f=\frac{XY-YZ+3Z^2-X^2}{4X^2-YZ}.
$$

Pada himpunan terbuka mana $f$ dan
$Y\frac{\partial f}{\partial X}$ terdefinisi?

<!-- upstream_entity: Fermat-Kubik/Explizite Differentialform/Aufgabe -->

## Soal 19.10 ★ {#br-bgk-2019-w19-ex10}

Kita meninjau kurva

$$
C=V_+(X^3+Y^3+Z^3)\subseteq\mathbb P_K^2
$$

di atas lapangan berkarakteristik bukan $3$. Tunjukkan bahwa bentuk-bentuk
diferensial

$$
\frac{X^2}{Y^2}\,d\!\left(\frac ZX\right)
\quad\text{pada }D_+(XY),
$$

$$
\frac{Y^2}{Z^2}\,d\!\left(\frac XY\right)
\quad\text{pada }D_+(YZ),
$$

dan

$$
\frac{Z^2}{X^2}\,d\!\left(\frac YZ\right)
\quad\text{pada }D_+(XZ)
$$

berimpit pada irisan-irisan dan karena itu mendefinisikan bentuk diferensial
taktrivial pada kurva $C$.

<!-- upstream_entity: Projektiver Raum/Globale Derivationen/Affine Beschreibung/Aufgabe -->

## Soal 19.11 {#br-bgk-2019-w19-ex11}

Nyatakan pembatasan derivasi-derivasi global

$$
X_i\frac{\partial}{\partial X_j}
$$

dari ruang projektif

$$
\mathbb P_R^n=\operatorname{Proj}(R[X_0,X_1,\ldots,X_n])
$$

ke himpunan terbuka

$$
D_+(X_0)=\operatorname{Spek}(R[Y_1,\ldots,Y_n])
\subseteq\mathbb P_R^n,
$$

dengan $Y_k=X_k/X_0$, sebagai kombinasi linear berbentuk

$$
\sum_{k=1}^n g_k\frac{\partial}{\partial Y_k},
\qquad g_k\in R[Y_1,\ldots,Y_n].
$$

<!-- upstream_entity: Fermat-Kubik/4 Variablen/Affin/Explizite Parametrisierung/Aufgabe -->

## Soal 19.12 {#br-bgk-2019-w19-ex12}

Kita meninjau kubik Fermat dalam empat variabel,

$$
V=V_+(X^3+Y^3+Z^3+W^3)\subseteq\mathbb P_K^3,
$$

dan bagian afin

$$
U=D_+(W)\cap V
=\operatorname{Spek}\bigl(K[X,Y,Z]/(X^3+Y^3+Z^3+1)\bigr)
$$

di atas lapangan tertutup secara aljabar $K$ berkarakteristik bukan $3$.
Tunjukkan bahwa rumus-rumus

$$
x(s,t)=
\frac{3t-\frac13(s^2+st+t^2)^2}
{t(s^2+st+t^2)-3},
$$

$$
y(s,t)=
\frac{3s+3t+\frac13(s^2+st+t^2)^2}
{t(s^2+st+t^2)-3},
$$

dan

$$
z(s,t)=
\frac{-3-(s^2+st+t^2)(s+t)}
{t(s^2+st+t^2)-3}
$$

memberikan parametrisasi rasional

$$
K^2\longrightarrow U.
$$
