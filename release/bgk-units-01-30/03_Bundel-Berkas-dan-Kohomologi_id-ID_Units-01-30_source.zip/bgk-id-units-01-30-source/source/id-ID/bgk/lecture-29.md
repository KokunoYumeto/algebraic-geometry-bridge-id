---
title: "Kuliah 29 - Genus Kurva"
stable_id: br-bgk-2019-l29
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 29"
upstream_pageid: 109033
upstream_revid: 1069570
upstream_timestamp: "2026-02-06T07:06:34Z"
upstream_mediawiki_sha1: 6c3afd8d6d4c0a4fac5ed90903c46b10ccab0aaa
source_url: "https://de.wikiversity.org/w/index.php?oldid=1069570"
authority_manifest: authority/wikiversity-bgk/unit-29/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 376380a874b545579d61c100d1f66eac11bad854d76f7e586b10cd621e7a54f7
lecture_xml: authority/wikiversity-bgk/unit-29/lecture-29.xml
lecture_xml_sha256: 2b6d1a6b75858ecfa71730685caa7499ec878ca4326208c9dfe38edbc2902a5b
lecture_expanded_tex: authority/wikiversity-bgk/unit-29/lecture-29-expanded.tex
lecture_expanded_tex_sha256: 019ac2495bb9c5b2347c44c0332a8212b2946953dbd1aa519e7248c53103f06c
official_pdf: authority/artifacts/bgk-lecture-29-official.pdf
official_pdf_sha256: d612185a0afbeddd66a3c434dddac48679c00947723565a2367c08d2bc76dd15
official_course_pdf: authority/artifacts/bgk-course-official.pdf
media_credits: source/id-ID/media-credits-bgk-unit-29.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponennya sendiri; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 29: Genus Kurva {#br-bgk-2019-l29}

## Kurva projektif mulus dan genusnya {#br-bgk-2019-l29-s01}

<!-- upstream_entity: Glatte projektive Kurve/Geschlecht/Erste Kohomologie/Definition -->
### Definisi 29.1: genus {#br-bgk-2019-l29-def-01}

Untuk suatu kurva projektif mulus $C$ di atas lapangan tertutup aljabar $K$,
bilangan

$$
g:=\dim_K H^1(C,\mathcal O_C)
$$

disebut *genus* kurva tersebut.

Menurut Teorema 27.7, dimensi $H^1(C,\mathcal O_C)$ berhingga. Jadi genus
suatu kurva merupakan bilangan asli.

> **Ilustrasi sumber.** Tiga permukaan berikut memperlihatkan genus satu,
> dua, dan tiga melalui banyaknya pegangan. Ketiganya muncul dalam urutan ini
> pada kuliah resmi dan mempertahankan status domain publik komponennya.

![Permukaan torus berwarna hijau dengan satu pegangan, yaitu permukaan bergenus satu](authority/assets/bgk-torus-illustration-500.png)

![Permukaan torus ganda berwarna hijau dengan dua pegangan, yaitu permukaan bergenus dua](authority/assets/bgk-double-torus-illustration-500.png)

![Permukaan hijau menyerupai bola dengan tiga pegangan, yaitu permukaan bergenus tiga](authority/assets/bgk-sphere-with-three-handles-500.png)

<!-- upstream_entity: Projektive Gerade/Kohomologisches Geschlecht/Beispiel -->
### Contoh 29.2 {#br-bgk-2019-l29-exa-02}

Menurut Teorema 27.4, genus garis projektif

$$
\mathbb P^1_K=\operatorname{Proj}(K[X,Y])
$$

adalah $0$.

<!-- upstream_entity: Elliptische Kurve/Geschlecht 1/Definition -->
### Definisi 29.3: kurva eliptik {#br-bgk-2019-l29-def-03}

Kurva projektif mulus $C$ ber-genus $1$ di atas lapangan tertutup aljabar
$K$ disebut *kurva eliptik*.

<!-- upstream_entity: Glatte projektive Kurven/C/Kurzübersicht zur topologischen Gestalt/2/Bemerkung -->
### Catatan 29.4 {#br-bgk-2019-l29-rem-04}

Jika bilangan kompleks $\mathbb C$ dipilih sebagai lapangan dasar, genus
kurva projektif mulus mempunyai interpretasi topologis sederhana. Kurva
tersebut dapat dipandang sebagai manifold kompleks kompak berdimensi satu —
suatu permukaan Riemann — dan juga sebagai manifold real kompak berorientasi
berdimensi dua. Manifold jenis terakhir ini mempunyai klasifikasi topologis
sederhana: setiap manifold demikian homeomorfik dengan permukaan bola yang
diberi $g$ pegangan. Bilangan ini disebut genus topologis permukaan real, dan
karena itu juga genus kurva.

Dapat dibuktikan bahwa genus yang didefinisikan secara aljabar melalui
kohomologi pertama berkas struktur sama dengan genus topologis tersebut.
Garis projektif kompleks merupakan bola berdimensi dua tanpa pegangan, jadi
genus topologisnya $0$. Permukaan ber-genus $1$ adalah torus — seperti ban —
yang homeomorfik dengan $S^1\times S^1$. Kurva projektif ber-genus $1$, yakni
kurva eliptik, mempunyai bentuk topologis ini.

<!-- upstream_entity: Ebene projektive Kurve/Grad/Kohomologisches Geschlecht/Fakt -->
### Teorema 29.5 {#br-bgk-2019-l29-thm-05}

Misalkan

$$
C=V_+(f)\subseteq\mathbb P^2_K
$$

kurva bidang projektif berderajat $d$ di atas lapangan tertutup aljabar $K$.
Maka

$$
\dim_K H^1(C,\mathcal O_C)=\frac{(d-1)(d-2)}{2}.
$$

#### Bukti {#br-bgk-2019-l29-thm-05-proof}

Tinjau barisan eksak pendek (bandingkan Soal 13.23)

$$
0\longrightarrow\mathcal O_{\mathbb P^2_K}(-d)
\xrightarrow{\ f\ }
\mathcal O_{\mathbb P^2_K}
\longrightarrow\mathcal O_C\longrightarrow0
$$

berkas koheren pada bidang projektif. Berkas struktur $\mathcal O_C$ di sini
dipandang sebagai berkas pada bidang projektif dengan dukungan $C$. Potongan
barisan eksak panjang kohomologi yang terkait adalah

$$
H^1(\mathbb P^2_K,\mathcal O_{\mathbb P^2_K})=0
\longrightarrow H^1(\mathbb P^2_K,\mathcal O_C)
\longrightarrow H^2(\mathbb P^2_K,\mathcal O_{\mathbb P^2_K}(-d))
\longrightarrow H^2(\mathbb P^2_K,\mathcal O_{\mathbb P^2_K})=0.
$$

Kedua kesamaan nol mengikuti dari Teorema 27.4. Menurut teorema yang sama,
ruang

$$
H^2(\mathbb P^2_K,\mathcal O_{\mathbb P^2_K}(-d))
$$

mempunyai basis yang terdiri atas semua monomial $x^iy^jz^k$ dengan semua
eksponen negatif dan $i+j+k=-d$. Jadi kita harus menghitung tupel
$(\alpha,\beta,\gamma)$ berderajat $d-3$. Menurut Soal 12.4, banyaknya adalah

$$
\binom{d-3+2}{2}=\binom{d-1}{2}=\frac{(d-1)(d-2)}{2}.
$$

Menurut Teorema 27.6,
$H^1(\mathbb P^2_K,\mathcal O_C)=H^1(C,\mathcal O_C)$, yang membuktikan
pernyataan. $\square$

> **Catatan edisi (saksi PDF).** Saksi PDF resmi 2020 masih merujuk Soal 11.4;
> revisi semantik beku yang menjadi kanon edisi ini telah memperbarui rujukan
> tersebut menjadi Soal 12.4.

Dalam kasus mulus, teorema ini memberikan rumus untuk menghitung genus kurva
bidang:

| $d$ | 1 | 2 | 3 | 4 | 5 |
|---:|---:|---:|---:|---:|---:|
| $g$ | 0 | 0 | 1 | 3 | 6 |

Untuk $d=1$ kita memperoleh garis projektif ber-genus $0$. Untuk $d=2$ kita
memperoleh kuadrik projektif bidang — suatu irisan kerucut — yang juga
ber-genus $0$ dan memang isomorfik dengan garis projektif. Untuk $d=3$ genus
adalah $1$, sehingga kurvanya eliptik. Dapat dibuktikan bahwa setiap kurva
eliptik dapat direalisasikan sebagai kurva kubik bidang. Sama sekali tidak
jelas sebelumnya bahwa ada kurva projektif mulus untuk setiap genus. Menurut
Teorema 29.5, tidak semuanya dapat direalisasikan sebagai kurva bidang.

<!-- upstream_entity: Glatte projektive Kurve/Kohomologisches Geschlecht/Differentialformen/Serre-Dualität/Bemerkung -->
### Catatan 29.6 {#br-bgk-2019-l29-rem-06}

Genus kurva projektif mulus yang didefinisikan secara kohomologis sama dengan
dimensi ruang vektor berkas kanoniknya. Dalam dimensi satu, berkas kanonik
adalah berkas diferensial Kähler $\Omega_{C\mid K}$, yakni berkas kotangen dan
dual berkas tangen. Jadi

$$
\dim_K H^1(C,\mathcal O_C)
=\dim_K\Gamma(C,\omega_C).
$$

Untuk kurva bidang hal ini terlihat langsung. Menurut Teorema 29.5, genusnya
adalah $(d-1)(d-2)/2$. Korolari 19.12 memberikan
$\omega_C\cong\mathcal O_C(d-3)$, dan menurut Soal 27.10 dimensi
$\Gamma(C,\mathcal O_C(d-3))$ juga sama dengan $(d-1)(d-2)/2$.

Dalam kasus umum berlaku dualitas Serre. Salah satu isinya ialah: untuk berkas
bebas lokal $\mathcal F$ pada kurva projektif mulus $C$, grup kohomologi
$H^1(C,\omega_C)$ merupakan ruang vektor berdimensi satu di atas $K$, dan
pemetaan alami

$$
\operatorname{Hom}(\mathcal F,\omega_C)
\times H^1(C,\mathcal F)
\longrightarrow H^1(C,\omega_C)\cong K
$$

memberikan dualitas sempurna. Dengan kata lain,
$\operatorname{Hom}(\mathcal F,\omega_C)$ dan $H^1(C,\mathcal F)$ saling
dual dan khususnya berdimensi sama. Untuk berkas struktur
$\mathcal F=\mathcal O_C$, kesamaan
$\operatorname{Hom}(\mathcal O_C,\omega_C)=\Gamma(C,\omega_C)$ dari
Teorema 13.10 memberikan dualitas antara $H^1(C,\mathcal O_C)$ dan
$\Gamma(C,\omega_C)$.

## Divisor pada kurva {#br-bgk-2019-l29-s02}

Pada kurva projektif mulus $C$, seperti pada setiap skema normal berdimensi
satu, divisor Weil hanyalah jumlah formal

$$
\sum_{P\in C} n_P\,P
$$

atas titik-titik tertutup $P$. Dalam kasus ini, titik-titik tersebut adalah
divisor prima, yaitu subhimpunan tertutup tak tereduksi berkodimensi $1$.
Koefisien $n_P\in\mathbb Z$ dan hanya berhingga banyak yang tidak nol. Menurut
Korolari 22.11, grup kelas divisor sama dengan grup Picard.

Kita akan membahas perilaku divisor pada kurva di bawah morfisme. Morfisme
antara dua kurva tak tereduksi selalu konstan atau mempunyai citra rapat.
Morfisme tak konstan $\varphi:C_1\to C_2$ menginduksi perluasan lapangan
fungsi

$$
Q(C_2)\subseteq Q(C_1).
$$

Mula-mula kita tunjukkan bahwa unsur lapangan fungsi suatu kurva mulus dapat
dipandang sebagai morfisme ke garis projektif. Secara umum, untuk unsur tak
konstan $q$ dalam lapangan fungsi skema normal $X$, divisor utama
$\operatorname{div}(q)$ dapat diuraikan menjadi divisor nol dan divisor kutub
dengan koefisien positif. Kedua divisor efektif itu ekuivalen linear dan,
dalam kasus faktorial lokal menurut Soal 22.15, bersesuaian dengan seksi dalam
berkas invertibel terkait
$\mathcal O_X(\text{divisor nol}(q))$. Hasil kuliah sebelumnya menunjukkan
bahwa kedua seksi ini menentukan morfisme ke garis projektif pada suatu
himpunan terbuka $U\subseteq X$. Hasil berikut lebih kuat untuk kurva mulus:
daerah definisinya adalah seluruh kurva.

> **Catatan edisi (saksi PDF).** Saksi PDF resmi 2020 masih merujuk Soal 22.13;
> revisi semantik beku yang menjadi kanon edisi ini telah memperbarui rujukan
> tersebut menjadi Soal 22.15.

<!-- upstream_entity: Glatte Kurve/Rationale Funktion/Morphismus/Fakt -->
### Lema 29.7 {#br-bgk-2019-l29-lem-07}

Misalkan $C$ kurva mulus tak tereduksi di atas lapangan tertutup aljabar $K$
dan $Q$ lapangan fungsinya. Setiap fungsi rasional $q\in Q$ secara alami
menentukan morfisme

$$
q:C\longrightarrow\mathbb P^1_K.
$$

#### Bukti {#br-bgk-2019-l29-lem-07-proof}

Misalkan

$$
U:=\{P\in C\mid q\in\mathcal O_{C,P}\}
$$

daerah definisi $q$ sebagai fungsi ke garis afin, dan, jika $q\ne0$,

$$
V:=\{P\in C\mid q^{-1}\in\mathcal O_{C,P}\}.
$$

Kita mempunyai $C=U\cup V$, sebab setiap $\mathcal O_{C,P}$ merupakan
gelanggang valuasi diskret dan di sana
$q=\pi^n u$ untuk suatu unit $u\in\mathcal O_{C,P}$, parameter lokal
$\pi\in\mathcal O_{C,P}$, dan $n\in\mathbb Z$. Menurut Korolari 10.12 terdapat
morfisme

$$
q:U\longrightarrow\mathbb A^1_K
=\operatorname{Spec}K\!\left[\frac YX\right]
\cong D_+(X)\subseteq\mathbb P^1_K
$$

dan morfisme

$$
q^{-1}:V\longrightarrow\mathbb A^1_K
=\operatorname{Spec}K\!\left[\frac XY\right]
\cong D_+(Y)\subseteq\mathbb P^1_K.
$$

Keduanya bersesuaian dengan homomorfisme substitusi $Y/X\mapsto q$ dan
$X/Y\mapsto q^{-1}$. Pada $U\cap V$ kedua morfisme berimpit, sehingga mereka
merekat menjadi morfisme ke garis projektif. $\square$

<!-- upstream_entity: Diskrete Bewertungsringe/Verzweigungsordnung/Definition -->
### Definisi 29.8: indeks ramifikasi {#br-bgk-2019-l29-def-08}

Untuk homomorfisme gelanggang injektif $R\subseteq S$ antara gelanggang
valuasi diskret, orde suatu penyeragam lokal $R$ di dalam $S$ disebut *indeks
ramifikasi* perluasan tersebut.

Orde ramifikasi dilambangkan $\operatorname{Ram}(S\mid R)$. Jika
$\varphi:C_1\to C_2$ morfisme tak konstan antara kurva mulus di atas lapangan
tertutup aljabar, maka untuk setiap titik tertutup $Q\in C_1$ dengan titik
citra $\varphi(Q)\in C_2$ terdapat perluasan gelanggang valuasi diskret

$$
\mathcal O_{C_2,\varphi(Q)}\subseteq\mathcal O_{C_1,Q}.
$$

Orde ramifikasi terkait juga disebut orde ramifikasi $\varphi$ di $Q$ dan
dilambangkan $\operatorname{Ram}(Q\mid\varphi(Q))$.

> **Catatan edisi (sumber dan saksi PDF).** Revisi semantik beku memakai
> *Verzweigungsindex* (“indeks ramifikasi”) di dalam definisi, lalu
> *Verzweigungsordnung* (“orde ramifikasi”) dalam paragraf berikutnya. Saksi
> PDF resmi 2020 memakai *Verzweigungsordnung* juga di dalam definisi. Edisi
> ini mempertahankan perbedaan istilah antarsaksi tersebut secara eksplisit.

<!-- upstream_entity: Glatte Kurven/Morphismus/Zurückgezogener Divisor/Definition -->
### Definisi 29.9: tarik balik divisor Weil {#br-bgk-2019-l29-def-09}

Misalkan $\varphi:C_1\to C_2$ morfisme tak konstan antara kurva mulus di atas
lapangan tertutup aljabar dan

$$
D=\sum_P a_P\,P
$$

divisor Weil pada $C_2$. Divisor Weil

$$
\varphi^*D
:=\sum_{Q\in C_1}
\operatorname{Ram}(Q\mid\varphi(Q))a_{\varphi(Q)}\,Q
$$

disebut *divisor Weil tarik balik*.

Untuk satu titik $P\in C_2$, divisor tarik baliknya adalah

$$
\sum_{Q\in\varphi^{-1}(P)}
\operatorname{Ram}(Q\mid P)\,Q.
$$

Jadi ini pada dasarnya adalah serat di atas $P$, tetapi titik ramifikasi —
titik dengan orde ramifikasi sedikitnya $2$ — dihitung berulang sesuai
ordenya.

<!-- upstream_entity: Glatte Kurve/Morphismus/Zurückgezogener Divisor/Hauptdivisor/Fakt -->
### Lema 29.10 {#br-bgk-2019-l29-lem-10}

Misalkan $\varphi:C_1\to C_2$ morfisme tak konstan antara kurva mulus tak
tereduksi di atas lapangan tertutup aljabar, dan misalkan

$$
D=\sum_P a_P\,P=\operatorname{div}(q)
$$

divisor utama pada $C_2$, dengan $q\in Q(C_2)$ dan $q\ne0$. Maka
$\varphi^*(D)$ sama dengan divisor utama $q\in Q(C_1)$ pada $C_1$.

#### Bukti {#br-bgk-2019-l29-lem-10-proof}

Karena $\varphi$ tak konstan, terdapat perluasan lapangan
$Q(C_2)\subseteq Q(C_1)$. Untuk setiap $Q\in C_1$ terdapat diagram komutatif
homomorfisme injektif

$$
\begin{CD}
\mathcal O_{C_2,\varphi(Q)} @>>> \mathcal O_{C_1,Q}\\
@VVV @VVV\\
Q(C_2) @>>> Q(C_1),
\end{CD}
$$

dengan gelanggang valuasi diskret pada baris pertama. Jika
$q=u\pi_2^n$, dengan $u\in\mathcal O_{C_2,\varphi(Q)}$ suatu unit dan
$\pi_2$ penyeragam lokal, maka sumber menuliskan

$$
q=u\pi_2^n
=u\bigl(u'\pi_1^{\operatorname{Ram}(Q\mid\varphi(Q))}\bigr)^n
=uu'\pi_1^{n\operatorname{Ram}(Q\mid\varphi(Q))},
$$

dengan $\pi_1$ penyeragam lokal $\mathcal O_{C_1,Q}$. Ini memberikan
pernyataan. $\square$

> **Catatan edisi (sumber dan saksi PDF).** Revisi semantik beku memakai urutan
> $\operatorname{Ram}(Q\mid\varphi(Q))$ di atas, sedangkan saksi PDF resmi 2020
> membalik argumennya menjadi
> $\operatorname{Ram}(\varphi(Q)\mid Q)$. Edisi ini mengikuti revisi semantik
> beku. Namun, ketika $(u'\pi_1^e)^n$ dikembangkan, kedua saksi menulis faktor
> unit $u'$ alih-alih $(u')^n$; tampilan sumber itu dipertahankan dan
> ketidaktepatannya diungkapkan di sini.

<!-- upstream_entity: Glatte Kurve/Rationale Funktion/Morphismus nach P^1/Hauptdivisor/Fakt -->
### Korolari 29.11 {#br-bgk-2019-l29-cor-11}

Misalkan $C$ kurva mulus tak tereduksi di atas lapangan tertutup aljabar $K$,
$Q$ lapangan fungsinya, dan $q\in Q\setminus K$. Untuk morfisme terkait

$$
q:C\longrightarrow\mathbb P^1_K
$$

berlaku

$$
q^*((0)-(\infty))=\operatorname{div}(q).
$$

#### Bukti {#br-bgk-2019-l29-cor-11-proof}

Lapangan fungsi garis projektif
$\mathbb P^1_K=\operatorname{Proj}(K[X,Y])$ adalah $K(t)$ dengan $t=Y/X$.
Perluasan lapangan fungsi diberikan oleh

$$
K(t)\longrightarrow Q(C),\qquad t\longmapsto q.
$$

Divisor utama $t$ adalah $(0)-(\infty)=(Y)-(X)$. Jadi pernyataan mengikuti
dari Lema 29.10. $\square$

## Derajat divisor {#br-bgk-2019-l29-s03}

<!-- upstream_entity: Glatte projektive Kurve/Weildivisor/Grad/Definition -->
### Definisi 29.12 {#br-bgk-2019-l29-def-12}

Misalkan $C$ kurva projektif mulus di atas lapangan tertutup aljabar $K$.
Derajat divisor Weil $D=\sum_{P\in C}n_P P$ didefinisikan sebagai

$$
\deg(D):=\sum_{P\in C}n_P.
$$

<!-- upstream_entity: Glatte projektive Kurve/Hauptdivisor/Grad 0/Fakt -->
### Teorema 29.13 {#br-bgk-2019-l29-thm-13}

Misalkan $C$ kurva projektif mulus di atas lapangan tertutup aljabar $K$.
Derajat setiap divisor utama sama dengan $0$.

Teorema ini diberikan tanpa bukti. Akibatnya, homomorfisme grup

$$
\operatorname{Div}(C)\longrightarrow\mathbb Z,
\qquad D\longmapsto\deg(D),
$$

memfaktor melalui grup kelas divisor $C$. Karena itu definisi berikut masuk
akal.

<!-- upstream_entity: Glatte projektive Kurve/Invertierbare Garbe/Grad/Definition -->
### Definisi 29.14 {#br-bgk-2019-l29-def-14}

Misalkan $C$ kurva projektif mulus di atas lapangan tertutup aljabar $K$.
Derajat berkas invertibel $\mathcal L$ pada $C$ didefinisikan sebagai derajat
suatu divisor Weil yang bersesuaian dengannya.

“Bersesuaian” berarti bahwa divisor $D$ dikaitkan dengan berkas invertibel
$\mathcal O_C(D)$; khususnya, divisor efektif bersesuaian dengan seksi-seksi
dalam berkas tersebut.
