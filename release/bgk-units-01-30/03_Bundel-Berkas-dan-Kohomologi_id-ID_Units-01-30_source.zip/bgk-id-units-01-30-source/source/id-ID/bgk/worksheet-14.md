---
title: "Lembar Kerja 14 - Modul Kuasikoheren"
stable_id: br-bgk-2019-w14
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 14"
upstream_pageid: 110221
upstream_revid: 1005264
upstream_timestamp: "2025-06-23T17:55:24Z"
upstream_mediawiki_sha1: 86f9f44b4b41b187f66c06e15294d4b2a3d11517
source_url: "https://de.wikiversity.org/w/index.php?oldid=1005264"
worksheet_xml: authority/wikiversity-bgk/unit-14/worksheet-14.xml
worksheet_xml_sha256: 8ddd8aeaf012194a6cd7982ebd0677b2f65757c2ae843007afe1c8537e411694
worksheet_expanded_tex: authority/wikiversity-bgk/unit-14/worksheet-14-expanded.tex
worksheet_expanded_tex_sha256: e6645368e0aeb0160fb3909544bae84da2e1c51ef8b07a4511a231df415b6e85
ordered_exercise_map: authority/wikiversity-bgk/unit-14/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 5e5e8e176197359fb6726abc791fc58ad61051ad150859b24f746e83cb91cac4
candidate_evidence: authority/wikiversity-bgk/unit-14/worksheet-solution-candidates-api.json
candidate_evidence_sha256: 69af9a5a8678c2af5cb8b562b588b9eda47635744dd9cf0bcc790194396cfd5c
official_pdf_metadata: authority/wikiversity-bgk/unit-14/official-pdfs-api.json
official_pdf_metadata_sha256: 87597a5f905829e257b9997c3b4b9855ae455be7d1272aa1dec2fa0f4b5851a3
official_course_pdf: authority/artifacts/bgk-course-official.pdf
official_course_pdf_bytes: 2104862
official_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
official_course_pdf_printed_pages: "126-130"
course_authority_manifest: authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json
course_authority_manifest_sha256: ea0bf346e261db8ed80b7565f7746e95c79e0c376d25d9fbce5d96879dff7dd8
exercise_count: 26
public_solution_count: 0
public_solution_numbers: ""
negative_public_solution_count: 26
negative_solution_numbers: "1-26"
media_credits: source/id-ID/media-credits-bgk-unit-14.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 14: Modul Kuasikoheren {#br-bgk-2019-w14}

Pada batas revisi yang dibekukan, tidak satu pun dari 26 soal mempunyai
halaman solusi publik. Edisi ini mempertahankan hasil kandidat negatif itu dan
tidak menciptakan solusi baru.

<!-- upstream_entity: Kommutativer Ring/Ideal/Spektrumsmodul/Isomorphie/Aufgabe -->

## Soal 14.1 {#br-bgk-2019-w14-ex01}

Misalkan $\mathfrak a\subseteq R$ ideal dalam gelanggang komutatif $R$ dan
$X=\operatorname{Spek}(R)$. Buktikan bahwa

$$
\widetilde{\mathfrak a}|_{D(\mathfrak a)}
\cong\mathcal O_X|_{D(\mathfrak a)}.
$$

<!-- upstream_entity: Kommutativer Ring/Modul/Nenneraufnahme/Spektrum/Aufgabe -->

## Soal 14.2 {#br-bgk-2019-w14-ex02}

Misalkan $M$ modul $R$ di atas gelanggang komutatif $R$ dan $f\in R$.
Buktikan bahwa

$$
\widetilde M|_{D(f)}\cong\widetilde{M_f},
$$

dengan ruas kanan menyatakan berkas modul yang terkait dengan modul
$R_f$ $M_f$.

<!-- upstream_entity: Kommutativer Ring/Modul/Endlich erzeugter/0 in Punkt/Umgebung/Aufgabe -->

## Soal 14.3 {#br-bgk-2019-w14-ex03}

Misalkan $R$ gelanggang komutatif dan $M$ modul $R$ yang dibangkitkan secara
hingga. Misalkan $\mathfrak p\in\operatorname{Spek}(R)$ ideal prima dengan
$M_{\mathfrak p}=0$. Buktikan bahwa terdapat $f\notin\mathfrak p$ dengan

$$
M_f=0.
$$

<!-- upstream_entity: Kommutativer Ring/Moduln/Endlich erzeugt/Homomorphismus/Surjektiv/Punkt/Aufgabe -->

## Soal 14.4 {#br-bgk-2019-w14-ex04}

Misalkan $R$ gelanggang komutatif dan

$$
\varphi:M\longrightarrow N
$$

homomorfisme modul $R$ di antara modul-modul $R$ yang dibangkitkan secara
hingga. Misalkan $\mathfrak p\in\operatorname{Spek}(R)$ ideal prima
sedemikian sehingga homomorfisme terinduksi

$$
\varphi:M_{\mathfrak p}\longrightarrow N_{\mathfrak p}
$$

surjektif. Buktikan bahwa terdapat $f\notin\mathfrak p$ sedemikian sehingga

$$
\varphi:M_f\longrightarrow N_f
$$

surjektif.

<!-- upstream_entity: Kommutativer Ring/Noethersch/Moduln/Endlich erzeugt/Homomorphismus/Injektiv/Punkt/Aufgabe -->

## Soal 14.5 {#br-bgk-2019-w14-ex05}

Misalkan $R$ gelanggang komutatif Noether dan

$$
\varphi:M\longrightarrow N
$$

homomorfisme modul $R$ di antara modul-modul $R$ yang dibangkitkan secara
hingga. Misalkan $\mathfrak p\in\operatorname{Spek}(R)$ ideal prima
sedemikian sehingga homomorfisme terinduksi

$$
\varphi:M_{\mathfrak p}\longrightarrow N_{\mathfrak p}
$$

injektif. Buktikan bahwa terdapat $f\notin\mathfrak p$ sedemikian sehingga

$$
\varphi:M_f\longrightarrow N_f
$$

injektif.

<!-- upstream_entity: Z/Q mod Z/Nicht endlich erzeugt/Lokalisierungsphänomene/Aufgabe -->

## Soal 14.6 {#br-bgk-2019-w14-ex06}

Dengan memakai $R=\mathbb Z$ dan $M=\mathbb Q/\mathbb Z$, tunjukkan bahwa
pernyataan-pernyataan dalam Soal 14.3, 14.4, dan 14.5 tidak benar tanpa
asumsi bahwa modul dibangkitkan secara hingga.

<!-- upstream_entity: Kommutativer Ring/Nicht noethersch/Moduln/Homomorphismus/Lokalisierungsphänomene/Aufgabe -->

## Soal 14.7 {#br-bgk-2019-w14-ex07}

Misalkan $K$ lapangan,

$$
R=K[X_n,Y_n,\ n\in\mathbb N]/(X_nY_n,\ n\in\mathbb N),
$$

dan

$$
\mathfrak p=(X_n,\ n\in\mathbb N)\subseteq R.
$$

1. Buktikan bahwa $\mathfrak p$ adalah ideal prima.
2. Buktikan bahwa $\mathfrak p_{\mathfrak p}=0$.
3. Buktikan bahwa $\mathfrak p_f\ne0$ untuk setiap $f\notin\mathfrak p$.
4. Buktikan bahwa

   $$
   \varphi:R\longrightarrow R/\mathfrak p
   $$

   menjadi injektif setelah dilokalkan pada $\mathfrak p$ (dan dengan
   demikian juga bijektif), tetapi tidak ada pelokalan homomorfisme itu pada
   satu unsur $f\notin\mathfrak p$ yang injektif.

<!-- upstream_entity: Integritätsbereich/Quotientenkörper/Konstante Garbe/Spektrum/Aufgabe -->

## Soal 14.8 {#br-bgk-2019-w14-ex08}

Misalkan $R$ domain integral dengan lapangan pecahan $Q(R)$. Buktikan bahwa

$$
\widetilde{Q(R)}
$$

adalah berkas konstan pada spektrum $\operatorname{Spek}(R)$.

<!-- upstream_entity: Kommutativer Ring/Moduln/Homomorphismenmodul/Spektrum/Aufgabe -->

## Soal 14.9 {#br-bgk-2019-w14-ex09}

Misalkan $R$ gelanggang komutatif dan $M,N$ modul $R$. Buktikan bahwa

$$
\widetilde{\operatorname{Hom}(M,N)}
\cong
\mathcal Hom(\widetilde M,\widetilde N).
$$

<!-- upstream_entity: Punktierte Ebene/Festlegungssatz/Kein Einheitsideal/Surjektiv/Aufgabe -->

## Soal 14.10 {#br-bgk-2019-w14-ex10}

Misalkan

$$
U=(\mathbb A_K^2\setminus\{(0,0)\},\mathcal O_X)
$$

bidang afin yang dilubangi. Berikan contoh seksi global

$$
s_1,s_2\in\Gamma(U,\mathcal O_X)
$$

sedemikian sehingga $(s_1,s_2)$ bukan ideal satuan, tetapi homomorfisme modul
$\mathcal O_X$ terkait

$$
\mathcal O_U^2\longrightarrow\mathcal O_U,
\qquad e_i\longmapsto s_i,
$$

surjektif.

<!-- upstream_entity: Punktierte Ebene/Maximales Ideal/Kurze exakte Sequenz/Aufgabe -->

## Soal 14.11 {#br-bgk-2019-w14-ex11}

Untuk $R=K[X,Y]$, tinjau barisan eksak pendek

$$
0\longrightarrow R\longrightarrow R^2
\longrightarrow(X,Y)=\mathfrak m\longrightarrow0,
$$

dengan pemetaan paling kanan mengirim vektor-vektor standar ke pembangkit
ideal, sedangkan pemetaan paling kiri mengirim $1$ ke $(Y,-X)$. Menurut
Lema 14.9, barisan ini menghasilkan barisan eksak berkas

$$
0\longrightarrow\mathcal O_{\operatorname{Spek}(R)}
\longrightarrow\mathcal O_{\operatorname{Spek}(R)}^2
\longrightarrow\widetilde{\mathfrak m}\longrightarrow0.
$$

Misalkan $U=D(X,Y)$. Buktikan pernyataan-pernyataan berikut.

1. $\Gamma(U,\mathcal O_{\operatorname{Spek}(R)})=R$.
2. $\Gamma(U,\widetilde{\mathfrak m})=R$.
3. Evaluasi barisan eksak berkas tersebut pada $U$ adalah

   $$
   0\longrightarrow R\longrightarrow R^2\longrightarrow R,
   $$

   dan pemetaan paling kanan tidak surjektif.

<!-- upstream_entity: Ring/Ideal/Kurze exakte Sequenz/Spektrum/Aufgabe -->

## Soal 14.12 {#br-bgk-2019-w14-ex12}

Misalkan $R$ gelanggang komutatif dan $I\subseteq R$ ideal dengan barisan
eksak pendek terkait

$$
0\longrightarrow I\longrightarrow R\longrightarrow R/I\longrightarrow0.
$$

Tafsirkan barisan eksak pendek berkas yang bersesuaian

$$
0\longrightarrow\widetilde I\longrightarrow\widetilde R
\longrightarrow\widetilde{R/I}\longrightarrow0
$$

pada spektrum $R$. Pada himpunan terbuka mana dan di titik mana objek-objek
tersebut - masing-masing evaluasi dan tangkainya - menjadi nol, dan
homomorfisme-homomorfismenya menjadi isomorfisme?

<!-- upstream_entity: Ringwechsel/Spektrumsabbildung/Vorgeschobener Modul/Aufgabe -->

## Soal 14.13 {#br-bgk-2019-w14-ex13}

Misalkan $\theta:A\to B$ homomorfisme gelanggang di antara gelanggang
komutatif $A$ dan $B$, dan misalkan

$$
\varphi:\operatorname{Spek}(B)\longrightarrow\operatorname{Spek}(A)
$$

pemetaan spektrum terkait. Misalkan $N$ modul $B$ dengan berkas modul
terkait $\widetilde N$ pada $\operatorname{Spek}(B)$. Buktikan bahwa

$$
\varphi_*(\widetilde N)=\widetilde{N'},
$$

dengan $N'$ semata-mata modul $B$ $N$ yang dipandang sebagai modul $A$.

<!-- upstream_entity: Ringwechsel/Spektrumsabbildung/Zurückgezogener Modul/Aufgabe -->

## Soal 14.14 {#br-bgk-2019-w14-ex14}

Misalkan $\theta:A\to B$ homomorfisme gelanggang di antara gelanggang
komutatif $A$ dan $B$, dan misalkan

$$
\varphi:\operatorname{Spek}(B)\longrightarrow\operatorname{Spek}(A)
$$

pemetaan spektrum terkait. Misalkan $M$ modul $A$ dengan berkas modul terkait
$\widetilde M$ pada $\operatorname{Spek}(A)$. Buktikan bahwa

$$
\varphi^*(\widetilde M)=\widetilde{M\otimes_AB}
$$

pada $\operatorname{Spek}(B)$.

Soal berikut mendeskripsikan versi teori gelanggang dari Lema Lampiran 4.3.
Bersama kedua soal sebelumnya, soal ini kembali menghasilkan versi spektrum
dari pernyataan tersebut.

<!-- upstream_entity: Ringwechsel/Vorgezogener und zurückgezogener Modul/Homomorphismus/Aufgabe -->

## Soal 14.15 {#br-bgk-2019-w14-ex15}

Misalkan $\theta:A\to B$ homomorfisme di antara gelanggang komutatif $A$ dan
$B$. Misalkan $M$ modul $A$ dan $N$ modul $B$. Buktikan bahwa terdapat
isomorfisme grup alami

$$
\operatorname{Hom}_B(M\otimes_AB,N)
=\operatorname{Hom}_A(M,N'),
$$

dengan $N'$ menyatakan modul $B$ $N$ yang dipandang sebagai modul $A$.

<!-- upstream_entity: Affines Schema/Quasikohärenter Modul/Global/Aufgabe -->

## Soal 14.16 {#br-bgk-2019-w14-ex16}

Misalkan $R$ gelanggang komutatif dan $\mathcal M$ modul kuasikoheren pada
$\operatorname{Spek}(R)$. Buktikan bahwa

$$
\mathcal M\cong\widetilde M
$$

untuk suatu modul $R$ $M$.

<!-- upstream_entity: Schema/Quasikohärente Garbe/Direkte Summe/Aufgabe -->

## Soal 14.17 {#br-bgk-2019-w14-ex17}

Misalkan $\mathcal F$ dan $\mathcal G$ modul kuasikoheren pada suatu skema
$(X,\mathcal O_X)$. Buktikan bahwa jumlah langsung

$$
\mathcal F\oplus\mathcal G
$$

juga kuasikoheren.

<!-- upstream_entity: Schema/Kohärente Garbe/Direkte Summe/Aufgabe -->

## Soal 14.18 {#br-bgk-2019-w14-ex18}

Misalkan $\mathcal F$ dan $\mathcal G$ modul koheren pada suatu skema
$(X,\mathcal O_X)$. Buktikan bahwa jumlah langsung

$$
\mathcal F\oplus\mathcal G
$$

juga koheren.

<!-- upstream_entity: Schema/Quasikohärente Garben/Homomorphismus/Kern/Aufgabe -->

## Soal 14.19 {#br-bgk-2019-w14-ex19}

Misalkan $\mathcal F$ dan $\mathcal G$ modul kuasikoheren pada suatu skema
$(X,\mathcal O_X)$, dan misalkan

$$
\varphi:\mathcal F\longrightarrow\mathcal G
$$

suatu homomorfisme. Buktikan bahwa kernel $\ker\varphi$ juga kuasikoheren.

<!-- upstream_entity: Noethersches Schema/Kohärente Garben/Homomorphismus/Kern/Aufgabe -->

## Soal 14.20 {#br-bgk-2019-w14-ex20}

Misalkan $\mathcal F$ dan $\mathcal G$ modul koheren pada skema Noether
$(X,\mathcal O_X)$, dan misalkan

$$
\varphi:\mathcal F\longrightarrow\mathcal G
$$

suatu homomorfisme. Buktikan bahwa kernel $\ker\varphi$ juga koheren.

<!-- upstream_entity: Schema/Quasikohärente Garben/Homomorphismus/Kokern/Aufgabe -->

## Soal 14.21 {#br-bgk-2019-w14-ex21}

Misalkan $\mathcal F$ dan $\mathcal G$ modul kuasikoheren pada suatu skema
$(X,\mathcal O_X)$, dan misalkan

$$
\varphi:\mathcal F\longrightarrow\mathcal G
$$

suatu homomorfisme. Buktikan bahwa kokernel $\operatorname{coker}\varphi$
juga kuasikoheren.

<!-- upstream_entity: Noethersches Schema/Invertierbarkeitsort/Quasikohärenter Modul/Nenneraufnahme/Aufgabe -->

## Soal 14.22 {#br-bgk-2019-w14-ex22}

Misalkan $(X,\mathcal O_X)$ skema Noether dan

$$
f\in\Gamma(X,\mathcal O_X)
$$

fungsi global dengan lokus keterbalikan $X_f$. Misalkan $\mathcal M$ modul
$\mathcal O_U$ kuasikoheren pada $X$. Buktikan bahwa

$$
\Gamma(X_f,\mathcal M)=\Gamma(X,\mathcal M)_f.
$$

<!-- upstream_entity: Noethersches Schema/Offenes Unterschema/Quasikohärenter Modul/Vorschub/Aufgabe -->

## Soal 14.23 {#br-bgk-2019-w14-ex23}

Misalkan $(X,\mathcal O_X)$ skema Noether dan $U\subseteq X$ subhimpunan
terbuka. Misalkan $\mathcal M$ modul $\mathcal O_U$ kuasikoheren pada $U$.
Buktikan bahwa dorong maju

$$
i_*\mathcal M
$$

adalah modul kuasikoheren pada $X$.

Petunjuk: tinjau terlebih dahulu situasi ketika $X$ afin.

<!-- upstream_entity: Projektiver Raum/Funktion auf D+(x0)/Globale Liftung/Aufgabe -->

## Soal 14.24 {#br-bgk-2019-w14-ex24}

Tinjau berkas invertibel $\mathcal O_{\mathbb P_K^n}(1)$ pada ruang projektif
di atas lapangan $K$, bersama seksi global

$$
X_0\in\Gamma(\mathbb P_K^n,\mathcal O_{\mathbb P_K^n}(1))
$$

dan lokus keterbalikan

$$
(\mathbb P_K^n)_{X_0}=D_+(X_0).
$$

Misalkan

$$
f\in\Gamma(D_+(X_0),\mathcal O_{\mathbb P_K^n})
$$

fungsi yang terdefinisi pada $D_+(X_0)\subseteq\mathbb P_K^n$. Buktikan
secara langsung bahwa terdapat $m\in\mathbb N$ sedemikian sehingga

$$
X_0^mf\in
\Gamma\!\left(
\mathbb P_K^n,
(\mathcal O_{\mathbb P_K^n}(1))^m\otimes
\mathcal O_{\mathbb P_K^n}
\right)
$$

berasal dari suatu unsur global dalam

$$
\Gamma\!\left(
\mathbb P_K^n,
(\mathcal O_{\mathbb P_K^n}(1))^m\otimes
\mathcal O_{\mathbb P_K^n}
\right).
$$

<!-- upstream_entity: Projektive Gerade/Funktion auf D+(x0)/Globale Liftung/Aufgabe -->

## Soal 14.25 {#br-bgk-2019-w14-ex25}

Tinjau berkas invertibel $\mathcal O_{\mathbb P_K^1}(1)$ pada garis projektif

$$
\mathbb P_K^1=\operatorname{Proj}(K[X,Y])
$$

di atas lapangan $K$, bersama seksi global

$$
X\in\Gamma(\mathbb P_K^1,\mathcal O_{\mathbb P_K^1}(1))
$$

dan lokus keterbalikan

$$
(\mathbb P_K^1)_X=D_+(X).
$$

Untuk setiap fungsi $f$ berikut dari
$\Gamma(D_+(X),\mathcal O_{\mathbb P_K^1}(1))$, tentukan $n$ yang sesuai
sedemikian sehingga

$$
X^nf\in\Gamma(D_+(X),\mathcal O_{\mathbb P_K^1}(n))
$$

berasal dari suatu unsur - unsur yang mana? - dalam
$\Gamma(\mathbb P_K^1,\mathcal O_{\mathbb P_K^1}(n))$.

1. $\displaystyle\frac YX$,
2. $\displaystyle\frac{2Y^3-3Y^2X+4X^3}{X^3}$,
3. $\displaystyle\frac{Y^{17}+X^{17}}{X^{17}}$.

<!-- upstream_entity: Noethersches Schema/Quasikohärente Garbe/Invertierbare Garbe/Invertierbarkeitsort/Globale Ausdehnung/Strukturgarbe/Aufgabe -->

## Soal 14.26 {#br-bgk-2019-w14-ex26}

Khususkan Teorema 14.13 pada kasus ketika $\mathcal M$ adalah berkas struktur
pada $X$.
