---
title: "Kuliah 7 - Ruang Berdering dan Ruang Berdering Lokal"
stable_id: br-bgk-2019-l07
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 7"
upstream_pageid: 109011
upstream_revid: 1003731
upstream_timestamp: "2025-06-08T15:30:36Z"
upstream_mediawiki_sha1: b0b4d8ab050e0948ecc6e3f8cb86a1c7091c1f3d
source_url: "https://de.wikiversity.org/w/index.php?oldid=1003731"
authority_manifest: authority/wikiversity-bgk/unit-07/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 001074c62cedb1efc988d3214416d2d86a02976d5b22dc272f4fe064e72dfc95
lecture_xml: authority/wikiversity-bgk/unit-07/lecture-07.xml
lecture_xml_sha256: 34de24fb81ee5bae5fa6664ecbc592b1103f6497e766f77be4404aadea6fcb4a
lecture_expanded_tex: authority/wikiversity-bgk/unit-07/lecture-07-expanded.tex
lecture_expanded_tex_sha256: b321142f917f6bf95e169b293cbd407288d59cd21266f09ad0174f0547a47189
official_pdf: authority/artifacts/bgk-lecture-07-official.pdf
official_pdf_sha256: 9be947907e8d819612a7c824fc7dd949ca447887547732769f967f27f19df43a
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 7: Ruang Berdering dan Ruang Berdering Lokal {#br-bgk-2019-l07}

## Ruang berdering {#br-bgk-2019-l07-s01}

<!-- upstream_entity: Beringter Raum/Definition -->

### Definisi 7.1: ruang berdering {#br-bgk-2019-l07-def-01}

Ruang topologis yang dilengkapi dengan sebuah berkas gelanggang komutatif
disebut *ruang berdering*.

Sebuah ruang berdering sering ditulis dalam bentuk

$$
(X,\mathcal O_X),
$$

dengan $X$ ruang dasarnya dan $\mathcal O_X$ berkas gelanggang komutatifnya.
Berkas ini disebut *berkas struktur* ruang berdering. Evaluasi

$$
\Gamma(U,\mathcal O_X)=\mathcal O_X(U)
$$

juga disebut *gelanggang seksi* untuk himpunan terbuka $U\subseteq X$, dan
notasi

$$
\Gamma(U,\mathcal O_X)
$$

disebut *gelanggang seksi global* (pada $U$). Setelah Contoh 3.9 dan
Contoh 3.10, kita mempunyai contoh-contoh standar berikut.

<!-- upstream_entity: Topologischer Raum/Prägarbe der stetigen Funktionen/Garbe/beringter Raum/Beispiel -->

### Contoh 7.2: fungsi kontinu bernilai real {#br-bgk-2019-l07-exa-01}

Misalkan $X$ sebuah ruang topologis. Untuk setiap himpunan terbuka
$U\subseteq X$, tetapkan

$$
\mathcal C(U)=C^0(U,\mathbb R)
 =\{f:U\longrightarrow\mathbb R\mid f\text{ kontinu}\}.
$$

Ini adalah gelanggang komutatif, dan penetapan
$U\mapsto\mathcal C(U)$, bersama pemetaan restriksi alami, merupakan sebuah
berkas. Dengan demikian $X$ menjadi ruang berdering.

<!-- upstream_entity: Differenzierbare Mannigfaltigkeit/Prägarbe der differenzierbaren Funktionen/Beispiel -->

### Contoh 7.3: fungsi terdiferensialkan {#br-bgk-2019-l07-exa-02}

Pada manifold terdiferensialkan $M$, setiap himpunan terbuka $U\subseteq M$
memiliki gelanggang komutatif

$$
C^1(U,\mathbb R)=\{f:U\longrightarrow\mathbb R\mid f\text{ terdiferensialkan kontinu}\}.
$$

Penetapan ini merupakan sebuah berkas, sehingga $M$ menjadi ruang berdering.

<!-- upstream_entity: Komplexe Mannigfaltigkeit/Holomorphe Funktion/Beringter Raum/Beispiel -->

### Contoh 7.4: fungsi holomorfik {#br-bgk-2019-l07-exa-03}

Pada manifold kompleks $M$, untuk setiap himpunan terbuka $U\subseteq M$ kita
memiliki gelanggang komutatif

$$
C^1(U,\mathbb C)=\{f:U\longrightarrow\mathbb C\mid f\text{ holomorfik}\}.
$$

Penetapan tersebut merupakan sebuah berkas dan menjadikan $M$ ruang
berdering.

<!-- upstream_entity: Kommutativer Ring/Punkt/Beringter Raum/Beispiel -->

### Contoh 7.5: ruang satu titik {#br-bgk-2019-l07-exa-04}

Misalkan $R$ sebuah gelanggang komutatif dan $X=\{P\}$ ruang topologis yang
hanya memiliki satu titik. Dengan menetapkan

$$
\Gamma(X,\mathcal O_X):=R,\qquad
\Gamma(\varnothing,\mathcal O_X):=0,
$$

$X$ menjadi ruang berdering.

<!-- upstream_entity: Beringter Raum/Punkt/Halm/Definition -->

### Definisi 7.6: tangkai ruang berdering {#br-bgk-2019-l07-def-02}

Untuk suatu titik $P\in X$ dalam ruang berdering
$\bigl(X,\mathcal O_X\bigr)$, tangkai berkas struktur di titik $P$ disebut
*tangkai di $P$*. Tangkai tersebut ditulis

$$
\mathcal O_{X,P}\quad\text{atau, secara singkat,}\quad\mathcal O_P.
$$

## Morfisme ruang berdering {#br-bgk-2019-l07-s02}

Untuk pemetaan kontinu $\varphi:X\to Y$ di antara ruang topologis, setiap
himpunan terbuka $V\subseteq Y$ memberikan homomorfisme gelanggang

$$
\begin{aligned}
C^0(V,\mathbb R)&\longrightarrow C^0(\varphi^{-1}(V),\mathbb R),\\
f&\longmapsto f\circ\varphi.
\end{aligned}
$$

Fungsi kontinu yang ditarik balik ini juga ditulis $\varphi^*f$. Notasi yang
sama akan dipakai dalam definisi abstrak berikut.

<!-- upstream_entity: Beringter Raum/Morphismus/Definition -->

### Definisi 7.7: morfisme ruang berdering {#br-bgk-2019-l07-def-03}

Misalkan $(X,\mathcal O_X)$ dan $(Y,\mathcal O_Y)$ ruang berdering.
Sebuah *morfisme ruang berdering* adalah pemetaan kontinu

$$
\varphi:X\longrightarrow Y
$$

bersama keluarga homomorfisme gelanggang

$$
\varphi_V^*:\Gamma(V,\mathcal O_Y)
\longrightarrow\Gamma(\varphi^{-1}(V),\mathcal O_X)
$$

untuk setiap himpunan terbuka $V\subseteq Y$, yang kompatibel dengan
pemetaan-pemetaan restriksi.

Kompatibilitas berarti bahwa untuk himpunan terbuka
$W\subseteq V\subseteq Y$, diagram

$$
\begin{array}{ccc}
\Gamma(V,\mathcal O_Y)&\xrightarrow{\ \varphi_V^*\ }&
\Gamma(\varphi^{-1}(V),\mathcal O_X)\\
\downarrow&&\downarrow\\
\Gamma(W,\mathcal O_Y)&\xrightarrow{\ \varphi_W^*\ }&
\Gamma(\varphi^{-1}(W),\mathcal O_X)
\end{array}
$$

komutatif. Morfisme $\varphi:X\to Y$ ruang berdering menginduksi, untuk
setiap titik $P\in X$, sebuah homomorfisme gelanggang pada tangkai

$$
\mathcal O_{Y,\varphi(P)}\longrightarrow\mathcal O_{X,P}.
$$

Secara eksplisit, jika $f\in\mathcal O_{Y,\varphi(P)}$ direpresentasikan oleh
$f\in\Gamma(V,\mathcal O_Y)$ pada suatu lingkungan terbuka
$\varphi(P)\in V$, maka citranya adalah germ dari

$$
\varphi^*(f)\in\Gamma(\varphi^{-1}(V),\mathcal O_X).
$$

<!-- upstream_entity: Beringter Raum/Isomorphismus/Definition -->

### Definisi 7.8: isomorfisme ruang berdering {#br-bgk-2019-l07-def-04}

Morfisme ruang berdering

$$
\varphi:(X,\mathcal O_X)\longrightarrow(Y,\mathcal O_Y)
$$

disebut *isomorfisme* apabila terdapat morfisme ruang berdering

$$
\psi:(Y,\mathcal O_Y)\longrightarrow(X,\mathcal O_X)
$$

sedemikian sehingga

$$
\psi\circ\varphi=\operatorname{Id}_X,\qquad
\varphi\circ\psi=\operatorname{Id}_Y,
$$

dengan kedua identitas dipahami sebagai identitas ruang berdering.

## Data pengeleman untuk ruang berdering {#br-bgk-2019-l07-s03}

Konstruksi berikut memperluas Lema 2.6.

<!-- upstream_entity: Beringter Raum/Verklebungsdatum/Definition -->

### Definisi 7.9: data pengeleman {#br-bgk-2019-l07-def-05}

Yang dimaksud dengan *data pengeleman* untuk ruang berdering adalah data
berikut.

1. Sebuah keluarga ruang berdering

   $$
   (U_i,\mathcal O_{U_i}),\qquad i\in I.
   $$

2. Untuk setiap pasangan $(i,j)$, sebuah himpunan terbuka
   $U_{ij}\subseteq U_i$, dengan $U_{ii}=U_i$.

3. Untuk setiap pasangan $(i,j)$, sebuah isomorfisme ruang berdering

   $$
   \varphi_{ji}:(U_{ij},\mathcal O_{U_{ij}})
   \longrightarrow(U_{ji},\mathcal O_{U_{ji}}),
   $$

   dengan $\varphi_{ii}=\operatorname{Id}_{(U_i,\mathcal O_{U_i})}$.

Untuk indeks $i,j,k\in I$, dipenuhi *syarat kokikel*

$$
\varphi_{kj}\circ\varphi_{ji}=\varphi_{ki}
$$

sebagai homomorfisme dari $U_{ik}\cap U_{ij}$ ke $U_k$.

<!-- upstream_entity: Beringter Raum/Verklebungsdatum/Existenz/Fakt -->

### Lema 7.10: keberadaan hasil pengeleman {#br-bgk-2019-l07-lem-01}

Misalkan diberikan data pengeleman
$\bigl(U_i,\mathcal O_{U_i}\bigr)_{i\in I}$ untuk ruang berdering. Maka ada
sebuah ruang berdering $(X,\mathcal O_X)$, sebuah penutup terbuka

$$
X=\bigcup_{i\in I}V_i,
$$

dan isomorfisme-isomorfisme ruang berdering

$$
\psi_i:U_i\longrightarrow V_i
$$

sedemikian sehingga

$$
\psi_i(U_{ij})=V_i\cap V_j
$$

dan

$$
\psi_i|_{U_{ij}}=\psi_j|_{U_{ji}}\circ\varphi_{ji}
$$

berlaku.

#### Bukti {#br-bgk-2019-l07-lem-01-proof}

Keberadaan ruang dasar $X$ diperoleh dari Lema 2.6. Untuk himpunan terbuka
$W\subseteq X$, terdapat penutup

$$
W=\bigcup_{i\in I}(W\cap V_i).
$$

Kita tetapkan gelanggang seksi dengan

$$
\begin{aligned}
\Gamma(W,\mathcal O_X):=\bigl\{(s_i)_{i\in I}\mid {}
&
s_i\in\Gamma\bigl(\psi_i^{-1}(W\cap V_i),\mathcal O_{U_i}\bigr),\\
&\varphi_{ji}\!\left(s_i\big|_{\psi_i^{-1}(W)\cap U_{ij}}\right)
=s_j\big|_{\psi_j^{-1}(W)\cap U_{ji}}\bigr\}.
\end{aligned}
$$

Ini adalah berkas gelanggang komutatif pada $X$ yang pada $V_i$, melalui
$\psi_i$, berimpit dengan berkas yang telah diberikan pada $U_i$.

## Ruang berdering lokal {#br-bgk-2019-l07-s04}

<!-- upstream_entity: Lokal beringter Raum/Definition -->

### Definisi 7.11: ruang berdering lokal {#br-bgk-2019-l07-def-06}

Ruang berdering $(X,\mathcal O_X)$ disebut *ruang berdering lokal* apabila,
untuk setiap titik $P\in X$, tangkai $\mathcal O_P$ merupakan gelanggang
lokal.

<!-- upstream_entity: Topologischer Raum/Stetige Funktionen/Lokal beringter Raum/Beispiel -->

### Contoh 7.12: fungsi kontinu {#br-bgk-2019-l07-exa-05}

Ruang topologis $X$, bersama berkas fungsi kontinu
$C^0(-,\mathbb R)$, merupakan ruang berdering lokal. Untuk setiap titik
$P\in X$ dan fungsi kontinu $f$ yang didefinisikan pada lingkungan terbuka
$P$, berlaku

$$
f(P)\ne0
$$

tepat ketika terdapat lingkungan terbuka tempat $f$ invertibel. Karena itu,
setiap tangkai $\mathcal O_P$ merupakan gelanggang lokal dan $X$ berdering
lokal. Hal yang sama berlaku pada manifold real maupun kompleks.

<!-- upstream_entity: Lokal beringter Raum/Punkt/Restekörper/Definition -->

### Definisi 7.13: lapangan residu {#br-bgk-2019-l07-def-07}

Untuk ruang berdering lokal $(X,\mathcal O_X)$ dan titik $P\in X$, lapangan
residu gelanggang lokal $\mathcal O_P$ disebut *lapangan residu* titik $P$.
Lapangan ini ditulis

$$
\kappa(P).
$$

Lapangan residu pada ruang topologis dengan berkas fungsi kontinu hanyalah
$\mathbb R$; lihat Soal 7.16.

<!-- upstream_entity: Lokal beringter Raum/Funktion/Auswertung/Definition -->

### Definisi 7.14: evaluasi {#br-bgk-2019-l07-def-08}

Untuk ruang berdering lokal $(X,\mathcal O_X)$, titik $x\in X$, dan fungsi
global

$$
f\in\Gamma(X,\mathcal O_X),
$$

nilai $f$ di lapangan residu $\kappa(x)$ disebut *evaluasi* $f$ di $x$ dan
ditulis $f(x)$.

Di dalam ruang berdering lokal, untuk setiap
$f\in\Gamma(X,\mathcal O_X)$ dan $P\in X$ berlaku ekuivalensi

$$
f(P)=0\text{ di }\kappa(P)
\quad\Longleftrightarrow\quad
f_P\in\mathfrak m_P
\quad\Longleftrightarrow\quad
f_P\text{ bukan satuan di }\mathcal O_{X,P}.
$$

> **Catatan edisi — kapitalisasi pada sumber.** Sumber menulis “IN einem
> lokal beringten Raum”. Terjemahan menormalkan kapitalisasi bahasa Indonesia;
> isi matematis dan ekuivalensinya tidak diubah.

<!-- upstream_entity: Lokal beringter Raum/Morphismus/Definition -->

### Definisi 7.15: morfisme ruang berdering lokal {#br-bgk-2019-l07-def-09}

Untuk ruang berdering lokal $(X,\mathcal O_X)$ dan $(Y,\mathcal O_Y)$,
*morfisme ruang berdering lokal* dari $X$ ke $Y$ adalah morfisme ruang
berdering $\varphi:X\to Y$ yang homomorfisme gelanggang tangkai terinduksinya

$$
\varphi_P^*:\mathcal O_{Y,\varphi(P)}\longrightarrow\mathcal O_{X,P}
$$

merupakan homomorfisme lokal untuk setiap titik $P\in X$.

## Lokus keterbalikan {#br-bgk-2019-l07-s05}

<!-- upstream_entity: Lokal beringter Raum/Funktion/Invertierbarkeit/Offen/Fakt -->

### Lema 7.16: keterbukaan lokus keterbalikan {#br-bgk-2019-l07-lem-02}

Untuk ruang berdering lokal $(X,\mathcal O_X)$ dan fungsi global
$f\in\Gamma(X,\mathcal O_X)$, himpunan

$$
X_f:=\{P\in X\mid f(P)\ne0\text{ di }\kappa(P)\}
$$

merupakan himpunan terbuka.

#### Bukti {#br-bgk-2019-l07-lem-02-proof}

Mula-mula, $f(P)=0$ di lapangan residu tepat ketika $f_P\in\mathfrak m_P$
di gelanggang lokal $\mathcal O_P$, dan ini tepat ketika $f$ tidak invertibel
di $\mathcal O_P$. Ambil $P\in X_f$. Maka $f$ invertibel di $\mathcal O_P$,
sehingga ada $g\in\mathcal O_P$ dengan

$$
gf=1.
$$

Ada lingkungan terbuka $P\in U\subseteq X$ tempat $g$ mempunyai representasi

$$
g\in\Gamma(U,\mathcal O_X),
$$

dan, mungkin setelah memperkecilnya, ada lingkungan terbuka $U'$ dengan

$$
fg=1.
$$

Jadi $f$ invertibel pada $U'$ dan

$$
P\in U'\subseteq X_f.
$$

Gabungan semua lingkungan terbuka seperti itu menunjukkan bahwa $X_f$
terbuka.

Himpunan titik tempat $f$, sebagai unsur tangkai $\mathcal O_P$, tidak nol
belum tentu terbuka; lihat Contoh 11.17.

<!-- upstream_entity: Lokal beringter Raum/Funktion/Invertierbarkeitsort/Definition -->

### Definisi 7.17: lokus keterbalikan {#br-bgk-2019-l07-def-10}

Untuk ruang berdering lokal $(X,\mathcal O_X)$ dan fungsi global
$f\in\Gamma(X,\mathcal O_X)$, himpunan

$$
X_f:=\{P\in X\mid f(P)\ne0\text{ di }\kappa(P)\}
$$

disebut *lokus keterbalikan* dari $f$.

Menurut Soal 7.20, $f$ merupakan satuan di
$\Gamma(X_f,\mathcal O_X)$.

<!-- upstream_entity: Lokal beringte Räume/Morphismus/Invertierbarkeitsort/Fakt -->

### Lema 7.18: prabayang lokus keterbalikan {#br-bgk-2019-l07-lem-03}

Misalkan $X$ dan $Y$ ruang berdering lokal dan
$\varphi:X\to Y$ sebuah morfisme ruang berdering lokal. Untuk setiap

$$
f\in\Gamma(Y,\mathcal O_Y)
$$

berlaku

$$
\varphi^{-1}(Y_f)=X_{\varphi^*f}.
$$

#### Bukti {#br-bgk-2019-l07-lem-03-proof}

Unsur $f$ merupakan satuan di $\Gamma(Y_f,\mathcal O_Y)$. Homomorfisme
gelanggang terinduksi menunjukkan bahwa $\varphi^*f$ merupakan satuan di

$$
\Gamma\bigl(\varphi^{-1}(Y_f),\mathcal O_X\bigr),
$$

sehingga

$$
\varphi^{-1}(Y_f)\subseteq X_{\varphi^*f}.
$$

Sebaliknya, ambil $P\in X_{\varphi^*f}$. Maka $\varphi^*f$ adalah satuan
di gelanggang lokal $\mathcal O_{X,P}$. Karena homomorfisme tangkai

$$
\mathcal O_{Y,\varphi(P)}\longrightarrow\mathcal O_{X,P}
$$

bersifat lokal, $f\in\mathcal O_{Y,\varphi(P)}$ juga merupakan satuan. Ini
berarti $\varphi(P)\in Y_f$, sehingga

$$
P\in\varphi^{-1}(Y_f).
$$

Kedua inklusi tersebut memberikan kesamaan yang diinginkan.
