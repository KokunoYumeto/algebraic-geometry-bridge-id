---
title: "Kuliah 21 - Skema Normal"
stable_id: br-bgk-2019-l21
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 21"
upstream_pageid: 109025
upstream_revid: 793614
upstream_timestamp: "2022-08-25T06:23:48Z"
upstream_mediawiki_sha1: 937e82c634f49d87e1555222366229d89f65aef0
source_url: "https://de.wikiversity.org/w/index.php?oldid=793614"
course_authority_manifest: authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json
course_authority_manifest_sha256: ea0bf346e261db8ed80b7565f7746e95c79e0c376d25d9fbce5d96879dff7dd8
authority_manifest: authority/wikiversity-bgk/unit-21/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 684637decc945c94137670f7c4238110b4a4c395287cf985b3f69adceedd9ef7
authority_manifest_status: "Bekuan authority terminal lengkap; 35 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
unit_capture_identity: authority/wikiversity-bgk/unit-21/CAPTURE_IDENTITY.json
unit_capture_identity_sha256: 869931efce9e3df0e42984b2db28fc367f93f113a8d632175ac0f9d7414cb791
lecture_api: authority/wikiversity-bgk/unit-21/lecture-21-api.json
lecture_api_sha256: 9dbf8ae5a489a2a6cb88cf63cf0220382a14f7fda7caf2f413e97d2b3bcf90d1
lecture_xml: authority/wikiversity-bgk/unit-21/lecture-21.xml
lecture_xml_sha256: e6b557402bf4338a73831da5d496b873bcec4c27f6ac317e7df5bbe0bb2427f8
lecture_html: authority/wikiversity-bgk/unit-21/lecture-21.html
lecture_html_sha256: c8c8dae22b766c2a17ab06b247677ada97feae22818fb2804bce6816fb0b6a64
lecture_expanded_tex: authority/wikiversity-bgk/unit-21/lecture-21-expanded.tex
lecture_expanded_tex_sha256: dc17c27ab323951d1301bb6c771d65ae3cc5f37f4631476145b61054e2926ff8
official_pdf: authority/artifacts/bgk-lecture-21-official.pdf
official_pdf_pages: 5
official_pdf_sha256: 31ddf1226d25837e8e79f15417008616f2d054337f06043feeea581b6d3ed606
official_pdf_metadata: authority/wikiversity-bgk/unit-21/official-pdfs-api.json
official_pdf_metadata_sha256: 4be79ab72566114ba54376bbb902cb00346bc9237e4d8ac988345b78cfc2a2ca
official_pdf_source_bytes: 60765
official_pdf_source_sha1: ca80c1b369883e1c6c9940ba58d42d1ed22e2746
older_course_pdf: authority/artifacts/bgk-course-official.pdf
older_course_pdf_pages: "186-189"
older_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
authority_precedence: "Revisi semantik Wikiversity yang dibekukan mengendalikan teks; PDF resmi tahun 2020 hanya saksi historis."
media_credits: source/id-ID/media-credits-bgk-unit-21.md
media_credits_sha256: 07ef5ecaa38890028ebbc245b3511bfb3eb8a29b174c8802dd84a3492496d814
rights_ledger: authority/RIGHTS-bgk-unit-21.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-21.json
asset_closure_sha256: 5fd26087ca516efbb8cbc6823c3622338bd9272eb7ab1452c87ba41c6e28afdd
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF adalah saksi authority, bukan teks edisi; metadata Commons CC BY-SA 4.0 dan pemberitahuan tertanam CC-by-sa 3.0 dipertahankan tanpa pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 21: Skema Normal {#br-bgk-2019-l21}

## Gelanggang normal {#br-bgk-2019-l21-s01}

<!-- upstream_entity: Kommutativer Ring/Totaler Quotientenring/Definition -->

### Definisi 21.1: gelanggang pecahan total {#br-bgk-2019-l21-def-01}

Misalkan $R$ gelanggang komutatif dan $S\subseteq R$ himpunan semua unsur
bukan pembagi nol dalam $R$. Pelokalan $R_S$ disebut *gelanggang pecahan
total* $R$ dan dilambangkan dengan

$$
Q(R).
$$

<!-- upstream_entity: Kommutativer Ring/Normal/Definition -->

### Definisi 21.2: gelanggang normal {#br-bgk-2019-l21-def-02}

Gelanggang komutatif disebut *normal* jika tertutup secara integral di dalam
gelanggang pecahan totalnya.

<!-- upstream_entity: Kommutativer Ring/Normalisierung/Definition -->

### Definisi 21.3: normalisasi {#br-bgk-2019-l21-def-03}

Misalkan $R$ gelanggang komutatif dan $Q(R)$ gelanggang pecahan totalnya.
Penutupan integral $R$ di dalam $Q(R)$ disebut *normalisasi* $R$.

<!-- upstream_entity: Achsenkreuz/Normalisierung/Beispiel -->

### Contoh 21.4: normalisasi salib sumbu {#br-bgk-2019-l21-exm-01}

Kita menentukan normalisasi gelanggang

$$
K[X,Y]/(XY)
$$

di atas suatu lapangan $K$. Unsur $X+Y$ bukan pembagi nol. Untuk unsur

$$
\frac{X-Y}{X+Y}\in Q(R)
$$

berlaku

$$
\left(\frac{X-Y}{X+Y}\right)^2
=\frac{(X-Y)^2}{(X+Y)^2}
=\frac{X^2+Y^2}{X^2+Y^2}
=1.
$$

Jadi unsur ini memenuhi persamaan keintegralan dan dengan demikian termasuk
normalisasi.

> **Catatan edisi - cakupan contoh sumber.** Sumber mengumumkan penentuan
> normalisasi, tetapi bagian yang tersedia hanya membuktikan bahwa unsur
> $(X-Y)/(X+Y)$ integral atas $R$. Edisi tidak melengkapi perhitungan yang
> tidak diberikan oleh sumber. Sumber juga beralih ke notasi $Q(R)$ tanpa
> terlebih dahulu menetapkan simbol $R$ bagi gelanggang yang ditampilkan.

## Gelanggang valuasi diskret {#br-bgk-2019-l21-s02}

<!-- upstream_entity: Kommutative Ringtheorie/Diskreter Bewertungsring/Definition -->

### Definisi 21.5: gelanggang valuasi diskret {#br-bgk-2019-l21-def-04}

Suatu *gelanggang valuasi diskret* $R$ adalah domain ideal utama yang,
hingga asosiasi, mempunyai tepat satu unsur prima.

<!-- upstream_entity: Diskreter Bewertungsring/Ordnung/Definition -->

### Definisi 21.6: orde {#br-bgk-2019-l21-def-05}

Misalkan $f\in R$, $f\ne0$, suatu unsur dalam gelanggang valuasi diskret
$R$ dengan unsur prima $p$. Bilangan $n\in\mathbb N$ yang memenuhi

$$
f=up^n,
$$

dengan $u$ suatu satuan, disebut *orde* $f$ dan dilambangkan dengan

$$
\operatorname{ord}(f).
$$

<!-- upstream_entity: Diskreter Bewertungsring/Ordnungsfunktion/Erste Eigenschaften/Fakt -->

### Lema 21.7: sifat-sifat orde {#br-bgk-2019-l21-lem-01}

Misalkan $R$ gelanggang valuasi diskret dengan ideal maksimal
$\mathfrak m=(p)$. Pemetaan orde

$$
R\setminus\{0\}\longrightarrow\mathbb N,
\qquad
f\longmapsto\operatorname{ord}(f),
$$

mempunyai sifat-sifat berikut.

1. Berlaku

   $$
   \operatorname{ord}(fg)
   =\operatorname{ord}(f)+\operatorname{ord}(g).
   $$

2. Berlaku

   $$
   \operatorname{ord}(f+g)
   \geq\min\{\operatorname{ord}(f),\operatorname{ord}(g)\}.
   $$

3. Berlaku $f\in\mathfrak m$ jika dan hanya jika
   $\operatorname{ord}(f)\geq1$.
4. Berlaku $f\in R^\times$ jika dan hanya jika
   $\operatorname{ord}(f)=0$.

#### Bukti {#br-bgk-2019-l21-lem-01-proof}

Lihat [Soal 21.7](worksheet-21.md#br-bgk-2019-w21-ex07).

> **Catatan edisi - domain fungsi orde.** Sumber mendefinisikan
> $\operatorname{ord}$ pada $R\setminus\{0\}$, tetapi bagian 2 tidak
> mengecualikan $f+g=0$. Pernyataan sumber dipertahankan; apabila
> $\operatorname{ord}(0)$ tidak didefinisikan, pertaksamaan itu hanya bermakna
> untuk $f+g\ne0$.

Kita mengutip teorema karakterisasi berikut. Secara khusus, teorema ini
menyatakan bahwa domain integral lokal normal berdimensi satu merupakan
gelanggang valuasi diskret, sehingga merupakan domain faktorisasi tunggal dan
bersifat reguler. Karena
itu, untuk suatu domain integral normal dan Noether $R$, semua pelokalan pada
ideal prima berketinggian $1$ merupakan gelanggang valuasi diskret.

<!-- upstream_entity: Diskrete Bewertungsringe/Charakterisierung/1/Fakt -->

### Teorema 21.8: karakterisasi gelanggang valuasi diskret {#br-bgk-2019-l21-thm-01}

Misalkan $R$ domain integral lokal dan Noether yang mempunyai tepat dua
ideal prima

$$
0\subset\mathfrak m.
$$

Pernyataan-pernyataan berikut ekuivalen.

1. $R$ merupakan gelanggang valuasi diskret.
2. $R$ merupakan domain ideal utama.
3. $R$ merupakan domain faktorisasi tunggal.
4. $R$ normal.
5. $\mathfrak m$ merupakan ideal utama.

<!-- upstream_entity: Diskreter Bewertungsrin/K/Restklassenkörper/Ordnung/Fakt -->

### Lema 21.9: orde sebagai dimensi ruang vektor {#br-bgk-2019-l21-lem-02}

Misalkan $K$ lapangan dan $B$ gelanggang valuasi diskret di atas $K$ yang
lapangan residunya sama dengan $K$. Untuk setiap $f\in B$, $f\ne0$, orde
$f$ sama dengan dimensi ruang vektor atas $K$ dari $B/(f)$:

$$
\operatorname{ord}(f)=\dim_K(B/(f)).
$$

#### Bukti {#br-bgk-2019-l21-lem-02-proof}

Pernyataan ini mengikuti dari
[Soal 21.2](worksheet-21.md#br-bgk-2019-w21-ex02) melalui induksi pada orde
$f$.

## Skema normal {#br-bgk-2019-l21-s03}

<!-- upstream_entity: Normales Schema/Einführung/Textabschnitt -->

### Definisi 21.10: skema normal {#br-bgk-2019-l21-def-06}

Suatu skema $X$ disebut *normal* jika setiap gelanggang lokal
$\mathcal O_x$, untuk $x\in X$, merupakan gelanggang normal.

### Lema 21.11: kriteria afin bagi kenormalan {#br-bgk-2019-l21-lem-03}

Untuk suatu skema $(X,\mathcal O_X)$, sifat-sifat berikut ekuivalen.

1. $X$ normal.
2. Untuk setiap subhimpunan terbuka afin $U=\operatorname{Spek}(R)$ dari
   $X$, gelanggang $R$ normal.
3. Terdapat penutup terbuka afin

   $$
   X=\bigcup_{i\in I}U_i,
   \qquad
   U_i=\operatorname{Spek}(R_i),
   $$

   dengan setiap $R_i$ gelanggang normal.

#### Bukti {#br-bgk-2019-l21-lem-03-proof}

Implikasi $(2)\Rightarrow(3)$ langsung. Andaikan (3)
berlaku. Untuk setiap titik $x\in X$, terdapat lingkungan terbuka afin

$$
x\in U=\operatorname{Spek}(R)\subseteq X
$$

dengan $R$ normal. Dalam hal ini

$$
\mathcal O_x=R_{\mathfrak p}
$$

untuk suatu ideal prima $\mathfrak p$ dari $R$. Menurut
[Teorema 42.3 dalam Aljabar Komutatif](https://de.wikiversity.org/wiki/Kommutative_Ringtheorie/Normal/Nenneraufnahme_ist_normal/Fakt),
$R_{\mathfrak p}$ juga normal.

> **Catatan edisi - arah implikasi dalam sumber.** Sumber menyatakan tiga
> sifat yang ekuivalen dan memberikan $(2)\Rightarrow(3)$ serta
> $(3)\Rightarrow(1)$, tetapi tidak menuliskan argumen untuk
> $(1)\Rightarrow(2)$. Edisi tidak menciptakan bukti yang tidak tersedia.

<!-- upstream_entity: Normaler noetherscher Bereich/Durchschnitt/Lokalisierungen zur Höhe 1/Fakt -->

### Teorema 21.12: perpotongan pelokalan berketinggian satu {#br-bgk-2019-l21-thm-02}

Misalkan $R$ domain integral normal dan Noether. Maka

$$
R=\bigcap_{\mathfrak p}R_{\mathfrak p},
$$

dengan $\mathfrak p$ merentang semua ideal prima berketinggian $1$ dari
$R$.

#### Bukti {#br-bgk-2019-l21-thm-02-proof}

Misalkan $f=g/h\in Q(R)$ dan andaikan $f\notin R$. Menurut
[Lema 44.12 dalam Aljabar Komutatif](https://de.wikiversity.org/wiki/Noetherscher_Integrit%C3%A4tsbereich/Durchschnittseigenschaft/Assoziierte_Primideale/Fakt),
terdapat ideal prima $\mathfrak p$ yang terasosiasi dengan suatu gelanggang
faktor oleh ideal utama dan memenuhi

$$
f\notin R_{\mathfrak p}.
$$

Dengan demikian, $\mathfrak p$ adalah ideal anihilator suatu unsur $x$
modulo ideal utama $(y)$. Melalui pelokalan, kita boleh mengandaikan bahwa
$\mathfrak p$ merupakan ideal maksimal $R$. Tinjau submodul-$R$

$$
N=\{q\in Q(R)\mid q\mathfrak p\subseteq R\}\subseteq Q(R).
$$

Kita mempunyai

$$
\mathfrak p\subseteq\mathfrak pN\subseteq R.
$$

Karena $\mathfrak p$ maksimal, berlaku

$$
\mathfrak p=\mathfrak pN
$$

atau

$$
\mathfrak pN=R.
$$

Dalam kasus pertama,
[Lema 41.7 dalam Aljabar Komutatif](https://de.wikiversity.org/wiki/Kommutative_Ringtheorie/Ganzheit/Ganzes_Element/Charakterisierung/Fakt)
menyatakan bahwa unsur-unsur $N$ integral atas $R$. Kenormalan $R$ kemudian
memberi $N=R$.
Karena

$$
x\mathfrak p\subseteq(y),
$$

kita juga mempunyai

$$
\frac{x}{y}\mathfrak p\subseteq R,
$$

sehingga

$$
\frac{x}{y}\in N=R,
$$

suatu kontradiksi. Jadi berlaku kasus kedua, $\mathfrak pN=R$. Karena itu
terdapat $a\in\mathfrak p$ dan $q\in N$ yang memenuhi

$$
aq=1.
$$

Untuk $b\in\mathfrak p$, kita kemudian mempunyai

$$
bq=\frac ba\in R.
$$

Jadi $b\in(a)$ dan dengan demikian $\mathfrak p=(a)$ merupakan ideal utama.
Menurut [Teorema 21.8](#br-bgk-2019-l21-thm-01), $R$ merupakan gelanggang
valuasi diskret dan $\mathfrak p$ mempunyai ketinggian $1$.

> **Catatan edisi - pergantian notasi dalam bukti.** Bukti sumber mula-mula
> menulis $f=g/h$, lalu memperkenalkan kelas $x$ modulo $(y)$ dan menggunakan
> pecahan $x/y$ tanpa menyatakan hubungan notasi itu dengan $g/h$. Edisi
> mempertahankan urutan argumen sumber dan tidak menambahkan identifikasi yang
> tidak diberikan.
