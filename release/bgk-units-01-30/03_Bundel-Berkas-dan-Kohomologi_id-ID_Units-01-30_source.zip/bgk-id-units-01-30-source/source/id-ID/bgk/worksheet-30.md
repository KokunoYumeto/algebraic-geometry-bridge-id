---
title: "Lembar Kerja 30 - Teorema Riemann–Roch"
stable_id: br-bgk-2019-w30
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 30"
upstream_pageid: 110239
upstream_revid: 991891
upstream_timestamp: "2025-01-23T14:50:11Z"
upstream_mediawiki_sha1: fd0f75147d3f8a494f1238b4cf4b400b35fcc871
source_url: "https://de.wikiversity.org/w/index.php?oldid=991891"
authority_manifest: authority/wikiversity-bgk/unit-30/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 956990c5550c5fa417f3441dc1bb8f093acbdbb8fe1064ae37c384fa17b8fcb0
ordered_exercise_map: authority/wikiversity-bgk/unit-30/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 3bbf65672ab614c8f88caa438f06230328a87849a245447ae3207be682a59ecc
candidate_evidence: authority/wikiversity-bgk/unit-30/worksheet-solution-candidates-api.json
candidate_evidence_sha256: 3ffdcede4d7bb2407ad0028ad3f8e18046b6142814bb7dcfe89dd3551a4b498a
exercise_count: 5
public_solution_count: 0
public_solution_numbers: ""
official_course_pdf: authority/artifacts/bgk-course-official.pdf
media_credits: source/id-ID/media-credits-bgk-unit-30.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponennya sendiri; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 30: Teorema Riemann–Roch {#br-bgk-2019-w30}

<!-- upstream_entity: Projektive Gerade/Riemann-Roch/Direkt/Aufgabe -->
### Soal 30.1 {#br-bgk-2019-w30-ex01}

Buktikan Teorema Riemann–Roch secara langsung untuk garis projektif.

<!-- upstream_entity: Glatte Ebene Kurve/Syzygienbündel/Gradberechnung/Aufgabe -->
### Soal 30.2 {#br-bgk-2019-w30-ex02}

Misalkan $f\in K[X,Y,Z]$ polinomial homogen berderajat $e$ di atas lapangan
tertutup secara aljabar $K$ sedemikian sehingga

$$
C=\operatorname{Proj}(K[X,Y,Z]/(f))\subseteq\mathbb P^2_K
$$

merupakan kurva projektif mulus. Misalkan
$g_1,\ldots,g_n\in K[X,Y,Z]$ unsur-unsur homogen berderajat
$d_1,\ldots,d_n$ sedemikian sehingga $D_+(g_i)$ menutupi kurva. Pandang
$g_i$ sebagai homomorfisme berkas

$$
\mathcal O_C(-d_i)\longrightarrow\mathcal O_C,
\qquad h\longmapsto hg_i,
$$

atau, untuk $m\in\mathbb Z$,

$$
\mathcal O_C(m-d_i)\longrightarrow\mathcal O_C(m),
\qquad h\longmapsto hg_i.
$$

1. Buktikan bahwa homomorfisme berkas
   $$
   \bigoplus_{i=1}^{n}\mathcal O_C(m-d_i)
   \longrightarrow\mathcal O_C(m)
   $$
   surjektif.
2. Misalkan $\operatorname{Syz}(g_1,\ldots,g_n)(m)$ berkas kernel
   homomorfisme pada bagian (1). Buktikan bahwa berkas ini bebas lokal.
3. Tentukan rank $\operatorname{Syz}(g_1,\ldots,g_n)(m)$.
4. Tentukan derajat $\operatorname{Syz}(g_1,\ldots,g_n)(m)$.

<!-- upstream_entity: Projektive Gerade/Rang 2/Grad 0/Schnitte/Aufgabe -->
### Soal 30.3 {#br-bgk-2019-w30-ex03}

Berikan contoh pada garis projektif $\mathbb P^1_K$ berupa berkas bebas lokal
ber-rank $2$ dan berderajat $0$ sedemikian sehingga dimensi seksi globalnya dapat
dibuat sebesar apa pun.

> **Catatan edisi (sumber).** Badan soal sumber kehilangan nilai sesudah kata
> “berderajat”, sedangkan judul entitas resmi menyatakan `Grad 0`. Edisi ini
> memulihkan derajat $0$ agar badan soal sesuai dengan identitas entitasnya.

<!-- upstream_entity: Projektive Ebene/Kotangentialbündel/Einschränkung/Gerade/Aufgabe -->
### Soal 30.4 {#br-bgk-2019-w30-ex04}

Misalkan, sebagaimana pada Teorema 19.8,

$$
\operatorname{Syz}(x,y,z)\cong\Omega_{\mathbb P^2_K\mid K}
$$

berkas kotangen pada bidang projektif, dan misalkan
$L\subseteq\mathbb P^2_K$ garis projektif. Buktikan

$$
\operatorname{Syz}(x,y,z)|_L
\cong\mathcal O_L(-1)\oplus\mathcal O_L(-2).
$$

<!-- upstream_entity: Projektive Ebene/Kotangentialbündel/Einschränkung/Quadrik/Aufgabe -->
### Soal 30.5 {#br-bgk-2019-w30-ex05}

Misalkan, sebagaimana pada Teorema 19.8,

$$
\operatorname{Syz}(x,y,z)\cong\Omega_{\mathbb P^2_K\mid K}
$$

berkas kotangen pada bidang projektif, dan misalkan
$C=V_+(F)\subseteq\mathbb P^2_K$ kuadrik mulus. Buktikan bahwa
$\operatorname{Syz}(x,y,z)|_C$ mempunyai dekomposisi langsung sebagai jumlah
dua berkas invertibel. Gunakan suatu isomorfisme
$\mathbb P^1_K\cong C$.
