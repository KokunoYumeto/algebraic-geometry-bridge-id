---
title: "Kuliah 11 - Ruang Tak Tereduksi dan Skema Noether"
stable_id: br-bgk-2019-l11
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 11"
upstream_pageid: 109015
upstream_revid: 1019976
upstream_timestamp: "2025-08-09T13:36:06Z"
upstream_mediawiki_sha1: dc9c24551d94791f407b85a6f32d01b16db66218
source_url: "https://de.wikiversity.org/w/index.php?oldid=1019976"
authority_manifest: authority/wikiversity-bgk/unit-11/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: c55c715d0a1bd3ef5b13ac96ccf38f9b5c261e87124c6da5ccc5984cb61deb09
lecture_xml: authority/wikiversity-bgk/unit-11/lecture-11.xml
lecture_xml_sha256: e9b4b62c76baa6de50115714db97c773a298cb9ec831d535b971c0f1836a67f5
lecture_expanded_tex: authority/wikiversity-bgk/unit-11/lecture-11-expanded.tex
lecture_expanded_tex_sha256: 96a022fe9c9c7f174e51fb55668f179713d052eb0c37c6e24fbd39550e6c27e7
official_pdf: authority/artifacts/bgk-lecture-11-official.pdf
official_pdf_sha256: 011e4366b05a93c260db17ab966ab28464afd5cbb9e8df8158dcf25eaa4b40ff
media_credits: source/id-ID/media-credits-bgk-unit-11.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 11: Ruang Tak Tereduksi dan Skema Noether {#br-bgk-2019-l11}

Dibandingkan dengan ruang metrik, sebuah skema mempunyai sifat-sifat
topologis yang agak tidak biasa. Kita mulai dengan ketaktereduksian.

## Ruang tak tereduksi {#br-bgk-2019-l11-s01}

<!-- upstream_entity: Topologie/Irreduzibler Raum/Definition -->

### Definisi 11.1: ruang tak tereduksi {#br-bgk-2019-l11-def-01}

Ruang topologis $V$ disebut *tak tereduksi* jika $V\ne\varnothing$ dan tidak
ada penguraian

$$
V=Y\cup Z
$$

dengan $Y,Z\subsetneq V$ keduanya tertutup.

<!-- upstream_entity: Topologie/Irreduzibler Raum/Charakterisierung/Fakt -->

### Lema 11.2: karakterisasi melalui irisan terbuka {#br-bgk-2019-l11-lem-01}

Ruang topologis tak kosong $X$ tak tereduksi jika dan hanya jika untuk setiap
dua himpunan terbuka tak kosong $U,V\subseteq X$, irisan $U\cap V$ juga tak
kosong.

#### Bukti {#br-bgk-2019-l11-lem-01-proof}

Hal ini langsung mengikuti definisi. Untuk himpunan tertutup
$Y=X\setminus U$ dan $Z=X\setminus V$, kesamaan $X=Y\cup Z$ berlaku tepat
ketika $U\cap V=\varnothing$.

Sebuah subhimpunan $Y\subseteq X$ dari ruang topologis $X$ disebut tak
tereduksi jika $Y$, dengan topologi terinduksi, merupakan ruang topologis tak
tereduksi.

<!-- upstream_entity: Affines Schema/Irreduzible Teilmenge/Primideal/Fakt -->

### Lema 11.3: himpunan tertutup tak tereduksi pada spektrum {#br-bgk-2019-l11-lem-02}

Misalkan $R$ gelanggang komutatif dan $\mathfrak a\subseteq R$ sebuah ideal.
Himpunan tertutup

$$
V(\mathfrak a)\subseteq\operatorname{Spek}(R)
$$

tak tereduksi jika dan hanya jika radikal $\mathfrak a$ merupakan ideal
prima.

#### Bukti {#br-bgk-2019-l11-lem-02-proof}

Kita dapat langsung menganggap bahwa $\mathfrak a$ adalah ideal radikal.
Selain itu, $\mathfrak a$ bukan ideal satuan. Jika $V(\mathfrak a)$ tidak tak
tereduksi, terdapat penguraian tak trivial

$$
V(\mathfrak a)=Y\cup Z=V(\mathfrak b)\cup V(\mathfrak c),
$$

dan kita dapat menganggap $\mathfrak b$ serta $\mathfrak c$ radikal. Ini
berarti

$$
\mathfrak a=\mathfrak b\cap\mathfrak c.
$$

Karena $V(\mathfrak b),V(\mathfrak c)\subsetneq V(\mathfrak a)$, menurut
Proposisi 8.4(5) berlaku

$$
\mathfrak a\subsetneq\mathfrak b,
\qquad
\mathfrak a\subsetneq\mathfrak c.
$$

Jadi ada $f\in\mathfrak b\setminus\mathfrak a$ dan
$g\in\mathfrak c\setminus\mathfrak a$. Akan tetapi,

$$
fg\in\mathfrak b\cap\mathfrak c=\mathfrak a,
$$

sehingga $\mathfrak a$ bukan ideal prima.

Sebaliknya, jika $\mathfrak a$ bukan ideal prima, ada
$f,g\notin\mathfrak a$ dengan $fg\in\mathfrak a$. Maka

$$
D(fg)\subseteq D(\mathfrak a),
\qquad
D(fg)\cap V(\mathfrak a)=\varnothing.
$$

Karena $\mathfrak a$ radikal, $f^n\notin\mathfrak a$ untuk setiap
$n\in\mathbb N$. Menurut Soal 8.5, terdapat ideal prima $\mathfrak p$ dengan

$$
f\notin\mathfrak p,
\qquad
\mathfrak a\subseteq\mathfrak p.
$$

Jadi $D(f)\cap V(\mathfrak a)\ne\varnothing$, dan hal yang sama berlaku untuk
$D(g)$. Karena

$$
D(f)\cap D(g)\cap V(\mathfrak a)
=D(fg)\cap V(\mathfrak a)=\varnothing,
$$

Lema 11.2 menunjukkan bahwa $V(\mathfrak a)$ tidak tak tereduksi.

Dengan demikian, korespondensi

$$
\mathfrak p\longleftrightarrow V(\mathfrak p)
$$

menghubungkan ideal-ideal prima dengan subhimpunan tertutup tak tereduksi
dari spektrum. Ideal maksimal bersesuaian dengan titik tertutup tunggal,
sedangkan ideal prima minimal bersesuaian dengan komponen tak tereduksi dari
spektrum yang akan dibahas di bawah.

<!-- upstream_entity: Topologischer Raum/Irreduzible Teilmenge/Generischer Punkt/Definition -->

### Definisi 11.4: titik generik {#br-bgk-2019-l11-def-02}

Misalkan $X$ ruang topologis dan $Y\subseteq X$ subhimpunan tertutup tak
tereduksi. Titik $\eta\in Y$ disebut *titik generik* dari $Y$ jika untuk setiap
himpunan terbuka $U\subseteq X$ berlaku

$$
U\cap Y\ne\varnothing
\quad\Longleftrightarrow\quad
\eta\in U.
$$

<!-- upstream_entity: Schema/Irreduzible Teilmenge/Generischer Punkt/Fakt -->

### Lema 11.5: keberadaan dan ketunggalan titik generik {#br-bgk-2019-l11-lem-03}

Dalam sebuah skema $X$, setiap subhimpunan tertutup tak tereduksi
$Y\subseteq X$ mempunyai tepat satu titik generik.

#### Bukti {#br-bgk-2019-l11-lem-03-proof}

Menurut asumsi, $Y$ tidak kosong. Ambil $P\in Y$ dan lingkungan afin terbuka

$$
P\in W=\operatorname{Spek}(R).
$$

Maka $Y\cap W$ adalah subhimpunan tertutup tak tereduksi dari skema afin
$W$. Menurut Lema 11.3,

$$
Y\cap W=V(\mathfrak p)
$$

untuk suatu ideal prima $\mathfrak p\in W$. Kita klaim bahwa $\mathfrak p$
adalah titik generik $Y$. Jika $U\subseteq X$ terbuka dan
$Y\cap U\ne\varnothing$, maka ketaktereduksian $Y$ memberi

$$
Y\cap U\cap W\ne\varnothing,
$$

sehingga $\mathfrak p\in U$. Titik generik itu tunggal karena, sebagai titik
di dalam skema afin $W$, ia ditentukan secara tunggal.

## Dimensi Krull {#br-bgk-2019-l11-s02}

<!-- upstream_entity: Topologischer Raum/Krulldimension/Definition -->

### Definisi 11.6: dimensi Krull ruang topologis {#br-bgk-2019-l11-def-03}

Untuk ruang topologis $X$, panjang maksimum rantai subhimpunan tertutup tak
tereduksi

$$
X_0\subsetneq X_1\subsetneq\cdots\subsetneq X_{n-1}\subsetneq X_n
$$

di dalam $X$ disebut *dimensi Krull* ruang tersebut.

<!-- upstream_entity: Affines Schema/Krulldimension/Fakt -->

### Lema 11.7: dimensi gelanggang dan spektrumnya {#br-bgk-2019-l11-lem-04}

Dimensi Krull gelanggang komutatif $R$ sama dengan dimensi Krull spektrumnya
$\operatorname{Spek}(R)$.

#### Bukti {#br-bgk-2019-l11-lem-04-proof}

Pernyataan mengikuti Lema 11.3 dan Proposisi 8.4(5).

## Ruang Noether {#br-bgk-2019-l11-s03}

<!-- upstream_entity: Topologischer Raum/Noethersch/Offene Mengen/Definition -->

### Definisi 11.8: ruang topologis Noether {#br-bgk-2019-l11-def-04}

Ruang topologis $X$ disebut *Noether* jika setiap rantai naik himpunan
terbuka

$$
U_1\subseteq U_2\subseteq U_3\subseteq\cdots
$$

menjadi stasioner, yakni terdapat $n$ sehingga

$$
U_n=U_{n+1}=U_{n+2}=\cdots.
$$

<!-- upstream_entity: Topologischer Raum/Noethersch/Quasikompakt/Fakt -->

### Lema 11.9: karakterisasi melalui kekuasikompakan {#br-bgk-2019-l11-lem-05}

Ruang topologis $X$ Noether jika dan hanya jika setiap subhimpunan terbukanya
kuasikompak.

#### Bukti {#br-bgk-2019-l11-lem-05-proof}

Setiap subhimpunan terbuka dari ruang Noether juga Noether. Untuk arah maju,
cukup dibuktikan bahwa $X$ kuasikompak. Misalkan

$$
X=\bigcup_{i\in I}U_i
$$

penutup terbuka dan andaikan tidak ada subpenutup berhingga. Maka dapat
dibangun rantai naik tegas tak berhingga dari himpunan terbuka

$$
V_n=\bigcup_{i\in I_n}U_i,
$$

dengan setiap $I_n\subseteq I$ berhingga, bertentangan dengan sifat Noether.

Sebaliknya, andaikan setiap himpunan terbuka kuasikompak dan diberikan rantai
naik $U_k\subseteq U_{k+1}$. Himpunan

$$
U=\bigcup_{k\in\mathbb N}U_k
$$

terbuka dan kuasikompak, sehingga penutup tersebut mempunyai subpenutup
berhingga. Jadi ada indeks $n$ dengan $U_n=U_k$ untuk semua $k\ge n$.

Dalam ruang Noether, setiap koleksi tak kosong dari himpunan terbuka
(masing-masing, himpunan tertutup) mempunyai unsur maksimal (masing-masing,
minimal). Sifat ini memberi prinsip bukti melalui *induksi Noether*. Untuk
membuktikan bahwa suatu sifat $E$ berlaku bagi semua himpunan tertutup,
andaikan terdapat himpunan tertutup yang tidak memenuhi $E$ dan pilih yang
minimal. Himpunan itu kemudian harus menghasilkan kontradiksi. Prinsip ini
sah karena dari koleksi tak kosong tanpa unsur minimal dapat dibangun rantai
turun tak berhingga.

<!-- upstream_entity: Topologischer Raum/Noethersch/Zerlegung in irreduzible Komponenten/Fakt -->

### Teorema 11.10: komponen tak tereduksi {#br-bgk-2019-l11-thm-01}

Setiap ruang topologis Noether $X$ mempunyai penguraian tak redundan yang
tunggal

$$
X=V_1\cup\cdots\cup V_k
$$

menjadi subhimpunan tertutup tak tereduksi; *tak redundan* berarti tidak ada
$V_i$ yang termuat dalam $V_j$ untuk $i\ne j$.

#### Bukti {#br-bgk-2019-l11-thm-01-proof}

Keberadaan dibuktikan dengan induksi Noether pada subhimpunan tertutup dari
$X$. Andaikan tidak setiap subhimpunan tertutup mempunyai penguraian seperti
itu. Maka ada subhimpunan minimal, katakanlah $V\subseteq X$, yang tidak
mempunyainya. Himpunan $V$ tidak mungkin tak tereduksi, sehingga ada
penguraian tak trivial

$$
V=V_1\cup V_2.
$$

Karena $V_1$ dan $V_2$ merupakan subhimpunan sejati dari $V$, masing-masing
mempunyai penguraian berhingga sebagai gabungan subhimpunan tertutup tak
tereduksi. Menggabungkan kedua penguraian itu memberi penguraian berhingga
bagi $V$, sebuah kontradiksi.

Untuk ketunggalan, misalkan

$$
X=V_1\cup\cdots\cup V_k=W_1\cup\cdots\cup W_m
$$

dua penguraian menjadi subhimpunan tak tereduksi, masing-masing tanpa relasi
inklusi. Maka

$$
\begin{aligned}
V_1
&=V_1\cap X\\
&=V_1\cap(W_1\cup\cdots\cup W_m)\\
&=(V_1\cap W_1)\cup\cdots\cup(V_1\cap W_m).
\end{aligned}
$$

Karena $V_1$ tak tereduksi, ada $j$ dengan $V_1\subseteq W_j$. Dengan argumen
yang sama, ada $i$ dengan $W_j\subseteq V_i$. Ketakredundanan memaksa $i=1$
dan $V_1=W_j$. Setiap $V_i$ lain ditemukan dengan cara yang sama di
penguraian sebelah kanan, sehingga penguraiannya tunggal.

> **Catatan edisi - syarat ketakredundanan.** Pernyataan sumber hanya menulis
> “penguraian tunggal”, sedangkan buktinya baru mensyaratkan “masing-masing
> tanpa relasi inklusi” ketika membandingkan dua penguraian. Edisi membawa
> syarat yang diperlukan itu ke pernyataan; komponen dan argumen sumber tidak
> diubah.

Himpunan-himpunan yang muncul dalam penguraian ini disebut *komponen tak
tereduksi* ruang tersebut.

<!-- upstream_entity: Schema/Noethersch/Definition -->

### Definisi 11.11: skema Noether {#br-bgk-2019-l11-def-05}

Sebuah skema $X$ disebut *Noether* jika dapat ditutup oleh berhingga banyak
skema afin yang terkait dengan gelanggang Noether.

Secara khusus, spektrum gelanggang Noether merupakan skema Noether.

<!-- upstream_entity: Noethersches Schema/Noetherscher Raum/Fakt -->

### Lema 11.12: topologi skema Noether {#br-bgk-2019-l11-lem-06}

Sebuah skema Noether merupakan ruang topologis Noether.

#### Bukti {#br-bgk-2019-l11-lem-06-proof}

Gabungan berhingga ruang Noether kembali Noether, sehingga cukup dibahas
spektrum sebuah gelanggang Noether. Menurut Lema 11.9, kita harus menunjukkan
bahwa setiap himpunan terbuka

$$
U=D(\mathfrak a)\subseteq\operatorname{Spek}(R)
$$

kuasikompak. Karena $R$ Noether,

$$
\mathfrak a=(f_1,\ldots,f_n),
$$

dan menurut Proposisi 8.4(2),

$$
D(\mathfrak a)=D(f_1)\cup\cdots\cup D(f_n).
$$

Korolari 8.6 bersama Proposisi 8.11 menyatakan bahwa setiap $D(f_i)$
kuasikompak, sehingga gabungan berhingganya juga kuasikompak.

Metode topologis ini langsung memberi hasil aljabar murni berikut.

<!-- upstream_entity: Noetherscher Ring/Minimale Primideale/Endlich/Fakt -->

### Lema 11.13: ideal prima minimal berhingga banyak {#br-bgk-2019-l11-lem-07}

Dalam gelanggang komutatif Noether hanya terdapat berhingga banyak ideal
prima minimal.

#### Bukti {#br-bgk-2019-l11-lem-07-proof}

Lihat Soal 11.15.

## Skema integral {#br-bgk-2019-l11-s04}

<!-- upstream_entity: Beringter Raum/Reduziert/Offene Mengen/Definition -->

### Definisi 11.14: ruang berdering tereduksi {#br-bgk-2019-l11-def-06}

Ruang berdering $(X,\mathcal O_X)$ disebut *tereduksi* jika untuk setiap
himpunan terbuka $U\subseteq X$, gelanggang
$\Gamma(U,\mathcal O_X)$ tereduksi.

<!-- upstream_entity: Schema/Integer/Irreduzibel und reduziert/Definition -->

### Definisi 11.15: skema integral {#br-bgk-2019-l11-def-07}

Sebuah skema $X$ disebut *integral* jika tak tereduksi dan tereduksi.

<!-- upstream_entity: Integres Schema/Injektive Restriktionen/Fakt -->

### Lema 11.16: restriksi pada skema integral bersifat injektif {#br-bgk-2019-l11-lem-08}

Dalam skema integral, pemetaan restriksi

$$
\Gamma(U,\mathcal O_X)\longrightarrow\Gamma(V,\mathcal O_X)
$$

injektif untuk setiap $\varnothing\ne V\subseteq U\subseteq X$ yang terbuka.

#### Bukti {#br-bgk-2019-l11-lem-08-proof}

Ambil $0\ne f\in\Gamma(U,\mathcal O_X)$. Himpunan

$$
U_f=\{P\in U\mid f(P)\ne0\}
$$

terbuka menurut Lema 7.16 dan, karena ketereduksian, tidak kosong. Karena $X$
tak tereduksi, $U_f\cap V$ juga tidak kosong. Jadi restriksi $f$ pada $V$
tidak nol.

> **Catatan edisi - domain seksi.** Sumber menamai himpunan di atas $X_f$ dan
> menulis $P\in X$, padahal $f$ hanya diberikan sebagai seksi pada $U$.
> Edisi menulis $U_f$ dan $P\in U$; lokus tak nol dan argumen injektivitasnya
> tidak berubah.

<!-- upstream_entity: Irreduzibel/Restriktionsabbildung nicht injektiv/Beispiel -->

### Contoh 11.17: ketaktereduksian saja tidak cukup {#br-bgk-2019-l11-exa-01}

Misalkan $K$ lapangan dan

$$
R=K[X,Y]/(X^2,XY).
$$

Ideal $\mathfrak q=(X)$ adalah satu-satunya ideal prima minimal dari $R$,
sehingga $\operatorname{Spek}(R)$ tak tereduksi. Karena
$Y\notin\mathfrak q$ dan $XY=0$, di dalam pelokalan $R_{\mathfrak q}$ berlaku
$X=0$, dan

$$
R_{\mathfrak q}=K[Y]_{(0)}=K(Y)
$$

merupakan lapangan. Pemetaan restriksi $R\to R_{\mathfrak q}$ tidak
injektif. Selain itu,

$$
D(X)=\varnothing,
$$

tetapi unsur $X$ tidak nol di dalam pelokalan $R_{(X,Y)}$.

<!-- upstream_entity: Integres Schema/Integritätsbereich/Fakt -->

### Lema 11.18: gelanggang seksi adalah domain integral {#br-bgk-2019-l11-lem-09}

Dalam skema integral $X$, untuk setiap himpunan terbuka tak kosong
$U\subseteq X$, gelanggang seksi $\Gamma(U,\mathcal O_X)$ merupakan domain
integral.

#### Bukti {#br-bgk-2019-l11-lem-09-proof}

Karena $U$ terbuka dan tidak kosong, terdapat himpunan terbuka afin tak kosong

$$
V=\operatorname{Spek}(R)\subseteq U.
$$

Menurut Lema 11.16, cukup dibuktikan bahwa $R$ domain integral. Misalkan
$\mathfrak a$ nilradikal $R$. Karena $V$ tak tereduksi sebagai akibat
ketaktereduksian $X$, Lema 11.3 menyatakan bahwa $\mathfrak a$ ideal prima.
Ketereduksian adalah sifat lokal menurut Soal 11.18, sehingga
$\mathfrak a=0$. Jadi ideal nol prima, dan $R$ merupakan domain integral.

> **Catatan edisi - nomor soal sumber.** Sumber merujuk ke Soal 10.14, tetapi
> Lembar Kerja 10 yang dibekukan hanya mempunyai enam soal. Soal 11.18 yang
> dibekukan tepat menyatakan ekuivalensi antara ketereduksian ruang berdering
> dan ketereduksian semua tangkainya. Edisi memperbaiki nomor silang menjadi
> 11.18 dan mempertahankan fakta sumber yang salah dalam catatan ini.

<!-- upstream_entity: Integres Schema/Generischer Halm/Körper/Fakt -->

### Lema 11.19: tangkai generik adalah lapangan {#br-bgk-2019-l11-lem-10}

Untuk skema integral, tangkai berkas struktur di titik generik merupakan
lapangan.

#### Bukti {#br-bgk-2019-l11-lem-10-proof}

Tangkai itu dapat dihitung dari sembarang himpunan terbuka afin tak kosong.
Himpunan tersebut berbentuk

$$
U=\operatorname{Spek}(R),
$$

dengan $R$ gelanggang komutatif yang merupakan domain integral menurut Lema
11.18. Titik generiknya bersesuaian dengan ideal nol, dan pelokalan pada ideal
nol menghasilkan lapangan pecahan $R$.

<!-- upstream_entity: Integres Schema/Funktionenkörper/Definition -->

### Definisi 11.20: lapangan fungsi {#br-bgk-2019-l11-def-08}

Untuk skema integral $X$, tangkai berkas struktur di titik generik disebut
*lapangan fungsi* $X$.

Dalam skema integral, gelanggang seksi pada setiap himpunan terbuka tak kosong
merupakan subgelanggang lapangan fungsi.
