---
title: "Lembar Kerja 16 - Berkas Bebas Lokal"
stable_id: br-bgk-2019-w16
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 16"
upstream_pageid: 110223
upstream_revid: 619454
upstream_timestamp: "2020-02-17T16:19:33Z"
upstream_mediawiki_sha1: 24134a0ca04b3c50ce0559772d5870e22c79401a
source_url: "https://de.wikiversity.org/w/index.php?oldid=619454"
authority_manifest: null
authority_manifest_status: "Tidak diterbitkan oleh proses capture; pengikatan audit memakai permukaan individual persis di bawah ini."
worksheet_api: authority/wikiversity-bgk/unit-16/worksheet-16-api.json
worksheet_api_sha256: ff6db5399f5db8602d7580bde3262b2ea3313c2c12ad4887b745c12fa733c189
worksheet_xml: authority/wikiversity-bgk/unit-16/worksheet-16.xml
worksheet_xml_sha256: 96cded28a6359e233f24552c42fd53be657452e16e4d13ca132298c09fc5ba60
worksheet_expanded_tex: authority/wikiversity-bgk/unit-16/worksheet-16-expanded.tex
worksheet_expanded_tex_sha256: fd1035bbdc57bb7ff9da79f1ea0d26d2e17666b33e373c4c36f23f2c2ce3500a
course_authority_manifest: authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json
course_authority_manifest_sha256: ea0bf346e261db8ed80b7565f7746e95c79e0c376d25d9fbce5d96879dff7dd8
official_course_pdf: authority/artifacts/bgk-course-official.pdf
official_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
official_course_pdf_pages: "145-148"
ordered_exercise_map: authority/wikiversity-bgk/unit-16/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: da420bada3728eb5f3fcf0a6c0ed7e75c1dd792b9ed99f1579a5acf7e7500526
candidate_evidence: authority/wikiversity-bgk/unit-16/worksheet-solution-candidates-api.json
candidate_evidence_sha256: 022a9d9912991339073c1768b0ac14ff886b6bbb9c601778ce683a6d9f5a98a7
exercise_count: 23
public_solution_count: 1
public_solution_numbers: "12"
media_credits: source/id-ID/media-credits-bgk-unit-16.md
license: "Teks kursus semantik dan terjemahan ini: CC BY-SA 4.0. Metadata Commons untuk PDF kursus resmi menyatakan CC BY-SA 4.0, sedangkan halaman 265 PDF memuat pemberitahuan CC BY-SA 3.0; keduanya dipertahankan tanpa klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
source_binding_status: "verified_individual_surfaces_and_exact_course_pdf_without_unit_manifest"
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 16: Berkas Bebas Lokal {#br-bgk-2019-w16}

Tanda bintang menunjukkan satu-satunya soal dengan solusi publik yang
dibekukan, yaitu Soal 16.12. Dua puluh dua soal lainnya mempunyai hasil
kandidat negatif; edisi tidak menciptakan solusi baru.

<!-- upstream_entity: Beringter Raum/Lokal freie Garbe/Direkte Summe/Aufgabe -->

## Soal 16.1 {#br-bgk-2019-w16-ex01}

Misalkan $\mathcal F$ dan $\mathcal G$ berkas bebas lokal pada suatu ruang
berdering, masing-masing ber-rank $r$ dan $s$. Buktikan bahwa jumlah langsung
$\mathcal F\oplus\mathcal G$ bebas lokal ber-rank $r+s$.

<!-- upstream_entity: Beringter Raum/Lokal freie Garben/Duale Garbe/Lokal frei/Aufgabe -->

## Soal 16.2 {#br-bgk-2019-w16-ex02}

Misalkan $\mathcal F$ berkas bebas lokal ber-rank $r$ pada ruang berdering
$(X,\mathcal O_X)$. Buktikan bahwa berkas dual $\mathcal F^*$ juga bebas
lokal ber-rank $r$.

<!-- upstream_entity: Beringter Raum/Lokal freie Garbe/Bidual/Aufgabe -->

## Soal 16.3 {#br-bgk-2019-w16-ex03}

Buktikan bahwa suatu berkas bebas lokal $\mathcal F$ pada ruang berdering
$(X,\mathcal O_X)$ secara alami isomorfik dengan bidualnya
$\mathcal F^{**}$.

<!-- upstream_entity: Beringter Raum/Lokal freie Garbe/Homomorphismus/Surjektiv/Kern/Aufgabe -->

## Soal 16.4 {#br-bgk-2019-w16-ex04}

Misalkan $\mathcal F$ dan $\mathcal G$ berkas bebas lokal pada suatu ruang
berdering, dan misalkan

$$
\varphi:\mathcal F\longrightarrow\mathcal G
$$

homomorfisme modul surjektif. Buktikan bahwa kernel
$\operatorname{kern}\varphi$ juga bebas lokal.

<!-- upstream_entity: Beringter Raum/Lokal freie Garbe/Rang/Additiv/Aufgabe -->

## Soal 16.5 {#br-bgk-2019-w16-ex05}

Buktikan bahwa rank berkas bebas lokal pada ruang berdering
$(X,\mathcal O_X)$ bersifat aditif terhadap barisan eksak pendek. Artinya,
jika terdapat barisan eksak pendek berkas-berkas bebas lokal

$$
0\longrightarrow\mathcal F
\longrightarrow\mathcal G
\longrightarrow\mathcal H
\longrightarrow0,
$$

maka

$$
\operatorname{rank}\mathcal G
=\operatorname{rank}\mathcal F+\operatorname{rank}\mathcal H.
$$

<!-- upstream_entity: Beringter Raum/Lokal freie Garbe/Tensorprodukt/Aufgabe -->

## Soal 16.6 {#br-bgk-2019-w16-ex06}

Misalkan $\mathcal F$ dan $\mathcal G$ berkas bebas lokal pada suatu ruang
berdering, masing-masing ber-rank $r$ dan $s$. Buktikan bahwa hasil kali
tensor

$$
\mathcal F\otimes_{\mathcal O_X}\mathcal G
$$

bebas lokal ber-rank $rs$.

<!-- upstream_entity: Beringter Raum/Lokal freie Garbe/Homomorphismus/Injektiv/Quotient/Aufgabe -->

## Soal 16.7 {#br-bgk-2019-w16-ex07}

Misalkan $\mathcal F$ dan $\mathcal G$ berkas bebas lokal pada suatu ruang
berdering, dan misalkan $\varphi:\mathcal F\to\mathcal G$ homomorfisme modul
injektif. Tunjukkan bahwa berkas hasil bagi $\mathcal G/\mathcal F$ secara
umum tidak bebas lokal.

<!-- upstream_entity: Noethersches Schema/Kohärenter Modul/Lokal frei/Punktweise/Aufgabe -->

## Soal 16.8 {#br-bgk-2019-w16-ex08}

Misalkan $\mathcal F$ modul koheren pada skema Noether $(X,\mathcal O_X)$ dan
$r\in\mathbb N$. Buktikan bahwa sifat-sifat berikut ekuivalen.

1. $\mathcal F$ bebas lokal ber-rank $r$.
2. Untuk setiap titik $P\in X$, $\mathcal F_P$ sebagai modul
   $\mathcal O_{X,P}$ bebas ber-rank $r$.

<!-- upstream_entity: Integres noethersches Schema/Kohärenter Modul/Offene Menge/Frei/Aufgabe -->

## Soal 16.9 {#br-bgk-2019-w16-ex09}

Misalkan $(X,\mathcal O_X)$ skema integral Noether dan $\mathcal F$ modul
koheren pada $X$. Buktikan bahwa terdapat subhimpunan terbuka tak kosong
$U\subseteq X$ sedemikian sehingga $\mathcal F|_U$ bebas.

<!-- upstream_entity: Noethersches Schema/Kohärente Garben/Isomorphismus im Punkt/Isomorphismus auf Umgebung/Aufgabe -->

## Soal 16.10 {#br-bgk-2019-w16-ex10}

Misalkan $(X,\mathcal O_X)$ skema Noether dan
$\varphi:\mathcal F\to\mathcal G$ homomorfisme modul-modul koheren
$\mathcal F$ dan $\mathcal G$ pada $X$. Misalkan $P\in X$ suatu titik
sedemikian sehingga

$$
\varphi_P:\mathcal F_P\longrightarrow\mathcal G_P
$$

merupakan isomorfisme. Buktikan bahwa terdapat lingkungan terbuka
$P\in U\subseteq X$ sedemikian sehingga

$$
\varphi:\mathcal F|_U\longrightarrow\mathcal G|_U
$$

merupakan isomorfisme.

<!-- upstream_entity: Flacher Modul/Ringwechsel/Aufgabe -->

## Soal 16.11 {#br-bgk-2019-w16-ex11}

Misalkan $R$ gelanggang komutatif, $M$ modul $R$ datar, dan $S$ suatu aljabar
$R$. Buktikan bahwa $M\otimes_RS$ merupakan modul $S$ datar.

<!-- upstream_entity: Kommutativer Ring/Projektiver Modul/Universell und direkter Summand/Fakt/Beweis/Aufgabe -->

## Soal 16.12 ★ {#br-bgk-2019-w16-ex12}

Misalkan $R$ gelanggang komutatif dan $M$ modul $R$. Buktikan bahwa $M$
merupakan modul projektif jika dan hanya jika terdapat modul lain $N$
sedemikian sehingga jumlah langsung $M\oplus N$ bebas.

<!-- upstream_entity: Produktring/Körper/Projektiver Modul/Aufgabe -->

## Soal 16.13 {#br-bgk-2019-w16-ex13}

Misalkan $K$ lapangan dan $R=K^n$ gelanggang produk. Buktikan bahwa setiap
$R$-modul $M$ bersifat projektif.

<!-- upstream_entity: Kommutativer Ring/Nulldimensional/Nicht projektiv/Aufgabe -->

## Soal 16.14 {#br-bgk-2019-w16-ex14}

Berikan contoh suatu gelanggang Artin dan suatu $R$-modul $M$ yang
dibangkitkan hingga tetapi tidak projektif.

<!-- upstream_entity: Z/Q/Nicht projektiv/Aufgabe -->

## Soal 16.15 {#br-bgk-2019-w16-ex15}

Buktikan bahwa untuk homomorfisme grup surjektif

$$
p:\mathbb Z^{(\mathbb N_+)}\longrightarrow\mathbb Q,
\qquad
e_n\longmapsto\frac1n,
$$

tidak terdapat homomorfisme grup

$$
i:\mathbb Q\longrightarrow\mathbb Z^{(\mathbb N_+)}
$$

dengan $p\circ i=\operatorname{Id}_{\mathbb Q}$. Simpulkan bahwa
$\mathbb Q$, sebagai modul $\mathbb Z$, tidak projektif.

<!-- upstream_entity: Projektiver Modul/Nenneraufnahme/Aufgabe -->

## Soal 16.16 {#br-bgk-2019-w16-ex16}

Misalkan $R$ gelanggang komutatif, $M$ modul $R$ projektif, dan
$T\subseteq R$ suatu sistem multiplikatif. Buktikan bahwa $M_T$ merupakan
modul $R_T$ projektif.

<!-- upstream_entity: Projektiver Modul/Ringwechsel/Aufgabe -->

## Soal 16.17 {#br-bgk-2019-w16-ex17}

Misalkan $R$ gelanggang komutatif, $M$ modul $R$ projektif, dan $S$ suatu
aljabar $R$. Buktikan bahwa $M\otimes_RS$ merupakan modul $S$ projektif.

<!-- upstream_entity: Affines Schema/Syzygienbündel/Explizite Trivialisierungen/Aufgabe -->

## Soal 16.18 {#br-bgk-2019-w16-ex18}

Misalkan $R$ gelanggang komutatif dan $f_1,\ldots,f_n\in R$. Misalkan

$$
\mathcal S=\operatorname{Syz}(f_1,\ldots,f_n)
$$

berkas sizigi yang bersesuaian pada

$$
U=D(f_1,\ldots,f_n)\subseteq\operatorname{Spek}(R).
$$

Berikan secara eksplisit trivialisasi-trivialisasi bagi
$\mathcal S|_{D(f_i)}$.

<!-- upstream_entity: Projektives Schema/Syzygienbündel/Lokal frei/Aufgabe -->

## Soal 16.19 {#br-bgk-2019-w16-ex19}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$ dan
$f_1,\ldots,f_n\in R$ unsur-unsur homogen berderajat $d_i$. Misalkan ideal
$I$ yang dibangkitkan oleh $f_i$ dan ideal irelevan $R_+$ mempunyai radikal
yang sama. Buktikan pernyataan-pernyataan berikut.

1. Terdapat barisan eksak pendek

   $$
   0\longrightarrow\operatorname{Syz}(f_1,\ldots,f_n)
   \longrightarrow\bigoplus_{i=1}^nR(-d_i)
   \longrightarrow I
   \longrightarrow0
   $$

   dari modul-modul $R$ bergradasi dengan homomorfisme-homomorfisme homogen.

2. Pada $Y=\operatorname{Proj}(R)$ terdapat barisan eksak pendek

   $$
   0\longrightarrow\operatorname{Syz}(f_1,\ldots,f_n)
   \longrightarrow\bigoplus_{i=1}^n\mathcal O_Y(-d_i)
   \longrightarrow\mathcal O_Y
   \longrightarrow0
   $$

   dari berkas-berkas bebas lokal.

3. Pada $D_+(f_i)$, pembatasan berkas bebas lokal
   $\operatorname{Syz}(f_1,\ldots,f_n)$ isomorfik dengan suatu jumlah langsung
   berkas-berkas struktur terpuntir.

<!-- upstream_entity: Lokal freie Garbe/Beringter Raum/Determinantengarbe/Invertierbar/Aufgabe -->

## Soal 16.20 {#br-bgk-2019-w16-ex20}

Misalkan $\mathcal F$ berkas bebas lokal pada suatu ruang berdering. Buktikan
bahwa berkas determinan $\operatorname{Det}F$ invertibel.

<!-- upstream_entity: Lokal freie Garbe/Beringter Raum/Duale Garbe/Determinantengarbe/Aufgabe -->

## Soal 16.21 {#br-bgk-2019-w16-ex21}

Misalkan $\mathcal F$ berkas bebas lokal pada suatu ruang berdering dengan
berkas dual $\mathcal F^*$. Buktikan bahwa untuk berkas determinan berlaku

$$
(\operatorname{Det}F)^*
=\operatorname{Det}(F^*).
$$

<!-- upstream_entity: Beringter Raum/Lokal freie Garbe/Direkte Summe/Invertierbare Garben/Determinantengarbe/Fakt/Beweis/Aufgabe -->

## Soal 16.22 {#br-bgk-2019-w16-ex22}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan

$$
\mathcal F=\mathcal L_1\oplus\cdots\oplus\mathcal L_r
$$

suatu jumlah langsung berkas-berkas invertibel. Buktikan bahwa

$$
\operatorname{Det}F
\cong\mathcal L_1\otimes\cdots\otimes\mathcal L_r.
$$

<!-- upstream_entity: Projektives Schema/Syzygienbündel/Determinantengarbe/Aufgabe -->

## Soal 16.23 {#br-bgk-2019-w16-ex23}

Buktikan bahwa dalam situasi Soal 16.19, berkas determinan dari berkas bebas
lokal $\operatorname{Syz}(f_1,\ldots,f_n)$ pada
$Y=\operatorname{Proj}(R)$ adalah

$$
\operatorname{Det}(\operatorname{Syz}(f_1,\ldots,f_n))
=\mathcal O_Y\left(-\sum_{i=1}^n d_i\right).
$$
