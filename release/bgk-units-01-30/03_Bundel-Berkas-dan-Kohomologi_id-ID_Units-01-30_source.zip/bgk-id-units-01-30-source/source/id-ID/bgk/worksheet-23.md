---
title: "Lembar Kerja 23 - Modul Injektif"
stable_id: br-bgk-2019-w23
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 23"
upstream_pageid: 110231
upstream_revid: 991889
upstream_timestamp: "2025-01-23T14:49:51Z"
upstream_mediawiki_sha1: ade4a516931ededdb1c721b98df2cf02dc9bac0c
source_url: "https://de.wikiversity.org/w/index.php?oldid=991889"
course_authority_manifest: authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json
course_authority_manifest_sha256: ea0bf346e261db8ed80b7565f7746e95c79e0c376d25d9fbce5d96879dff7dd8
capture_identity: authority/wikiversity-bgk/unit-23/CAPTURE_IDENTITY.json
capture_identity_sha256: de194d9895b48db11613225072c9995377499c2c7ebf0a010de54bd3e4756c63
authority_manifest: authority/wikiversity-bgk/unit-23/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 96fb36e19dd3e6dcef56149150ce09c238843bee08ff36503d87a55284113775
authority_manifest_status: complete
official_pdf: authority/artifacts/bgk-worksheet-23-official.pdf
official_pdf_sha256: 35711c9254b2e357f190bf8bcb56b931edf68ec0b8e86e8b601cfbb25caca799
official_pdf_status: verified_source_bytes_and_upload_sha1
official_pdf_metadata: authority/wikiversity-bgk/unit-23/official-pdfs-api.json
official_pdf_source_bytes: 43316
official_pdf_source_sha1: c69a77b3295b90037cd7a11b6306fa13d777a990
authority_precedence: "Revisi semantik beku mengendalikan teks; PDF resmi lama adalah saksi pelengkap yang tetap dibedakan."
official_course_pdf: authority/artifacts/bgk-course-official.pdf
official_course_pdf_bytes: 2104862
official_course_pdf_pages: 265
official_course_pdf_unit_pages: "200-209"
official_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
worksheet_xml: authority/wikiversity-bgk/unit-23/worksheet-23.xml
worksheet_xml_sha256: 9485e0a9c42e7c9791e0a496c885245b40188f823aaab607fcfeea5cba654a08
worksheet_expanded_tex: authority/wikiversity-bgk/unit-23/worksheet-23-expanded.tex
worksheet_expanded_tex_sha256: 7dff718c864ff156fbb8088ae3dcf06fa9cf52a8d7046677a3b0315a028866ef
ordered_exercise_map: authority/wikiversity-bgk/unit-23/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 14d9869b2836a5e953acb70c34bfa3f29ecf28b406a7cf1050f3849ee682806f
exercise_count: 21
public_solution_count: 0
public_solution_numbers: ""
media_credits: source/id-ID/media-credits-bgk-unit-23.md
rights_ledger: authority/RIGHTS-bgk-unit-23.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-23.json
asset_closure_sha256: 00673ca97e9a0caeca0bdf9bc02b1e18881dc5576ce2a9285cf904c503c189a7
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 23: Modul Injektif {#br-bgk-2019-w23}

Tidak ada tanda bintang karena penutupan sumber beku tidak menemukan halaman
solusi publik untuk satu pun dari 21 soal. Semua Soal 23.1--23.21 mempunyai
hasil kandidat negatif; edisi tidak menciptakan solusi baru.

<!-- upstream_entity: Kommutative Gruppe/Untergruppe/Homomorphismus nach Z/Fortsetzung nach Q/Aufgabe -->

## Soal 23.1 {#br-bgk-2019-w23-ex01}

Misalkan $H\subseteq G$ subgrup dari grup komutatif $G$, dan misalkan

$$
\varphi:H\longrightarrow\mathbb Z
$$

homomorfisme grup. Buktikan bahwa terdapat homomorfisme grup

$$
G\longrightarrow\mathbb Q
$$

yang memperluas $\varphi$, dengan $\varphi$ dipandang sebagai pemetaan ke
$\mathbb Q$.

<!-- upstream_entity: Rationale Zahlen/Positiv/Nicht divisibel/Aufgabe -->

## Soal 23.2 {#br-bgk-2019-w23-ex02}

Buktikan bahwa grup $(\mathbb Q_+,\cdot)$ tidak divisibel.

<!-- upstream_entity: Reelle Zahlen/Positive Einheitengruppe/Divisibel/Aufgabe -->

## Soal 23.3 {#br-bgk-2019-w23-ex03}

Buktikan bahwa grup $(\mathbb R,+)$ dan $(\mathbb R_+,\cdot)$ divisibel.
Apakah $(\mathbb R^\times,\cdot)$ juga divisibel?

<!-- upstream_entity: Endliche zyklische Gruppe/Nicht injektiv/Aufgabe -->

## Soal 23.4 {#br-bgk-2019-w23-ex04}

Buktikan bahwa grup $\mathbb Z/(n)$ dengan $n\in\mathbb N_+$ tidak injektif.

<!-- upstream_entity: Algebraisch abgeschlossener Körper/Einheitengruppe/Divisibel/Aufgabe -->

## Soal 23.5 {#br-bgk-2019-w23-ex05}

Misalkan $K$ lapangan tertutup secara aljabar. Buktikan bahwa grup satuan
$K^\times$ divisibel.

<!-- upstream_entity: Zyklische Gruppe/Einbettung/Divisible Gruppe/Aufgabe -->

## Soal 23.6 {#br-bgk-2019-w23-ex06}

Untuk grup siklik $\mathbb Z/(n)$, deskripsikan suatu grup divisibel $D$
dengan

$$
\mathbb Z/(n)\subseteq D.
$$

<!-- upstream_entity: Divisible Gruppe/Indexmenge/Abbildungen/Aufgabe -->

## Soal 23.7 {#br-bgk-2019-w23-ex07}

Misalkan $D$ grup divisibel dan $S$ suatu himpunan. Buktikan bahwa grup

$$
\operatorname{Abb}(S,D)
$$

juga divisibel.

<!-- upstream_entity: Divisible Gruppe/Kommutative Gruppe/Homomorphismen/Aufgabe -->

## Soal 23.8 {#br-bgk-2019-w23-ex08}

Misalkan $D$ grup divisibel dan $S$ grup komutatif. Buktikan bahwa grup

$$
\operatorname{Hom}(S,D)
$$

juga divisibel.

<!-- upstream_entity: Moduln/Injektiv und projektiv/Vergleich/Aufgabe -->

## Soal 23.9 {#br-bgk-2019-w23-ex09}

Bahas perbedaan dan persamaan antara modul injektif dan modul projektif di
atas gelanggang komutatif $R$.

<!-- upstream_entity: Modul/Nicht divisible Gruppe/Injektiv/Aufgabe -->

## Soal 23.10 {#br-bgk-2019-w23-ex10}

Berikan contoh suatu modul $R$ injektif $M$ di atas gelanggang komutatif $R$
sedemikian sehingga $M$ sebagai grup komutatif tidak divisibel.

<!-- upstream_entity: Modul/Divisible Gruppe/Nicht injektiv/Aufgabe -->

## Soal 23.11 {#br-bgk-2019-w23-ex11}

Berikan contoh suatu modul $R$ yang tidak injektif, $M$, di atas gelanggang
komutatif $R$ sedemikian sehingga $M$ sebagai grup komutatif divisibel.

**Petunjuk.** Tinjau

$$
R=M=\mathbb Q[X].
$$

<!-- upstream_entity: Injektiver Modul/Multiplikation mit Nichtnullteiler/Aufgabe -->

## Soal 23.12 {#br-bgk-2019-w23-ex12}

Misalkan $I$ modul $R$ yang injektif di atas gelanggang komutatif $R$, dan
misalkan $r\in R$ bukan pembagi nol. Buktikan bahwa perkalian

$$
\mu_r:I\longrightarrow I,\qquad v\longmapsto rv,
$$

bersifat surjektif.

> **Catatan edisi - variabel modul dalam sumber.** Teks sumber beku memulai
> soal dengan menyebut $R$ sebagai modul $R$ yang injektif, tetapi rumusnya
> kemudian memakai $\mu_r:I\to I$. Agar objek pada kalimat dan rumus sama,
> edisi memakai $I$ sebagai variabel modul, tanpa mengubah hipotesis atau
> kesimpulan matematis lain.

<!-- upstream_entity: Kommutative Gruppe/Kurze injektive Auflösung/Aufgabe -->

## Soal 23.13 {#br-bgk-2019-w23-ex13}

Buktikan bahwa setiap grup komutatif $G$ mempunyai resolusi injektif berbentuk

$$
0\longrightarrow G\longrightarrow I_0\longrightarrow I_1
\longrightarrow 0.
$$

<!-- upstream_entity: Injektive Garbe/Direktes Produkt/Aufgabe -->

## Soal 23.14 {#br-bgk-2019-w23-ex14}

Misalkan $\mathcal I_j$, $j\in J$, suatu keluarga berkas grup komutatif yang
injektif pada ruang topologis $X$. Buktikan bahwa produk langsung

$$
\prod_{j\in J}\mathcal I_j
$$

juga injektif.

<!-- upstream_entity: Stetige Funktionen/R/Nicht welk/Aufgabe -->

## Soal 23.15 {#br-bgk-2019-w23-ex15}

Buktikan bahwa berkas fungsi kontinu bernilai real pada $\mathbb R$ tidak
flasque.

<!-- upstream_entity: Diskreter Raum/Garbe/Welk/Aufgabe -->

## Soal 23.16 {#br-bgk-2019-w23-ex16}

Buktikan bahwa pada ruang topologis diskret $X$, setiap berkas bersifat
flasque.

<!-- upstream_entity: Lokal konstante Garbe/Irreduzibel/Welk/Aufgabe -->

## Soal 23.17 {#br-bgk-2019-w23-ex17}

Buktikan bahwa berkas konstan lokal $\mathcal G$ pada ruang topologis
tak tereduksi bersifat flasque.

<!-- upstream_entity: Lokal konstante Garbe/Nicht welk/Aufgabe -->

## Soal 23.18 {#br-bgk-2019-w23-ex18}

Buktikan bahwa suatu berkas konstan lokal $\mathcal G$ pada ruang topologis
tidak harus flasque.

<!-- upstream_entity: Kommutative Gruppe/Abbildungen/Garbe/Welk/Aufgabe -->

## Soal 23.19 {#br-bgk-2019-w23-ex19}

Misalkan $G$ grup komutatif dan $X$ ruang topologis. Buktikan bahwa berkas

$$
U\longmapsto\operatorname{Abb}(U,G)
$$

pada $X$ bersifat flasque.

<!-- upstream_entity: Welke Garbe/Direktes Produkt/Aufgabe -->

## Soal 23.20 {#br-bgk-2019-w23-ex20}

Misalkan $\mathcal G_j$, $j\in J$, suatu keluarga berkas flasque pada ruang
topologis $X$. Buktikan bahwa produk langsung

$$
\prod_{j\in J}\mathcal G_j
$$

juga flasque.

<!-- upstream_entity: Topologischer Raum/Disjunkte offene Vereinigung/Welke Garben/Aufgabe -->

## Soal 23.21 {#br-bgk-2019-w23-ex21}

Misalkan $X$ ruang topologis dengan dekomposisi

$$
X=Y\uplus Z
$$

menjadi subhimpunan terbuka tak kosong yang saling lepas. Misalkan
$\mathcal G$ berkas pada $Y$ dan $\mathcal H$ berkas pada $Z$. Buktikan bahwa
berkas $\mathcal F$ yang didefinisikan oleh

$$
\mathcal F(U)=
\mathcal G(U\cap Y)\times\mathcal H(U\cap Z)
$$

bersifat flasque tepat ketika $\mathcal G$ dan $\mathcal H$ flasque.

> **Catatan edisi - subjek gramatikal yang hilang.** Kalimat sumber beku
> berbunyi, secara harfiah, “buktikan bahwa yang melalui
> $\mathcal F(U)=\cdots$ tepat ketika flasque”, tanpa menyebut objek yang
> didefinisikan. Rumus dan sisa kalimat menentukan objek itu sebagai berkas
> $\mathcal F$. Edisi menyatakannya secara eksplisit dan mempertahankan rumus,
> hipotesis, serta ekuivalensi sumber.
