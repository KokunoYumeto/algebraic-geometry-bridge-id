---
title: "Kuliah 8 - Spektrum Gelanggang Komutatif"
stable_id: br-bgk-2019-l08
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 8"
upstream_pageid: 109012
upstream_revid: 793632
upstream_timestamp: "2022-08-25T06:26:28Z"
upstream_mediawiki_sha1: dedf36ef3494817e0d35ddb9ff305a5adedd92d7
source_url: "https://de.wikiversity.org/w/index.php?oldid=793632"
authority_manifest: authority/wikiversity-bgk/unit-08/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: cadebf48e67a54a238f4b22e0abf806fbf1f81821b6d012993739ecf50dd8d32
lecture_xml: authority/wikiversity-bgk/unit-08/lecture-08.xml
lecture_xml_sha256: fc38c16bb3a748d8db389bb0984152c9e8f1313c7f4d1a73ea799778669470bd
lecture_expanded_tex: authority/wikiversity-bgk/unit-08/lecture-08-expanded.tex
lecture_expanded_tex_sha256: 926cd9ff6e41b384d89b2b63e9c1f7dab7d37dca34a864bd1fd045b6a565db11
official_pdf: authority/artifacts/bgk-lecture-08-official.pdf
official_pdf_sha256: 4907b8a1438d786d326667256e9b4c3f8124f4b170d53c782a5f58f68cc09727
media_credits: source/id-ID/media-credits-bgk-unit-08.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi dan media sumber mempertahankan pemberitahuan komponen masing-masing; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 8: Spektrum Gelanggang Komutatif {#br-bgk-2019-l08}

Sejauh ini kita telah membahas ruang berdering yang ruang dasarnya, dalam
arti tertentu, tersedia terlebih dahulu: ruang topologis sebarang, manifold
real, atau manifold kompleks. Dari ruang tersebut muncul secara alami berkas
gelanggang komutatif berupa berkas fungsi kontinu, terdiferensialkan, atau
holomorfik. Unsur-unsur gelanggang itu sudah kita kenal sebagai fungsi, tetapi
gelanggangnya sendiri pada umumnya sangat besar dan sukar ditinjau secara
menyeluruh.

Sebaliknya, kita dapat bertanya sejauh mana setiap gelanggang komutatif dapat
diperoleh sebagai gelanggang seksi global suatu ruang berdering, atau apakah
ada ruang berdering yang mencerminkan sifat gelanggang dengan sangat baik dan
membantu kita memahaminya. Pertanyaan-pertanyaan ini akan dijawab secara
positif dalam kuliah ini dan kuliah berikutnya. Ruang berdering yang dihasilkan
sekaligus merupakan blok bangunan lokal geometri aljabar.

## Spektrum gelanggang komutatif {#br-bgk-2019-l08-s01}

<!-- upstream_entity: Kommutativer Ring/Spektrum/Definition -->

### Definisi 8.1: spektrum {#br-bgk-2019-l08-def-01}

Untuk gelanggang komutatif $R$, himpunan semua ideal prima dari $R$ disebut
*spektrum* $R$ dan ditulis

$$
\operatorname{Spek}(R).
$$

Spektrum ini juga disebut *skema afin*.

<!-- upstream_entity: Kommutativer Ring/Spektrum/Zariski-Topologie/Definition -->

### Definisi 8.2: topologi Zariski {#br-bgk-2019-l08-def-02}

Pada spektrum gelanggang komutatif $R$, *topologi Zariski* didefinisikan
dengan menyatakan bahwa, untuk setiap subhimpunan $T\subseteq R$, himpunan

$$
D(T):=\{\mathfrak p\in\operatorname{Spek}(R)\mid
T\not\subseteq\mathfrak p\}
$$

adalah terbuka.

Untuk subhimpunan satu unsur $T=\{f\}$, kita menulis $D(f)$ sebagai ganti
$D(\{f\})$.

<!-- upstream_entity: Kommutativer Ring/Spektrum/Zariski-Topologie/Ist Topologie/Fakt -->

### Lema 8.3: keluarga Zariski memang suatu topologi {#br-bgk-2019-l08-lem-01}

Topologi Zariski pada spektrum $\operatorname{Spek}(R)$ suatu gelanggang
komutatif $R$ memang merupakan sebuah topologi.

#### Bukti {#br-bgk-2019-l08-lem-01-proof}

Kita mempunyai

$$
D(0)=\varnothing,
\qquad
D(1)=\operatorname{Spek}(R),
$$

karena setiap ideal prima memuat $0$ dan tidak ada ideal prima yang memuat
$1$.

Untuk keluarga sebarang subhimpunan $T_i\subseteq R$, $i\in I$, berlaku

$$
\bigcup_{i\in I}D(T_i)
=D\!\left(\bigcup_{i\in I}T_i\right).
$$

Inklusi dari kiri ke kanan jelas, sebab $T_i\subseteq\bigcup_{i\in I}T_i$
dan $S\subseteq T$ selalu mengakibatkan $D(S)\subseteq D(T)$. Untuk inklusi
sebaliknya, ambil

$$
\mathfrak p\in D\!\left(\bigcup_{i\in I}T_i\right).
$$

Ada $f\in\bigcup_{i\in I}T_i$ dengan $f\notin\mathfrak p$. Jadi ada
$i\in I$ dengan $f\in T_i$, sehingga $\mathfrak p\in D(T_i)$.

Untuk keluarga berhingga $T_1,\ldots,T_n\subseteq R$, berlaku

$$
\bigcap_{i=1}^{n}D(T_i)=D(T_1\cdots T_n),
$$

di mana $T_1\cdots T_n$ adalah himpunan semua hasil kali
$f_1\cdots f_n$ dengan $f_i\in T_i$. Inklusi dari kanan ke kiri jelas. Untuk
inklusi sebaliknya, andaikan $\mathfrak p\in D(T_i)$ untuk semua
$i=1,\ldots,n$. Maka ada $f_i\in T_i$ dengan $f_i\notin\mathfrak p$.
Karena $\mathfrak p$ prima, $f_1\cdots f_n\notin\mathfrak p$, sehingga
$\mathfrak p\in D(T_1\cdots T_n)$.

Kita selalu memandang spektrum sebagai ruang topologis. Ideal-ideal prima
adalah titik-titik ruang ini. Untuk menekankan sudut pandang geometri, kita
sering menulis

$$
X=\operatorname{Spek}(R),\qquad x\in X,
$$

dan menulis $\mathfrak p_x$ untuk ideal prima yang direpresentasikan oleh
$x$.

Komplemen himpunan terbuka, yakni himpunan tertutup dalam topologi Zariski,
ditulis

$$
V(T)=\{\mathfrak p\in\operatorname{Spek}(R)\mid T\subseteq\mathfrak p\}.
$$

<!-- upstream_entity: Kommutativer Ring/Spektrum/Zariski-Topologie/Erste Eigenschaften/Fakt -->

### Proposisi 8.4: sifat-sifat pertama topologi Zariski {#br-bgk-2019-l08-prop-01}

Untuk spektrum $X=\operatorname{Spek}(R)$ gelanggang komutatif $R$, berlaku
sifat-sifat berikut.

1. $D(T)=D(\mathfrak a)$, dengan $\mathfrak a$ ideal yang dibangkitkan oleh
   $T$ (atau radikal ideal tersebut). Jadi, untuk mendeskripsikan himpunan
   terbuka, cukup mempertimbangkan ideal-ideal radikal dalam $R$.
2. Untuk keluarga ideal $\mathfrak a_i\subseteq R$, $i\in I$,

   $$
   \bigcup_{i\in I}D(\mathfrak a_i)
   =D\!\left(\sum_{i\in I}\mathfrak a_i\right).
   $$

3. Untuk keluarga berhingga ideal $\mathfrak a_i\subseteq R$,
   $i=1,\ldots,n$,

   $$
   \bigcap_{i=1}^{n}D(\mathfrak a_i)
   =D\!\left(\bigcap_{i=1}^{n}\mathfrak a_i\right)
   =D(\mathfrak a_1\cdots\mathfrak a_n).
   $$

4. $D(\mathfrak a)=X$ tepat ketika $\mathfrak a$ adalah ideal satuan.
5. $D(\mathfrak a)\subseteq D(\mathfrak b)$ tepat ketika
   $\mathfrak a\subseteq\operatorname{rad}(\mathfrak b)$.
6. Spektrum kosong tepat ketika $R$ adalah gelanggang nol.
7. $D(\mathfrak a)=\varnothing$ tepat ketika $\mathfrak a$ hanya memuat
   unsur-unsur nilpoten.
8. Himpunan-himpunan terbuka $D(f)$, $f\in R$, membentuk basis topologi.
9. Keluarga himpunan terbuka $D(\mathfrak a_i)$, $i\in I$, merupakan
   penutup $X$ tepat ketika ideal-ideal $\mathfrak a_i$ bersama-sama
   membangkitkan ideal satuan.

#### Bukti {#br-bgk-2019-l08-prop-01-proof}

(1) Inklusi $D(T)\subseteq D(\mathfrak a)$ jelas. Untuk inklusi sebaliknya,
kita menggunakan kontraposisi dan mengandaikan $\mathfrak p\notin D(T)$.
Maka $T\subseteq\mathfrak p$, sehingga

$$
\mathfrak a\subseteq\operatorname{rad}(\mathfrak a)
\subseteq\mathfrak p,
$$

sebab ideal prima adalah ideal radikal. Jadi
$\mathfrak p\notin D(\operatorname{rad}(\mathfrak a))$.

(2) dan (3) mengikuti dari (1) dan bukti Lema 8.3.

(4) Jika $\mathfrak a$ bukan ideal satuan, maka menurut Soal 8.1 ada ideal
maksimal $\mathfrak m$ dengan $\mathfrak a\subseteq\mathfrak m$. Karena itu
$\mathfrak m\notin D(\mathfrak a)$.

(5) Implikasi dari kanan ke kiri jelas. Untuk arah sebaliknya, andaikan

$$
\mathfrak a\not\subseteq\operatorname{rad}(\mathfrak b).
$$

Maka ada $f\in\mathfrak a$ dengan $f^n\notin\mathfrak b$ untuk setiap
$n\in\mathbb N$. Menurut Soal 8.5, ada ideal prima
$\mathfrak p\supseteq\mathfrak b$ dengan $f\notin\mathfrak p$. Jadi
$\mathfrak p\in D(\mathfrak a)$ tetapi
$\mathfrak p\notin D(\mathfrak b)$.

> **Catatan edisi — nomor rujukan sumber hilang.** Saksi TeX sumber
> menampilkan `*****` pada rujukan ini. Target tautan dan peta soal yang
> dibekukan mengidentifikasinya sebagai Soal 8.5; label tersebut dipulihkan
> tanpa mengubah argumen.

(6) Gelanggang nol tidak mempunyai ideal prima. Setiap gelanggang komutatif
yang bukan gelanggang nol mempunyai ideal maksimal menurut Soal 8.1.

(7) Setiap ideal prima memuat semua unsur nilpoten, sehingga
$V(\mathfrak a)=X$ untuk ideal semacam itu. Sebaliknya, jika $\mathfrak a$
memuat unsur tak nilpoten $f$, maka menurut Soal 8.5 ada ideal prima
$\mathfrak p$ dengan $f\notin\mathfrak p$. Dengan demikian
$\mathfrak p\in D(f)\subseteq D(\mathfrak a)$.

(8) Ini langsung mengikuti dari

$$
D(\mathfrak a)=\bigcup_{f\in\mathfrak a}D(f).
$$

(9) mengikuti dari (2) dan (4).

> **Catatan edisi — kata ganda pada sumber.** Kalimat terakhir bukti sumber
> menulis padanan “mengikuti dari dan (2) dan (4)”. Kata sambung ganda
> dinormalkan; rujukan matematis tetap (2) dan (4).

<!-- upstream_entity: Kommutativer Ring/Spektrum/Abschluss/Fakt -->

### Proposisi 8.5: penutupan pada spektrum {#br-bgk-2019-l08-prop-02}

Untuk spektrum $X=\operatorname{Spek}(R)$ gelanggang komutatif $R$, berlaku:

1. penutupan subhimpunan $T\subseteq X$ adalah

   $$
   V\!\left(\bigcap_{x\in T}\mathfrak p_x\right);
   $$

2. penutupan titik $x\in X$ adalah $V(\mathfrak p_x)$;
3. titik $x\in\operatorname{Spek}(R)$ tertutup tepat ketika
   $\mathfrak p_x$ adalah ideal maksimal.

#### Bukti {#br-bgk-2019-l08-prop-02-proof}

(1) Untuk $y\in T$, berlaku

$$
y\in V(\mathfrak p_y)
\subseteq V\!\left(\bigcap_{x\in T}\mathfrak p_x\right),
$$

sehingga himpunan di sebelah kanan adalah himpunan tertutup yang memuat $T$.
Ambil ideal prima $\mathfrak q$ dengan

$$
\mathfrak q\in V\!\left(\bigcap_{x\in T}\mathfrak p_x\right),
\qquad
\bigcap_{x\in T}\mathfrak p_x\subseteq\mathfrak q.
$$

Untuk menunjukkan bahwa $\mathfrak q$ termasuk penutupan $T$, cukup
menunjukkan bahwa $T$ memotong setiap lingkungan terbuka $\mathfrak q$.
Andaikan $\mathfrak q\in D(f)$, yakni $f\notin\mathfrak q$. Maka
$f\notin\bigcap_{x\in T}\mathfrak p_x$, sehingga ada $x\in T$ dengan
$f\notin\mathfrak p_x$. Jadi $\mathfrak p_x\in D(f)$ dan
$T\cap D(f)\ne\varnothing$.

(2) adalah kasus khusus (1), dan (3) mengikuti dari (2).

<!-- upstream_entity: Kommutativer Ring/Spektrum/Zariski-Topologie/Quasikompaktheit/Fakt -->

### Korolari 8.6: spektrum kuasikompak {#br-bgk-2019-l08-cor-01}

Spektrum $X=\operatorname{Spek}(R)$ setiap gelanggang komutatif $R$ bersifat
kuasikompak.

#### Bukti {#br-bgk-2019-l08-cor-01-proof}

Menurut Proposisi 8.4(9),

$$
X=\bigcup_{i\in I}D(\mathfrak a_i)
$$

tepat ketika ideal-ideal $\mathfrak a_i$, $i\in I$, bersama-sama
membangkitkan ideal satuan. Ideal yang dibangkitkan keluarga tersebut terdiri
atas semua jumlah berhingga $f_1+\cdots+f_n$ dengan
$f_j\in\mathfrak a_{i_j}$. Jadi, jika ideal satuan dibangkitkan, ada pilihan
berhingga $\{i_1,\ldots,i_n\}\subseteq I$ dan unsur
$f_j\in\mathfrak a_{i_j}$ dengan

$$
\sum_{j=1}^{n}f_j=1.
$$

Akibatnya,

$$
X=D(1)=\bigcup_{j=1}^{n}D(f_j)
=\bigcup_{j=1}^{n}D(\mathfrak a_{i_j}),
$$

sehingga diperoleh subkeluarga penutup yang berhingga.

Spektrum hanya menjadi ruang Hausdorff dalam keadaan khusus. Pada umumnya,
dua titik spektrum tidak dapat dipisahkan oleh lingkungan-lingkungan terbuka.

<!-- upstream_entity: Körper/Spektrum/Beispiel -->

### Contoh 8.7: spektrum lapangan {#br-bgk-2019-l08-exa-01}

Sebuah lapangan hanya mempunyai dua ideal: ideal satuan $K$, yang bukan ideal
prima, dan ideal nol $0$, yang merupakan ideal prima. Jadi spektrum lapangan
hanya terdiri atas satu titik.

<!-- upstream_entity: Z/Spektrum/Beispiel -->

### Contoh 8.8: spektrum bilangan bulat {#br-bgk-2019-l08-exa-02}

Ideal-ideal prima dalam $\mathbb Z$ adalah ideal maksimal $(p)$, dengan $p$
bilangan prima, serta ideal nol $0$. Ideal-ideal maksimal membentuk titik-titik
tertutup $\operatorname{Spek}(\mathbb Z)$. Ideal nol adalah satu titik tambahan
yang tidak tertutup. Satu-satunya himpunan tertutup yang memuat titik ini
adalah seluruh ruang. Selain seluruh ruang, himpunan-himpunan tertutup dalam
$\operatorname{Spek}(\mathbb Z)$ adalah subhimpunan berhingga ideal-ideal
maksimal.

Kita membayangkan $\operatorname{Spek}(\mathbb Z)$ sebagai garis konseptual:
bilangan-bilangan prima terletak secara diskret, sedangkan ideal nol digambar
sebagai titik tebal yang merepresentasikan seluruh garis.

> **Ilustrasi sumber tidak tersedia.** Sumber mendeklarasikan
> `File:Spektrum_von_Z._xcf`, tetapi API Commons resmi mengembalikannya sebagai
> *missing*, HTML sumber menampilkan media rusak, dan PDF resmi tidak memuat
> biner gambar. Keterangan sumber menggambarkan titik-titik prima diskret,
> ideal nol tebal sebagai titik rapat, serta garis penghubung yang menunjukkan
> objek berdimensi satu. Edisi mempertahankan keterangan dan makna
> aksesibilitas itu tanpa mengklaim pemulihan gambar.

<!-- upstream_entity: Polynomring über Körper/Spektrum/Beispiel -->

### Contoh 8.9: spektrum gelanggang polinomial {#br-bgk-2019-l08-exa-03}

Untuk gelanggang polinomial

$$
R=K[X_1,\ldots,X_n]
$$

di atas lapangan $K$, ideal-ideal titik memberi gambaran geometri yang baik
tentang $\operatorname{Spek}(R)$. Ideal titik berbentuk

$$
(X_1-a_1,X_2-a_2,\ldots,X_n-a_n)
$$

untuk tupel tetap $a=(a_1,a_2,\ldots,a_n)\in K^n$. Ideal ini adalah kernel
homomorfisme aljabar-$K$

$$
\begin{aligned}
\varphi_a:R&\longrightarrow K,\\
X_i&\longmapsto a_i,
\end{aligned}
$$

dan karena itu merupakan ideal maksimal. Penetapan tersebut mendefinisikan
pemetaan injektif

$$
K^n\longrightarrow\operatorname{Spek}(R).
$$

Jika $K$ tertutup secara aljabar, pemetaan ini bahkan mencakup semua ideal
maksimal $R$. Karena itu spektrum gelanggang polinomial dalam $n$ peubah
dibayangkan sebagai ruang afin, tetapi juga memuat titik-titik tambahan yang
tidak tertutup dan lebih sukar divisualisasikan. Untuk polinomial
$f\in K[X_1,\ldots,X_n]$, himpunan $V(f)\cap K^n$ mempunyai arti konkret:

$$
a\in V(f)\cap K^n
\quad\Longleftrightarrow\quad
f(a_1,\ldots,a_n)=0.
$$

## Sifat-sifat funktorial {#br-bgk-2019-l08-s02}

<!-- upstream_entity: Kommutativer Ring/Spektrum/Zariski-Topologie/Funktorialität/Fakt -->

### Proposisi 8.10: funktorialitas spektrum {#br-bgk-2019-l08-prop-03}

Misalkan

$$
\varphi:R\longrightarrow S
$$

homomorfisme gelanggang di antara gelanggang komutatif. Maka:

1. penetapan

   $$
   \begin{aligned}
   \varphi^*:\operatorname{Spek}(S)&\longrightarrow\operatorname{Spek}(R),\\
   \mathfrak p&\longmapsto\varphi^*(\mathfrak p)
   :=\varphi^{-1}(\mathfrak p)
   \end{aligned}
   $$

   terdefinisi dengan baik dan kontinu;
2. untuk setiap ideal $\mathfrak a\subseteq R$,

   $$
   (\varphi^*)^{-1}(D(\mathfrak a))=D(\mathfrak a S);
   $$

3. untuk homomorfisme gelanggang lain $\psi:S\to T$,

   $$
   (\psi\circ\varphi)^*=\varphi^*\circ\psi^*.
   $$

#### Bukti {#br-bgk-2019-l08-prop-03-proof}

Menurut Soal 8.9, pemetaan tersebut terdefinisi dengan baik. Untuk
kontinuitas, cukup membuktikan (2). Kita menggunakan himpunan tertutup. Untuk
ideal prima $\mathfrak q\in\operatorname{Spek}(S)$, berlaku

$$
\varphi^*(\mathfrak q)\in V(\mathfrak a)
$$

tepat ketika $\mathfrak a\subseteq\varphi^{-1}(\mathfrak q)$. Syarat ini
ekuivalen dengan $\varphi(\mathfrak a)\subseteq\mathfrak q$, dan juga dengan
$\mathfrak aS\subseteq\mathfrak q$. Pernyataan (3) langsung.

Pemetaan kontinu yang diperkenalkan di atas disebut *pemetaan spektrum* dari
homomorfisme gelanggang yang diberikan. Untuk subgelanggang $R\subseteq S$,
pemetaan itu hanyalah

$$
\mathfrak p\longmapsto\mathfrak p\cap R,
$$

yang juga disebut *kontraksi* ideal prima.

<!-- upstream_entity: Kommutativer Ring/Spektrum/Zariski-Topologie/Abgeschlossene und offene Teilmengen/Fakt -->

### Proposisi 8.11: subhimpunan tertutup dan terbuka {#br-bgk-2019-l08-prop-04}

Misalkan $R$ gelanggang komutatif. Maka berlaku:

1. untuk ideal $\mathfrak a\subseteq R$ dan pemetaan hasil bagi

   $$
   q:R\longrightarrow R/\mathfrak a,
   $$

   pemetaan spektrum

   $$
   q^*:\operatorname{Spek}(R/\mathfrak a)
   \longrightarrow\operatorname{Spek}(R)
   $$

   merupakan pembenaman tertutup dengan citra $V(\mathfrak a)$;
2. untuk sistem multiplikatif $M\subseteq R$, pemetaan yang terkait dengan
   pemetaan kanonik

   $$
   \iota:R\longrightarrow R_M
   $$

   adalah pemetaan injektif

   $$
   \iota^*:\operatorname{Spek}(R_M)
   \longrightarrow\operatorname{Spek}(R),
   $$

   yang citranya terdiri atas ideal-ideal prima $R$ yang terpisah dari $M$;
3. untuk $f\in R$, pemetaan yang terkait dengan

   $$
   \iota:R\longrightarrow R_f
   $$

   merupakan pembenaman terbuka

   $$
   \iota^*:\operatorname{Spek}(R_f)
   \longrightarrow\operatorname{Spek}(R)
   $$

   dengan citra $D(f)$.

#### Bukti {#br-bgk-2019-l08-prop-04-proof}

(1) mengikuti dari Soal 8.6. Ideal-ideal prima dalam $R/\mathfrak a$
berkorespondensi dengan ideal-ideal prima $R$ yang memuat $\mathfrak a$
melalui

$$
\mathfrak p\longmapsto q^{-1}(\mathfrak p)=\mathfrak p+\mathfrak a.
$$

Jadi pemetaan tersebut bijektif ke citra yang telah dideskripsikan. Untuk
ideal $\mathfrak b\subseteq R/\mathfrak a$ dan ideal prima
$\mathfrak p\subseteq R/\mathfrak a$, berlaku
$\mathfrak b\subseteq\mathfrak p$ tepat ketika, melalui korespondensi hasil
bagi,

$$
q^{-1}(\mathfrak b)=\mathfrak b+\mathfrak a
\subseteq\mathfrak p+\mathfrak a=q^{-1}(\mathfrak p)
$$

di $R$. Jadi citra $V(\mathfrak b)$ adalah
$V(\mathfrak b+\mathfrak a)$ dan karena itu tertutup.

(2) Lihat Soal 8.7.

(3) Untuk ideal prima $\mathfrak p$ dan unsur $f\in R$, hubungan
$f\notin\mathfrak p$ berlaku tepat ketika $\mathfrak p$ terpisah dari sistem
multiplikatif

$$
\{f^n\mid n\in\mathbb N\}.
$$

Menurut (2), pemetaan itu injektif dan citranya $D(f)$. Argumen yang sama,
diterapkan pada $g\in R$ dan $g/1\in R_f$, menunjukkan bahwa citra

$$
D(g)\subseteq\operatorname{Spek}(R_f)
$$

adalah $D(fg)$ dan dengan demikian terbuka.

<!-- upstream_entity: Kommutativer Ring/Spektrumsabbildung/Faser/Fakt -->

### Lema 8.12: serat pemetaan spektrum {#br-bgk-2019-l08-lem-02}

Misalkan $\varphi:R\to S$ homomorfisme gelanggang di antara gelanggang
komutatif, dan misalkan

$$
\begin{aligned}
\varphi^*:\operatorname{Spek}(S)&\longrightarrow\operatorname{Spek}(R),\\
\mathfrak p&\longmapsto\varphi^*(\mathfrak p)
\end{aligned}
$$

pemetaan spektrum yang terkait. Serat di atas ideal prima
$\mathfrak q\in\operatorname{Spek}(R)$ adalah

$$
\operatorname{Spek}\!\left(
(S/\mathfrak qS)_{\varphi(R\setminus\mathfrak q)}
\right).
$$

Dengan kata lain, serat tersebut terdiri atas semua ideal prima
$\mathfrak p\in\operatorname{Spek}(S)$ yang memenuhi

$$
\mathfrak qS\subseteq\mathfrak p,
\qquad
\mathfrak p\cap\varphi(R\setminus\mathfrak q)=\varnothing.
$$

#### Bukti {#br-bgk-2019-l08-lem-02-proof}

Berdasarkan Proposisi 8.11, cukup membuktikan rumusan kedua. Untuk ideal prima
$\mathfrak p\subseteq S$, berlaku

$$
\varphi^{-1}(\mathfrak p)=\mathfrak q
$$

tepat ketika sekaligus

$$
\varphi(\mathfrak q)\subseteq\mathfrak p
\quad\text{dan}\quad
\varphi(R\setminus\mathfrak q)\subseteq S\setminus\mathfrak p.
$$

Syarat pertama ekuivalen dengan $\mathfrak qS\subseteq\mathfrak p$, dan
syarat kedua ekuivalen dengan

$$
\varphi(R\setminus\mathfrak q)\cap\mathfrak p=\varnothing.
$$

Khususnya, serat morfisme spektrum di atas suatu titik kembali merupakan
spektrum suatu gelanggang. Jika $\mathfrak m$ ideal maksimal, serat di atasnya
adalah

$$
\operatorname{Spek}(S/\mathfrak mS),
$$

sebab dari $\mathfrak mS\subseteq\mathfrak p$ langsung diperoleh
$\mathfrak m\subseteq\varphi^{-1}(\mathfrak p)$, dan maksimalitas memaksa
kesamaan. Jika $R$ domain integral dan titiknya adalah ideal nol, ideal
perluasan tidak perlu dipertimbangkan; seratnya cukup dideskripsikan oleh

$$
\operatorname{Spek}\!\left(S_{\varphi(R\setminus\{0\})}\right).
$$

<!-- upstream_entity: Kommutativer Ring/Spektrumsabbildung/Faser ist leer/Fakt -->

### Korolari 8.13: kriteria serat kosong {#br-bgk-2019-l08-cor-02}

Misalkan $\varphi:R\to S$ homomorfisme gelanggang di antara gelanggang
komutatif dan $\varphi^*:\operatorname{Spek}(S)\to\operatorname{Spek}(R)$
pemetaan spektrum yang terkait. Serat di atas ideal prima
$\mathfrak q\in\operatorname{Spek}(R)$ kosong tepat ketika

$$
\mathfrak qS\cap\varphi(R\setminus\mathfrak q)\ne\varnothing.
$$

#### Bukti {#br-bgk-2019-l08-cor-02-proof}

Pernyataan ini mengikuti dari Lema 8.12 dan Proposisi 8.4(6).
