---
title: "Kuliah 15 - Modul pada Skema Projektif"
stable_id: br-bgk-2019-l15
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 15"
upstream_pageid: 109019
upstream_revid: 1003744
upstream_timestamp: "2025-06-08T15:41:44Z"
upstream_mediawiki_sha1: 35b2de7ebb7276afe88784ffa590aae83faa8788
source_url: "https://de.wikiversity.org/w/index.php?oldid=1003744"
authority_manifest: authority/wikiversity-bgk/unit-15/UNIT_AUTHORITY_MANIFEST.json
lecture_xml: authority/wikiversity-bgk/unit-15/lecture-15.xml
lecture_xml_sha256: d7f8c9271d15063c1d37396fb4ba0c46cc1aeadbe39f04d5a41d7545fd925be8
lecture_expanded_tex: authority/wikiversity-bgk/unit-15/lecture-15-expanded.tex
lecture_expanded_tex_sha256: 59c9522b6920c91ef70091593891f8444f60ce73ad31b150b77d4e8c89931796
official_pdf: authority/artifacts/bgk-lecture-15-official.pdf
media_credits: source/id-ID/media-credits-bgk-unit-15.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 15: Modul pada Skema Projektif {#br-bgk-2019-l15}

## Modul kuasikoheren pada skema projektif {#br-bgk-2019-l15-s01}

Modul bergradasi atas suatu gelanggang bergradasi $R$ menghasilkan modul
kuasiprojektif pada

$$
\operatorname{Proj}(R).
$$

<!-- upstream_entity: Graduierter Ring/Graduierter Modul/Affin/Graduierung auf homogenen Mengen/Fakt -->

### Lema 15.1: gradasi pada himpunan terbuka homogen {#br-bgk-2019-l15-lem-01}

Misalkan $R$ gelanggang komutatif bergradasi $\mathbb Z$ dan $M$ modul
$R$ bergradasi $\mathbb Z$. Modul $\mathcal O_X$ terkait $\widetilde M$ pada
$\operatorname{Spek}(R)$ mempunyai sifat berikut: untuk setiap himpunan
terbuka

$$
U=D(\mathfrak a)\subseteq\operatorname{Spek}(R)
$$

yang berasal dari ideal homogen $\mathfrak a$, modul
$\Gamma(U,\widetilde M)$ atas $\Gamma(U,\mathcal O_X)$ mempunyai gradasi
$\mathbb Z$ yang kompatibel dengan pemetaan-pemetaan pembatasan.

#### Bukti {#br-bgk-2019-l15-lem-01-proof}

Untuk $M=R$, pernyataan itu pertama-tama berarti bahwa berkas struktur pada
himpunan-himpunan terbuka yang berasal dari ideal homogen mempunyai suatu
gradasi. Hal ini jelas untuk $D(f)$ dengan $f$ homogen, dan dari sini berlaku
pula untuk $D(\mathfrak a)$ dengan $\mathfrak a$ ideal homogen sembarang.
Kasus modul diperoleh dengan cara yang sama.

Tidak masuk akal untuk mengatakan bahwa $\widetilde M$ secara keseluruhan
bergradasi, sebab pada himpunan terbuka sembarang yang tidak berasal dari
ideal homogen, gradasi tersebut tidak terdefinisi. Namun, gradasi pada
subhimpunan-subhimpunan homogen memungkinkan kita mendefinisikan suatu
berkas modul pada spektrum projektif yang terkait dengan $R$.

<!-- upstream_entity: Graduierter Ring/Projektives Spektrum/Graduierter Modul/Garbe/Definition -->

### Definisi 15.2: berkas modul pada spektrum projektif {#br-bgk-2019-l15-def-01}

Misalkan $R$ gelanggang komutatif bergradasi $\mathbb Z$, $M$ modul $R$
bergradasi $\mathbb Z$, dan

$$
Y=\operatorname{Proj}(R)
$$

spektrum projektif $R$. Berkas modul $\mathcal O_Y$ yang terkait dengan $M$,
yakni $\widehat M$, ditetapkan sebagai berikut. Untuk setiap himpunan terbuka

$$
V=D_+(\mathfrak a)\subseteq Y
$$

yang berasal dari ideal homogen $\mathfrak a$, tetapkan

$$
\Gamma(V,\widehat M)
:=\Gamma(D(\mathfrak a),\widetilde M)_0,
$$

lalu lengkapi dengan pemetaan-pemetaan pembatasan alami dan struktur modul
$\mathcal O_Y$ yang alami.

Untuk modul $R$ bergradasi $M$ dan ideal prima homogen $\mathfrak p$, kita
tetapkan

$$
M_{(\mathfrak p)}
=\left(M_{\{h\text{ homogen}\mid h\notin\mathfrak p\}}\right)_0.
$$

<!-- upstream_entity: Graduierter Ring/Projektives Spektrum/Graduierter Modul/Garbe/Quasikohärenz/Fakt -->

### Lema 15.3: sifat berkas modul projektif {#br-bgk-2019-l15-lem-02}

Misalkan $R$ gelanggang komutatif bergradasi $\mathbb Z$, $M$ modul $R$
bergradasi $\mathbb Z$, $Y=\operatorname{Proj}(R)$ spektrum projektif $R$,
dan $\widehat M$ modul $\mathcal O_Y$ yang terkait. Maka berlaku sifat-sifat
berikut.

1. $\widehat M$ merupakan modul kuasikoheren.

2. Untuk unsur homogen $f\in R_+$,

   $$
   \Gamma(D_+(f),\widehat M)=(M_f)_0.
   $$

   Selain itu, pembatasan $\widehat M$ pada $D_+(f)$ sama dengan pembentukan
   berkas afin dari $(M_f)_0$ pada

   $$
   D_+(f)=\operatorname{Spek}((R_f)_0).
   $$

3. Untuk ideal prima homogen $\mathfrak p$ dengan
   $R_+\nsubseteq\mathfrak p$,

   $$
   \widehat M_{\mathfrak p}=M_{(\mathfrak p)}.
   $$

4. Berlaku

   $$
   \Gamma(Y,\widehat M)
   =\left(\Gamma(D(R_+),\widetilde M)\right)_0.
   $$

#### Bukti {#br-bgk-2019-l15-lem-02-proof}

1. Sifat berkas mengikuti dari sifat berkas $\widetilde M$. Untuk
   kekuasikoherenan, lihat bagian (2).

2. Untuk $f\in R_+$ homogen, menurut Lema 14.5,

   $$
   \Gamma(D_+(f),\widehat M)
   =\Gamma(D(f),\widetilde M)_0
   =(M_f)_0.
   $$

   Jadi pada keseluruhan $D_+(f)$, berkas
   $\widehat M|_{D_+(f)}$ sama dengan berkas $\widetilde{(M_f)_0}$. Untuk
   himpunan-himpunan terbuka $D(g)\subseteq D(f)$ berlaku kesamaan-kesamaan
   yang bersesuaian, dan identifikasi tersebut kompatibel dengan pembatasan.
   Karena itu kedua berkas memang sama, dan kekuasikoherenan pun berlaku.

3. Ini mengikuti dari (2) melalui

   $$
   \begin{aligned}
   \widehat M_{\mathfrak p}
   &=\operatorname*{colim}_{\mathfrak p\in D_+(f)}
     \Gamma(D_+(f),\widehat M)\\
   &=\operatorname*{colim}_{\mathfrak p\in D_+(f)}(M_f)_0\\
   &=\left(\operatorname*{colim}_{\mathfrak p\in D_+(f)}M_f\right)_0\\
   &=\left(M_{R\setminus\mathfrak p\cap H}\right)_0\\
   &=M_{(\mathfrak p)}.
   \end{aligned}
   $$

4. Ini merupakan kasus khusus dari definisi umum.

Pernyataan terakhir berarti bahwa, secara umum, modul seksi global
$\widehat M$ pada $Y$ tidak dapat dihitung langsung dari $M$.

<!-- upstream_entity: Graduierter Ring/Projektives Spektrum/Verschiebung/Twist/Definition -->

### Definisi 15.4: berkas struktur terpuntir {#br-bgk-2019-l15-def-02}

Misalkan $R$ gelanggang komutatif bergradasi $\mathbb Z$ dan $R(n)$
gelanggang bergradasi yang digeser sebesar $n$. Modul $\mathcal O_Y$ terkait
pada $Y=\operatorname{Proj}(R)$ yang dilambangkan

$$
\mathcal O_Y(n):=\widehat{R(n)}
$$

disebut *berkas struktur terpuntir*.

<!-- upstream_entity: Polynomring/Projektiver Raum/Getwistete Strukturgarben/Beispiel -->

### Contoh 15.5: berkas struktur terpuntir pada ruang projektif {#br-bgk-2019-l15-exm-01}

Untuk gelanggang polinomial bergradasi standar
$K[X_0,X_1,\ldots,X_d]$, dengan $d\geq 1$, berlaku

$$
\Gamma\left(\mathbb P_K^d,
\mathcal O_{\mathbb P_K^d}(\ell)\right)
=K[X_0,X_1,\ldots,X_d]_\ell,
$$

yakni ruang polinomial berderajat $\ell$ dalam $d+1$ variabel. Untuk
$\ell<0$, ini adalah ruang nol; untuk $\ell=0$ (berkas struktur), ruang ini
sama dengan $K$; untuk $\ell=1$, ruang ini terdiri atas semua bentuk linear;
dan seterusnya. Untuk himpunan-himpunan terbuka $D_+(X_i)$ berlaku

$$
\begin{aligned}
\Gamma\left(D_+(X_i),\mathcal O_{\mathbb P_K^d}(\ell)\right)
&=\left(K[X_0,X_1,\ldots,X_d]_{X_i}\right)_\ell\\
&=K\left[\frac{X_0}{X_i},\ldots,
\frac{X_{i-1}}{X_i},\frac{X_{i+1}}{X_i},\ldots,
\frac{X_d}{X_i}\right]\cdot X_i^\ell.
\end{aligned}
$$

Untuk ruang projektif, kita telah melihat dalam Contoh 13.19 bahwa
berkas-berkas ini invertibel. Hal itu juga berlaku secara umum.

<!-- upstream_entity: Standard-graduierter Ring/Projektives Spektrum/Verschiebung/Twist/Invertierbar/Fakt -->

### Lema 15.6: berkas struktur terpuntir bersifat invertibel {#br-bgk-2019-l15-lem-03}

Misalkan $R$ gelanggang komutatif bergradasi standar. Maka berkas-berkas
struktur terpuntir $\mathcal O_Y(n)$ pada
$Y=\operatorname{Proj}(R)$ bersifat invertibel.

#### Bukti {#br-bgk-2019-l15-lem-03-proof}

Tuliskan

$$
R=R_0[x_1,\ldots,x_d]
=R_0[X_1,\ldots,X_d]/\mathfrak a,
$$

dengan $x_i$ berderajat $1$. Unsur-unsur $x_i$ juga membangkitkan ideal
irelevan, sehingga terdapat liputan terbuka afin

$$
\operatorname{Proj}(R)=\bigcup_{i=1}^d D_+(x_i).
$$

Misalkan $x$ salah satu dari $x_i$. Menurut Lema 15.3(2),

$$
\mathcal O_Y(n)|_{D_+(x)}=\mathcal L,
$$

dengan $\mathcal L$ pembentukan berkas afin dari modul $(R_x)_0$

$$
L=(R_x(n))_0=(R_x)_n
$$

pada

$$
D_+(x)=\operatorname{Spek}((R_x)_0).
$$

Dalam situasi ini,

$$
(R_x)_0\longrightarrow(R_x)_n,
\qquad h\longmapsto hx^n,
$$

merupakan isomorfisme modul $(R_x)_0$. Karena itu terdapat isomorfisme
modul $\mathcal O_Y|_{D_+(x)}$

$$
\mathcal O_Y|_{D_+(x)}
\longrightarrow\mathcal O_Y(n)|_{D_+(x)}.
$$

Berkas struktur terpuntir $\mathcal O_Y(n)$ merupakan berkas invertibel yang
khas bagi skema projektif $Y=\operatorname{Proj}(R)$, meskipun bergantung
pada gelanggang bergradasi $R$.

<!-- upstream_entity: Standard-graduierter Ring/Projektives Spektrum/Modul/Verschiebung/Twist/Tensorierung/Fakt -->

### Lema 15.7: pergeseran modul dan tensor dengan berkas terpuntir {#br-bgk-2019-l15-lem-04}

Misalkan $R$ gelanggang komutatif bergradasi standar, $M$ modul $R$
bergradasi, dan $n\in\mathbb Z$. Terdapat isomorfisme $\mathcal O_Y$ alami

$$
\widehat M\otimes_{\mathcal O_Y}\mathcal O_Y(n)
\longrightarrow\widehat{M(n)}
$$

pada $Y=\operatorname{Proj}(R)$, dengan $M(n)$ modul yang diperoleh dengan
menggeser $M$ sebesar $n$.

#### Bukti {#br-bgk-2019-l15-lem-04-proof}

Untuk unsur homogen $f\in R_+$ terdapat homomorfisme modul $(R_f)_0$

$$
(M_f)_0\otimes_{(R_f)_0}(R_f)_n
\longrightarrow(M_f)_n,
\qquad
\frac{m}{f^k}\otimes\frac{r}{f^\ell}
\longmapsto\frac{rm}{f^{k+\ell}},
$$

yang langsung berasal dari perkalian modul homogen
$M\times R\to M$. Homomorfisme-homomorfisme ini menginduksi, untuk setiap
himpunan terbuka $U\subseteq\operatorname{Proj}(R)$, homomorfisme modul

$$
\operatorname*{colim}_{U\subseteq D_+(f)}
\left((M_f)_0\otimes_{(R_f)_0}(R_f)_n\right)
\longrightarrow
\operatorname*{colim}_{U\subseteq D_+(f)}(M_f)_n,
$$

yang secara keseluruhan merupakan homomorfisme praberkas. Karena

$$
(M(n)_f)_0=(M_f)_n,
$$

pembentukan berkas dari praberkas di ruas kanan sama dengan
$\widehat{M(n)}$. Pembentukan berkas dari ruas kiri, dalam dua langkah,
adalah

$$
\widehat M\otimes_{\mathcal O_{\operatorname{Proj}(R)}}\mathcal O_Y(n),
$$

sehingga diperoleh homomorfisme modul

$$
\widehat M\otimes_{\mathcal O_{\operatorname{Proj}(R)}}\mathcal O_Y(n)
\longrightarrow\widehat{M(n)}.
$$

Bahwa homomorfisme ini merupakan isomorfisme dapat dibuktikan pada suatu
liputan afin. Jika $f$ homogen, maka menurut Lema 14.10 dan Lema 15.3(2),
homomorfisme modul $(R_f)_0$ di atas,

$$
(M_f)_0\otimes_{(R_f)_0}(R_f)_n
\longrightarrow(M_f)_n,
$$

sama dengan evaluasi homomorfisme yang telah dijadikan berkas. Jika $f$
berderajat $1$ - dan himpunan-himpunan terbuka $D_+(f)$ yang bersangkutan
menutupi $Y$ - maka homomorfisme itu merupakan isomorfisme. Menurut
Soal 12.2,

$$
(R_f)_0\cong(R_f)_n
$$

melalui $1\mapsto f^n$, sehingga modul di ruas kiri isomorfik dengan
$(M_f)_0$. Dengan identifikasi ini, pemetaannya diberikan oleh

$$
\frac{m}{f^k}\longmapsto f^n\cdot\frac{m}{f^k},
$$

dan pemetaan ini bijektif karena $f$ merupakan unit.

<!-- upstream_entity: Standard-graduierter Ring/Projektives Spektrum/Quasikohärenter Modul/Twist/Definition -->

### Definisi 15.8: twist modul kuasikoheren {#br-bgk-2019-l15-def-03}

Misalkan $R$ gelanggang bergradasi standar, $\mathcal F$ modul kuasikoheren
pada $Y=\operatorname{Proj}(R)$, dan $n\in\mathbb Z$. Modul

$$
\mathcal F(n):=\mathcal F\otimes_{\mathcal O_Y}\mathcal O_Y(n)
$$

disebut *twist ke-$n$* dari $\mathcal F$.

Dengan demikian, berkas modul $\widehat{M(n)}$ sama dengan twist ke-$n$ dari
$\widehat M$.

## Pembangkitan global {#br-bgk-2019-l15-s02}

<!-- upstream_entity: Beringter Raum/Modulgarbe/Von globalen Schnitten erzeugt/Definition -->

### Definisi 15.9: dibangkitkan oleh seksi global {#br-bgk-2019-l15-def-04}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal M$ modul
$\mathcal O_X$ pada $X$. Kita mengatakan bahwa $\mathcal M$ *dibangkitkan
oleh seksi global* jika terdapat suatu keluarga

$$
s_i\in\Gamma(X,\mathcal M),\qquad i\in I,
$$

sedemikian sehingga, untuk setiap titik $x\in X$, tangkai $\mathcal M_x$
sebagai modul $\mathcal O_{X,x}$ dibangkitkan oleh pembatasan-pembatasan
$s_i$.

<!-- upstream_entity: Schema/Modulgarbe/Von globalen Schnitten erzeugt/Fakt -->

### Proposisi 15.10: sifat keterbangkitan global {#br-bgk-2019-l15-prop-01}

Misalkan $(X,\mathcal O_X)$ suatu skema. Maka berlaku pernyataan-pernyataan
berikut.

1. Berkas struktur $\mathcal O_X$ dibangkitkan oleh seksi global.

2. Modul kuasikoheren $\mathcal M$ dibangkitkan oleh seksi global jika dan
   hanya jika terdapat homomorfisme modul surjektif

   $$
   \mathcal O_X^{(I)}\longrightarrow\mathcal M.
   $$

3. Pada skema afin, setiap modul kuasikoheren dibangkitkan oleh seksi global.

4. Jika $\mathcal M$ dibangkitkan oleh seksi global dan
   $\mathcal M\to\mathcal N$ surjektif, maka $\mathcal N$ juga dibangkitkan
   oleh seksi global.

#### Bukti {#br-bgk-2019-l15-prop-01-proof}

Lihat Soal 15.17.

<!-- upstream_entity: Projektiver Raum/Getwistete Strukturgarbe/Von globalen Schnitten erzeugt/Fakt -->

### Lema 15.11: keterbangkitan global berkas struktur terpuntir {#br-bgk-2019-l15-lem-05}

Pada ruang projektif $\mathbb P_R^d$ di atas gelanggang komutatif $R$,
berkas struktur terpuntir $\mathcal O_{\mathbb P_R^d}(k)$ dibangkitkan oleh
seksi global untuk $k\geq0$, dan tidak dibangkitkan oleh seksi global untuk
$k<0$ dan $d\geq1$.

#### Bukti {#br-bgk-2019-l15-lem-05-proof}

Lihat Soal 15.18.

<!-- upstream_entity: Projektiver Raum/Noethersch/Kohärente Garbe/Twist/Von globalen Schnitten erzeugt/Fakt -->

### Teorema 15.12: twist positif akhirnya dibangkitkan secara global {#br-bgk-2019-l15-thm-01}

Misalkan $\mathbb P_R^d$ ruang projektif di atas gelanggang Noether $R$, dan
misalkan $\mathcal G$ berkas koheren pada $\mathbb P_R^d$. Maka terdapat
$\ell\in\mathbb N_+$ sedemikian sehingga $\mathcal G(\ell)$ dibangkitkan
oleh seksi global.

#### Bukti {#br-bgk-2019-l15-thm-01-proof}

Terdapat isomorfisme

$$
\mathcal G|_{D_+(X_i)}\cong\widetilde M_i,
$$

dengan $M_i$ modul yang dibangkitkan secara hingga atas gelanggang polinomial $R_i$ yang
bersesuaian dengan $D_+(X_i)$. Untuk berkas invertibel
$\mathcal O_{\mathbb P_R^d}(1)$, lokus keterbalikan seksi global $X_i$
menurut Soal 13.21 sama dengan $D_+(X_i)$. Untuk sistem pembangkit modul
hingga $s_{ij}$, $j\in J_i$, dari $M_i$ atas $R_i$, menurut Teorema 14.13(2)
terdapat suatu eksponen bersama $n$ sedemikian sehingga $X_i^n s_{ij}$
berasal dari unsur-unsur global dalam

$$
\Gamma(\mathbb P_R^d,\mathcal G(n)).
$$

Hal ini dapat dilakukan untuk setiap $i$, sehingga diperoleh suatu $\ell$
sedemikian sehingga seksi-seksi global dari
$\Gamma(\mathbb P_R^d,\mathcal G(\ell))$ membangkitkan modul-modul pada
liputan terbuka afin. Akibatnya, seksi-seksi itu juga membangkitkan semua
tangkai, sehingga keterbangkitan global berlaku.

<!-- upstream_entity: Projektiver Raum/Kohärente Garbe/Surjektion mit direkter Summe/Fakt -->

### Teorema 15.13: presentasi surjektif oleh berkas struktur terpuntir {#br-bgk-2019-l15-thm-02}

Misalkan $\mathbb P_R^d$ ruang projektif di atas gelanggang Noether $R$, dan
misalkan $\mathcal G$ berkas koheren pada $\mathbb P_R^d$. Maka terdapat
suatu jumlah langsung hingga

$$
\bigoplus_{j\in J}\mathcal O_{\mathbb P_R^d}(\ell_j)
$$

dan suatu homomorfisme modul surjektif

$$
\bigoplus_{j\in J}\mathcal O_{\mathbb P_R^d}(\ell_j)
\longrightarrow\mathcal G.
$$

#### Bukti {#br-bgk-2019-l15-thm-02-proof}

Menurut Teorema 15.12, terdapat $\ell$ sedemikian sehingga
$\mathcal G(\ell)$ dibangkitkan oleh sejumlah hingga seksi global. Menurut
Proposisi 15.10(2), terdapat homomorfisme modul surjektif

$$
\mathcal O_{\mathbb P_R^d}^{r}\longrightarrow\mathcal G(\ell).
$$

Dengan menensor pemetaan ini oleh $\mathcal O_{\mathbb P_R^d}(-\ell)$, kita
memperoleh surjeksi

$$
\left(\mathcal O_{\mathbb P_R^d}(-\ell)\right)^r
\longrightarrow\mathcal G.
$$
