---
title: "Lembar Kerja 7 - Ruang Berdering dan Gelanggang Lokal"
stable_id: br-bgk-2019-w07
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 7"
upstream_pageid: 110212
upstream_revid: 618943
upstream_timestamp: "2020-02-16T12:35:13Z"
upstream_mediawiki_sha1: fe0e1a1fd6c0ca988bc7aea5d9f262f55f785aa1
source_url: "https://de.wikiversity.org/w/index.php?oldid=618943"
authority_manifest: authority/wikiversity-bgk/unit-07/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 001074c62cedb1efc988d3214416d2d86a02976d5b22dc272f4fe064e72dfc95
worksheet_xml: authority/wikiversity-bgk/unit-07/worksheet-07.xml
worksheet_xml_sha256: 4115e3aef855bacb808d29db8d41477629bb0a50e895c8a38b5e237fb0b1436b
worksheet_expanded_tex: authority/wikiversity-bgk/unit-07/worksheet-07-expanded.tex
worksheet_expanded_tex_sha256: 5318e77fd0a3d79dbd08281bca06b39c6639940901fbf6aaf13fac16fd60d898
exercise_map: authority/wikiversity-bgk/unit-07/ORDERED_EXERCISE_MAP.json
exercise_map_sha256: 309a1478ffcc6b7fdd02ddb72f29dca37d9d9ca8756737e7723d9bae148365c0
official_pdf: authority/artifacts/bgk-worksheet-07-official.pdf
official_pdf_sha256: a0cacead1e51ae62e560992c04bb9e519a1aaa85c8fd007d6756602bd594693f
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
exercise_count: 21
public_solution_count: 1
---

# Lembar Kerja 7: Ruang Berdering dan Gelanggang Lokal {#br-bgk-2019-w07}

<!-- upstream_entity: Beringter Raum/Offene Teilmenge/Aufgabe -->

## Soal 7.1 {#br-bgk-2019-w07-ex01}

Tunjukkan bahwa setiap himpunan terbuka $U\subseteq X$ dari ruang berdering
$\bigl(X,\mathcal O_X\bigr)$ kembali merupakan ruang berdering.

<!-- upstream_entity: Beringter Raum/Global 0/Aufgabe -->

## Soal 7.2 {#br-bgk-2019-w07-ex02}

Misalkan $(X,\mathcal O_X)$ ruang berdering dengan

$$
\Gamma(X,\mathcal O_X)=0.
$$

Tunjukkan bahwa untuk setiap himpunan terbuka $U\subseteq X$ juga berlaku

$$
\Gamma(U,\mathcal O_X)=0.
$$

<!-- upstream_entity: Topologischer Raum/Stetige Funktionen/Offene dichte Teilmenge/Restriktion/Injektiv/Aufgabe -->

## Soal 7.3 {#br-bgk-2019-w07-ex03}

Misalkan $X$ ruang topologis yang dilengkapi berkas fungsi bernilai real, dan
$U\subseteq X$ himpunan terbuka yang padat. Tunjukkan bahwa pemetaan restriksi

$$
\begin{aligned}
\Gamma(X,\mathcal O_X)&\longrightarrow\Gamma(U,\mathcal O_X),\\
f&\longmapsto f\big|_U
\end{aligned}
$$

bersifat injektif.

<!-- upstream_entity: Topologischer Raum/Stetige Funktionen/Offene dichte Teilmenge/Restriktion/Nicht surjektiv/Aufgabe -->

## Soal 7.4 {#br-bgk-2019-w07-ex04}

Misalkan $X$ ruang topologis yang dilengkapi berkas fungsi bernilai real, dan
$U\subseteq X$ himpunan terbuka yang padat. Tunjukkan bahwa pemetaan restriksi

$$
\Gamma(X,\mathcal O_X)\longrightarrow\Gamma(U,\mathcal O_X),
\qquad f\longmapsto f\big|_U,
$$

tidak harus surjektif.

<!-- upstream_entity: Beringter Raum/Einheiten/Garbe/Aufgabe -->

## Soal 7.5 {#br-bgk-2019-w07-ex05}

Misalkan $(X,\mathcal O_X)$ ruang berdering. Tunjukkan bahwa penetapan yang
mengaitkan setiap himpunan terbuka $U\subseteq X$ dengan grup satuan

$$
\bigl(\Gamma(U,\mathcal O_X)\bigr)^\times
$$

dari gelanggang komutatif $\Gamma(U,\mathcal O_X)$, bersama restriksi alami,
merupakan sebuah berkas grup komutatif.

Berkas ini mempunyai nama khusus. Untuk ruang berdering
$(X,\mathcal O_X)$, berkas yang pada himpunan terbuka $U\subseteq X$
didefinisikan oleh

$$
\Gamma(U,\mathcal O_X^\times)
:=\bigl(\Gamma(U,\mathcal O_X)\bigr)^\times
$$

disebut *berkas satuan* pada $X$.

<!-- upstream_entity: Beringter Raum/Morphismus/Hintereinanderschaltung/Aufgabe -->

## Soal 7.6 {#br-bgk-2019-w07-ex06}

Tunjukkan bahwa komposisi morfisme-morfisme ruang berdering kembali merupakan
morfisme ruang berdering.

<!-- upstream_entity: Beringter Raum/Offene Teilmenge/Inklusion/Morphismus/Aufgabe -->

## Soal 7.7 {#br-bgk-2019-w07-ex07}

Tunjukkan bahwa untuk setiap himpunan terbuka $U\subseteq X$ dari ruang
berdering $(X,\mathcal O_X)$ terdapat morfisme ruang berdering

$$
(U,\mathcal O_X|_U)\longrightarrow(X,\mathcal O_X).
$$

<!-- upstream_entity: Topologischer Raum/Stetige Funktionen/Beringter Raum/Morphismus/Aufgabe -->

## Soal 7.8 {#br-bgk-2019-w07-ex08}

Misalkan $X$ dan $Y$ ruang topologis serta $\varphi:X\to Y$ pemetaan kontinu.
Tunjukkan bahwa pemetaan ini menginduksi sebuah morfisme ruang berdering lokal.

<!-- upstream_entity: Reelle Mannigfaltigkeit/Differenzierbare Abbildung/Beringter Raum/Morphismus/Aufgabe -->

## Soal 7.9 {#br-bgk-2019-w07-ex09}

Misalkan $L$ dan $M$ manifold terdiferensialkan serta
$\varphi:L\to M$ pemetaan terdiferensialkan. Tunjukkan bahwa pemetaan ini
menginduksi sebuah morfisme ruang berdering lokal.

<!-- upstream_entity: Reelle Mannigfaltigkeit/Stetige Funktionen/Differenzierbare Funktionen/Morphismus/Aufgabe -->

## Soal 7.10 {#br-bgk-2019-w07-ex10}

Misalkan $M$ manifold terdiferensialkan. Kita dapat menjadikannya ruang
berdering dengan dua cara: menggunakan berkas fungsi kontinu
$C^0(-,\mathbb R)$, atau menggunakan berkas fungsi terdiferensialkan
$C^1(-,\mathbb R)$. Tunjukkan bahwa terdapat morfisme ruang berdering

$$
(M,C^0(-,\mathbb R))\longrightarrow(M,C^1(-,\mathbb R))
$$

yang secara topologis merupakan identitas, tetapi bukan isomorfisme ruang
berdering.

> **Catatan edisi — objek fungsi.** Kedua berkas pada sumber dibaca sebagai
> berkas fungsi real kontinu dan terdiferensialkan pada himpunan terbuka yang
> sama; notasi $C^0(-,\mathbb R)$ dan $C^1(-,\mathbb R)$ dipertahankan.

Dalam soal-soal berikut, gelanggang lokal menjadi pusat perhatian.

<!-- upstream_entity: Lokaler Ring/Charakterisierung mit Addition/Aufgabe -->

## Soal 7.11 {#br-bgk-2019-w07-ex11}

Misalkan $R$ gelanggang komutatif. Tunjukkan bahwa $R$ merupakan gelanggang
lokal tepat ketika $a+b$ hanya merupakan satuan apabila $a$ atau $b$ merupakan
satuan.

<!-- upstream_entity: Kommutative Ringtheorie/Lokaler Ring/Definition äquivalent/Aufgabe -->

## Soal 7.12 {#br-bgk-2019-w07-ex12}

Misalkan $R$ gelanggang komutatif. Tunjukkan ekuivalensi pernyataan-pernyataan
berikut.

1. $R$ mempunyai tepat satu ideal maksimal.
2. Himpunan bukan-satuan $R\setminus R^\times$ membentuk sebuah ideal di $R$.

<!-- upstream_entity: Lokaler Ring/Enthält Körper/Gleiche Charakteristik/Aufgabe -->

## Soal 7.13 {#br-bgk-2019-w07-ex13}

Misalkan $R$ gelanggang lokal dengan lapangan residu $K$. Tunjukkan bahwa $R$
dan $K$ mempunyai karakteristik yang sama tepat ketika $R$ memuat sebuah
lapangan.

<!-- upstream_entity: Lokaler Ring/Restklassenring/Einheiten surjektiv/Aufgabe -->

## Soal 7.14* {#br-bgk-2019-w07-ex14}

Misalkan $R$ gelanggang lokal dan $\mathfrak a$ sebuah ideal dari $R$.
Tunjukkan bahwa pemetaan

$$
R^\times\longrightarrow(R/\mathfrak a)^\times
$$

surjektif.

<!-- upstream_entity: Rationale Zahlen/Unterringe/Lokaler Ring/Aufgabe -->

## Soal 7.15 {#br-bgk-2019-w07-ex15}

Tentukan subgelanggang dari bilangan rasional $\mathbb Q$ yang bersifat lokal.

<!-- upstream_entity: Topologischer Raum/Stetige Funktionen/Restekörper/Aufgabe -->

## Soal 7.16 {#br-bgk-2019-w07-ex16}

Misalkan $X$ ruang topologis yang dilengkapi berkas fungsi kontinu bernilai
real. Tunjukkan bahwa lapangan residu di setiap titik $X$ sama dengan
$\mathbb R$.

<!-- upstream_entity: Reelle Zahlen/Körperisomorphismus/Ist Identität/Aufgabe -->

## Soal 7.17 {#br-bgk-2019-w07-ex17}

Tunjukkan bahwa satu-satunya isomorfisme lapangan

$$
\varphi:\mathbb R\longrightarrow\mathbb R
$$

adalah identitas.

<!-- upstream_entity: Topologischer Raum/Stetige Funktion/Beringter Raum/Rekonstruktion/Aufgabe -->

## Soal 7.18 {#br-bgk-2019-w07-ex18}

Misalkan $X$ ruang topologis yang dilengkapi berkas fungsi kontinu bernilai
real. Kita memandangnya sebagai ruang berdering abstrak: kita melupakan bahwa
unsur-unsurnya adalah fungsi, tetapi masih mengetahui ruang topologis,
gelanggang, serta pemetaan restriksinya. Apakah makna unsur gelanggang sebagai
fungsi dapat direkonstruksi dari data ini?

<!-- upstream_entity: Topologischer Raum/Stetige Funktion/C/Beringter Raum/Automorphismus/Rekonstruktion/Aufgabe -->

## Soal 7.19 {#br-bgk-2019-w07-ex19}

Misalkan $X$ ruang topologis yang dilengkapi berkas fungsi kontinu bernilai
kompleks. Tunjukkan bahwa penetapan

$$
(X,C^0(-,\mathbb C))\longrightarrow(X,C^0(-,\mathbb C)),
$$

yang secara topologis merupakan identitas dan mengirim setiap fungsi pada
himpunan terbuka ke fungsi konjugat kompleksnya, merupakan automorfisme ruang
berdering. Simpulkan bahwa dari pengetahuan tentang
$(X,C^0(-,\mathbb C))$ sebagai ruang berdering abstrak, cara kerja unsur-unsur
gelanggang sebagai fungsi tidak dapat direkonstruksi.

<!-- upstream_entity: Beringter Raum/Einheit/Lokale Eigenschaft/Aufgabe -->

## Soal 7.20 {#br-bgk-2019-w07-ex20}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan

$$
f\in\Gamma(X,\mathcal O_X).
$$

Tunjukkan bahwa sifat-sifat berikut ekuivalen.

1. $f$ merupakan satuan di $\Gamma(X,\mathcal O_X)$.
2. Ada penutup terbuka

   $$
   X=\bigcup_{i\in I}U_i
   $$

   sedemikian sehingga setiap restriksi $f|_{U_i}$ merupakan satuan.
3. Germ $f_P\in\mathcal O_{X,P}$ merupakan satuan untuk setiap titik
   $P\in X$.

> **Catatan edisi — variabel pada sumber.** Sumber memakai huruf $s$ pada
> restriksi di butir (2), meskipun fungsi yang diperkenalkan ialah $f$.
> Terjemahan menulis $f|_{U_i}$ agar kuantifikasi matematisnya konsisten;
> tidak ada isi baru yang ditambahkan.

<!-- upstream_entity: Lokal beringter Raum/Invertierbarkeitsort/Monoidhomomorphismus/Aufgabe -->

## Soal 7.21 {#br-bgk-2019-w07-ex21}

Misalkan $(X,\mathcal O_X)$ ruang berdering lokal. Tunjukkan bahwa penetapan

$$
\begin{aligned}
\Gamma(X,\mathcal O_X)&\longrightarrow\tau(X),\\
f&\longmapsto X_f
\end{aligned}
$$

memberikan homomorfisme monoid antara monoid multiplikatif gelanggang seksi
global dan monoid himpunan terbuka pada $X$, dengan irisan sebagai operasi.

> **Catatan edisi — ruang dasar pada sumber.** Sumber menyebut monoid
> himpunan terbuka dari $M$ pada kalimat terakhir, meskipun ruang yang sedang
> digunakan ialah $X$. Terjemahan memperbaiki simbol ruang dasar menjadi $X$;
> definisi $X_f$ dan operasi irisan tetap sama.
