---
title: "Kuliah 14 - Modul Kuasikoheren"
stable_id: br-bgk-2019-l14
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 14"
upstream_pageid: 109018
upstream_revid: 1019980
upstream_timestamp: "2025-08-09T13:36:46Z"
upstream_mediawiki_sha1: f6d1200be466cd501f566a755ab3009dedda8b3e
source_url: "https://de.wikiversity.org/w/index.php?oldid=1019980"
lecture_xml: authority/wikiversity-bgk/unit-14/lecture-14.xml
lecture_xml_sha256: 29dacade22fd06d6d59b435665a143004580611eef2bebc706a507507b30d27c
lecture_expanded_tex: authority/wikiversity-bgk/unit-14/lecture-14-expanded.tex
lecture_expanded_tex_sha256: c7baacd23aa5ab8ae7b0525bebd1c3646438b5df95af3fa3b6e235974bfed279
official_pdf_metadata: authority/wikiversity-bgk/unit-14/official-pdfs-api.json
official_pdf_metadata_sha256: 87597a5f905829e257b9997c3b4b9855ae455be7d1272aa1dec2fa0f4b5851a3
official_course_pdf: authority/artifacts/bgk-course-official.pdf
official_course_pdf_bytes: 2104862
official_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
official_course_pdf_printed_pages: "120-126"
course_authority_manifest: authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json
course_authority_manifest_sha256: ea0bf346e261db8ed80b7565f7746e95c79e0c376d25d9fbce5d96879dff7dd8
media_credits: source/id-ID/media-credits-bgk-unit-14.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 14: Modul Kuasikoheren {#br-bgk-2019-l14}

## Modul kuasikoheren pada skema afin {#br-bgk-2019-l14-s01}

Untuk gelanggang komutatif $R$, modul-modul $R$ merupakan objek yang penting
dan mencirikan gelanggang tersebut, misalnya ideal, gelanggang faktor, modul
projektif, dan modul diferensial Kähler. Kita ingin menemukan kembali
modul-modul ini dalam konteks spektrum, yakni dalam bentuk yang digeometrikan.
Konstruksinya berjalan sejajar dengan cara berkas struktur diperkenalkan pada
spektrum.

<!-- upstream_entity: Spektrum/Modul/Prägarbe/Beispiel -->

### Contoh 14.1: praberkas yang berasal dari modul {#br-bgk-2019-l14-exm-01}

Misalkan $M$ modul $R$ di atas gelanggang komutatif $R$. Kita dapat
mendefinisikan praberkas modul dengan menetapkan, untuk setiap himpunan
terbuka $U\subseteq X$,

$$
\mathcal P(U)=\operatorname*{colim}_{U\subseteq D(f)}M_f.
$$

Objek-objek ini merupakan modul di atas gelanggang

$$
\operatorname*{colim}_{U\subseteq D(f)}R_f,
$$

dan terdapat homomorfisme restriksi alami yang kompatibel dengan struktur
modul. Tangkai praberkas ini pada ideal prima $\mathfrak p$ adalah
$M_{\mathfrak p}$.

<!-- upstream_entity: Spektrum/Modul/Definition -->

### Definisi 14.2: berkas modul pada spektrum {#br-bgk-2019-l14-def-01}

Misalkan

$$
(X,\mathcal O_X)=\operatorname{Spek}(R)
$$

skema afin dari gelanggang komutatif $R$, dan misalkan $M$ modul $R$.
*Modul $\mathcal O_X$ yang terkait dengan $M$*, dilambangkan $\widetilde M$,
adalah pemasangan yang kepada setiap himpunan terbuka $U\subseteq X$
memasangkan grup komutatif

$$
\begin{aligned}
\Gamma(U,\widetilde M)=\biggl\{&(s_{\mathfrak p})_{\mathfrak p\in U}
\in\prod_{\mathfrak p\in U}M_{\mathfrak p}\ \bigg|\\
&\text{untuk setiap }\mathfrak p\in U\text{ terdapat }m\in M\text{ dan }f\in R
\text{ dengan }\mathfrak p\in D(f)\subseteq U,\\
&\text{dan }s_{\mathfrak q}=m/f\text{ dalam }M_{\mathfrak q}
\text{ untuk semua }\mathfrak q\in D(f)\biggr\},
\end{aligned}
$$

bersama perkalian skalar

$$
\begin{aligned}
\Gamma(U,\mathcal O_X)\times\Gamma(U,\widetilde M)
&\longrightarrow\Gamma(U,\widetilde M),\\
\bigl((g_{\mathfrak p})_{\mathfrak p\in U},
(s_{\mathfrak p})_{\mathfrak p\in U}\bigr)
&\longmapsto(g_{\mathfrak p}s_{\mathfrak p})_{\mathfrak p\in U}.
\end{aligned}
$$

Kepada setiap inklusi $U\subseteq V$ dipasangkan proyeksi alami.

Jika konstruksi dimulai dengan gelanggang $R$ itu sendiri, hasilnya adalah
berkas struktur.

<!-- upstream_entity: Spektrum/Modul/Garbe/Fakt -->

### Lema 14.3: konstruksi tersebut menghasilkan modul $\mathcal O_X$ {#br-bgk-2019-l14-lem-01}

Untuk modul $R$ $M$ di atas gelanggang komutatif $R$, $\widetilde M$ adalah
modul $\mathcal O_X$ pada skema afin $X=\operatorname{Spek}(R)$.

#### Bukti {#br-bgk-2019-l14-lem-01-proof}

Hal ini bertumpu pada fakta bahwa $\widetilde M$ didefinisikan sebagai
berkasisasi praberkas

$$
U\longmapsto\operatorname*{colim}_{U\subseteq D(f)}M_f,
$$

dan struktur modul diwariskan kepada berkasisasinya.

<!-- upstream_entity: Affines Schema/Modul/Punkt/Halm/Lokalisierung/Fakt -->

### Lema 14.4: tangkai adalah pelokalan {#br-bgk-2019-l14-lem-02}

Misalkan $(X,\mathcal O_X)$ skema afin dari gelanggang komutatif $R$, dan
misalkan $x\in X$ titik yang bersesuaian dengan ideal prima $\mathfrak p$.
Jika $M$ modul $R$ dengan berkas modul terkait $\widetilde M$, maka tangkai
berkas tersebut adalah

$$
\widetilde M_x=M_{\mathfrak p}.
$$

#### Bukti {#br-bgk-2019-l14-lem-02-proof}

Pernyataan ini mengikuti dari Contoh 14.1 dan Lema 5.2(2).

<!-- upstream_entity: Affines Schema/Modul/Hauptmenge/Nenneraufnahme/Fakt -->

### Lema 14.5: seksi pada terbuka utama {#br-bgk-2019-l14-lem-03}

Misalkan $(X,\mathcal O_X)$ skema afin dari gelanggang komutatif $R$, dan
misalkan $M$ modul $R$ dengan modul $\mathcal O_X$ terkait $\widetilde M$.
Untuk $f\in R$ berlaku

$$
\Gamma(D(f),\widetilde M)=M_f.
$$

Khususnya, modul seksi global adalah

$$
\Gamma(X,\widetilde M)=M.
$$

#### Bukti {#br-bgk-2019-l14-lem-03-proof}

Kita terlebih dahulu membuktikan kasus khusus yang disebut terakhir. Terdapat
homomorfisme modul $R$ alami

$$
M\longrightarrow\Gamma(X,\widetilde M).
$$

Homomorfisme ini injektif karena nolnya suatu unsur dapat diuji secara lokal;
bandingkan Lema Lampiran 1.1. Untuk membuktikan surjektivitas, misalkan
$s\in\Gamma(X,\widetilde M)$ suatu unsur global. Artinya, terdapat penutup
terbuka

$$
X=\bigcup_{i\in I}U_i=\bigcup_{i\in I}D(f_i)
$$

dan unsur-unsur

$$
s_i=\frac{a_i}{f_i^{k_i}},
\qquad a_i\in M,
$$

yang berimpit sebagai seksi pada

$$
D(f_i)\cap D(f_j)=D(f_if_j),
$$

yakni berimpit sebagai unsur $M_{f_if_j}$. Menurut Korolari 8.6, kita dapat
menganggap $I$ berhingga. Kita juga dapat mengganti semua $k_i$ dengan
maksimumnya, $k$; tentu saja hal ini sekaligus mengubah pembilang lokal
$a_i$. Kompatibilitas

$$
\frac{a_i}{f_i^k}=\frac{a_j}{f_j^k}
$$

berarti terdapat persamaan

$$
(f_if_j)^m a_i f_j^k=(f_if_j)^m a_j f_i^k
$$

dalam $M$, dengan $m$ dipilih sebagai maksimum yang berlaku bagi semua
pasangan. Menurut Proposisi 8.4(2),(4), unsur-unsur $f_i$, $i\in I$,
membangkitkan ideal satuan. Hal yang sama berlaku bagi
$f_i^{m+k}$, sehingga terdapat $g_i\in R$ dengan

$$
1=\sum_{i\in I}g_if_i^{m+k}.
$$

Tetapkan

$$
a:=\sum_{i\in I}g_ia_if_i^m.
$$

Untuk setiap $j$ kemudian berlaku

$$
\begin{aligned}
af_j^{m+k}
&=\sum_{i\in I}g_ia_if_i^mf_j^{m+k}\\
&=\sum_{i\in I}g_i(f_if_j)^ma_if_j^k\\
&=\sum_{i\in I}g_i(f_if_j)^ma_jf_i^k\\
&=a_jf_j^m\left(\sum_{i\in I}g_if_i^{m+k}\right)\\
&=a_jf_j^m.
\end{aligned}
$$

Ini berarti bahwa

$$
\frac a1=\frac{a_j}{f_j^k}=s_j
$$

dalam $M_{f_j}$, sehingga seksi tersebut direpresentasikan oleh satu unsur
modul.

Sekarang tinjau situasi pada $D(f)$. Situasi ini sama dengan kasus yang baru
dibahas jika $R_f$ dipakai sebagai gelanggang baru dan $M_f$ sebagai modul
baru.

<!-- upstream_entity: Ganzheitsring/Wurzel -5/Standardideal/Garbe/Invertierbar/Beispiel -->

### Contoh 14.6: ideal takutama yang memberi berkas invertibel {#br-bgk-2019-l14-exm-02}

Dalam gelanggang bilangan kuadratik

$$
R=A_{-5}=\mathbb Z[\sqrt{-5}]=\mathbb Z[T]/(T^2+5)
$$

berlaku kesamaan

$$
2\cdot3=6=(1+\sqrt5\,\mathrm i)(1-\sqrt5\,\mathrm i).
$$

Tinjau ideal

$$
I=(2,1+\sqrt{-5}),
$$

yang merupakan ideal prima tetapi bukan ideal utama, beserta berkas ideal
terkait $\widetilde I$ pada $X=\operatorname{Spek}(R)$. Spektrum ditutupi oleh
dua himpunan terbuka $D(2)$ dan $D(3)$. Kita mempunyai

$$
\widetilde I|_{D(2)}\cong\mathcal O_X|_{D(2)},
$$

karena $2\in I$, sehingga ideal itu menjadi ideal satuan dalam pelokalan
$R_2$. Di dalam $R_3$, yakni pada $D(3)$, berlaku

$$
2=\frac{1-\sqrt5\,\mathrm i}3(1+\sqrt5\,\mathrm i),
$$

sehingga $I_3$ adalah ideal utama dengan pembangkit $1+\sqrt5\,\mathrm i$.
Jadi

$$
\widetilde I|_{D(3)}\cong\mathcal O_X|_{D(3)},
$$

dan $\widetilde I$ merupakan berkas invertibel.

<!-- upstream_entity: An-Singularität/Punktiertes Schema/Invertierbares Ideal/Beispiel -->

### Contoh 14.7: ideal invertibel pada singularitas yang dilubangi {#br-bgk-2019-l14-exm-03}

Tinjau ideal $I=(X,Z)$ dalam singularitas $A_{n-1}$

$$
R=K[X,Y,Z]/(XY-Z^n).
$$

Ideal ini mendefinisikan berkas ideal $\widetilde I$ pada
$\operatorname{Spek}(R)$, dan dengan demikian juga berkas ideal terbatas
$\widetilde I|_U$ pada skema kuasiafin

$$
U=D(X,Y,Z)=D(X,Y)
=\operatorname{Spek}(R)\setminus\{(X,Y,Z)\}
\subset\operatorname{Spek}(R).
$$

Berkas terbatas ini invertibel pada $U$. Memang, $X\in I$, dan dalam $R_Y$
berlaku

$$
X=\frac{Z^{n-1}}Y Z.
$$

Karena itu terdapat isomorfisme

$$
\widetilde I|_{D(X)}\cong
\mathcal O_{\operatorname{Spek}(R)}|_{D(X)}
\qquad\text{dan}\qquad
\widetilde I|_{D(Y)}\cong
\mathcal O_{\operatorname{Spek}(R)}|_{D(Y)}.
$$

Sebaliknya, $\widetilde I$ tidak invertibel pada seluruh spektrum, karena
ideal $I$ dalam pelokalan $R_{(X,Y,Z)}$ bukan ideal utama.

<!-- upstream_entity: Affines Schema/Moduln/Homomorphismus/Garbenversion/Fakt -->

### Lema 14.8: homomorfisme modul menginduksi homomorfisme berkas {#br-bgk-2019-l14-lem-04}

Misalkan $(X,\mathcal O_X)$ skema afin dari gelanggang komutatif $R$, dan
misalkan

$$
\varphi:M\longrightarrow N
$$

homomorfisme modul $R$. Terdapat tepat satu homomorfisme modul
$\mathcal O_X$

$$
\widetilde M\longrightarrow\widetilde N
$$

yang secara global sama dengan $\varphi$.

#### Bukti {#br-bgk-2019-l14-lem-04-proof}

Untuk setiap $f\in R$, kompatibilitas dengan restriksi mengharuskan diagram
berikut komutatif:

$$
\begin{matrix}
\Gamma(X,\widetilde M)=M&\xrightarrow{\ \varphi\ }&
\Gamma(X,\widetilde N)=N\\
\downarrow&&\downarrow\\
\Gamma(D(f),\widetilde M)=M_f&\longrightarrow&
\Gamma(D(f),\widetilde N)=N_f.
\end{matrix}
$$

Diagram tersebut menentukan pemetaan bawah secara unik. Penetapan ini lalu
menentukan satu homomorfisme praberkas, dan melalui berkasisasi menentukan
satu homomorfisme berkas.

<!-- upstream_entity: Affines Schema/Moduln/Exaktheit/Fakt -->

### Lema 14.9: barisan eksak pendek beralih ke berkas {#br-bgk-2019-l14-lem-05}

Misalkan $R$ gelanggang komutatif dan

$$
0\longrightarrow L\longrightarrow M\longrightarrow N\longrightarrow0
$$

barisan eksak pendek modul $R$. Pada skema afin
$(X,\mathcal O_X)=\operatorname{Spek}(R)$ terdapat barisan eksak pendek
berkas

$$
0\longrightarrow\widetilde L\longrightarrow\widetilde M
\longrightarrow\widetilde N\longrightarrow0
$$

yang terdiri atas modul $\mathcal O_X$ kuasikoheren.

#### Bukti {#br-bgk-2019-l14-lem-05-proof}

Menurut Lema Lampiran 2.2, untuk setiap ideal prima $\mathfrak p$, barisan
eksak pendek semula menghasilkan barisan eksak pendek

$$
0\longrightarrow L_{\mathfrak p}\longrightarrow M_{\mathfrak p}
\longrightarrow N_{\mathfrak p}\longrightarrow0.
$$

Menurut Lema 14.4, inilah versi pada tangkai dari homomorfisme modul di antara
$\widetilde L$, $\widetilde M$, dan $\widetilde N$ pada titik
$\mathfrak p$. Menurut Lema 6.3, hal itu tepat berarti kompleks berkas
tersebut eksak.

<!-- upstream_entity: Affines Schema/Moduln/Tensorprodukt/Fakt -->

### Lema 14.10: hasil kali tensor berkas modul afin {#br-bgk-2019-l14-lem-06}

Misalkan $R$ gelanggang komutatif, $M$ dan $N$ modul $R$, serta
$\widetilde M$ dan $\widetilde N$ berkas modul terkait pada
$X=\operatorname{Spek}(R)$. Terdapat isomorfisme kanonik

$$
\widetilde M\otimes_{\mathcal O_X}\widetilde N
\cong\widetilde{M\otimes_RN}.
$$

#### Bukti {#br-bgk-2019-l14-lem-06-proof}

Kita mempunyai

$$
M_f\otimes_{R_f}N_f=(M\otimes_RN)_f.
$$

Tinjau praberkas

$$
U\longmapsto
\operatorname*{colim}_{U\subseteq D(f)}
(M_f\otimes_{R_f}N_f)
=
\operatorname*{colim}_{U\subseteq D(f)}(M\otimes_RN)_f.
$$

Menurut definisi, berkasisasi ruas kanan adalah berkas kuasikoheren
$\widetilde{M\otimes_RN}$. Untuk himpunan terbuka $U\subseteq D(f)$ terdapat
homomorfisme modul kanonik

$$
M_f\otimes_{R_f}N_f\longrightarrow
\left(\operatorname*{colim}_{U\subseteq D(f)}M_f\right)
\otimes_{\operatorname*{colim}_{U\subseteq D(f)}R_f}
\left(\operatorname*{colim}_{U\subseteq D(f)}N_f\right).
$$

Dengan mengambil kolimit, untuk setiap himpunan terbuka diperoleh
homomorfisme modul dari praberkas pertama menuju hasil kali tensor kedua
praberkas modul tersebut. Homomorfisme ini kompatibel dengan restriksi, jadi
merupakan homomorfisme praberkas. Menurut Lema 5.2(1),(5), homomorfisme itu
beralih ke berkas terkait. Berdasarkan pengamatan awal, berkasisasi di sisi
kiri adalah $\widetilde{M\otimes_RN}$, sedangkan menurut definisi berkasisasi
di sisi kanan adalah
$\widetilde M\otimes_{\mathcal O_X}\widetilde N$. Karena homomorfisme ini
merupakan isomorfisme pada setiap tangkai, Lema 4.6 menunjukkan bahwa ia
merupakan isomorfisme berkas.

## Modul kuasikoheren {#br-bgk-2019-l14-s02}

Untuk skema sebarang, berkas modul yang paling penting adalah berkas yang
pada bagian-bagian afin tampak seperti $\widetilde M$.

<!-- upstream_entity: Schema/Quasikohärente Garbe/Definition -->

### Definisi 14.11: modul kuasikoheren {#br-bgk-2019-l14-def-02}

Modul $\mathcal O_X$ $\mathcal M$ pada skema $(X,\mathcal O_X)$ disebut
*kuasikoheren* jika terdapat penutup terbuka afin

$$
X=\bigcup_{i\in I}U_i,
\qquad U_i=\operatorname{Spek}(R_i),
$$

dan modul-modul $R_i$ $M_i$ sedemikian sehingga

$$
\mathcal M|_{U_i}=\widetilde{M_i}.
$$

Khususnya, berkas struktur pada suatu skema adalah berkas kuasikoheren,
karena pada himpunan terbuka afin $U=\operatorname{Spek}(R)$ berkas itu
berimpit dengan $\widetilde R$. Berkas invertibel juga kuasikoheren.

Dapat dibuktikan bahwa untuk berkas kuasikoheren, pada setiap subhimpunan
terbuka afin $U\subseteq X$, berkas terbatasnya sudah sama dengan berkas modul
yang berasal dari suatu modul di atas gelanggang $\Gamma(U,\mathcal O_X)$.

<!-- upstream_entity: Schema/Kohärenter Modul/Definition -->

### Definisi 14.12: modul koheren {#br-bgk-2019-l14-def-03}

Modul $\mathcal O_X$ kuasikoheren $\mathcal M$ pada skema
$(X,\mathcal O_X)$ disebut *koheren* jika terdapat penutup terbuka afin

$$
X=\bigcup_{i\in I}U_i
$$

sedemikian sehingga $\Gamma(U_i,\mathcal M)$ merupakan modul yang dibangkitkan
secara hingga di atas $\Gamma(U_i,\mathcal O_X)$.

Pada skema afin $\operatorname{Spek}(R)$, modul kuasikoheren dan modul $R$
bersesuaian. Khususnya, pada skema afin, modul kuasikoheren $\mathcal M$
mempunyai "banyak" seksi global yang dapat dipakai untuk memahami dan
merekonstruksi $\mathcal M$. Hal ini sama sekali tidak berlaku secara umum
untuk berkas kuasikoheren pada skema nonafin, dan khususnya sering gagal pada
skema projektif. Di sana bahkan sering terjadi bahwa, untuk modul
kuasikoheren yang rumit, evaluasi globalnya adalah modul nol.

Dalam keadaan semacam itu, berkas invertibel yang sesuai dapat digunakan
untuk "memuntir" modul tersebut sehingga versi terpuntirnya mempunyai seksi
global. Teorema umum berikut menjadi pedoman. Perhatikan bahwa unsur

$$
g\in\Gamma(X,\mathcal L),
\qquad
s\in\Gamma(X,\mathcal M),
$$

dengan $\mathcal L$ invertibel, melalui berkasisasi mendefinisikan unsur

$$
g^ns\in\Gamma(X,\mathcal L^n\otimes\mathcal M),
$$

dengan $\mathcal L^n$ menyatakan pangkat tensor ke-$n$ dari $\mathcal L$.

<!-- upstream_entity: Noethersches Schema/Quasikohärente Garbe/Invertierbare Garbe/Invertierbarkeitsort/Globale Ausdehnung/Fakt -->

### Teorema 14.13: perluasan global dari lokus keterbalikan {#br-bgk-2019-l14-thm-01}

Misalkan $\mathcal M$ modul $\mathcal O_X$ kuasikoheren pada skema Noether
$(X,\mathcal O_X)$. Misalkan $\mathcal L$ berkas invertibel pada $X$ dan

$$
g\in\Gamma(X,\mathcal L)
$$

seksi global dengan lokus keterbalikan $X_g$. Maka pernyataan berikut
berlaku.

1. Untuk seksi global $r\in\Gamma(X,\mathcal M)$ dengan $r|_{X_g}=0$,
   terdapat $m\in\mathbb N$ sehingga

   $$
   g^mr=0
   $$

   dalam $\Gamma(X,\mathcal L^m\otimes\mathcal M)$.

2. Untuk seksi $s\in\Gamma(X_g,\mathcal M)$, terdapat $n\in\mathbb N$
   sedemikian sehingga

   $$
   g^ns\in\Gamma(X_g,\mathcal L^n\otimes\mathcal M)
   $$

   berasal dari suatu seksi global dalam
   $\Gamma(X,\mathcal L^n\otimes\mathcal M)$.

#### Bukti {#br-bgk-2019-l14-thm-01-proof}

Pilih penutup terbuka afin berhingga

$$
X=\bigcup_{i\in I}U_i
$$

sedemikian sehingga pembatasan $\mathcal L$ pada setiap $U_i$ trivial.
Tinjau

$$
V_i=X_g\cap U_i\subseteq U_i,
$$

yang merupakan himpunan terbuka dalam skema afin
$U_i=\operatorname{Spek}(R_i)$. Terdapat modul $R_i$ $M_i$ dengan

$$
\mathcal M|_{U_i}=\widetilde{M_i}.
$$

Di bawah isomorfisme
$\mathcal L|_{U_i}\cong\mathcal O_{U_i}$, pembatasan $g$ pada $U_i$
bersesuaian dengan fungsi $f_i\in R_i$, dan untuk lokus keterbalikannya
berlaku

$$
X_g\cap U_i=D(f_i).
$$

Dengan demikian,

$$
\Gamma(V_i,\mathcal M)\cong(M_i)_{f_i}.
$$

1. Misalkan $r_i=r|_{U_i}\in M_i$. Menurut asumsi, pembatasannya pada
   $V_i$ sama dengan nol, sehingga terdapat $n_i\in\mathbb N$ dengan

   $$
   f_i^{m_i}r_i=0
   $$

   dalam $M_i$; persamaan ini tetap berlaku untuk setiap eksponen yang lebih
   besar. Jika diterjemahkan ke $\mathcal L^{m_i}\otimes\mathcal M$, hal ini
   berarti bahwa unsur global $g^{m_i}r$, setelah dibatasi pada $U_i$, sama
   dengan nol. Karena itu, dengan

   $$
   m=\max(m_i\mid i\in I),
   $$

   kita memperoleh $m$ sedemikian sehingga $g^mr$ nol pada semua $U_i$.
   Berdasarkan sifat berkas, $g^mr=0$ pada $X$.

2. Seksi yang diberikan, $s\in\Gamma(X_g,\mathcal M)$, melalui pembatasan
   menghasilkan seksi

   $$
   s_i\in\Gamma(V_i,\mathcal M)
   =\Gamma(D(f_i),M_i)=(M_i)_{f_i}.
   $$

   Jadi

   $$
   s_i=\frac{t_i}{f_i^{\ell_i}}
   $$

   dengan $t_i\in M_i$. Eksponen $\ell_i$ dapat diperbesar, sehingga kita
   dapat menganggap bahwa penyajian semacam itu berlaku untuk setiap $i$
   dengan satu eksponen bersama $\ell$. Artinya, pembatasan

   $$
   g^\ell s\in\Gamma(X_g,\mathcal L^\ell\otimes\mathcal M)
   $$

   pada $X_g\cap U_i$ berasal dari suatu unsur

   $$
   t_i\in\Gamma(U_i,\mathcal L^\ell\otimes\mathcal M).
   $$

   Pada umumnya unsur-unsur $t_i$ ini belum kompatibel. Namun, pembatasan
   $t_i-t_j$ pada $X_g\cap U_i\cap U_j$ sama dengan nol. Dengan menerapkan
   bagian pertama pada

   $$
   X_g\cap U_i\cap U_j\subseteq U_i\cap U_j,
   $$

   diperoleh $m_{ij}$ sedemikian sehingga

   $$
   g^{m_{ij}}(t_i-t_j)=0
   $$

   dalam
   $\Gamma(U_i\cap U_j,\mathcal L^{\ell+m_{ij}}\otimes\mathcal M)$.
   Kalikan seluruh situasi dengan $g^m$, dengan $m$ maksimum dari semua
   $m_{ij}$. Unsur-unsur lokal itu kemudian kompatibel, sehingga untuk
   $n=\ell+m$ diperoleh perluasan global dari $g^ns$.
