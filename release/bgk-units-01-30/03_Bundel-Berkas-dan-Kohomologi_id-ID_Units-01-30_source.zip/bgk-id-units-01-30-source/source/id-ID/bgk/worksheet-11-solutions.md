---
title: "Solusi Publik dan Cakupan Lembar Kerja 11"
stable_id: br-bgk-2019-w11-solutions
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
upstream_map: authority/wikiversity-bgk/unit-11/ORDERED_EXERCISE_MAP.json
upstream_map_sha256: 44c6b2f4a86976163360cf7d0b0b60e39334ec54336e8483249431039365c161
authority_manifest: authority/wikiversity-bgk/unit-11/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: c55c715d0a1bd3ef5b13ac96ccf38f9b5c261e87124c6da5ccc5984cb61deb09
candidate_evidence: authority/wikiversity-bgk/unit-11/worksheet-solution-candidates-api.json
candidate_evidence_sha256: 18795e45391de20c07918171f5dadf47b6ea04fde24113964d3461eddfe801c4
solution_ex09_xml: authority/wikiversity-bgk/unit-11/solution-ex09.xml
solution_ex09_xml_sha256: c1a8e3d35f3aed5ffe5e37f8f36bf009d1b17d0b4034d2ccbbe69bd6e82ace94
solution_ex09_html: authority/wikiversity-bgk/unit-11/solution-ex09.html
solution_ex09_html_sha256: 3cc9ed5fb74ba0f1fae953a479aaecd48eaf8664b2cb15ea5e8aab17d4954b2e
solution_ex09_upstream_pageid: 46303
solution_ex09_upstream_revid: 1106651
solution_ex09_mediawiki_sha1: de4c7d8f5839897ae9b847696318aa8d64677481
solution_ex09_frozen_revision_contributor: "Arbota"
solution_ex13_xml: authority/wikiversity-bgk/unit-11/solution-ex13.xml
solution_ex13_xml_sha256: 9a03466ce3c08e5afe63c17c7584c7fa863c2e1a3e208eba3bcf7b52d37ef10b
solution_ex13_html: authority/wikiversity-bgk/unit-11/solution-ex13.html
solution_ex13_html_sha256: 95fe2bf8bacce3a9b38c34e509f8c1c67a1452d0ea47471a2d77df9ae19d8f26
solution_ex13_upstream_pageid: 112468
solution_ex13_upstream_revid: 1089753
solution_ex13_mediawiki_sha1: c20228f9acca9fdea22e7c0c2f3b6c89f1905031
solution_ex13_frozen_revision_contributor: "Arbota"
solution_ex14_xml: authority/wikiversity-bgk/unit-11/solution-ex14.xml
solution_ex14_xml_sha256: 50e0903c021187f4476febca48565085083f3ed6215351084be9bdf7e963d0ce
solution_ex14_html: authority/wikiversity-bgk/unit-11/solution-ex14.html
solution_ex14_html_sha256: af692e48d0804abe49a6d40dcb4696c5a1197d26a36c71953e046be1878b5f96
solution_ex14_upstream_pageid: 112464
solution_ex14_upstream_revid: 1089757
solution_ex14_mediawiki_sha1: a866b421baa8b504355e926d0dea7a39f6cbbe09
solution_ex14_frozen_revision_contributor: "Arbota"
exercise_count: 19
public_solution_count: 3
public_solution_numbers: "9, 13, 14"
negative_public_solution_count: 16
negative_solution_numbers: "1-8, 10-12, 15-19"
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

```{=latex}
\clearpage
```

# Solusi Publik dan Cakupan Lembar Kerja 11 {#br-bgk-2019-w11-solutions}

Pada batas revisi yang dibekukan, sumber menyediakan tepat tiga solusi publik
di antara 19 soal, yaitu solusi Soal 11.9, 11.13, dan 11.14. Peta soal dan
bukti kandidat mencatat hasil negatif untuk Soal 11.1-11.8, 11.10-11.12, dan
11.15-11.19. Tidak ada solusi baru yang dibuat untuk edisi ini.

## Solusi sumber untuk Soal 11.9 {#br-bgk-2019-w11-ex09-solution}

Ambil titik $P\in M$ dan lingkungan koordinat terbuka $P\in U$ beserta peta
koordinat

$$
\alpha:U\longrightarrow V\subseteq\mathbb R^n,
$$

di mana $V=B(0,3)$ adalah bola terbuka berpusat di $0$ berjari-jari $3$ dan
$\alpha(P)=0$. Untuk $i=0,\ldots,n-1$, tetapkan

$$
B_i=\left\{
x\in V\ \middle|\
(x_1-1)^2+x_2^2+\cdots+x_n^2=1,
\ x_{i+2}=\cdots=x_n=0
\right\}.
$$

Jadi $B_{n-1}$ adalah permukaan bola berpusat di
$(1,0,\ldots,0)$ berjari-jari $1$, sedangkan $B_{n-2}$ adalah “ekuator” di
dalamnya yang ditentukan oleh $x_n=0$, dan seterusnya. Himpunan $B_i$
diperoleh dari $B_{i+1}$ dengan menambahkan persamaan $x_{i+2}=0$. Maka ada
rantai turun subhimpunan tertutup

$$
B_{n-1}\supseteq B_{n-2}\supseteq\cdots\supseteq B_1\supseteq B_0,
$$

dan

$$
B_0=\{(0,0,\ldots,0),(2,0,\ldots,0)\}.
$$

Kita dapat memandang $B_i$ sebagai serat di atas titik nol dari pemetaan

$$
\begin{aligned}
\varphi_i:V&\longrightarrow\mathbb R^{n-i},\\
(x_1,\ldots,x_n)&\longmapsto
\bigl((x_1-1)^2+x_2^2+\cdots+x_n^2-1,
x_{i+2},\ldots,x_n\bigr).
\end{aligned}
$$

Matriks Jacobinya adalah

$$
D\varphi_i(x)=
\begin{pmatrix}
2x_1-2&2x_2&\cdots&2x_{i+1}&2x_{i+2}&\cdots&2x_n\\
0&0&\cdots&0&1&\cdots&0\\
\vdots&\vdots&&\vdots&&\ddots&\vdots\\
0&0&\cdots&0&0&\cdots&1
\end{pmatrix}.
$$

Rank matriks ini kurang dari $n-i$ hanya jika

$$
x_1=1,
\qquad
x_2=\cdots=x_{i+1}=0,
$$

dan titik seperti itu tidak terletak pada $B_i$. Jadi $\varphi_i$ reguler di
sepanjang serat $B_i$. Menurut teorema fungsi implisit, $B_i$ merupakan
submanifold tertutup dari $V$ berdimensi $i$.

Sekarang tetapkan

$$
M_i=\alpha^{-1}(B_i)
\quad(0\le i\le n-1),
\qquad
M_n=M.
$$

Karena setiap $B_i$ kompak, $M_i$ juga tertutup di $M$. Sifat menjadi
submanifold tertutup bersifat lokal, sehingga semua $M_i$ adalah submanifold
tertutup dari $M$ dengan dimensi yang diminta.

> **Catatan edisi - batas indeks dan dua titik sumber.** Solusi sumber mula-mula
> mendefinisikan $B_i$ dan $M_i$ hanya untuk $i=1,\ldots,n-1$, tetapi kemudian
> memakai $B_0$ dan rantai yang memerlukan $M_0$. Edisi memasukkan $i=0$ pada
> kedua rentang. Sumber juga menyatakan bahwa $B_0$ terdiri atas titik
> $(\pm1,0,\ldots,0)$; substitusi ke persamaan bola berpusat di $(1,0,\ldots,0)$
> memberi titik yang benar $(0,0,\ldots,0)$ dan $(2,0,\ldots,0)$. Formula,
> rank, dan konstruksi submanifold selain itu dipertahankan.

## Solusi sumber untuk Soal 11.13 {#br-bgk-2019-w11-ex13-solution}

Karena spektrum kuasikompak, kita dapat menganggap $I$ berhingga. Menurut
Proposisi 8.4(9), unsur-unsur $f_i$ membangkitkan ideal satuan.

Misalkan $(a_j)_{j\in J}$ sebuah sistem pembangkit ideal $\mathfrak a$. Jika
dipandang di $R_{f_i}$, sistem ini juga membangkitkan
$\mathfrak aR_{f_i}$. Untuk setiap $i$, suatu subsistem berhingga sudah
cukup; karena $I$ berhingga, gabungan indeks-indeks yang diperlukan adalah
suatu himpunan berhingga $J_0\subseteq J$. Jadi
$(a_j)_{j\in J_0}$ membangkitkan setiap $\mathfrak aR_{f_i}$.

Kita klaim bahwa unsur-unsur tersebut sudah membangkitkan $\mathfrak a$.
Ambil $b\in\mathfrak a$. Untuk setiap $i$, di $R_{f_i}$ terdapat kesamaan

$$
b=\sum_{j\in J_0}\frac{c_{ij}}{f_i^{n_{ij}}}a_j.
$$

Setelah menyamakan penyebut, di $R$ diperoleh kesamaan berbentuk

$$
f_i^{m_i}b=\sum_{j\in J_0}d_{ij}a_j.
$$

Karena himpunan-himpunan $D(f_i^{m_i})=D(f_i)$ tetap menutup spektrum,
terdapat $g_i\in R$ dengan

$$
\sum_{i\in I}g_if_i^{m_i}=1.
$$

Dengan demikian,

$$
\begin{aligned}
b
&=b\left(\sum_{i\in I}g_if_i^{m_i}\right)\\
&=\sum_{i\in I}g_i b f_i^{m_i}\\
&=\sum_{i\in I}g_i\left(\sum_{j\in J_0}d_{ij}a_j\right)\\
&=\sum_{j\in J_0}\left(\sum_{i\in I}g_id_{ij}\right)a_j.
\end{aligned}
$$

Jadi setiap $b\in\mathfrak a$ merupakan kombinasi linear dari
$(a_j)_{j\in J_0}$, sehingga $\mathfrak a$ dibangkitkan secara berhingga.

## Solusi sumber untuk Soal 11.14 {#br-bgk-2019-w11-ex14-solution}

Jelas bahwa jika $R$ gelanggang Noether, maka
$X=\operatorname{Spek}(R)$ merupakan skema Noether.

Sebaliknya, andaikan $X$ skema Noether. Ambil penutup afin berhingga

$$
X=\bigcup_{i\in I}U_i,
\qquad
U_i=\operatorname{Spek}(R_i),
$$

dengan setiap $R_i$ gelanggang Noether. Karena $U_i$ terbuka di
$X=\operatorname{Spek}(R)$ dan kuasikompak, untuk setiap $i$ terdapat
berhingga banyak $f_{ij}\in R$ sehingga

$$
U_i=\bigcup_{j\in J_i}D_X(f_{ij}).
$$

Jika

$$
\rho_i:R=\Gamma(X,\mathcal O_X)
\longrightarrow R_i=\Gamma(U_i,\mathcal O_X)
$$

adalah restriksi, maka

$$
D_X(f_{ij})=D_{U_i}(\rho_i(f_{ij})).
$$

Karena itu gelanggang seksi pada himpunan terbuka utama tersebut adalah

$$
R_{f_{ij}}
\cong (R_i)_{\rho_i(f_{ij})},
$$

yang Noether sebagai pelokalan gelanggang Noether. Dengan menggabungkan
semua $i$ dan $j$, kita memperoleh penutup utama berhingga

$$
X=\bigcup_{k=1}^N D(g_k)
$$

dengan setiap $R_{g_k}$ Noether. Untuk sembarang ideal
$\mathfrak a\subseteq R$, setiap ideal
$\mathfrak aR_{g_k}$ dibangkitkan secara berhingga. Soal 11.13 sekarang
menunjukkan bahwa $\mathfrak a$ dibangkitkan secara berhingga. Jadi setiap
ideal $R$ dibangkitkan secara berhingga dan $R$ Noether.

> **Catatan edisi - simbol pada solusi sumber.** Solusi sumber menulis
> $U_i=\bigcup_{j\in J_i}D(f_j)$ dengan indeks $i$ yang kemudian hilang,
> memakai $f_j\in R$, lalu menempatkan $\rho(f_j)$ di gelanggang seksi suatu
> himpunan $U$ yang tidak didefinisikan dan menulis pelokalan dengan subskrip
> $f$ saja. Edisi menuliskan $f_{ij}$, restriksi
> $\rho_i:R\to R_i$, serta isomorfisme
> $R_{f_{ij}}\cong(R_i)_{\rho_i(f_{ij})}$ secara eksplisit. Ini adalah data
> yang dipakai argumen sumber; tidak ada hipotesis baru.
