---
title: "Lembar Kerja 8 - Spektrum dan Pemetaan Spektrum"
stable_id: br-bgk-2019-w08
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 8"
upstream_pageid: 109250
upstream_revid: 767578
upstream_timestamp: "2022-08-15T16:40:27Z"
upstream_mediawiki_sha1: 825abbae5b4bf1875f24cd915f2b37819f30d7d4
source_url: "https://de.wikiversity.org/w/index.php?oldid=767578"
authority_manifest: authority/wikiversity-bgk/unit-08/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: cadebf48e67a54a238f4b22e0abf806fbf1f81821b6d012993739ecf50dd8d32
worksheet_xml: authority/wikiversity-bgk/unit-08/worksheet-08.xml
worksheet_xml_sha256: 642586e18b22f64505bafef094cb36b3206d1fcea7f9ce62380757d8669f0b8f
worksheet_expanded_tex: authority/wikiversity-bgk/unit-08/worksheet-08-expanded.tex
worksheet_expanded_tex_sha256: 57d8a50579be711720d8125d4f7d3308ed9e07a588445d4c9ad4a40188a41b85
exercise_map: authority/wikiversity-bgk/unit-08/ORDERED_EXERCISE_MAP.json
exercise_map_sha256: 97c9bf59cae3e34263681875e74c4ad2f0626b87f19a6e0490d127ac4c921f1a
official_pdf: authority/artifacts/bgk-worksheet-08-official.pdf
official_pdf_sha256: f32f11e7fd3ec9d3ba2f6a20a89ab23c3652b4e8026db037278d2022108208bf
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
exercise_count: 22
public_solution_count: 3
---

# Lembar Kerja 8: Spektrum dan Pemetaan Spektrum {#br-bgk-2019-w08}

<!-- upstream_entity: Maximale Ideale/Existenz/Lemma von Zorn/Aufgabe -->

## Soal 8.1 {#br-bgk-2019-w08-ex01}

Misalkan $R$ gelanggang komutatif yang bukan gelanggang nol. Dengan
menggunakan lema Zorn, tunjukkan bahwa $R$ mempunyai ideal maksimal.

<!-- upstream_entity: Kommutative Ringtheorie/Maximales Ideal/Primideal/Fakt/Beweis/Aufgabe -->

## Soal 8.2 {#br-bgk-2019-w08-ex02}

Tunjukkan bahwa setiap ideal maksimal $\mathfrak m$ dalam gelanggang
komutatif $R$ merupakan ideal prima.

<!-- upstream_entity: Kommutative Ringtheorie/Primideal/Charakterisierung mit Restklassenring/Fakt/Beweis/Aufgabe -->

## Soal 8.3* {#br-bgk-2019-w08-ex03}

Misalkan $R$ gelanggang komutatif dan $\mathfrak p$ sebuah ideal. Tunjukkan
bahwa $\mathfrak p$ merupakan ideal prima tepat ketika gelanggang hasil bagi

$$
R/\mathfrak p
$$

merupakan domain integral.

<!-- upstream_entity: Primideal/Charakterisierung als Kern nach Körper/Aufgabe -->

## Soal 8.4* {#br-bgk-2019-w08-ex04}

Misalkan $\mathfrak a$ ideal dalam gelanggang komutatif $R$. Tunjukkan bahwa
$\mathfrak a$ merupakan ideal prima tepat ketika $\mathfrak a$ adalah kernel
suatu homomorfisme gelanggang

$$
\varphi:R\longrightarrow K
$$

ke suatu lapangan $K$.

<!-- upstream_entity: Ideal und multiplikatives System/Disjunkt/Primideal/Zorn/Aufgabe -->

## Soal 8.5 {#br-bgk-2019-w08-ex05}

Misalkan $R$ gelanggang komutatif, $\mathfrak a\subseteq R$ sebuah ideal,
dan $M\subseteq R$ sistem multiplikatif dengan

$$
\mathfrak a\cap M=\varnothing.
$$

Dengan lema Zorn, tunjukkan bahwa ada ideal prima $\mathfrak p$ yang
memenuhi

$$
\mathfrak a\subseteq\mathfrak p,
\qquad
\mathfrak p\cap M=\varnothing.
$$

<!-- upstream_entity: Idealtheorie (kommutative Algebra)/Ideale im Restklassenring/Korrespondenz/Aufgabe -->

## Soal 8.6 {#br-bgk-2019-w08-ex06}

Misalkan $R$ gelanggang komutatif, $\mathfrak a$ sebuah ideal, dan

$$
S=R/\mathfrak a.
$$

Tunjukkan bahwa ideal-ideal $S$ berkorespondensi secara tunggal dengan
ideal-ideal $R$ yang memuat $\mathfrak a$.

<!-- upstream_entity: Nenneraufnahme/Verhalten von Primidealen/Aufgabe -->

## Soal 8.7 {#br-bgk-2019-w08-ex07}

Misalkan $R$ gelanggang komutatif dan $S\subseteq R$ sistem multiplikatif.
Tunjukkan bahwa ideal-ideal prima dalam $R_S$ berkorespondensi tepat dengan
ideal-ideal prima dalam $R$ yang terpisah dari $S$.

<!-- upstream_entity: Lokalisierung/Beschreibung des Spektrums/Aufgabe -->

## Soal 8.8 {#br-bgk-2019-w08-ex08}

Deskripsikan spektrum

$$
\operatorname{Spek}(R_{\mathfrak p})
$$

dari pelokalan gelanggang komutatif $R$ pada ideal prima $\mathfrak p$.

<!-- upstream_entity: Kommutative Ringtheorie/Primideal/Unter Morphismus/Aufgabe -->

## Soal 8.9 {#br-bgk-2019-w08-ex09}

Misalkan $R$ dan $S$ gelanggang komutatif dan
$\varphi:R\to S$ homomorfisme gelanggang. Jika $\mathfrak p$ ideal prima
dalam $S$, tunjukkan bahwa prabayang

$$
\varphi^{-1}(\mathfrak p)
$$

merupakan ideal prima dalam $R$.

Berikan contoh yang menunjukkan bahwa prabayang suatu ideal maksimal tidak
harus merupakan ideal maksimal.

<!-- upstream_entity: Ringhomomorphismus/Primideal/Abbildung der Lokalisierung und der Restekörper/Aufgabe -->

## Soal 8.10 {#br-bgk-2019-w08-ex10}

Misalkan $\varphi:R\to S$ homomorfisme gelanggang di antara gelanggang
komutatif $R$ dan $S$, dan misalkan
$\mathfrak p\in\operatorname{Spek}(S)$ ideal prima. Tunjukkan bahwa terdapat
homomorfisme gelanggang alami

$$
R_{\varphi^{-1}(\mathfrak p)}\longrightarrow S_{\mathfrak p}
$$

di antara pelokalan, serta

$$
\kappa\!\left(\varphi^{-1}(\mathfrak p)\right)
\longrightarrow\kappa(\mathfrak p)
$$

di antara lapangan residu.

<!-- upstream_entity: Integre endlich erzeugte Algebren/Lokaler Isomorphismus/In Umgebung/Aufgabe -->

## Soal 8.11* {#br-bgk-2019-w08-ex11}

Misalkan $K$ lapangan, dan misalkan $R$ serta $S$ aljabar-$K$ domain integral
yang dibangkitkan secara hingga. Misalkan

$$
\varphi:R\longrightarrow S
$$

homomorfisme aljabar-$K$, dan $\mathfrak n$ ideal maksimal dalam $S$ dengan

$$
\varphi^{-1}(\mathfrak n)=\mathfrak m.
$$

Andaikan pemetaan tersebut menginduksi isomorfisme

$$
R_{\mathfrak m}\longrightarrow S_{\mathfrak n}.
$$

Tunjukkan bahwa ada $f\in R$ dengan $f\notin\mathfrak m$ sedemikian sehingga

$$
R_f\longrightarrow S_{\varphi(f)}
$$

merupakan isomorfisme.

<!-- upstream_entity: Reduktion/Spektrumsabbildung/Homöomorphismus/Aufgabe -->

## Soal 8.12 {#br-bgk-2019-w08-ex12}

Tunjukkan bahwa pemetaan spektrum yang terkait dengan reduksi

$$
R\longrightarrow R/\mathfrak n_R
$$

suatu gelanggang komutatif $R$ merupakan homeomorfisme.

<!-- upstream_entity: Kommutative Ringtheorie/Charakteristik/Positiv/Frobenius/Existenz/Aufgabe -->

## Soal 8.13 {#br-bgk-2019-w08-ex13}

Misalkan $R$ gelanggang komutatif yang memuat suatu lapangan berkarakteristik
positif

$$
p>0,
$$

dengan $p$ bilangan prima. Tunjukkan bahwa pemetaan

$$
\begin{aligned}
R&\longrightarrow R,\\
f&\longmapsto f^p
\end{aligned}
$$

merupakan homomorfisme gelanggang, yang disebut *homomorfisme Frobenius*.

<!-- upstream_entity: Frobeniushomomorphismus/Spektrumsabbildung/Homöomorphismus/Aufgabe -->

## Soal 8.14 {#br-bgk-2019-w08-ex14}

Misalkan $R$ gelanggang komutatif berkarakteristik positif $p>0$.
Tunjukkan bahwa pemetaan spektrum dari homomorfisme Frobenius

$$
\begin{aligned}
R&\longrightarrow R,\\
f&\longmapsto f^p
\end{aligned}
$$

merupakan homeomorfisme.

<!-- upstream_entity: Kommutativer Ring/Produktring/Spektrum/Fakt/Beweis/Aufgabe -->

## Soal 8.15 {#br-bgk-2019-w08-ex15}

Misalkan $R_1$ dan $R_2$ gelanggang komutatif dan

$$
R=R_1\times R_2
$$

gelanggang produknya. Tunjukkan bahwa terdapat homeomorfisme alami

$$
\operatorname{Spek}(R_1)\uplus\operatorname{Spek}(R_2)
\longrightarrow\operatorname{Spek}(R_1\times R_2).
$$

<!-- upstream_entity: Polynomring/Mehrere Variablen/Fasern der Spektrumsabbildung/Aufgabe -->

## Soal 8.16 {#br-bgk-2019-w08-ex16}

Misalkan $R$ gelanggang komutatif. Tentukan serat-serat pemetaan spektrum yang
terkait dengan perluasan gelanggang

$$
R\subseteq R[X_1,\ldots,X_n].
$$

<!-- upstream_entity: RX in CX/Spektrumsabbildung/Fasern/Aufgabe -->

## Soal 8.17 {#br-bgk-2019-w08-ex17}

Tentukan serat-serat pemetaan spektrum yang terkait dengan

$$
\mathbb R[X]\subseteq\mathbb C[X].
$$

Jika lapangan dasar adalah bilangan kompleks, spektrum-$\mathbb C$ juga
mempunyai topologi kompleks yang jauh lebih halus daripada topologi Zariski.
Soal-soal berikut mengembangkan hal ini.

<!-- upstream_entity: C-Spektrum/Natürliche Topologie/Aufgabe -->

## Soal 8.18 {#br-bgk-2019-w08-ex18}

Misalkan $R$ aljabar-$\mathbb C$ komutatif yang dibangkitkan secara hingga.
Tunjukkan bahwa spektrum-$\mathbb C$

$$
\mathbb C\!\operatorname{-Spek}(R)
$$

mempunyai *topologi alami* (atau *topologi kompleks*) yang, untuk gelanggang
polinomial $\mathbb C[X_1,\ldots,X_n]$, berimpit dengan topologi metrik pada
$\mathbb C^n$. Tunjukkan pula bahwa untuk homomorfisme aljabar-$\mathbb C$

$$
\varphi:R\longrightarrow S
$$

di antara aljabar-$\mathbb C$ yang dibangkitkan secara hingga, pemetaan
terinduksi

$$
\mathbb C\!\operatorname{-Spek}(S)
\longrightarrow
\mathbb C\!\operatorname{-Spek}(R)
$$

kontinu dalam topologi alami.

<!-- upstream_entity: Polynom/C nach C/Ganz/Urbild beschränkt/Aufgabe -->

## Soal 8.19 {#br-bgk-2019-w08-ex19}

Misalkan $P\in\mathbb C[X]$ polinomial tak konstan. Tunjukkan bahwa fungsi

$$
\begin{aligned}
\mathbb C&\longrightarrow\mathbb C,\\
z&\longmapsto P(z)
\end{aligned}
$$

mempunyai sifat bahwa prabayang setiap subhimpunan terbatas
$T\subseteq\mathbb C$ juga terbatas.

<!-- upstream_entity: Polynom/C/Mehrere Variablen/Ganz/Urbild beschränkt/Aufgabe -->

## Soal 8.20 {#br-bgk-2019-w08-ex20}

Misalkan

$$
F_1,\ldots,F_k\in\mathbb C[X_1,\ldots,X_n]
$$

polinomial sedemikian sehingga homomorfisme aljabar-$\mathbb C$

$$
\begin{aligned}
\mathbb C[Y_1,\ldots,Y_k]&\longrightarrow
\mathbb C[X_1,\ldots,X_n],\\
Y_j&\longmapsto F_j
\end{aligned}
$$

bersifat integral. Tunjukkan bahwa pemetaan terkait

$$
\begin{aligned}
\mathbb C^n&\longrightarrow\mathbb C^k,\\
(x_1,\ldots,x_n)&\longmapsto
(F_1(x_1,\ldots,x_n),\ldots,F_k(x_1,\ldots,x_n))
\end{aligned}
$$

mempunyai sifat bahwa prabayang setiap subhimpunan terbatas
$T\subseteq\mathbb C^k$ kembali terbatas.

Simpulkan bahwa dalam keadaan tersebut pemetaan $F$ bersifat proper, yakni
prabayang subhimpunan kompak kembali kompak, dan bahwa $F$ merupakan pemetaan
tertutup.

<!-- upstream_entity: QX in RX/Spektrumsabbildung/Fasern/Aufgabe -->

## Soal 8.21 {#br-bgk-2019-w08-ex21}

Tentukan serat-serat pemetaan spektrum yang terkait dengan

$$
\mathbb Q[X]\subseteq\mathbb R[X].
$$

Serat mana yang berhingga?

<!-- upstream_entity: Ringhomomorphismus/Spektrumsabbildung/Faserbeschreibung/Tensorprodukt/Aufgabe -->

## Soal 8.22 {#br-bgk-2019-w08-ex22}

Misalkan $\varphi:R\to S$ homomorfisme gelanggang di antara gelanggang
komutatif dan

$$
\begin{aligned}
\varphi^*:\operatorname{Spek}(S)&\longrightarrow\operatorname{Spek}(R),\\
\mathfrak p&\longmapsto\varphi^*(\mathfrak p)
\end{aligned}
$$

pemetaan spektrum yang terkait. Tunjukkan bahwa serat di atas ideal prima
$\mathfrak p\in\operatorname{Spek}(R)$ secara kanonik homeomorfik dengan

$$
\operatorname{Spec}\!\left(S\otimes_R\kappa(\mathfrak p)\right).
$$

> **Catatan edisi — notasi sumber.** Soal terakhir memakai
> $\operatorname{Spec}$, sedangkan kuliah dan soal-soal sebelumnya memakai
> $\operatorname{Spek}$. Perbedaan notasi sumber ini dipertahankan; kedua
> simbol menyatakan spektrum gelanggang.
