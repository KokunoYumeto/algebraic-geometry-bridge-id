---
title: "Kuliah 28 - Morfisme ke Ruang Projektif"
stable_id: br-bgk-2019-l28
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 28"
upstream_pageid: 109032
upstream_revid: 793621
upstream_timestamp: "2022-08-25T06:24:58Z"
upstream_mediawiki_sha1: e7e7f2f42fcdd2f5fe1f284396867bf05a9ab815
source_url: "https://de.wikiversity.org/w/index.php?oldid=793621"
authority_manifest: authority/wikiversity-bgk/unit-28/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 1ab20936afe74fcfdde3318452f2211f2458911ff0a77c554fba894de49f4b9f
lecture_xml: authority/wikiversity-bgk/unit-28/lecture-28.xml
lecture_xml_sha256: f29af0601c37c1c8d49489080a8d7b274bf530905dfd7ea680d9fecd11d73f0b
lecture_expanded_tex: authority/wikiversity-bgk/unit-28/lecture-28-expanded.tex
lecture_expanded_tex_sha256: 85df8cce341d0d4fe6d95086d52e1954ce90415f5eb556669f466f77457f6814
official_pdf: authority/artifacts/bgk-lecture-28-official.pdf
official_pdf_sha256: f38e9f12ad1d5a6d715389f28e942b2e6ae93c2f336a8e97a9b1795cbafb392f
official_course_pdf: authority/artifacts/bgk-course-official.pdf
media_credits: source/id-ID/media-credits-bgk-unit-28.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponennya sendiri; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 28: Morfisme ke Ruang Projektif {#br-bgk-2019-l28}

Menurut definisi, suatu varietas projektif $X$ di atas lapangan $K$ dapat
direalisasikan sebagai subvarietas tertutup $X\subseteq\mathbb P^n_K$. Di
sini terdapat dua sudut pandang yang saling bersaing.

Di satu pihak, realisasi $X$ sebagai bagian dari ruang projektif memungkinkan
kita memakai konsep, struktur, dan sifat ruang sekitar dengan membatasinya ke
$X$. Kita dapat menyelidiki perilaku perpotongan $X$ dengan subvarietas lain
$Y$, mencari hubungan dengan komplemen terbuka $\mathbb P^n_K\setminus X$,
dan memvisualisasikan $X$ di dalam suatu ruang sekitar. Inilah sudut pandang
*ekstrinsik*.

Di pihak lain, kita dapat menanyakan sifat mana yang melekat pada varietas
$X$ sendiri dan tidak bergantung pada realisasi tertentu. Inilah sudut pandang
*intrinsik*. Biasanya $X$ isomorfik dengan varietas “lain” $X'$ yang diberikan
sebagai himpunan tertutup $X'\subseteq\mathbb P^{n'}_K$. Sifat mana dari $X$
dan $X'$ yang tidak bergantung pada embedding masing-masing?

Kedua sudut pandang itu bertemu dalam pertanyaan-pertanyaan berikut. Berapa
banyak embedding yang dimiliki suatu $X$? Dapatkah semua embedding $X$ ke
ruang projektif dipahami sekaligus? Adakah embedding terbaik, misalnya dengan
ruang sekitar berdimensi kecil atau dengan hubungan yang sangat transparan?
Adakah embedding alami yang berkaitan dengan objek khas pada $X$?

Sebagai contoh, perhatikan kurva projektif tertutup

$$
C=V_+(Y^2-XZ)\subseteq\mathbb P^2_K.
$$

Kurva ini berderajat $2$, dan perpotongannya dengan setiap garis terdiri atas
dua titik, dengan multiplisitas diperhitungkan. Pemetaan

$$
\mathbb P^1_K\longrightarrow\mathbb P^2_K,
\qquad (s,t)\longmapsto(s^2,st,t^2),
$$

menginduksi isomorfisme $\mathbb P^1_K\to C\subseteq\mathbb P^2_K$. Jadi
$C$ isomorfik dengan garis projektif dan dapat dipandang sebagai versi garis
projektif yang “dilengkungkan secara tidak perlu”. Namun kurva berderajat dua
— kuadrik atau irisan kerucut — merupakan objek alami di bidang. Dari sudut
pandang garis projektif, unsur $s^2,st,t^2$ membentuk basis komponen homogen
kedua $K[s,t]_2$ dari gelanggang koordinat homogen $K[s,t]$. Unsur-unsur ini
juga muncul sebagai seksi global berkas invertibel
$\mathcal O_{\mathbb P^1_K}(2)$. Kita akan melihat bahwa embedding yang
berbeda-beda dari $X$ ke ruang projektif berkaitan dengan seksi global berkas
invertibel pada $X$.

## Berkas invertibel dan morfisme ke ruang projektif {#br-bgk-2019-l28-s01}

<!-- upstream_entity: Schema über R/Invertierbare Garbe/Schnitte/Morphismus in projektiven Raum/Fakt -->
### Lema 28.1 {#br-bgk-2019-l28-lem-01}

Misalkan $X$ skema di atas gelanggang komutatif $R$, misalkan $\mathcal L$
berkas invertibel pada $X$, dan misalkan

$$
s_0,s_1,\ldots,s_n\in\Gamma(X,\mathcal L).
$$

Jika $U\subseteq X$ adalah gabungan himpunan terbuka $X_{s_i}$, maka

$$
U\longrightarrow\mathbb P^n_R,
\qquad x\longmapsto(s_0(x),s_1(x),\ldots,s_n(x))
$$

merupakan suatu morfisme.

#### Bukti {#br-bgk-2019-l28-lem-01-proof}

Mula-mula tinjau situasi pada $X_i=X_{s_i}$. Menurut Lema 13.22,

$$
\mathcal O_X|_{X_i}\longrightarrow\mathcal L|_{X_i},
\qquad 1\longmapsto s_i,
$$

merupakan isomorfisme $\mathcal O_X$-modul. Di bawah isomorfisme ini, seksi
$s_k$ bersesuaian dengan fungsi

$$
f_{ki}\in\Gamma(X_i,\mathcal O_X),
\qquad f_{ki}=\frac{s_k}{s_i}.
$$

Hasil bagi tersebut terdefinisi dengan baik. Untuk $k\ne i$, fungsi-fungsi
$f_{ki}$ menurut Korolari 10.13 mendefinisikan morfisme

$$
\varphi_i:X_i\longrightarrow D_+(x_i)\cong\mathbb A^n_R
\subseteq\mathbb P^n_R.
$$

Secara keseluruhan kita mempunyai diagram komutatif

$$
\begin{CD}
X_i @>{\varphi_i}>> D_+(x_i)\cong\mathbb A^n_R\subseteq\mathbb P^n_R\\
@AAA @AAA\\
X_i\cap X_j @>>> D_+(x_i)\cap D_+(x_j)\\
@VVV @VVV\\
X_j @>{\varphi_j}>> D_+(x_j)\cong\mathbb A^n_R\subseteq\mathbb P^n_R.
\end{CD}
$$

Pada $X_i\cap X_j$, kedua morfisme ini bersesuaian dengan perekat yang sama
seperti pada irisan $D_+(x_i)\cap D_+(x_j)$ di ruang projektif. Karena itu
morfisme-morfisme tersebut merekat menjadi satu morfisme pada gabungan semua
$X_i$. $\square$

> **Catatan edisi (sumber).** Teks sumber membatasi trivialisasi dan fungsi
> $f_{ki}$ ke $U$ di tengah argumen yang sedang berlangsung pada $X_i$, lalu
> menulis $\mathbb P^n_K$ pada sudut diagram meskipun basisnya adalah
> $\operatorname{Spec}(R)$. Edisi ini menampilkan $X_i$ dan
> $\mathbb P^n_R$ secara konsisten; isi matematis argumen tidak diubah.

<!-- upstream_entity: Schema über R/Invertierbare Garbe/Schnitte/Zugehöriger Morphismus/Definition -->
### Definisi 28.2: morfisme yang diberikan oleh seksi {#br-bgk-2019-l28-def-02}

Misalkan $X$ skema di atas gelanggang komutatif $R$, $\mathcal L$ berkas
invertibel pada $X$, dan
$s_0,s_1,\ldots,s_n\in\Gamma(X,\mathcal L)$ seksi global. Morfisme dari
Lemma 28.1 yang terdefinisi pada

$$
U=\bigcup_{i=0}^{n}X_{s_i},
$$

yakni

$$
U\longrightarrow\mathbb P^n_R,
\qquad x\longmapsto(s_0(x),s_1(x),\ldots,s_n(x)),
$$

disebut *morfisme yang diberikan oleh seksi-seksi* $s_0,\ldots,s_n$, atau
*morfisme yang diberikan oleh sistem linear* $s_0,\ldots,s_n$. Morfisme ini
dilambangkan $\varphi_{s_0,\ldots,s_n}$ atau
$\varphi_{\mathcal L;s_0,\ldots,s_n}$.

<!-- upstream_entity: Schema/Invertierbare Garbe/Lineares System/Definition -->
### Definisi 28.3: sistem linear {#br-bgk-2019-l28-def-03}

Misalkan $X$ skema di atas gelanggang komutatif $R$ dan $\mathcal L$ berkas
invertibel pada $X$. Suatu $R$-submodul

$$
T\subseteq\Gamma(X,\mathcal L)
$$

disebut *sistem linear* pada $X$.

Menurut Soal 28.9, morfisme yang diberikan oleh suatu keluarga seksi terutama
bergantung pada submodul yang dibangkitkan keluarga tersebut. Ini khususnya
jelas bila seksi-seksinya bebas linear, sebagaimana sering disyaratkan. Jika
$T=\Gamma(X,\mathcal L)$, kita berbicara tentang *sistem linear lengkap*.

Sistem linear mempunyai makna geometris. Setiap seksi $s\in T$ menentukan
lokus keterbalikan $X_s$ dan himpunan nol

$$
Z(s):=X\setminus X_s.
$$

Untuk $s\ne0$, himpunan $Z(s)$ merupakan subhimpunan tertutup berkodimensi
$1$, yakni suatu hipermuka pada $X$ — bayangkan $X$ integral. Jadi keluarga
$Z(s)$ untuk $s\in T$, $s\ne0$, adalah keluarga hipermuka yang terkait dengan
sistem linear tersebut; keluarga ini sendiri juga sering disebut sistem
linear. Jika $X$ normal, semua $Z(s)$ dapat dipandang sebagai keluarga
divisor-divisor yang saling ekuivalen linear.

<!-- upstream_entity: Projektive Gerade/O(1)/Variablen/Zugehöriger voller Morphismus/Beispiel -->
### Contoh 28.4 {#br-bgk-2019-l28-exa-04}

Pada garis projektif

$$
\mathbb P^1_R=\operatorname{Proj}(R[X,Y])
$$

di atas gelanggang komutatif $R$, morfisme yang berkaitan dengan sistem linear
lengkap

$$
(X,Y)\subseteq\Gamma(\mathbb P^1_R,\mathcal O_{\mathbb P^1_R}(1))
$$

adalah identitas.

<!-- upstream_entity: Projektive Gerade/O(2)/Variablen/Zugehöriger voller Morphismus/Beispiel -->
### Contoh 28.5 {#br-bgk-2019-l28-exa-05}

Pada $\mathbb P^1_R=\operatorname{Proj}(R[X,Y])$, sistem linear lengkap

$$
(X^2,XY,Y^2)\subseteq
\Gamma(\mathbb P^1_R,\mathcal O_{\mathbb P^1_R}(2))
$$

memberikan morfisme

$$
\mathbb P^1_R\longrightarrow\mathbb P^2_R,
\qquad (x,y)\longmapsto(x^2,xy,y^2).
$$

Titik dengan koordinat homogen $(x,y)$ dipetakan ke titik dengan koordinat
homogen $(x^2,xy,y^2)=(u,v,w)$. Citranya memenuhi $uw=v^2$, sehingga terletak
pada kurva bidang

$$
V_+(uw-v^2)\subseteq\mathbb P^2_R.
$$

Sesungguhnya terdapat isomorfisme
$\mathbb P^1_R\cong V_+(uw-v^2)$.

<!-- upstream_entity: Schema/Invertierbare Garbe/Lineares System/Basispunktfrei/Definition -->
### Definisi 28.6: bebas titik basis {#br-bgk-2019-l28-def-06}

Misalkan $X$ skema di atas gelanggang komutatif $R$ dan $\mathcal L$ berkas
invertibel pada $X$. Sistem linear
$T\subseteq\Gamma(X,\mathcal L)$ disebut *bebas titik basis* jika untuk setiap
$x\in X$ terdapat $s\in T$ sedemikian sehingga $x\in X_s$.

Istilah ini terutama digunakan untuk skema di atas suatu lapangan. Kita juga
mengatakan bahwa seksi $s_0,s_1,\ldots,s_n$ bebas titik basis jika sistem
linear yang dibangkitkannya bebas titik basis.

<!-- upstream_entity: Schema über R/Invertierbare Garbe/Schnitte/Morphismus in projektiven Raum/Global definiert/Fakt -->
### Lema 28.7 {#br-bgk-2019-l28-lem-07}

Misalkan $X$ skema di atas gelanggang komutatif $R$, $\mathcal L$ berkas
invertibel pada $X$, dan
$s_0,s_1,\ldots,s_n\in\Gamma(X,\mathcal L)$ seksi global. Pernyataan berikut
ekuivalen.

1. $X=\bigcup_{i=0}^{n}X_{s_i}$.
2. Morfisme ke $\mathbb P^n_R$ yang diberikan oleh sistem linear
   $(s_0,s_1,\ldots,s_n)$ terdefinisi pada seluruh $X$.
3. Sistem linear $(s_0,s_1,\ldots,s_n)$ bebas titik basis.

#### Bukti {#br-bgk-2019-l28-lem-07-proof}

Lihat Soal 28.14. $\square$

<!-- upstream_entity: Schema über R/Invertierbare Garbe/Schnitte/Morphismus in projektiven Raum/Korrespondenz/Fakt -->
### Teorema 28.8 {#br-bgk-2019-l28-thm-08}

Misalkan $X$ skema di atas gelanggang komutatif $R$. Konsep-konsep berikut
saling bersesuaian.

1. Berkas invertibel $\mathcal L$ pada $X$ bersama seksi-seksi bebas titik
   basis
   $$
   s_0,s_1,\ldots,s_n\in\Gamma(X,\mathcal L).
   $$
2. Morfisme
   $$
   \varphi:X\longrightarrow\mathbb P^n_R
   $$
   di atas $\operatorname{Spec}(R)$.

Kepada seksi-seksi pada (1) dikaitkan morfisme
$\varphi_{s_0,s_1,\ldots,s_n}$. Sebaliknya, kepada morfisme $\varphi$ pada
(2) dikaitkan berkas invertibel
$\varphi^*(\mathcal O_{\mathbb P^n_R}(1))$ beserta seksi-seksi
$\varphi^*(x_i)$, $i=0,1,\ldots,n$.

#### Bukti {#br-bgk-2019-l28-thm-08-proof}

Mula-mula misalkan $\mathcal L$ dan seksi-seksi $s_0,\ldots,s_n$ diberikan.
Kita harus menunjukkan

$$
\varphi^*\mathcal O_{\mathbb P^n_R}(1)\cong\mathcal L.
$$

Pada ruang projektif terdapat homomorfisme
$\mathcal O_{\mathbb P^n_R}$-modul

$$
\Psi_i:\mathcal O_{\mathbb P^n_R}
\longrightarrow\mathcal O_{\mathbb P^n_R}(1),
\qquad 1\longmapsto x_i,
$$

yang menjadi isomorfisme setelah dibatasi ke $D_+(x_i)$. Tarik baliknya
memberi homomorfisme

$$
\mathcal O_X\longrightarrow
\varphi^*\mathcal O_{\mathbb P^n_R}(1),
\qquad 1\longmapsto\varphi^*(x_i),
$$

dan isomorfisme pada $X_{s_i}$. Digabungkan dengan isomorfisme

$$
\mathcal O_X|_{X_{s_i}}\longrightarrow\mathcal L|_{X_{s_i}},
\qquad 1\longmapsto s_i,
$$

kita memperoleh isomorfisme lokal

$$
\varphi^*\mathcal O_{\mathbb P^n_R}(1)|_{X_{s_i}}
\longrightarrow\mathcal L|_{X_{s_i}}
$$

yang memasangkan $\varphi^*(x_i)$ dengan $s_i$. Pembatasan isomorfisme ini
ke $X_{s_i s_j}$ berimpit. Karena itu, menurut Korolari 4.10, semuanya merekat
menjadi isomorfisme global

$$
\varphi^*\mathcal O_{\mathbb P^n_R}(1)\longrightarrow\mathcal L.
$$

Sebaliknya, misalkan $\varphi:X\to\mathbb P^n_K$ diberikan. Morfisme ini
menentukan seksi $s_i=\varphi^*(x_i)$, dan seksi-seksi itu kembali menentukan
morfisme $\varphi'$. Karena suatu morfisme ditentukan secara lokal, cukup
membandingkannya pada

$$
\varphi^{-1}(D_+(x_i))\longrightarrow D_+(x_i)\cong\mathbb A^n_K.
$$

Di sini variabel $x_k/x_i$ ditarik balik ke $s_k/s_i$, tepat seperti dalam
definisi $\varphi'$. Jadi $\varphi'=\varphi$. $\square$

> **Catatan edisi (sumber).** Walaupun pernyataan Teorema 28.8 dirumuskan di
> atas gelanggang komutatif $R$ dan menargetkan $\mathbb P^n_R$, arah balik
> dalam bukti sumber beralih ke $\mathbb P^n_K$ dan $\mathbb A^n_K$ tanpa
> memperkenalkan $K$. Edisi ini mempertahankan kedua simbol basis $K$ tersebut
> secara literal; peralihan itu merupakan ketidakkonsistenan notasi sumber,
> bukan generalisasi atau pembatasan baru.

<!-- upstream_entity: Schema über R/Invertierbare Garbe/Schnitte/Morphismus in projektiven Raum/Hyperebene/Urbild/Fakt -->
### Lema 28.9 {#br-bgk-2019-l28-lem-09}

Misalkan $X$ skema di atas gelanggang komutatif $R$, $\mathcal L$ berkas
invertibel pada $X$, $s_0,s_1,\ldots,s_n\in\Gamma(X,\mathcal L)$ seksi
global, dan $\varphi:X\to\mathbb P^n_R$ morfisme yang terkait. Pracitra
hiperbidang

$$
V_+(a_0X_0+a_1X_1+\cdots+a_nX_n)\subseteq\mathbb P^n_R,
$$

dengan $a_i\in R$ dan tidak semuanya nol, adalah himpunan nol seksi yang
ditarik balik,

$$
Z(a_0s_0+a_1s_1+\cdots+a_ns_n)
=X\setminus X_{a_0s_0+a_1s_1+\cdots+a_ns_n}.
$$

#### Bukti {#br-bgk-2019-l28-lem-09-proof}

Pernyataan ini mengikuti dari Lema Lampiran 4.3. $\square$

Berkas struktur terpilin $\mathcal O_{\mathbb P^n_R}(1)$, melalui keluarga
semua seksi global tak nol, menentukan keluarga semua hiperbidang di ruang
projektif. Demikian pula, berkas invertibel pada suatu skema, melalui keluarga
seksi global tak nolnya, menentukan keluarga himpunan nolnya. Di bawah
korespondensi Teorema 28.8, pracitra hiperbidang sama dengan himpunan nol.
Jika $\varphi$ memfaktor melalui subvarietas tertutup, yaitu jika terdapat

$$
X\longrightarrow Y\subseteq\mathbb P^n_R,
$$

maka himpunan nol juga merupakan pracitra perpotongan $Y\cap H$ dengan
hiperbidang $H$. Dalam Contoh 28.5, misalnya, keluarga himpunan nol sistem
linear lengkap pada $\mathcal O_{\mathbb P^1_R}(2)$ berimpit dengan keluarga
perpotongan $V_+(uw-v^2)\cap H$, dengan $H$ suatu garis.

## Berkas sangat ample {#br-bgk-2019-l28-s02}

<!-- upstream_entity: Schema/R/Invertierbare Garbe/Sehr ampel/Einbettung/Definition -->
### Definisi 28.10: sangat ample {#br-bgk-2019-l28-def-10}

Misalkan $X$ skema di atas gelanggang komutatif $R$ dan $\mathcal L$ berkas
invertibel pada $X$. Berkas $\mathcal L$ disebut *sangat ample* jika terdapat
embedding $\varphi:X\to\mathbb P^n_R$, untuk suatu $n$, sedemikian sehingga

$$
\varphi^*(\mathcal O_{\mathbb P^n_R}(1))\cong\mathcal L.
$$

<!-- upstream_entity: Schema/R/Invertierbare Garbe/Sehr ampel/Schnitte/Fakt -->
### Lema 28.11 {#br-bgk-2019-l28-lem-11}

Misalkan $X$ skema di atas gelanggang komutatif $R$ dan $\mathcal L$ berkas
invertibel pada $X$. Berkas $\mathcal L$ sangat ample tepat ketika terdapat
seksi-seksi global bebas titik basis

$$
s_0,s_1,\ldots,s_n\in\Gamma(X,\mathcal L)
$$

sedemikian sehingga morfisme $\varphi_{s_0,s_1,\ldots,s_n}$ yang terkait
merupakan embedding.

#### Bukti {#br-bgk-2019-l28-lem-11-proof}

Pernyataan ini mengikuti dari Teorema 28.8. $\square$

<!-- upstream_entity: Projektiver Raum/O(n)/Sehr ampel/Beispiel -->
### Contoh 28.12 {#br-bgk-2019-l28-exa-12}

Pada ruang projektif $\mathbb P^n_R$ di atas gelanggang komutatif $R$, berkas
invertibel $\mathcal O_{\mathbb P^n_R}(k)$ sangat ample untuk setiap $k\ge1$.
Kita mempunyai

$$
\Gamma(\mathbb P^n_R,\mathcal O_{\mathbb P^n_R}(k))
=R[X_0,X_1,\ldots,X_n]_k.
$$

Tinjau sistem linear yang dibangkitkan semua monomial berderajat $k$ dalam
$R[X_0,X_1,\ldots,X_n]$ serta morfisme terkait

$$
\varphi:\mathbb P^n_R\longrightarrow\mathbb P^m_R,
$$

dengan $m$ satu kurang dari banyaknya monomial tersebut. Pada
$D_+(X_0)=(\mathbb P^n_R)_{X_0^k}$, pemetaan ini diberikan oleh

$$
\mathbb A^n_R\longrightarrow D_+(Y_\nu)\subseteq\mathbb P^m_R,
\qquad
\left(\frac{X_1}{X_0},\ldots,\frac{X_n}{X_0}\right)
\longmapsto
\left(\frac{X^\mu}{X_0^k}
:\mu\text{ monomial berderajat }k\right),
$$

dan analog pada setiap $D_+(X_i)$. Pada tingkat gelanggang polinomial,
pemetaan ini adalah homomorfisme substitusi

$$
R[S_\mu:\mu\in I_k]\longrightarrow R[T_1,\ldots,T_n],
\qquad S_\mu\longmapsto T^\mu,
$$

dengan $I_k$ himpunan indeks semua monomial dalam $n$ variabel yang
berderajat paling tinggi $k$. Pemetaan ini surjektif, sehingga morfisme di atas
merupakan embedding tertutup.

Untuk $k\le0$ dan $n\ge1$, berkas $\mathcal O_{\mathbb P^n_R}(k)$ tidak
sangat ample.

<!-- upstream_entity: Invertierbare Garbe/Ampel/Potenz/Definition -->
### Definisi 28.13: ample {#br-bgk-2019-l28-def-13}

Misalkan $X$ skema di atas gelanggang komutatif $R$ dan $\mathcal L$ berkas
invertibel pada $X$. Berkas $\mathcal L$ disebut *ample* jika
$\mathcal L^n$ sangat ample untuk suatu $n\ge1$.
