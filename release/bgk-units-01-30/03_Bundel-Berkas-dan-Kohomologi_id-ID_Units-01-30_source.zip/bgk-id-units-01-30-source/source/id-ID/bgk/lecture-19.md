---
title: "Kuliah 19 - Bundel Tangen"
stable_id: br-bgk-2019-l19
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 19"
upstream_pageid: 109023
upstream_revid: 793611
upstream_timestamp: "2022-08-25T06:23:18Z"
upstream_mediawiki_sha1: 4eb53f5c2f3154e392b0a8989bc69dca84449e0c
source_url: "https://de.wikiversity.org/w/index.php?oldid=793611"
authority_manifest: authority/wikiversity-bgk/unit-19/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: ffd4e79d12cd6fd63836cb6d7fd17e5dc6481f3befaeb50efeb9a47c4cc70512
authority_manifest_status: "Bekuan authority terminal lengkap; 33 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
lecture_xml: authority/wikiversity-bgk/unit-19/lecture-19.xml
lecture_xml_sha256: 55e9011a39d21322986e608435f0689cadc87e316dc82d304ed821df9d4f0175
lecture_expanded_tex: authority/wikiversity-bgk/unit-19/lecture-19-expanded.tex
lecture_expanded_tex_sha256: fab690126be772df0cc413b7bb2ad907b23084b9b0a5301016b39bfe17cf441d
official_pdf: authority/artifacts/bgk-lecture-19-official.pdf
official_pdf_sha256: 656e979ceed28a4a9af768d91d4a0fdc53adcf65272e40edb153bc74c3b4ead7
official_pdf_status: "Saksi PDF resmi lokal; 100.644 byte, 7 halaman, dan SHA-1 unggahan b4925ff55aa2f3c72a595abfc8bb93c95e5bb4ac telah diverifikasi."
official_pdf_metadata: authority/wikiversity-bgk/unit-19/official-pdfs-api.json
official_pdf_metadata_sha256: a37c74918c2fea4dd11a6ce3f9aee6d903596250bf8471c3d089d1c162fbb2af
official_pdf_source_bytes: 100644
official_pdf_source_sha1: b4925ff55aa2f3c72a595abfc8bb93c95e5bb4ac
older_course_pdf: authority/artifacts/bgk-course-official.pdf
older_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
authority_precedence: "Revisi semantik Wikiversity yang dibekukan mengendalikan teks; PDF seluruh kursus tahun 2020 hanya saksi historis."
media_credits: source/id-ID/media-credits-bgk-unit-19.md
rights_ledger: authority/RIGHTS-bgk-unit-19.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-19.json
asset_closure_sha256: 0adbc2e593bd9dab369022c73e8d4e69e988ce95bc57e7b1414147c8eb0e03fd
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF adalah saksi authority, bukan teks edisi; metadata Commons CC BY-SA 4.0 dan pemberitahuan tertanam CC-by-sa 3.0 dipertahankan tanpa pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 19: Bundel Tangen {#br-bgk-2019-l19}

## Berkas diferensial Kähler pada sebuah skema {#br-bgk-2019-l19-s01}

Misalkan $X$ sebuah skema di atas skema basis $S$. Kita ingin mendefinisikan
versi berkas dari modul diferensial Kähler.

<!-- upstream_entity: Kähler-Differentiale/Schema/Einführung/Textabschnitt -->

<!-- upstream_entity: Affines Schema/Affines Basisschema/Garbe der Kähler-Differentiale/Lokalisierungseigenschaften/Fakt -->

### Lema 19.1: pelokalan berkas diferensial Kähler afin {#br-bgk-2019-l19-lem-01}

Misalkan $A$ aljabar komutatif atas gelanggang komutatif $R$. Untuk setiap
$f\in A$ berlaku

$$
\left(\Gamma\bigl(D(f),\widetilde{\Omega_{A\mid R}}\bigr),
\widetilde d\right)
=\left(\Omega_{A_f\mid R},d\right),
$$

dan untuk setiap ideal prima $\mathfrak p\in\operatorname{Spek}(A)$ berlaku

$$
\left(\bigl(\widetilde{\Omega_{A\mid R}}\bigr)_{\mathfrak p},
d_{\mathfrak p}\right)
=\left(\Omega_{A_{\mathfrak p}\mid R},d\right).
$$

#### Bukti {#br-bgk-2019-l19-lem-01-proof}

Pernyataan ini mengikuti dari Lema 18.6 bersama Lema 14.5.

<!-- upstream_entity: Schema/Basisschema/Garbe der Kähler-Differentiale/Definition -->

### Definisi 19.2: berkas diferensial Kähler {#br-bgk-2019-l19-def-01}

Misalkan $p:X\to S$ sebuah skema di atas skema basis $S$. *Berkas diferensial
Kähler* $\Omega_{X\mid S}$ adalah modul-$\mathcal O_X$ kuasikoheren pada $X$,
bersama suatu derivasi atas $p^{-1}\mathcal O_S$,

$$
d:\mathcal O_X\longrightarrow\Omega_{X\mid S},
$$

sedemikian sehingga untuk setiap titik $P\in X$ berlaku

$$
\bigl((\Omega_{X\mid S})_P,d_P\bigr)
=\bigl(\Omega_{\mathcal O_{X,P}\mid\mathcal O_{S,p(P)}},d\bigr).
$$

Perlu diperlihatkan bahwa objek semacam ini ada dan unik. Karena
kuasikoherensi, untuk setiap himpunan terbuka afin
$V=\operatorname{Spek}(R)\subseteq S$ dan setiap himpunan terbuka afin
$U=\operatorname{Spek}(A)\subseteq X$ dengan $U\subseteq p^{-1}(V)$, modul
tersebut pada $U$ harus sama dengan $\widetilde{\Omega_{A\mid R}}$. Dalam
kasus afin, menurut Lema 19.1 modul $\widetilde{\Omega_{A\mid R}}$ memang
merupakan model yang tepat.

Jika $(\Omega,d)$ dan $(\Omega',d')$ dua model, sifat universal mula-mula
pada bagian-bagian afin dan kemudian secara umum memberi suatu
homomorfisme modul-$\mathcal O_X$

$$
\widetilde{\Omega_{A\mid R}}\longrightarrow\Omega'.
$$

Karena homomorfisme ini merupakan isomorfisme pada setiap titik, ia merupakan
isomorfisme. Jadi, hanya mungkin ada satu berkas semacam itu.

Jika diberikan liputan afin

$$
S=\bigcup_{j\in J}V_j
$$

dan, bersamanya, liputan afin

$$
X=\bigcup_{i\in I}U_i,
$$

dengan $U_i\subseteq p^{-1}(V_j)$ untuk suatu $j=j(i)$, maka berkas-berkas
$\Omega_{U_i\mid V_{j(i)}}$ dapat dilem satu sama lain. Hal ini karena
pembatasannya pada bagian afin $U\subseteq U_i\cap U_{i'}$ di atas
$V\subseteq V_{j(i)}\cap V_{j(i')}$ ditentukan secara unik.

<!-- upstream_entity: Schema/Basisschema/Garbe der Kähler-Differentiale/Tangentialgarbe/Definition -->

### Definisi 19.3: berkas tangen {#br-bgk-2019-l19-def-02}

Misalkan $p:X\to S$ sebuah skema di atas skema basis $S$. *Berkas tangen*
$\mathcal T_{X,S}$ adalah modul dual

$$
\mathcal T_{X,S}=\Omega_{X\mid S}^{*}.
$$

Jadi,

$$
\mathcal T_{X,S}
=\Omega_{X\mid S}^{*}
=\mathcal Hom(\Omega_{X\mid S},\mathcal O_X)
=\mathcal{Der}(\mathcal O_X,\mathcal O_X),
$$

dengan kesamaan terakhir berasal dari sifat universal diferensial Kähler.
Sesuai dengan itu, berkas diferensial Kähler juga disebut *berkas kotangen*.

Sekarang kita merumuskan secara umum, bagi sebuah skema di atas skema basis,
pernyataan-pernyataan tentang diferensial Kähler dalam kasus afin dari kuliah
sebelumnya.

<!-- upstream_entity: Kähler-Differentiale/Relative Differentialsequenz/Schema/Fakt -->

### Lema 19.4: barisan diferensial relatif {#br-bgk-2019-l19-lem-02}

Misalkan $\varphi:X\to Y$ sebuah morfisme skema di atas skema basis $S$.
Maka barisan modul-$\mathcal O_X$ kuasikoheren

$$
\varphi^*\Omega_{Y\mid S}
\longrightarrow\Omega_{X\mid S}
\longrightarrow\Omega_{X\mid Y}
\longrightarrow 0
$$

eksak.

#### Bukti {#br-bgk-2019-l19-lem-02-proof}

Pernyataan ini mengikuti dari Lema 18.7.

<!-- upstream_entity: Kähler-Differentiale/Konormalensequenz/Schema/Fakt -->

### Lema 19.5: barisan konormal {#br-bgk-2019-l19-lem-03}

Misalkan $X$ sebuah skema di atas skema basis $S$, dan misalkan
$\mathcal I\subseteq\mathcal O_X$ suatu berkas ideal pada $X$ dengan
subskema tertutup terkait $j:Y\to X$. Maka barisan modul-$\mathcal O_Y$
kuasikoheren

$$
\mathcal I/\mathcal I^2
\longrightarrow j^*\Omega_{X\mid S}
\longrightarrow\Omega_{Y\mid S}
\longrightarrow 0
$$

eksak.

#### Bukti {#br-bgk-2019-l19-lem-03-proof}

Pernyataan ini mengikuti langsung dari Lema 18.8.

<!-- upstream_entity: Schema/Glatt/Kählermodul/Lokal frei/Fakt -->

### Korolari 19.6: kemulusan dan kebebasan lokal diferensial Kähler {#br-bgk-2019-l19-cor-01}

Misalkan $K$ lapangan tertutup secara aljabar dan $X$ skema terhubung
bertipe hingga di atas $K$. Maka $X$ mulus jika dan hanya jika modul
diferensial Kähler $\Omega_{X\mid K}$ bebas lokal dengan rank konstan
$\dim(X)$.

#### Bukti {#br-bgk-2019-l19-cor-01-proof}

Pernyataan ini mengikuti dari Teorema 18.16 dan Teorema 18.17.

<!-- upstream_entity: Schema/Glatt/Kanonische Garbe/Definition -->

### Definisi 19.7: berkas kanonik {#br-bgk-2019-l19-def-03}

Misalkan $K$ lapangan tertutup secara aljabar dan $X$ skema mulus terhubung
bertipe hingga di atas $K$ dengan dimensi $d$. Berkas

$$
\omega_X:=\det\Omega_{X\mid K}
=\bigwedge^d\Omega_{X\mid K}
$$

disebut *berkas kanonik* $X$.

## Bundel tangen pada ruang projektif {#br-bgk-2019-l19-s02}

<!-- upstream_entity: Projektiver Raum/R/Kählermodul/Fakt -->

### Teorema 19.8: barisan Euler untuk diferensial Kähler {#br-bgk-2019-l19-thm-01}

Misalkan

$$
\mathbb P_R^n=\operatorname{Proj}(R[X_0,X_1,\ldots,X_n])
$$

ruang projektif di atas gelanggang komutatif $R$. Modul
$\mathcal O_{\mathbb P_R^n}$ dari diferensial Kähler
$\Omega_{\mathbb P_R^n\mid R}$ dideskripsikan oleh barisan eksak pendek

$$
0\longrightarrow\Omega_{\mathbb P_R^n\mid R}
\longrightarrow\mathcal O_{\mathbb P_R^n}(-1)^{\oplus(n+1)}
\xrightarrow{\ X_0,\ldots,X_n\ }
\mathcal O_{\mathbb P_R^n}
\longrightarrow 0,
$$

bersama derivasi universal yang, pada setiap himpunan terbuka
$U\subseteq\mathbb P_R^n$, memetakan fungsi
$f\in\Gamma(U,\mathcal O_{\mathbb P_R^n})$ ke

$$
df=\left(\frac{\partial f}{\partial X_0},\ldots,
\frac{\partial f}{\partial X_n}\right).
$$

#### Bukti {#br-bgk-2019-l19-thm-01-proof}

Kita lambangkan berkas kernel di kiri, yang hendak kita buktikan sebagai
modul Kähler, dengan

$$
\mathcal S=\operatorname{Syz}(X_0,\ldots,X_n).
$$

Pemetaan $d$ di atas, yang berasal dari derivasi universal pada ruang
berdimensi $n+1$, mengubah fungsi berderajat $0$ menjadi fungsi berderajat
$-1$; hal ini dapat diperiksa langsung bagi monomial rasional. Jadi terdapat
pemetaan linear-$R$

$$
d:\Gamma(U,\mathcal O_{\mathbb P_R^n})
\longrightarrow
\Gamma\bigl(U,\mathcal O_{\mathbb P_R^n}(-1)^{\oplus(n+1)}\bigr).
$$

Aturan Leibniz berpindah ke sini karena turunan parsial memenuhi aturan
Leibniz. Kita harus menunjukkan bahwa citra $d$ terletak dalam kernel
pemetaan terakhir. Untuk monomial $X^\nu$ berderajat $0$, kita mempunyai

$$
\sum_{j=0}^n X_j\frac{\partial X^\nu}{\partial X_j}
=\sum_{j=0}^n\nu_jX^\nu
=\left(\sum_{j=0}^n\nu_j\right)X^\nu
=0.
$$

Sekarang tinjau situasinya pada $D_+(X_0)$ dan tetapkan
$Y_j=X_j/X_0$. Dengan menggunakan Contoh 12.10 dan Contoh 15.5, diperoleh

$$
\begin{aligned}
\Gamma(D_+(X_0),\mathcal S)
&=\ker\left(
\Gamma\bigl(D_+(X_0),\mathcal O_{\mathbb P_R^n}(-1)^{\oplus(n+1)}\bigr)
\xrightarrow{\ X_0,X_1,\ldots,X_n\ }
\Gamma(D_+(X_0),\mathcal O_{\mathbb P_R^n})
\right)\\
&=\ker\left(
(R[X_0,X_1,\ldots,X_n]_{X_0})_{-1}^{\oplus(n+1)}
\xrightarrow{\ X_0,X_1,\ldots,X_n\ }
(R[X_0,X_1,\ldots,X_n]_{X_0})_0
\right)\\
&=\ker\left(
R[Y_1,\ldots,Y_n]X_0^{-1}\oplus\cdots\oplus
R[Y_1,\ldots,Y_n]X_0^{-1}
\xrightarrow{\ X_0,X_0Y_1,\ldots,X_0Y_n\ }
R[Y_1,\ldots,Y_n]
\right)\\
&\cong R[Y_1,\ldots,Y_n]\oplus\cdots\oplus R[Y_1,\ldots,Y_n],
\end{aligned}
$$

dengan $n$ suku pada baris terakhir. Dalam isomorfisme ini, tupel
$(P_1,\ldots,P_n)$ bersesuaian dengan tupel kernel

$$
\left(-\sum_{i=1}^nP_iY_iX_0^{-1},
P_1X_0^{-1},\ldots,P_nX_0^{-1}\right).
$$

Di bawah pemetaan $d$, monomial

$$
Y^\mu
=\left(\frac{X_1}{X_0}\right)^{\mu_1}\cdots
\left(\frac{X_n}{X_0}\right)^{\mu_n}
=X_0^{-\sum_{j=1}^n\mu_j}X_1^{\mu_1}\cdots X_n^{\mu_n}
\in\Gamma(D_+(X_0),\mathcal O_{\mathbb P_R^n})
$$

dipetakan ke unsur

$$
\begin{aligned}
\biggl(&-\Bigl(\sum_{j=1}^n\mu_j\Bigr)
X_0^{-\sum_{j=1}^n\mu_j-1}X_1^{\mu_1}\cdots X_n^{\mu_n},\\
&\mu_1X_0^{-\sum_{j=1}^n\mu_j}X_1^{\mu_1-1}X_2^{\mu_2}\cdots X_n^{\mu_n},
\ldots,
\mu_nX_0^{-\sum_{j=1}^n\mu_j}X_1^{\mu_1}\cdots X_n^{\mu_n-1}
\biggr).
\end{aligned}
$$

Di bawah identifikasi di atas, yakni dengan menghilangkan komponen pertama
dan mengalikan dengan $X_0$, unsur ini menjadi tupel turunan terhadap
variabel-variabel $Y_j$. Jadi, menurut Lema 18.5, kita memperoleh derivasi
universal gelanggang polinomial $R[Y_1,\ldots,Y_n]$.

Khususnya, modul diferensial Kähler pada ruang projektif bebas lokal.

<!-- upstream_entity: Projektiver Raum/R/Tangentialgarbe/Fakt -->

### Korolari 19.9: barisan Euler untuk berkas tangen {#br-bgk-2019-l19-cor-02}

Misalkan

$$
\mathbb P_R^n=\operatorname{Proj}(R[X_0,X_1,\ldots,X_n])
$$

ruang projektif di atas gelanggang komutatif $R$. Berkas tangen pada
$\mathbb P_R^n$ dideskripsikan oleh barisan eksak pendek

$$
0\longrightarrow\mathcal O_{\mathbb P_R^n}
\xrightarrow{\ X_0,\ldots,X_n\ }
\mathcal O_{\mathbb P_R^n}(1)^{\oplus(n+1)}
\longrightarrow\mathcal T_{\mathbb P_R^n,R}
\longrightarrow 0.
$$

Pada ujung kanan, unsur global $X_i e_j$, yang terletak di komponen ke-$j$,
dipetakan ke derivasi global

$$
X_i\frac{\partial}{\partial X_j}.
$$

#### Bukti {#br-bgk-2019-l19-cor-02-proof}

Pernyataan ini mengikuti langsung dari Teorema 19.8 melalui dualisasi.
Tambahan pada pernyataan juga mengikuti dari Teorema 19.8: saat didualkan,
unsur $X_i e_j$ pada komponen ke-$j$ dari
$\mathcal O_{\mathbb P_R^n}(1)^{\oplus(n+1)}$ bersesuaian dengan pemetaan

$$
X_i\circ p_j:
\mathcal O_{\mathbb P_R^n}(-1)^{\oplus(n+1)}
\longrightarrow\mathcal O_{\mathbb P_R^n},
$$

yakni proyeksi ke komponen ke-$j$ yang disusul perkalian dengan $X_i$.
Jika dipandang sebagai bentuk linear pada modul bentuk diferensial Kähler
$\Omega_{\mathbb P_R^n\mid R}\subseteq
\mathcal O_{\mathbb P_R^n}(-1)^{\oplus(n+1)}$, pemetaan ini bersesuaian dengan
bentuk linear yang berasal dari derivasi

$$
f\longmapsto X_i\frac{\partial f}{\partial X_j}.
$$

Dibandingkan dengan varietas projektif lain, ruang projektif mempunyai ciri
khusus berupa banyaknya medan vektor global.

<!-- upstream_entity: Projektiver Raum/K/Kanonische Garbe/Fakt -->

### Korolari 19.10: berkas kanonik ruang projektif {#br-bgk-2019-l19-cor-03}

Misalkan

$$
\mathbb P_R^n=\operatorname{Proj}(R[X_0,X_1,\ldots,X_n])
$$

ruang projektif di atas gelanggang komutatif $R$. Maka berkas kanonik adalah

$$
\omega_{\mathbb P_R^n\mid R}
=\det\Omega_{\mathbb P_R^n\mid R}
\cong\mathcal O_{\mathbb P_R^n}(-n-1).
$$

#### Bukti {#br-bgk-2019-l19-cor-03-proof}

Pernyataan ini mengikuti dari Teorema 19.8, Teorema 16.11, dan Korolari
16.12.

Jadi, berkas antikanonik, yaitu dual dari berkas kanonik, pada ruang
projektif sama dengan $\mathcal O_{\mathbb P_K^n}(n+1)$ dan mempunyai banyak
seksi global.

## Hipermuka dalam ruang projektif {#br-bgk-2019-l19-s03}

<!-- upstream_entity: Projektiver Raum/K/Hyperfläche/Glatt/Charakterisierungen/Fakt -->

### Teorema 19.11: karakterisasi hipermuka projektif mulus {#br-bgk-2019-l19-thm-02}

Misalkan $K$ lapangan tertutup secara aljabar dan

$$
F\in K[X_0,X_1,\ldots,X_n]
$$

polinomial homogen berderajat $d$. Pernyataan-pernyataan berikut ekuivalen.

1. Hipermuka afin

   $$
   V(F)=\operatorname{Spek}(K[X_0,X_1,\ldots,X_n]/(F))
   \subseteq\mathbb A_K^{n+1}
   $$

   mulus di luar titik asal.

2. Hipermuka projektif

   $$
   Y=V_+(F)
   =\operatorname{Proj}(K[X_0,X_1,\ldots,X_n]/(F))
   \subseteq\mathbb P_K^n
   $$

   mulus.

3. Untuk setiap variabel $X_i$, aljabar

   $$
   K[X_0,\ldots,X_{i-1},X_{i+1},\ldots,X_n]/(\widetilde F_i)
   $$

   mulus, dengan

   $$
   \widetilde F_i=F\frac{1}{X_i}
   $$

   menyatakan dehomogenisasi $F$ terhadap $X_i$.

4. Modul diferensial Kähler $\Omega_{Y\mid K}$ bebas lokal.

5. Terdapat barisan eksak pendek berkas-berkas bebas lokal pada $Y$,

   $$
   0\longrightarrow\mathcal O_Y(-d)
   \longrightarrow j_Y^*\Omega_{\mathbb P_K^n\mid K}
   \longrightarrow\Omega_{Y\mid K}
   \longrightarrow 0.
   $$

#### Bukti {#br-bgk-2019-l19-thm-02-proof}

Ekuivalensi (2) dan (3) jelas dari Lema 12.17 dan fakta bahwa kemulusan
merupakan sifat lokal. Ekuivalensi (2) dan (4) berdasarkan Korolari 19.6.
Ekuivalensi (1) dan (3) berdasarkan fakta bahwa pemetaan kerucut, secara
lokal di atas $D_+(X_i)$, diberikan oleh

$$
D(X_i)=\operatorname{Spek}(R_{X_i})
=\operatorname{Spek}\bigl((R_{X_i})_0[X_i,X_i^{-1}]\bigr)
\longrightarrow
D_+(X_i)=\operatorname{Spek}((R_{X_i})_0).
$$

Jadi, secara lokal pemetaan kerucut merupakan silinder afin tertusuk di atas
basisnya.

Untuk implikasi dari (4), atau (2), ke (5), menurut Lema 19.5 terdapat
barisan eksak

$$
\mathcal I/\mathcal I^2
\longrightarrow j_Y^*\Omega_{\mathbb P_K^n\mid K}
\longrightarrow\Omega_{Y\mid K}
\longrightarrow 0.
$$

Di sini $\mathcal I$ adalah ideal utama yang dibangkitkan oleh $F$, dan
$\mathcal I\cong\mathcal O_{\mathbb P_K^n}(-\delta)$ melalui pemetaan

$$
\mathcal O_{\mathbb P_K^n}
\longrightarrow\mathcal O_{\mathbb P_K^n}(\delta),
\qquad 1\longmapsto F.
$$

Selanjutnya, pembatasan berkas ideal ini ke $Y$ adalah

$$
\mathcal O_Y(-\delta)
=\mathcal I\otimes\mathcal O_Y
=\mathcal I\otimes\mathcal O_{\mathbb P_K^n}/\mathcal I
=\mathcal I/\mathcal I^2.
$$

Sebagai pembatasan berkas invertibel, berkas ini kembali invertibel. Secara
lokal, pemetaan di kiri diberikan, seperti dalam Catatan 18.10, oleh matriks
Jacobi dehomogenisasi $F$; karena kemulusan, pemetaan ini injektif, bahkan
setelah beralih ke lapangan-lapangan residu. Implikasi dari (5) ke (4) adalah
suatu pembatasan.

<!-- upstream_entity: Projektiver Raum/K/Hyperfläche/Glatt/Kanonische Garbe/Fakt -->

### Korolari 19.12: berkas kanonik hipermuka mulus {#br-bgk-2019-l19-cor-04}

Misalkan $K$ lapangan tertutup secara aljabar dan
$F\in K[X_0,X_1,\ldots,X_n]$ polinomial homogen berderajat $d$ sedemikian
sehingga hipermuka projektif $Y=V_+(F)$ mulus. Maka

$$
\omega_Y\cong\mathcal O_Y(d-n-1).
$$

#### Bukti {#br-bgk-2019-l19-cor-04-proof}

Kita gunakan barisan eksak pendek berkas-berkas bebas lokal pada $Y$ dari
Teorema 19.11,

$$
0\longrightarrow\mathcal O_Y(-d)
\longrightarrow j_Y^*\Omega_{\mathbb P_K^n\mid K}
\longrightarrow\Omega_{Y\mid K}
\longrightarrow 0.
$$

Menurut Teorema 16.11 dan Korolari 19.10,

$$
\begin{aligned}
\mathcal O_Y(-d)\otimes\omega_{Y\mid K}
&=\mathcal O_Y(-d)\otimes\det\Omega_{Y\mid K}\\
&=\det j_Y^*\Omega_{\mathbb P_K^n\mid K}\\
&=j_Y^*\det\Omega_{\mathbb P_K^n\mid K}\\
&=j_Y^*\mathcal O_{\mathbb P_K^n}(-n-1)\\
&=\mathcal O_Y(-n-1).
\end{aligned}
$$

Kesamaan terakhir berdasarkan Lema Lampiran 4.7. Menensor dengan
$\mathcal O_Y(d)$ menghasilkan klaim.

<!-- upstream_entity: Projektiver Raum/Hyperfläche/Kanonische Garbe/Grobe Klassifikation/Bemerkung -->

### Catatan 19.13: klasifikasi kasar hipermuka mulus {#br-bgk-2019-l19-rem-01}

Korolari 19.12 memungkinkan klasifikasi kasar bagi hipermuka mulus

$$
Y=V_+(F)\subseteq\mathbb P_K^n
$$

dalam ruang projektif, menurut apakah puntiran $d-n-1$ dalam
$\omega_Y\cong\mathcal O_Y(d-n-1)$ negatif, sama dengan $0$, atau positif.

Untuk $n=2$, yakni kurva dalam bidang projektif, pada $d=1,2$ diperoleh
garis projektif; pada $d=3$, ketika berkas kanonik trivial, diperoleh kurva
eliptik; dan pada $d\geq4$ diperoleh kurva bertipe umum.

Untuk $n=3$, yakni permukaan dalam ruang projektif, pada $d=1$ diperoleh
bidang projektif; pada $d=2$ diperoleh permukaan yang isomorfik dengan
$\mathbb P_K^1\times\mathbb P_K^1$; dan pada $d=3$ diperoleh permukaan yang
isomorfik dengan bidang projektif yang telah diledakkan pada enam titik.
Bagaimanapun, untuk $d\leq3$ diperoleh apa yang disebut *permukaan rasional*,
yang lapangan fungsinya sama dengan lapangan fungsi rasional dalam dua
variabel. Pada $d=4$, ketika berkas kanonik trivial, diperoleh apa yang
disebut permukaan $K3$. Pada $d\geq5$ diperoleh permukaan bertipe umum.
