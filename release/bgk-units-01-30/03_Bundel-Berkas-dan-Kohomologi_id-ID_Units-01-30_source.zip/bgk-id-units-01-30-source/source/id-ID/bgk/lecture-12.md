---
title: "Kuliah 12 - Spektrum Projektif Gelanggang Bergradasi"
stable_id: br-bgk-2019-l12
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 12"
upstream_pageid: 109016
upstream_revid: 1003742
upstream_timestamp: "2025-06-08T15:40:27Z"
upstream_mediawiki_sha1: 93e650abc2ff69aec101c168714ac078059b79de
source_url: "https://de.wikiversity.org/w/index.php?oldid=1003742"
authority_manifest: authority/wikiversity-bgk/unit-12/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 0e83f8718364e1d902dbe961cbf142cc7fb61e4ebfc7537f24488d508334e914
lecture_xml: authority/wikiversity-bgk/unit-12/lecture-12.xml
lecture_xml_sha256: 407b81b235ad725697753ef0f0e06f3703f9589839f48c9ddd3b0a0583f61756
lecture_expanded_tex: authority/wikiversity-bgk/unit-12/lecture-12-expanded.tex
lecture_expanded_tex_sha256: 01f084e340c09049b25fe0e9d399a841d9ef422705ab2a0ac634c1011a3e6856
official_pdf: authority/artifacts/bgk-lecture-12-official.pdf
official_pdf_sha256: 92000a36dadd4f0f9459276f40e4c927f414269cf441f60532571aa369baa5bd
media_credits: source/id-ID/media-credits-bgk-unit-12.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 12: Spektrum Projektif Gelanggang Bergradasi {#br-bgk-2019-l12}

## Spektrum projektif {#br-bgk-2019-l12-s01}

Spektrum projektif biasanya diperkenalkan untuk gelanggang bergradasi
$\mathbb N$. Akan tetapi, konstruksinya memakai pelokalan pada unsur homogen,
dan derajat negatif juga muncul di sana. Karena itu lebih wajar bekerja sejak
awal dengan gradasi $\mathbb Z$.

<!-- upstream_entity: Graduierter Ring/Z/Irrelevantes Ideal/Definition -->

### Definisi 12.1: ideal irelevan {#br-bgk-2019-l12-def-01}

Untuk gelanggang bergradasi $\mathbb Z$, ideal yang dibangkitkan oleh semua
unsur homogen berderajat bukan nol disebut *ideal irelevan*. Ideal ini
dilambangkan dengan $R_+$.

Dalam kasus bergradasi positif, ideal ini hanyalah

$$
\bigoplus_{n\geq 1}R_n.
$$

Jika terdapat derajat negatif, ideal irelevan bahkan dapat menjadi ideal
satuan.

<!-- upstream_entity: Graduierter Ring/Projektives Spektrum/Definition -->

### Definisi 12.2: himpunan spektrum projektif {#br-bgk-2019-l12-def-02}

Misalkan $R$ gelanggang komutatif bergradasi $\mathbb Z$. Himpunan semua ideal
prima homogen $R$ yang tidak memuat $R_+$ disebut *spektrum projektif* $R$ dan
dilambangkan

$$
\operatorname{Proj}(R).
$$

<!-- upstream_entity: Graduierter Ring/Projektives Spektrum/Zariski-Topologie/Definition -->

### Definisi 12.3: topologi pada spektrum projektif {#br-bgk-2019-l12-def-03}

Misalkan $R$ gelanggang komutatif bergradasi $\mathbb Z$. Spektrum projektif
$R$ sebagai ruang topologis adalah himpunan ideal prima homogen yang tidak
memuat $R_+$, dengan himpunan-himpunan

$$
D_+(\mathfrak a)
=\{\mathfrak p\in\operatorname{Proj}(R)
  \mid \mathfrak a\not\subseteq\mathfrak p\}
$$

dinyatakan terbuka.

Himpunan-himpunan ini memang menentukan suatu topologi. Kita mempunyai

$$
D_+(\mathfrak a)
=\bigcup_{\substack{f\in\mathfrak a\\ f\text{ homogen}}}D_+(f),
\qquad
D_+(f)=\{\mathfrak p\in\operatorname{Proj}(R)\mid f\notin\mathfrak p\}.
$$

Himpunan $D_+(f)$ membentuk basis topologi tersebut.

<!-- upstream_entity: Polynomring/Projektives Spektrum/Projektiver Raum/Definition -->

### Definisi 12.4: ruang projektif {#br-bgk-2019-l12-def-04}

Spektrum projektif gelanggang polinomial

$$
R[X_0,X_1,\ldots,X_n]
$$

disebut *ruang projektif berdimensi $n$ di atas $R$*.

Untuk gelanggang bergradasi $\mathbb Z$, $S_0$ menyatakan gelanggang pada
derajat nol. Jika $R$ bergradasi $\mathbb N$, gelanggang $R_0$ sering kali
sederhana, misalnya suatu lapangan. Namun, jika $f\in R$ homogen dan
berderajat positif, pelokalan $R_f$ secara alami bergradasi $\mathbb Z$, dan
$(R_f)_0$ dapat mempunyai struktur yang arbitrer rumit.

Untuk ideal prima homogen $\mathfrak p$, irisan sistem multiplikatif
$R\setminus\mathfrak p$ dengan himpunan semua unsur homogen juga merupakan
sistem multiplikatif. Gelanggang derajat nol dari pelokalan tersebut memainkan
peranan khusus dan dilambangkan

$$
R_{(\mathfrak p)}
=\left(R_{(R\setminus\mathfrak p)\cap
\{\text{unsur homogen}\}}\right)_0.
$$

<!-- upstream_entity: Graduierter Ring/Homogenes Primideal/Lokalisierung/Nullte Stufe/Fakt -->

### Lema 12.5: gelanggang lokal pada ideal prima homogen {#br-bgk-2019-l12-lem-01}

Untuk ideal prima homogen $\mathfrak p$ dalam gelanggang bergradasi
$\mathbb N$ $R$, gelanggang $R_{(\mathfrak p)}$ merupakan gelanggang lokal.

#### Bukti {#br-bgk-2019-l12-lem-01-proof}

Misalkan $r,s\in R_{(\mathfrak p)}$ bukan satuan. Kita dapat menulis

$$
r=\frac af,
\qquad
s=\frac bg,
$$

dengan $f,g\notin\mathfrak p$ homogen dan $a,b\in R$ homogen, masing-masing
berderajat sama dengan penyebutnya. Kita harus mempunyai
$a,b\in\mathfrak p$; jika tidak, pecahan yang bersangkutan adalah satuan.
Maka $ag+bf\in\mathfrak p$, sehingga

$$
\frac af+\frac bg=\frac{ag+bf}{fg}
$$

juga bukan satuan dalam $R_{(\mathfrak p)}$. Jadi himpunan bukan-satuan
tertutup terhadap penjumlahan, yang memberi ideal maksimal tunggal.

## Berkas struktur {#br-bgk-2019-l12-s02}

<!-- upstream_entity: Graduierter Ring/Projektives Spektrum/Strukturgarbe/Definition -->

### Definisi 12.6: berkas struktur pada spektrum projektif {#br-bgk-2019-l12-def-05}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$ dan
$Y=\operatorname{Proj}(R)$ spektrum projektifnya dengan topologi Zariski.
*Berkas struktur* pada $Y$ memasangkan kepada setiap himpunan terbuka
$U\subseteq Y$ gelanggang komutatif

$$
\begin{aligned}
\Gamma(U,\mathcal O_Y)=\biggl\{&(s_{\mathfrak p})_{\mathfrak p\in U}
\in\prod_{\mathfrak p\in U}R_{(\mathfrak p)}\ \bigg|\\
&\text{untuk setiap }\mathfrak p\in U\text{ terdapat unsur homogen }a,b\in R
\text{ dengan }\mathfrak p\in D_+(b)\subseteq U,\\
&\text{dan }s_{\mathfrak q}=a/b\text{ dalam }R_{(\mathfrak q)}
\text{ untuk semua }\mathfrak q\in D_+(b)\biggr\}.
\end{aligned}
$$

Kepada setiap inklusi $U\subseteq V$ dipasangkan proyeksi pembatasan alami.

Definisi ini khususnya mensyaratkan
$\deg(a)-\deg(b)=0$ dalam setiap penyajian. Definisi tersebut dapat dipandang
sebagai pembentukan berkas dari praberkas

$$
D_+(\mathfrak a)\longmapsto
\operatorname*{colim}_{D_+(\mathfrak a)\subseteq D_+(f)}(R_f)_0,
$$

yang juga memperlihatkan bahwa kita memang memperoleh berkas gelanggang
komutatif.

<!-- upstream_entity: Graduierter Ring/Projektives Spektrum/Schema/Definition -->

### Definisi 12.7: spektrum projektif sebagai ruang berdering {#br-bgk-2019-l12-def-06}

Untuk gelanggang bergradasi $\mathbb Z$ $R$, *spektrum projektif*

$$
Y=\operatorname{Proj}(R)
$$

berarti spektrum projektif yang dilengkapi topologi Zariski dan berkas
strukturnya.

<!-- upstream_entity: Graduierter Ring/Projektives Spektrum/Homogene Einheit/Homöomorphie/Fakt -->

### Lema 12.8: unit homogen dan spektrum komponen derajat nol {#br-bgk-2019-l12-lem-02}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$ yang mempunyai setidaknya satu
unit homogen berderajat positif. Pemetaan

$$
\operatorname{Proj}(R)\longrightarrow\operatorname{Spek}(R_0),
\qquad
\mathfrak p\longmapsto\mathfrak p\cap R_0,
$$

merupakan bijeksi, homeomorfisme untuk topologi Zariski, dan isomorfisme untuk
berkas struktur. Selain itu,

$$
R_{(\mathfrak p)}=(R_0)_{\mathfrak p\cap R_0}.
$$

#### Bukti {#br-bgk-2019-l12-lem-02-proof}

Pertama,

$$
\mathfrak p_0:=\mathfrak p\cap R_0
$$

adalah ideal prima, sehingga pemetaan tersebut terdefinisi dengan baik.
Misalkan $g$ unit homogen berderajat positif. Kita akan merekonstruksi
$\mathfrak p$ dari $\mathfrak p_0$. Jika $H$ menyatakan himpunan unsur
homogen, maka

$$
\mathfrak p\cap H
=\{h\text{ homogen}\mid
\text{terdapat }i\in\mathbb Z, j\in\mathbb N_+
\text{ dengan }g^ih^j\in\mathfrak p_0\}.
$$

Inklusi dari kiri ke kanan jelas: $i$ dan $j$ dapat dipilih agar
$\deg(g^ih^j)=0$. Sebaliknya, jika
$g^ih^j\in\mathfrak p_0$, maka $h^j\in\mathfrak p$ karena $g$ satuan, dan
selanjutnya $h\in\mathfrak p$ karena $\mathfrak p$ prima. Dengan demikian
pemetaan itu injektif.

Untuk surjektivitas, ambil ideal prima $\mathfrak q\subseteq R_0$ dan bentuk
ideal yang dibangkitkan oleh

$$
\{h\text{ homogen}\mid
\text{terdapat }i\in\mathbb Z, j\in\mathbb N_+
\text{ dengan }g^ih^j\in\mathfrak q\}.
$$

Ideal ini tidak memuat unit, sehingga tidak memuat seluruh $R_+$; khususnya
ia tidak memuat $g$, karena $\mathfrak q$ tidak memuat $1$. Jika $h_1h_2$
termasuk himpunan di atas, maka untuk beberapa $i,j$ berlaku

$$
g^ih_1^jh_2^j\in\mathfrak q.
$$

Untuk suatu pangkat, kita dapat menulis

$$
(g^ih_1^jh_2^j)^n=(g^ah_1^b)(g^ch_2^d)
$$

dengan kedua faktor berderajat nol. Salah satu faktor harus termasuk
$\mathfrak q$, sehingga $h_1$ atau $h_2$ termasuk himpunan tersebut. Ideal
yang dihasilkan dengan demikian prima dan memberi invers pemetaan.

Untuk homeomorfisme, perhatikan basis-basis yang dibentuk oleh
$D_+(f)$ di sisi projektif dan $D(f)$ di sisi derajat nol. Pracitra $D(f)$
adalah $D_+(f)$, dan suatu unsur homogen dapat dikalikan dengan pangkat $g$
tanpa mengubah terbuka projektifnya:

$$
D_+(f)=D_+(fg^j).
$$

Identifikasi gelanggang lokal dan kompatibilitas berkas mengikuti dari
deskripsi pelokalan derajat nol yang sama.

<!-- upstream_entity: Graduierter Ring/Projektives Spektrum/Hauptmenge/Schema/Fakt -->

### Lema 12.9: terbuka utama projektif bersifat afin {#br-bgk-2019-l12-lem-03}

Untuk gelanggang bergradasi $\mathbb Z$ $R$ dan unsur homogen
$f\in R$ berderajat bukan nol,

$$
D_+(f)\cong\operatorname{Spek}((R_f)_0)
$$

sebagai ruang berdering. Khususnya, spektrum projektif
$\operatorname{Proj}(R)$ merupakan skema.

#### Bukti {#br-bgk-2019-l12-lem-03-proof}

Terapkan Lema 12.8 pada $R_f$, dengan memperhatikan bahwa ideal prima homogen
di $D_+(f)$ bersesuaian dengan ideal prima homogen $R_f$. Sifat skema
mengikuti karena himpunan $D_+(f)$ untuk $f\in R_+$ menutupi spektrum
projektif.

<!-- upstream_entity: Projektiver Raum/Schema/Affine Räume/Überdeckung/Beispiel -->

### Contoh 12.10: liputan afin standar ruang projektif {#br-bgk-2019-l12-exm-01}

Ruang projektif, yaitu spektrum projektif gelanggang polinomial bergradasi
standar $R[X_0,X_1,\ldots,X_n]$, ditutupi oleh $D_+(X_i)$. Ini disebut
*liputan afin standar ruang projektif*. Kita mempunyai

$$
\begin{aligned}
\Gamma(D_+(X_i),\mathcal O_{\mathbb P_R^n})
&=(R[X_0,X_1,\ldots,X_n]_{X_i})_0\\
&=R\left[\frac{X_0}{X_i},\ldots,
\frac{X_{i-1}}{X_i},\frac{X_{i+1}}{X_i},\ldots,
\frac{X_n}{X_i}\right].
\end{aligned}
$$

Ini gelanggang polinomial dalam $n$ variabel. Dengan
$Y_j=X_j/X_i$ untuk $j\ne i$, kita memperoleh

$$
D_+(X_i)
=\operatorname{Spek}(R[Y_0,\ldots,Y_{i-1},Y_{i+1},\ldots,Y_n])
=\mathbb A_R^n.
$$

Jadi ruang projektif berdimensi $n$ ditutupi oleh $n+1$ ruang afin.

## Morfisme dan skema projektif {#br-bgk-2019-l12-s03}

<!-- upstream_entity: Graduierter Ring/Z/Homogener Ringhomomorphismus/Morphismus/Fakt -->

### Teorema 12.11: morfisme yang diinduksi homomorfisme homogen {#br-bgk-2019-l12-thm-01}

Misalkan $A$ dan $B$ gelanggang bergradasi $\mathbb Z$ di atas gelanggang
komutatif $R=A_0$, dan misalkan

$$
\theta:A\longrightarrow B
$$

homomorfisme gelanggang homogen. Terdapat morfisme skema alami

$$
D_+(\theta(A_+)B)\longrightarrow\operatorname{Proj}(A),
\qquad
\mathfrak p\longmapsto\theta^{-1}(\mathfrak p).
$$

#### Bukti {#br-bgk-2019-l12-thm-01-proof}

Pracitra ideal prima di bawah homomorfisme gelanggang kembali merupakan ideal
prima, dan pracitra ideal homogen kembali homogen. Jika

$$
\mathfrak p\in D_+(\theta(A_+)B),
$$

terdapat unsur homogen $f\in A_+$ dengan
$\theta(f)\notin\mathfrak p$. Maka
$A_+\not\subseteq\theta^{-1}(\mathfrak p)$, sehingga

$$
\theta^{-1}(\mathfrak p)\in\operatorname{Proj}(A).
$$

Jadi terdapat pemetaan

$$
\varphi:D_+(\theta(A_+)B)\longrightarrow\operatorname{Proj}(A).
$$

Untuk unsur homogen $f\in A_+$,

$$
\varphi^{-1}(D_+(f))=D_+(\theta(f)),
$$

sebagaimana pada pemetaan spektrum. Jadi $\varphi$ kontinu. Menurut Korolari
10.10, pemetaan spektrum ini secara unik merupakan morfisme skema. Pada setiap
$D_+(f)$, pemetaan tersebut diberikan oleh homomorfisme homogen

$$
\theta_f:A_f\longrightarrow B_{\theta(f)},
$$

yang menginduksi homomorfisme pada komponen derajat nol

$$
(\theta_f)_0:(A_f)_0\longrightarrow(B_{\theta(f)})_0.
$$

Menurut Lema 12.9, ini adalah homomorfisme gelanggang seksi pada
$D_+(f)$ dan $D_+(\theta(f))$. Homomorfisme-homomorfisme tersebut kompatibel
dengan pembatasan, dan diagram

$$
\begin{matrix}
D_+(\theta(f))&\xrightarrow{\ \varphi=\theta^{-1}\ }&D_+(f)\\
\downarrow&&\downarrow\\
\operatorname{Spek}((B_{\theta(f)})_0)
&\xrightarrow{\ (\theta_f)_0^{-1}\ }&
\operatorname{Spek}((A_f)_0)
\end{matrix}
$$

komutatif. Karena itu $\varphi$ merupakan morfisme ruang berdering lokal.

> **Catatan edisi - domain dalam bukti sumber.** Pernyataan sumber memberi
> domain $D_+(\theta(A_+)B)$ dengan benar, tetapi baris pertama buktinya
> mencetak $D_+(\theta(A_+)B)=\operatorname{Proj}(B)$. Kesamaan itu tidak
> berlaku tanpa hipotesis tambahan. Edisi mempertahankan domain terbuka dari
> pernyataan. Sumber kemudian menulis $D(f)$ sekali untuk terbuka projektif;
> edisi menuliskan $D_+(f)$ secara konsisten.

<!-- upstream_entity: Projektiver Raum/Schema/Projektion weg von einem Punkt/Beispiel -->

### Contoh 12.12: proyeksi menjauhi sebuah titik {#br-bgk-2019-l12-exm-02}

Inklusi subgelanggang

$$
K[X_1,\ldots,X_n]\subseteq K[X_0,X_1,\ldots,X_n]
$$

memberi, menurut Teorema 12.11, morfisme skema

$$
\mathbb P_K^n\supset D_+(X_1,\ldots,X_n)
\longrightarrow\mathbb P_K^{n-1}.
$$

Titik $K$ dengan koordinat homogen $(x_0,x_1,\ldots,x_n)$ dipetakan ke
$(x_1,\ldots,x_n)$. Pemetaan ini hanya terdefinisi pada himpunan terbuka yang
ditampilkan dan tidak memiliki perpanjangan bermakna ke titik
$(1,0,\ldots,0)$. Pemetaan itu disebut *proyeksi menjauhi sebuah titik*.
Dalam ruang afin $\mathbb A_K^{n+1}$ dan $\mathbb A_K^n$, ini berarti setiap
garis diproyeksikan ke sebuah hiperbidang. Untuk garis yang "tegak lurus"
terhadap hiperbidang, konstruksi tersebut tidak terdefinisi dengan baik
karena proyeksinya tidak menghasilkan sebuah garis.

<!-- upstream_entity: Projektives Schema/Ring/Definition -->

### Definisi 12.13: skema projektif {#br-bgk-2019-l12-def-07}

Skema $(X,\mathcal O_X)$ di atas gelanggang komutatif $R$ disebut
*projektif* jika terdapat faktorisasi

$$
X\xrightarrow{i}\mathbb P_R^n
\longrightarrow\operatorname{Spek}(R)
$$

dengan $i$ suatu pembenaman tertutup.

<!-- upstream_entity: Standard-graduierter Ring/Projektives Spektrum/Projektives Schema/Fakt -->

### Lema 12.14: Proj gelanggang bergradasi standar bersifat projektif {#br-bgk-2019-l12-lem-04}

Untuk gelanggang bergradasi standar $A$, spektrum projektif
$\operatorname{Proj}(A)$ merupakan skema projektif di atas
$\operatorname{Spek}(A_0)$.

#### Bukti {#br-bgk-2019-l12-lem-04-proof}

Kita dapat menulis

$$
A=A_0[X_0,X_1,\ldots,X_n]/\mathfrak a
$$

dengan ideal homogen
$\mathfrak a\subseteq A_0[X_0,X_1,\ldots,X_n]$. Menurut Teorema 12.11,
pemetaan kelas sisa

$$
\theta:A_0[X_0,X_1,\ldots,X_n]\longrightarrow A
$$

memberi morfisme skema

$$
i:\operatorname{Proj}(A)\longrightarrow\mathbb P_{A_0}^n.
$$

Sebagaimana pemetaan spektrum

$$
\operatorname{Spek}(A)\longrightarrow
V(\mathfrak a)\subseteq\mathbb A_{A_0}^{n+1},
\qquad
\mathfrak p\longmapsto\theta^{-1}(\mathfrak p),
$$

merupakan homeomorfisme, versi projektif ini merupakan homeomorfisme ke
$V_+(\mathfrak a)$. Jadi $\operatorname{Proj}(A)$ secara alami bersesuaian
dengan subhimpunan tertutup ruang projektif di atas $A_0$.

Tinggal dibuktikan bahwa homomorfisme berkas

$$
\mathcal O_{\mathbb P_{A_0}^n}
\longrightarrow i_*\mathcal O_{\operatorname{Proj}(A)}
$$

surjektif. Pada $D_+(f)$ untuk unsur homogen
$f\in A_0[X_0,X_1,\ldots,X_n]_+$, ini adalah pemetaan

$$
(A_0[X_0,X_1,\ldots,X_n]_f)_0
\longrightarrow(A_f)_0,
$$

yang surjektif.

Pada pernyataan di atas, homomorfisme gelanggang hanya surjektif pada himpunan
berbentuk $D_+(f)$, bukan pada semua himpunan terbuka. Karena himpunan tersebut
membentuk basis topologi, pemetaan pada tangkai juga surjektif. Maka kita
memperoleh homomorfisme berkas surjektif, dan $i$ adalah pembenaman tertutup.

## Hipermuka projektif {#br-bgk-2019-l12-s04}

<!-- upstream_entity: Projektiver Raum/Hyperfläche/Definition -->

### Definisi 12.15: hipermuka projektif {#br-bgk-2019-l12-def-08}

Untuk polinomial homogen

$$
F\in K[X_0,X_1,\ldots,X_n]
$$

di atas lapangan $K$, himpunan

$$
V_+(F)=\operatorname{Proj}(K[X_0,X_1,\ldots,X_n]/(F))
\subset\mathbb P_K^n
$$

disebut *hipermuka projektif* yang ditentukan oleh $F$.

<!-- upstream_entity: Projektiver Raum/Hyperfläche/Grad/Definition -->

### Definisi 12.16: derajat hipermuka {#br-bgk-2019-l12-def-09}

Untuk hipermuka projektif

$$
V_+(F)=\operatorname{Proj}(K[X_0,X_1,\ldots,X_n]/(F))
\subset\mathbb P_K^n,
$$

derajat polinomial homogen $F$ juga disebut *derajat hipermuka*.

Hipermuka berderajat $1$ disebut *hiperbidang*; objek-objek ini adalah
subruang linear projektif berkodimensi $1$.

<!-- upstream_entity: Standard-graduierter Ring/Proj/Affine Beschreibung/Fakt -->

### Lema 12.17: deskripsi afin melalui dehomogenisasi {#br-bgk-2019-l12-lem-05}

Misalkan

$$
R=K[X_0,X_1,\ldots,X_d]/(f_1,\ldots,f_s)
$$

gelanggang bergradasi standar, dengan pembangkit homogen $f_j$ berderajat
$d_j$. Maka

$$
(R_{X_i})_0
=K\left[\frac{X_0}{X_i},\ldots,\frac{X_{i-1}}{X_i},
\frac{X_{i+1}}{X_i},\ldots,\frac{X_d}{X_i}\right]
\bigg/
\left(\frac{f_1}{X_i^{d_1}},\ldots,
\frac{f_s}{X_i^{d_s}}\right).
$$

Gelanggang kelas sisa ini dideskripsikan oleh dehomogenisasi $f_\ell$
terhadap variabel $X_i$.

#### Bukti {#br-bgk-2019-l12-lem-05-proof}

Kita mempunyai

$$
\begin{aligned}
R_{X_i}
&=K[X_0,\ldots,X_d,X_i^{-1}]/(f_1,\ldots,f_s)\\
&=K\left[\frac{X_0}{X_i},\ldots,\frac{X_{i-1}}{X_i},
\frac{X_{i+1}}{X_i},\ldots,\frac{X_d}{X_i},X_i,X_i^{-1}\right]
\bigg/
\left(\frac{f_1}{X_i^{d_1}},\ldots,
\frac{f_s}{X_i^{d_s}}\right)\\
&=\left(
K\left[\frac{X_0}{X_i},\ldots,\frac{X_{i-1}}{X_i},
\frac{X_{i+1}}{X_i},\ldots,\frac{X_d}{X_i}\right]
\bigg/
\left(\frac{f_1}{X_i^{d_1}},\ldots,
\frac{f_s}{X_i^{d_s}}\right)
\right)[X_i,X_i^{-1}].
\end{aligned}
$$

Dalam deskripsi terakhir, komponen derajat nol dapat dibaca langsung. Jika

$$
Y_k=\frac{X_k}{X_i},
\qquad Y_i=1,
$$

maka, dengan $f_\ell=\sum_\nu a_\nu X^\nu$,

$$
\frac{f_\ell}{X_i^{d_\ell}}
=\frac{\sum_\nu a_\nu X^\nu}{X_i^{d_\ell}}
=\sum_\nu a_\nu Y^\nu.
$$

Inilah dehomogenisasi $f_\ell$ terhadap variabel $X_i$.

> **Catatan edisi - peran indeks dan derajat.** Sumber memakai $d$ sebagai
> indeks variabel terakhir dalam $X_0,\ldots,X_d$, sedangkan $d_j$ dan
> $d_\ell$ menyatakan derajat polinomial. Edisi mempertahankan semua simbol
> tetapi menyatakan kedua peran itu secara eksplisit agar tidak tertukar.
