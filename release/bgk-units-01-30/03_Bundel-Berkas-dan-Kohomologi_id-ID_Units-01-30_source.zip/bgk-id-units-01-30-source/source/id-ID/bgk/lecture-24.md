---
title: "Kuliah 24 - Funktor Turunan Kanan"
stable_id: br-bgk-2019-l24
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 24"
upstream_pageid: 109028
upstream_revid: 1003753
upstream_timestamp: "2025-06-08T16:37:44Z"
upstream_mediawiki_sha1: e320bcba4562078adb0a963725102422a19ce046
source_url: "https://de.wikiversity.org/w/index.php?oldid=1003753"
authority_capture_identity: authority/wikiversity-bgk/unit-24/CAPTURE_IDENTITY.json
authority_capture_identity_sha256: 842c6963306e8d2f624a632554364d970b2d021300974752b7337b8e70b6f1f8
lecture_xml: authority/wikiversity-bgk/unit-24/lecture-24.xml
lecture_xml_sha256: 07145dbf2a9c0a27475b8a8a39f7099a1652d07e7ff9aedbad5c8eafb1f7aacd
lecture_expanded_tex: authority/wikiversity-bgk/unit-24/lecture-24-expanded.tex
lecture_expanded_tex_sha256: 57345576a2ae9403bcb2b0598be4420efaf09d0605ae34fb1ba5bec3188d84a8
official_pdf_inventory: authority/wikiversity-bgk/unit-24/official-pdfs-api.json
official_pdf_inventory_sha256: 303704d2786c8c83db4a4d3ee5104de5078c240f9245257d25437ec40f812bee
official_course_pdf: authority/artifacts/bgk-course-official.pdf
official_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
official_course_pdf_printed_pages: "209-214"
media_credits: source/id-ID/media-credits-bgk-unit-24.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. Hak atas PDF dan setiap komponennya tidak diperluas oleh edisi ini."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
authority_manifest: authority/wikiversity-bgk/unit-24/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: b938d6366fb91058f9e35b1b3b7c4ba255f5f53a7860f9f0dc2b905f732b263b
official_pdf: authority/artifacts/bgk-lecture-24-official.pdf
official_pdf_sha256: 5f06a64aff74b064df8753ccdf2fe82358fd0f869f67a4df64082743d754a355
component_metadata: authority/commons-imageinfo-bgk-unit-24.json
component_metadata_sha256: 9b595f13f72a9416a587b97aa694b5655c538fa88ffbc69b54508da64c394f97
rights_ledger: authority/RIGHTS-bgk-unit-24.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-24.json
asset_closure_sha256: 1583dbc371fb9c97b43346d27b50e1e733424d89c4972cc1e6171e5c258c019b
media_credits_sha256: f3db5e0d70186a875db9c554930417bec4413b763f0cd4061f09a577288f440a
---

# Kuliah 24: Funktor Turunan Kanan {#br-bgk-2019-l24}

## Kategori abelian {#br-bgk-2019-l24-s01}

Konsep kategori abelian dideskripsikan secara abstrak melalui suatu daftar
aksioma yang telah kami himpun dalam sebuah lampiran. Bagi kita, empat contoh
utama berikut penting.

1. Kategori grup komutatif dengan homomorfisme grup.
2. Kategori modul $R$ di atas suatu gelanggang komutatif, dengan homomorfisme
   modul $R$.
3. Kategori berkas grup komutatif di atas suatu ruang topologis $X$, dengan
   homomorfisme berkas.
4. Kategori modul $\mathcal O_X$ pada suatu ruang berdering
   $(X,\mathcal O_X)$, dengan homomorfisme modul $\mathcal O_X$.

Dalam setiap kategori ini, makna barisan eksak pendek ataupun keeksakan
kompleks sudah jelas. Selain itu, dalam kategori-kategori ini setiap objek
dapat dibenamkan ke dalam suatu objek injektif dalam kategori tersebut,
sehingga resolusi injektif juga dapat dikonstruksi; lihat Korolari 23.8 dan
Lema 23.13. Sifat ini bahkan layak diberi nama tersendiri.

<!-- upstream_entity: Abelsche Kategorie/Genügend viele injektive Objekte/Definition -->

### Definisi 24.1: cukup banyak objek injektif {#br-bgk-2019-l24-def-01}

Suatu kategori abelian $\mathcal A$ dikatakan *mempunyai cukup banyak objek
injektif* jika untuk setiap objek $M\in\mathcal A$ terdapat suatu objek
injektif $I$ dan suatu monomorfisme

$$
M\longrightarrow I.
$$

## Funktor aditif eksak kiri {#br-bgk-2019-l24-s02}

<!-- upstream_entity: Kovarianter Funktor/Additive Kategorie/Additiv/Definition -->

### Definisi 24.2: funktor aditif {#br-bgk-2019-l24-def-02}

Misalkan $\mathcal A$ dan $\mathcal B$ kategori aditif. Suatu funktor
kovarian

$$
F:\mathcal A\longrightarrow\mathcal B
$$

disebut *aditif* jika untuk objek $G,H\in\mathcal A$, pemetaan

$$
\operatorname{Mor}(G,H)\longrightarrow
\operatorname{Mor}(F(G),F(H)),
\qquad \varphi\longmapsto F(\varphi),
$$

merupakan homomorfisme grup.

<!-- upstream_entity: Kovarianter Funktor/Abelsche Kategorie/Linksexakt/Definition -->

### Definisi 24.3: funktor eksak kiri {#br-bgk-2019-l24-def-03}

Misalkan $\mathcal A$ dan $\mathcal B$ kategori abelian. Suatu funktor
kovarian

$$
F:\mathcal A\longrightarrow\mathcal B
$$

disebut *eksak kiri* jika funktor itu aditif dan, untuk setiap barisan eksak
pendek

$$
0\longrightarrow A\longrightarrow B\longrightarrow C\longrightarrow 0
$$

dalam $\mathcal A$, barisan

$$
0\longrightarrow F(A)\longrightarrow F(B)\longrightarrow F(C)
$$

eksak dalam $\mathcal B$.

Bagi kita, dua funktor yang mempunyai kedua sifat tersebut akan penting.

<!-- upstream_entity: Modul/Hom/Linksexakt und genügend Injektive/Beispiel -->

### Contoh 24.4: funktor Hom {#br-bgk-2019-l24-exm-01}

Misalkan $R$ gelanggang komutatif dan $A$ suatu modul $R$ tetap. Penetapan
yang memasangkan kepada setiap modul $R$ $M$ modul homomorfisme

$$
\operatorname{Hom}_R(A,M)
$$

bersifat eksak kiri; lihat Soal 24.1.

<!-- upstream_entity: Topologischer Raum/Garbe/Globale Auswertung/Linksexakt und genügend Injektive/Beispiel -->

### Contoh 24.5: funktor seksi global {#br-bgk-2019-l24-exm-02}

Misalkan $X$ suatu ruang topologis dan $\mathcal A$ kategori berkas grup
komutatif pada $X$, dengan penetapan

$$
\mathcal G\longmapsto\Gamma(X,\mathcal G).
$$

Misalkan

$$
\mathcal B=\operatorname{ABEL}
$$

kategori grup abelian, dan misalkan $F$ adalah evaluasi global pada $X$.
Maka $\mathcal A$ mempunyai cukup banyak objek injektif dan $F$ merupakan
funktor kovarian, aditif, dan eksak kiri. Keeksakan kiri ini berdasarkan
Lema 6.8, sedangkan keberadaan cukup banyak berkas injektif berdasarkan
Lema 23.13.

Dalam contoh-contoh di atas, penetapan tersebut tidak eksak kanan; lihat
Soal 24.2 dan Contoh 6.6. Teori kohomologi yang akan kita pelajari antara lain
akan menangkap secara teoretis kegagalan keeksakan kanan ini.

## Funktor turunan {#br-bgk-2019-l24-s03}

<!-- upstream_entity: Abelsche Kategorie/Genügend Injektive/Linksexakter Funktor/Rechtsabgeleiteter Funktor/Definition -->

### Definisi 24.6: funktor turunan kanan {#br-bgk-2019-l24-def-04}

Misalkan $\mathcal A$ dan $\mathcal B$ kategori abelian, dan misalkan
$\mathcal A$ mempunyai cukup banyak objek injektif. Misalkan

$$
F:\mathcal A\longrightarrow\mathcal B
$$

funktor kovarian, aditif, dan eksak kiri. *Funktor turunan kanan ke-$n$*

$$
R^nF:\mathcal A\longrightarrow\mathcal B,
\qquad n\in\mathbb N,
$$

didefinisikan sebagai berikut. Untuk suatu objek $M\in\mathcal A$, ambil
suatu resolusi injektif $I^\bullet$ dari $M$ dan tetapkan

$$
R^nF(M):=H^n(F(I^\bullet)).
$$

Untuk suatu homomorfisme $\varphi:M\longrightarrow N$ dalam $\mathcal A$,
ambil suatu perluasan

$$
\widetilde\varphi:I^\bullet\longrightarrow J^\bullet,
$$

dengan $J^\bullet$ suatu resolusi injektif dari $N$, dan tetapkan

$$
R^nF(\varphi):=
\bigl(H^n(\widetilde\varphi):H^n(F(I^\bullet))
\longrightarrow H^n(F(J^\bullet))\bigr),
$$

dengan homomorfisme terinduksi pada homologi dalam pengertian Lema Lampiran
8.5.

<!-- upstream_entity: Abelsche Kategorie/Genügend Injektive/Rechtsabgeleiteter Funktor/Delta-Eigenschaften/Fakt -->

### Teorema 24.7: sifat-sifat delta funktor turunan kanan {#br-bgk-2019-l24-thm-01}

Misalkan $\mathcal A$ dan $\mathcal B$ kategori abelian, dan misalkan
$\mathcal A$ mempunyai cukup banyak objek injektif. Misalkan
$F:\mathcal A\longrightarrow\mathcal B$ funktor kovarian, aditif, dan eksak
kiri, serta $R^nF$ menyatakan funktor-funktor turunan kanannya. Maka berlaku
sifat-sifat berikut.

1. $R^nF$ merupakan funktor aditif yang terdefinisi dengan baik dari
   $\mathcal A$ ke $\mathcal B$.
2. Terdapat isomorfisme alami

   $$
   R^0F\cong F.
   $$

3. Untuk setiap barisan eksak pendek

   $$
   0\longrightarrow A\longrightarrow B\longrightarrow C\longrightarrow 0
   $$

   dalam $\mathcal A$ dan setiap $n\in\mathbb N$, terdapat homomorfisme
   penghubung alami

   $$
   \delta^n:R^nF(C)\longrightarrow R^{n+1}F(A)
   $$

   sedemikian sehingga dalam $\mathcal B$ terdapat kompleks eksak

   $$
   \begin{aligned}
   \ldots\longrightarrow R^{n-1}F(C)
   &\overset{\delta^{n-1}}{\longrightarrow}R^nF(A)
   \longrightarrow R^nF(B)\longrightarrow R^nF(C)\\
   &\overset{\delta^n}{\longrightarrow}R^{n+1}F(A)
   \longrightarrow R^{n+1}F(B)\longrightarrow\ldots .
   \end{aligned}
   $$

4. Untuk suatu homomorfisme barisan eksak

   $$
   \begin{matrix}
   0&\longrightarrow&A&\longrightarrow&B&\longrightarrow&C&\longrightarrow&0\\
   \downarrow&&\downarrow&&\downarrow&&\downarrow&&\downarrow\\
   0&\longrightarrow&A'&\longrightarrow&B'&\longrightarrow&C'&\longrightarrow&0,
   \end{matrix}
   $$

   diagram

   $$
   \begin{matrix}
   R^nF(C)&\overset{\delta^n}{\longrightarrow}&R^{n+1}F(A)\\
   \downarrow&&\downarrow\\
   R^nF(C')&\overset{\delta^n}{\longrightarrow}&R^{n+1}F(A')
   \end{matrix}
   $$

   komutatif.

#### Bukti {#br-bgk-2019-l24-thm-01-proof}

1. Untuk menunjukkan bahwa konstruksi terdefinisi dengan baik, yakni tidak
   bergantung pada resolusi injektif yang dipilih, kita membuktikannya dalam
   kasus bahwa $\mathcal A$ adalah kategori modul $R$; perumusannya dalam
   kasus umum sedikit lebih panjang. Misalkan

   $$
   0\longrightarrow N\longrightarrow L_0\longrightarrow L_1
   \longrightarrow\ldots
   $$

   dan

   $$
   0\longrightarrow N\longrightarrow I_0\longrightarrow I_1
   \longrightarrow\ldots
   $$

   adalah resolusi injektif dari suatu modul $N$. Menurut Lema 23.11,
   terdapat homomorfisme kompleks rantai

   $$
   \varphi:L_\bullet\longrightarrow I_\bullet
   $$

   dan

   $$
   \psi:I_\bullet\longrightarrow L_\bullet.
   $$

   Menurut Lema 23.12, komposisi $\psi\circ\varphi$ dan
   $\varphi\circ\psi$ masing-masing homotop dengan identitas pada
   $L_\bullet$ dan $I_\bullet$. Menurut Lema Lampiran 8.9, hal yang sama
   berlaku bagi homomorfisme terkait pada kompleks $F(L_\bullet)$ dan
   $F(I_\bullet)$. Artinya, bagi homomorfisme terinduksi pada homologi,
   komposisi

   $$
   H_n(F(L_\bullet))
   \overset{H_n(\varphi)}{\longrightarrow}H_n(F(I_\bullet))
   \overset{H_n(\psi)}{\longrightarrow}H_n(F(L_\bullet))
   $$

   adalah identitas. Dengan demikian, $H(\varphi)$ merupakan isomorfisme
   kanonik. Sifat aditif selalu berlaku pada homologi menurut Lema Lampiran
   8.5.

2. Misalkan $I^\bullet$ suatu resolusi injektif dari objek $M$. Homologi
   ke-$0$ dari kompleks

   $$
   0\longrightarrow F(I^0)\longrightarrow F(I^1)
   \longrightarrow F(I^2)\longrightarrow\ldots
   $$

   tidak lain adalah kernel homomorfisme

   $$
   F(I^0)\longrightarrow F(I^1).
   $$

   Karena $F$ eksak kiri, kernel ini sama dengan $F(M)$.

3. Menurut Lema Lampiran 9.9, terdapat diagram komutatif

   $$
   \begin{matrix}
   &&0&&0&&0&&\\
   &&\downarrow&&\downarrow&&\downarrow&&\\
   0&\longrightarrow&A&\longrightarrow&B&\longrightarrow&C&\longrightarrow&0\\
   &&\downarrow&&\downarrow&&\downarrow&&\\
   0&\longrightarrow&I^0&\longrightarrow&J^0&\longrightarrow&K^0&\longrightarrow&0\\
   &&\downarrow&&\downarrow&&\downarrow&&\\
   0&\longrightarrow&I^1&\longrightarrow&J^1&\longrightarrow&K^1&\longrightarrow&0\\
   &&\downarrow&&\downarrow&&\downarrow&&\\
   &&\vdots&&\vdots&&\vdots&&
   \end{matrix}
   $$

   dengan baris dan kolom eksak. Karena setiap baris selain barisan awal
   terbelah, untuk setiap $n\geq0$ diperoleh barisan eksak pendek

   $$
   0\longrightarrow F(I^n)\longrightarrow F(J^n)
   \longrightarrow F(K^n)\longrightarrow0.
   $$

   Jadi terdapat diagram komutatif

   $$
   \begin{matrix}
   0&\longrightarrow&F(I^{n-1})&\longrightarrow&F(J^{n-1})&\longrightarrow&F(K^{n-1})&\longrightarrow&0\\
   &&\downarrow&&\downarrow&&\downarrow&&\\
   0&\longrightarrow&F(I^n)&\longrightarrow&F(J^n)&\longrightarrow&F(K^n)&\longrightarrow&0\\
   &&\downarrow&&\downarrow&&\downarrow&&\\
   0&\longrightarrow&F(I^{n+1})&\longrightarrow&F(J^{n+1})&\longrightarrow&F(K^{n+1})&\longrightarrow&0
   \end{matrix}
   $$

   dengan baris-baris eksak. Dalam situasi seperti ini, menurut Lema
   Lampiran 8.6 terdapat homomorfisme dari kernel

   $$
   F(K^{n-1})\longrightarrow F(K^n)
   $$

   ke kernel

   $$
   F(I^n)\longrightarrow F(I^{n+1}),
   $$

   dan dengan demikian juga ke $R^nF(A)$. Citra $F(K^{n-2})$ dipetakan ke
   $0$, sehingga hal ini menginduksi suatu homomorfisme

   $$
   R^{n-1}F(C)\longrightarrow R^nF(A).
   $$

4. Lihat Soal 24.5.

Pemetaan $\delta$ juga disebut *homomorfisme penghubung*.

<!-- upstream_entity: Abelsche Kategorie/Genügend Injektive/Rechtsabgeleiteter Funktor/Injektives Objekt/Fakt -->

### Teorema 24.8: objek injektif bersifat asiklik {#br-bgk-2019-l24-thm-02}

Misalkan $\mathcal A$ dan $\mathcal B$ kategori abelian, dan misalkan
$\mathcal A$ mempunyai cukup banyak objek injektif. Misalkan
$F:\mathcal A\longrightarrow\mathcal B$ funktor kovarian, aditif, dan eksak
kiri. Maka untuk setiap objek injektif $I$ dalam $\mathcal A$ dan setiap
$n\geq1$, funktor turunan kanan memenuhi

$$
R^nF(I)=0.
$$

#### Bukti {#br-bgk-2019-l24-thm-02-proof}

Hal ini langsung diperoleh karena kita dapat memakai resolusi injektif

$$
I_0=I\longrightarrow0\longrightarrow0\longrightarrow\ldots .
$$

<!-- upstream_entity: Abelsche Kategorie/Genügend Injektive/Rechtsabgeleiteter Funktor/Azyklisches Objekt/Definition -->

### Definisi 24.9: objek asiklik {#br-bgk-2019-l24-def-05}

Misalkan $\mathcal A$ dan $\mathcal B$ kategori abelian, dan misalkan
$\mathcal A$ mempunyai cukup banyak objek injektif. Misalkan
$F:\mathcal A\longrightarrow\mathcal B$ funktor kovarian, aditif, dan eksak
kiri. Suatu objek $Z$ dalam $\mathcal A$ disebut *asiklik* (terhadap $F$)
jika untuk setiap $n\geq1$, funktor turunan kanan memenuhi

$$
R^nF(Z)=0.
$$

Menurut Teorema 24.8, setiap objek injektif bersifat asiklik.

<!-- upstream_entity: Abelsche Kategorie/Genügend Injektive/Rechtsabgeleiteter Funktor/Kurze exakte Sequenz/Azyklisches Objekt in Mitte/Fakt -->

### Korolari 24.10: penurunan dimensi melalui objek asiklik {#br-bgk-2019-l24-cor-01}

Misalkan $\mathcal A$ dan $\mathcal B$ kategori abelian, dan misalkan
$\mathcal A$ mempunyai cukup banyak objek injektif. Misalkan
$F:\mathcal A\longrightarrow\mathcal B$ funktor kovarian, aditif, dan eksak
kiri. Misalkan $A$ suatu objek dalam $\mathcal A$ dan

$$
0\longrightarrow A\longrightarrow Z
$$

eksak, dengan $Z$ suatu objek asiklik. Maka

$$
R^1F(A)=F(Z/A)/\operatorname{bild}(F(Z))
$$

dan

$$
R^nF(A)=R^{n-1}F(Z/A)
$$

untuk $n\geq2$.

#### Bukti {#br-bgk-2019-l24-cor-01-proof}

Kita tinjau barisan eksak pendek

$$
0\longrightarrow A\longrightarrow Z\longrightarrow Z/A\longrightarrow0.
$$

Pernyataan tersebut mengikuti dari barisan eksak panjang karena, menurut
hipotesis, suku-suku tengah $R^nF(Z)=0$.

<!-- upstream_entity: Modul/Extmoduln/Rechtsderiviert/Definition -->

### Definisi 24.11: funktor Ext {#br-bgk-2019-l24-def-06}

Misalkan $R$ gelanggang komutatif dan $M$ suatu modul $R$. Funktor turunan
kanan dari funktor

$$
N\longmapsto\operatorname{Hom}_R(M,N)
$$

(dari kategori modul $R$ ke dirinya sendiri) disebut *funktor Ext* dan
dilambangkan dengan

$$
\operatorname{Ext}^n(M,N).
$$

Untuk menghitung modul-modul Ext, menurut definisi kita harus mengambil
suatu resolusi injektif dari modul kedua, yaitu

$$
0\longrightarrow N\longrightarrow I_0\longrightarrow I_1
\longrightarrow I_2\longrightarrow\ldots,
$$

kemudian menentukan homologi kompleks

$$
\operatorname{Hom}(M,I_{n-1})\longrightarrow
\operatorname{Hom}(M,I_n)\longrightarrow
\operatorname{Hom}(M,I_{n+1}).
$$
