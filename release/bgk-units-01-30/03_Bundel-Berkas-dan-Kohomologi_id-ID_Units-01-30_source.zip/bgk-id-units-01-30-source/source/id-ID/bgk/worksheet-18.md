---
title: "Lembar Kerja 18 - Diferensial Kähler"
stable_id: br-bgk-2019-w18
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 18"
upstream_pageid: 110225
upstream_revid: 1008805
upstream_timestamp: "2025-07-10T16:33:18Z"
upstream_mediawiki_sha1: 9d122888e407ae4a211bdff1a5368dd467ac9ff6
source_url: "https://de.wikiversity.org/w/index.php?oldid=1008805"
authority_manifest: authority/wikiversity-bgk/unit-18/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: f0014846fe068d3b1bfd4488c1db66fdd6039fa2d70ff7b8a213875a56d39495
authority_manifest_status: "Bekuan authority terminal lengkap; 41 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
worksheet_xml: authority/wikiversity-bgk/unit-18/worksheet-18.xml
worksheet_xml_sha256: 6756943999b9441a20a48b7c1890dedd42d37d862965b1be1e7caa263c99623b
worksheet_expanded_tex: authority/wikiversity-bgk/unit-18/worksheet-18-expanded.tex
worksheet_expanded_tex_sha256: 0b01a90880f15272b078a42e6d510f20bbdd9b0498d4cb4b300d6e278b1cacd0
official_pdf: authority/artifacts/bgk-worksheet-18-official.pdf
official_pdf_sha256: 2d9a8cb439babbb5bb4f671ded98614d86f29871f26ae689e5d7b3280f6f8bb1
official_pdf_status: "Saksi PDF resmi lokal; 56.337 byte, 5 halaman, dan SHA-1 unggahan 60eb61113b2059edae845ecb161b9fcb1cb5f7a3 telah diverifikasi."
official_pdf_metadata: authority/wikiversity-bgk/unit-18/official-pdfs-api.json
official_pdf_source_bytes: 56337
official_pdf_source_sha1: 60eb61113b2059edae845ecb161b9fcb1cb5f7a3
older_course_pdf: authority/artifacts/bgk-course-official.pdf
older_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
authority_precedence: "Revisi semantik Wikiversity yang dibekukan mengendalikan teks; PDF seluruh kursus tahun 2020 hanya saksi historis."
ordered_exercise_map: authority/wikiversity-bgk/unit-18/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 2d687492b05ef02025dd2d7e53e3bf76c8034f69e26047f9ba72d9d1a1a5f79f
exercise_count: 25
public_solution_count: 3
public_solution_numbers: "6, 17, 18"
media_credits: source/id-ID/media-credits-bgk-unit-18.md
rights_ledger: authority/RIGHTS-bgk-unit-18.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-18.json
asset_closure_sha256: 33d6804e99934e11b06f7d05a732646e9371a51dd6fbbb35d642da28080caa77
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF adalah saksi authority, bukan teks edisi; metadata Commons CC BY-SA 4.0 dan pemberitahuan tertanam CC-by-sa 3.0 dipertahankan tanpa pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 18: Diferensial Kähler {#br-bgk-2019-w18}

Tanda bintang menunjukkan tepat tiga soal dengan solusi publik yang dibekukan,
yaitu Soal 18.6, 18.17, dan 18.18. Dua puluh dua soal lainnya mempunyai hasil
kandidat negatif; edisi tidak menciptakan solusi baru.

<!-- upstream_entity: Derivation/Potenz/Aufgabe -->

## Soal 18.1 {#br-bgk-2019-w18-ex01}

Misalkan $R$ gelanggang komutatif, $A$ aljabar komutatif $R$, $M$ modul
$R$, dan

$$
D:A\longrightarrow M
$$

suatu derivasi $R$. Buktikan bahwa

$$
D(f^n)=nf^{n-1}D(f)
$$

untuk setiap $f\in A$.

<!-- upstream_entity: Derivation/Allgemeine Produktregel/Aufgabe -->

## Soal 18.2 {#br-bgk-2019-w18-ex02}

Misalkan $R$ gelanggang komutatif, $A$ aljabar komutatif $R$, $M$ modul
$R$, dan $D:A\to M$ suatu derivasi $R$. Buktikan bahwa

$$
\begin{aligned}
D(f_1\cdots f_r)={}&f_2\cdots f_rD(f_1)
+f_1f_3\cdots f_rD(f_2)\\
&+\cdots+f_1\cdots f_{r-1}D(f_r)
\end{aligned}
$$

untuk $f_1,\ldots,f_r\in A$.

<!-- upstream_entity: Derivation/Monom/Aufgabe -->

## Soal 18.3 {#br-bgk-2019-w18-ex03}

Misalkan $R$ gelanggang komutatif, $A$ aljabar komutatif $R$, $M$ modul
$R$, dan $D:A\to M$ suatu derivasi $R$. Misalkan

$$
x_1^{n_1}\cdots x_r^{n_r}\in A.
$$

Buktikan bahwa

$$
\begin{aligned}
D(x_1^{n_1}\cdots x_r^{n_r})={}&
n_1x_1^{n_1-1}x_2^{n_2}\cdots x_{r-1}^{n_{r-1}}x_r^{n_r}D(x_1)\\
&+\cdots+
n_rx_1^{n_1}\cdots x_{r-1}^{n_{r-1}}x_r^{n_r-1}D(x_r).
\end{aligned}
$$

<!-- upstream_entity: Derivation/R-Modul/Aufgabe -->

## Soal 18.4 {#br-bgk-2019-w18-ex04}

Misalkan $A$ aljabar komutatif $R$ dan $M$ modul $A$. Buktikan bahwa
himpunan derivasi dari $A$ ke $M$ menjadi modul $A$ apabila $f\delta$
didefinisikan oleh

$$
(f\delta)(a)=f\delta(a).
$$

<!-- upstream_entity: Derivation/Fortsetzung auf Nenneraufnahme/Aufgabe -->

## Soal 18.5 {#br-bgk-2019-w18-ex05}

Misalkan $R$ aljabar komutatif $K$, $W\subseteq R$ suatu sistem
multiplikatif, dan $D:R\to R$ suatu derivasi $K$. Buktikan bahwa rumus

$$
D\left(\frac fg\right):=\frac{gD(f)-fD(g)}{g^2}
$$

mendefinisikan derivasi pada pelokalan $R_W$ yang memperluas $D$.

<!-- upstream_entity: Derivation/Lie-Klammer/Multiplikation/Aufgabe -->

## Soal 18.6 ★ {#br-bgk-2019-w18-ex06}

Misalkan $A$ aljabar komutatif $R$ di atas gelanggang komutatif $R$. Untuk
$f\in A$, nyatakan pemetaan perkalian linear-$R$ dengan $f$ sebagai

$$
\mu_f:A\longrightarrow A,\qquad x\longmapsto fx,
$$

dan untuk dua pemetaan linear-$R$

$$
\varphi_1,\varphi_2:A\longrightarrow A
$$

nyatakan

$$
[\varphi_1,\varphi_2]
=\varphi_1\circ\varphi_2-\varphi_2\circ\varphi_1.
$$

Misalkan $\delta:A\to A$ suatu derivasi $R$. Buktikan bahwa untuk setiap
$g\in A$, pemetaan $[\delta,\mu_g]$ merupakan pemetaan perkalian.

<!-- upstream_entity: Universelle Derivation/Derivation/Aufgabe -->

## Soal 18.7 {#br-bgk-2019-w18-ex07}

Misalkan $R$ gelanggang komutatif, $A$ aljabar komutatif $R$, dan
$\Omega_{A/R}$ modul diferensial Kähler. Buktikan bahwa derivasi universal

$$
A\longrightarrow\Omega_{A/R},\qquad f\longmapsto df,
$$

merupakan suatu derivasi.

<!-- upstream_entity: Kähler-Modul/C über R/Aufgabe -->

## Soal 18.8 {#br-bgk-2019-w18-ex08}

Tentukan $\Omega_{\mathbb C/\mathbb R}$.

<!-- upstream_entity: Kähler-Modul/Endliche Körpererweiterung/Separabel/Aufgabe -->

## Soal 18.9 {#br-bgk-2019-w18-ex09}

Misalkan $K\subseteq L$ suatu perluasan lapangan separabel hingga. Buktikan
bahwa

$$
\Omega_{L/K}=0.
$$

<!-- upstream_entity: Kähler-Modul/Zi über Z/Aufgabe -->

## Soal 18.10 {#br-bgk-2019-w18-ex10}

Tentukan $\Omega_{\mathbb Z[i]/\mathbb Z}$.

<!-- upstream_entity: Graph/Kähler-Modul/Frei/Aufgabe -->

## Soal 18.11 {#br-bgk-2019-w18-ex11}

Misalkan $R$ gelanggang komutatif dan

$$
A=R[X_1,\ldots,X_n]/(X_n-f(X_1,\ldots,X_{n-1}))
$$

dengan $f\in R[X_1,\ldots,X_{n-1}]$ (jadi himpunan nolnya adalah grafik
$f$). Buktikan dengan dua cara berbeda bahwa $\Omega_{A/R}$ merupakan modul
$A$ bebas berperingkat $n-1$.

Soal-soal berikut berkaitan dengan hasil kali tensor modul dan aljabar; lihat
juga lampiran.

<!-- upstream_entity: Z-Moduln/Tensorprodukt/Z mod 5 und Q/Aufgabe -->

## Soal 18.12 {#br-bgk-2019-w18-ex12}

Hitung $\mathbb Q\otimes_{\mathbb Z}\mathbb Z/(5)$.

<!-- upstream_entity: Abelsche Gruppen/Endlich erzeugte/Tensorprodukt/Berechne/Aufgabe -->

## Soal 18.13 {#br-bgk-2019-w18-ex13}

Hitung hasil kali tensor

$$
\bigl(\mathbb Z^3\oplus(\mathbb Z/(2))^2\oplus\mathbb Z/(3)\bigr)
\otimes_{\mathbb Z}
\bigl(\mathbb Z^2\oplus\mathbb Z/(2)\oplus\mathbb Z/(4)\bigr).
$$

<!-- upstream_entity: Tensorprodukt/Freie endliche Moduln/Aufgabe -->

## Soal 18.14 {#br-bgk-2019-w18-ex14}

Misalkan $R$ gelanggang komutatif. Buktikan isomorfisme modul $R$

$$
R^n\otimes_RR^m\cong R^{nm}.
$$

<!-- upstream_entity: Kommutativer Ring/Restklassenringe/Tensorprodukt/Fakt/Beweis/Aufgabe -->

## Soal 18.15 {#br-bgk-2019-w18-ex15}

Misalkan $R$ gelanggang komutatif dan $\mathfrak a,\mathfrak b\subseteq R$
ideal-ideal. Buktikan isomorfisme aljabar $R$

$$
R/\mathfrak a\otimes_RR/\mathfrak b
=R/(\mathfrak a+\mathfrak b).
$$

<!-- upstream_entity: Kommutativer Ring/Nenneraufnahmen/Tensorprodukt/Fakt/Beweis/Aufgabe -->

## Soal 18.16 {#br-bgk-2019-w18-ex16}

Misalkan $R$ gelanggang komutatif dan $S,T\subseteq R$ sistem-sistem
multiplikatif. Buktikan isomorfisme aljabar $R$

$$
R_S\otimes_RR_T=R_{S\cdot T}.
$$

<!-- upstream_entity: Monoidringe/Tensorprodukt/Aufgabe -->

## Soal 18.17 ★ {#br-bgk-2019-w18-ex17}

Misalkan $M$ dan $N$ monoid-monoid komutatif dan $R$ gelanggang komutatif.
Buktikan isomorfisme aljabar $R$

$$
R[M\times N]\cong R[M]\otimes_RR[N].
$$

<!-- upstream_entity: Kähler-Differentiale/Nenneraufnahme über Ring/Aufgabe -->

## Soal 18.18 ★ {#br-bgk-2019-w18-ex18}

Misalkan $A$ gelanggang komutatif dan $S\subseteq A$ suatu sistem
multiplikatif. Buktikan bahwa

$$
\Omega_{A_S/A}=0.
$$

<!-- upstream_entity: Kähler-Differentiale/Nenneraufnahme/Fakt/Beweis/Aufgabe -->

## Soal 18.19 {#br-bgk-2019-w18-ex19}

Misalkan $R$ gelanggang komutatif, $A$ aljabar komutatif $R$, dan
$S\subseteq A$ suatu sistem multiplikatif. Buktikan bahwa

$$
\Omega_{A_S/R}\cong(\Omega_{A/R})_S.
$$

<!-- upstream_entity: Kähler-Differentiale/Konormalensequenz/Positive Charakteristik/Variablenpotenz/Aufgabe -->

## Soal 18.20 {#br-bgk-2019-w18-ex20}

Bahas Lema 18.8 dalam kasus ketika $R=K$ merupakan lapangan berkarakteristik
positif $p$, $A=K[X]$, dan $I=(X^p)$.

<!-- upstream_entity: E8-Singularität/Kähler-Modul/Aufgabe -->

## Soal 18.21 {#br-bgk-2019-w18-ex21}

Untuk

$$
A=\mathbb C[X,Y,Z]/(X^2+Y^3+Z^5),
$$

deskripsikan modul diferensial Kähler melalui pembangkit dan relasi.

<!-- upstream_entity: Kähler-Modul/C über R/Restklassenbeschreibung/Aufgabe -->

## Soal 18.22 {#br-bgk-2019-w18-ex22}

Tentukan $\Omega_{\mathbb C/\mathbb R}$ dengan menggunakan Korolari 18.9.

<!-- upstream_entity: Nichtseparable Standarderweiterung/Kotangentialraum und Kählerversion/Aufgabe -->

## Soal 18.23 {#br-bgk-2019-w18-ex23}

Misalkan $p$ bilangan prima. Kita meninjau perluasan lapangan yang diberikan
oleh

$$
K=\mathbb Z/(p)(U)\subseteq\mathbb Z/(p)(Y)=L,
\qquad U\longmapsto Y^p.
$$

Buktikan bahwa Lema 18.14 tidak berlaku dalam situasi ini.

<!-- upstream_entity: Nichtvollkommener Körper/Regulär/Kählermodul nicht frei/Aufgabe -->

## Soal 18.24 {#br-bgk-2019-w18-ex24}

Misalkan $p$ bilangan prima dan

$$
K=\mathbb Z/(p)(U)\subseteq
R=K[Y]/(Y^p-U).
$$

Buktikan bahwa $R\cong K(Y)$, bahwa $R$ regular, dan bahwa modul diferensial
Kähler $\Omega_{R/K}$ tidak bebas.

<!-- upstream_entity: Zweidimensionale Sphäre/Kählermodul/Lokal frei/Explizit/Aufgabe -->

## Soal 18.25 {#br-bgk-2019-w18-ex25}

Misalkan

$$
R=\mathbb R[X,Y,Z]/(X^2+Y^2+Z^2-1).
$$

Buktikan bahwa modul diferensial Kähler $R$

$$
\Omega_{R/\mathbb R}
=RdX\oplus RdY\oplus RdZ/(XdX+YdY+ZdZ)
$$

menjadi bebas setelah dibatasi pada himpunan-himpunan terbuka
$D(X),D(Y),D(Z)$ (jadi, misalnya,
$(\Omega_{R/\mathbb R})_X=\Omega_{R_X/\mathbb R}$), dan simpulkan bahwa
$\Omega_{R/\mathbb R}$ bebas lokal.
