---
title: "Solusi Publik dan Cakupan Lembar Kerja 30"
stable_id: br-bgk-2019-w30-solutions
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
worksheet_upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 30"
worksheet_upstream_pageid: 110239
worksheet_upstream_revid: 991891
worksheet_upstream_parentid: 834041
worksheet_upstream_timestamp: "2025-01-23T14:50:11Z"
worksheet_upstream_mediawiki_sha1_base36: tk647bzywbelr9zlz7qvuyu9wb680vl
worksheet_frozen_revision_contributor: "Arbota"
worksheet_url: "https://de.wikiversity.org/wiki/Kurs:B%C3%BCndel,_Garben_und_Kohomologie_(Osnabr%C3%BCck_2019-2020)/Arbeitsblatt_30"
worksheet_revision_url: "https://de.wikiversity.org/w/index.php?oldid=991891"
authority_manifest: authority/wikiversity-bgk/unit-30/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 956990c5550c5fa417f3441dc1bb8f093acbdbb8fe1064ae37c384fa17b8fcb0
upstream_map: authority/wikiversity-bgk/unit-30/ORDERED_EXERCISE_MAP.json
upstream_map_sha256: 3bbf65672ab614c8f88caa438f06230328a87849a245447ae3207be682a59ecc
candidate_evidence: authority/wikiversity-bgk/unit-30/worksheet-solution-candidates-api.json
candidate_evidence_sha256: 3ffdcede4d7bb2407ad0028ad3f8e18046b6142814bb7dcfe89dd3551a4b498a
selection_rule: "Setiap judul halaman soal yang tepat dari wikitext lembar kerja saat ini diperiksa pada judul resmi <soal>/Lösung yang tepat; bintang dan ketiadaan tautan bukan bukti."
exercise_count: 5
candidate_solution_count: 5
public_solution_count: 0
public_solution_numbers: ""
negative_public_solution_count: 5
negative_solution_numbers: "1-5"
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

```{=latex}
\clearpage
```

# Solusi Publik dan Cakupan Lembar Kerja 30 {#br-bgk-2019-w30-solutions}

Halaman resmi Lembar Kerja 30 saat ini memuat tepat lima soal. Untuk setiap
judul halaman soal yang tepat, halaman resmi dengan akhiran `/Lösung` diperiksa
secara langsung. Kelima halaman kandidat tersebut tidak ada, sehingga tidak
terdapat teks solusi publik yang dapat diterjemahkan. Kesimpulan ini tidak
ditarik dari bintang maupun dari ada atau tidaknya tautan pada lembar kerja.

## Kandidat resmi yang diperiksa {#br-bgk-2019-w30-solutions-candidates}

1. Soal 30.1

   - Halaman soal: `Projektive Gerade/Riemann-Roch/Direkt/Aufgabe`
   - Kandidat solusi: [`Projektive Gerade/Riemann-Roch/Direkt/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Projektive_Gerade/Riemann-Roch/Direkt/Aufgabe/L%C3%B6sung)
   - Hasil resmi: halaman tidak ada.

2. Soal 30.2

   - Halaman soal: `Glatte Ebene Kurve/Syzygienbündel/Gradberechnung/Aufgabe`
   - Kandidat solusi: [`Glatte Ebene Kurve/Syzygienbündel/Gradberechnung/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Glatte_Ebene_Kurve/Syzygienb%C3%BCndel/Gradberechnung/Aufgabe/L%C3%B6sung)
   - Hasil resmi: halaman tidak ada.

3. Soal 30.3

   - Halaman soal: `Projektive Gerade/Rang 2/Grad 0/Schnitte/Aufgabe`
   - Kandidat solusi: [`Projektive Gerade/Rang 2/Grad 0/Schnitte/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Projektive_Gerade/Rang_2/Grad_0/Schnitte/Aufgabe/L%C3%B6sung)
   - Hasil resmi: halaman tidak ada.

4. Soal 30.4

   - Halaman soal: `Projektive Ebene/Kotangentialbündel/Einschränkung/Gerade/Aufgabe`
   - Kandidat solusi: [`Projektive Ebene/Kotangentialbündel/Einschränkung/Gerade/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Projektive_Ebene/Kotangentialb%C3%BCndel/Einschr%C3%A4nkung/Gerade/Aufgabe/L%C3%B6sung)
   - Hasil resmi: halaman tidak ada.

5. Soal 30.5

   - Halaman soal: `Projektive Ebene/Kotangentialbündel/Einschränkung/Quadrik/Aufgabe`
   - Kandidat solusi: [`Projektive Ebene/Kotangentialbündel/Einschränkung/Quadrik/Aufgabe/Lösung`](https://de.wikiversity.org/wiki/Projektive_Ebene/Kotangentialb%C3%BCndel/Einschr%C3%A4nkung/Quadrik/Aufgabe/L%C3%B6sung)
   - Hasil resmi: halaman tidak ada.

## Hasil negatif yang dibuktikan halaman resmi {#br-bgk-2019-w30-solutions-negative}

Tidak satu pun dari lima judul kandidat resmi di atas mempunyai halaman
publik. Pernyataan ini hanya mencatat status halaman sumber pada pemeriksaan
ini; pernyataan ini bukan klaim bahwa solusi matematis tidak ada.
