---
title: "Solusi Publik dan Cakupan Lembar Kerja 25"
stable_id: br-bgk-2019-w25-solutions
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Intervall/Intervallüberdeckung/2/Stetige Funktion/Differenz/Aufgabe/Lösung"
upstream_pageid: 125477
upstream_revid: 1096264
upstream_timestamp: "2026-06-15T08:23:34Z"
upstream_mediawiki_sha1: 4873a553ced30228b6d6eb2e1f1b247f181f488b
source_url: "https://de.wikiversity.org/w/index.php?oldid=1096264"
source_attribution: "im Wesentlichen Tarek Emmrich"
authority_manifest: authority/wikiversity-bgk/unit-25/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: f454cb2f8ada795015dcf78d4ad56a54107d9773705b7113a1ef1600b341e26d
authority_manifest_status: "Bekuan authority terminal lengkap; 33 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
solution_ex01_xml: authority/wikiversity-bgk/unit-25/solution-ex01.xml
solution_ex01_xml_sha256: ee5a739c70fdff70b2d4c037972c6091a92a0436a3c97a3a0deb93ae3ebf6b34
solution_ex01_html: authority/wikiversity-bgk/unit-25/solution-ex01.html
solution_ex01_html_sha256: 3cfb91666b17069c63a9256c5f0e27411cc802ff6419763f6922238cf43b6fc5
upstream_map: authority/wikiversity-bgk/unit-25/ORDERED_EXERCISE_MAP.json
upstream_map_sha256: 03b696f0c666352947f89c01a2c1ca0c1c5fb38bae0af77693cf21021b6b381b
candidate_evidence: authority/wikiversity-bgk/unit-25/worksheet-solution-candidates-api.json
candidate_evidence_sha256: 37ce99c2c415ef9bc13592e6e9d0537322c4fcf0b83b3112f8b6d1796828c939
exercise_count: 13
public_solution_count: 1
public_solution_numbers: "1"
negative_public_solution_count: 12
negative_solution_numbers: "2-13"
media_credits: source/id-ID/media-credits-bgk-unit-25.md
media_credits_sha256: c0367344876a648ab7141eb306e6a9a02f14c47b3b57a03012073940f4297037
rights_ledger: authority/RIGHTS-bgk-unit-25.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-25.json
asset_closure_sha256: b897e839fc6999e5c149e1bf065a634b96246b563860d46f0a16ddb82ae1c9d5
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

```{=latex}
\clearpage
```

# Solusi Publik dan Cakupan Lembar Kerja 25 {#br-bgk-2019-w25-solutions}

Pada batas revisi yang dibekukan, sumber menyediakan tepat satu solusi publik
di antara 13 soal, yaitu solusi Soal 25.1. Peta soal dan bukti kandidat mencatat
hasil negatif untuk Soal 25.2--25.13. Ketiadaan halaman solusi publik tidak
diubah menjadi solusi buatan.

<!-- upstream_entity: Intervall/Intervallüberdeckung/2/Stetige Funktion/Differenz/Aufgabe/Lösung -->

## Solusi Soal 25.1 {#br-bgk-2019-w25-sol-ex01}

Misalkan

$$
U=]a,b[
$$

dan

$$
V=]c,d[
$$

dengan

$$
a<c<b<d.
$$

Jika irisannya kosong, pernyataan itu trivial. Batas-batas luar juga dapat
termasuk ke dalam interval.

Pilih $\epsilon>0$ sedemikian sehingga

$$
2\epsilon<b-c.
$$

Kita definisikan

$$
g(x):=
\begin{cases}
f(x),&x\geq b-\epsilon,\\[2pt]
f(x)\dfrac{x-c-\epsilon}{b-c-2\epsilon},
&x\in]c+\epsilon,b-\epsilon[,\\[8pt]
0,&x\leq c+\epsilon,
\end{cases}
$$

dan

$$
-h(x):=
\begin{cases}
0,&x\geq b-\epsilon,\\[2pt]
f(x)\dfrac{-x+b-\epsilon}{b-c-2\epsilon},
&x\in]c+\epsilon,b-\epsilon[,\\[8pt]
f(x),&x\leq c+\epsilon.
\end{cases}
$$

Fungsi-fungsi ini kontinu karena nilai-nilainya berimpit pada titik-titik
peralihan. Untuk

$$
x\in]c+\epsilon,b-\epsilon[
$$

berlaku

$$
\begin{aligned}
g(x)-h(x)
&=f(x)\frac{x-c-\epsilon}{b-c-2\epsilon}
 +f(x)\frac{-x+b-\epsilon}{b-c-2\epsilon}\\
&=f(x)\frac{x-c-\epsilon-x+b-\epsilon}
{b-c-2\epsilon}\\
&=f(x).
\end{aligned}
$$

Di luar interval ini, persamaan tersebut juga berlaku.

Sumber solusi mencantumkan atribusi "pada pokoknya Tarek Emmrich".

## Hasil negatif yang dibekukan {#br-bgk-2019-w25-solutions-negative}

Tidak ada halaman solusi publik pada revisi yang dibekukan untuk Soal 25.2,
25.3, 25.4, 25.5, 25.6, 25.7, 25.8, 25.9, 25.10, 25.11, 25.12, atau 25.13.
Pernyataan ini adalah hasil pemeriksaan kandidat, bukan klaim bahwa solusi
matematis tidak ada.
