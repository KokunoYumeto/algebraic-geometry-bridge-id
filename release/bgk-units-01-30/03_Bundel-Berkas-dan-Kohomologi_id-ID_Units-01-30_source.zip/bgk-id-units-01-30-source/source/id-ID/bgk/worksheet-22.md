---
title: "Lembar Kerja 22 - Grup Kelas Pembagi"
stable_id: br-bgk-2019-w22
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 22"
upstream_pageid: 110230
upstream_revid: 1069409
upstream_timestamp: "2026-02-05T19:19:17Z"
upstream_mediawiki_sha1: 47f103239ec0db5780bf211ea257e727d72f3098
source_url: "https://de.wikiversity.org/w/index.php?oldid=1069409"
authority_manifest: authority/wikiversity-bgk/unit-22/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 98e1716c4a8e95d42a19fd6a8b9efb04e222687e5bb6dc296ae42496baab1e39
worksheet_xml: authority/wikiversity-bgk/unit-22/worksheet-22.xml
worksheet_xml_sha256: bff3059aba572579c9352dd309b26129da7e1341aa8094b0a091366d919209da
worksheet_expanded_tex: authority/wikiversity-bgk/unit-22/worksheet-22-expanded.tex
worksheet_expanded_tex_sha256: 18dce8bae2bb05f3337d69cc93949e9b0d2867e3ef3eacd84fcff005e5908b64
official_pdf: authority/artifacts/bgk-worksheet-22-official.pdf
official_pdf_sha256: 2d0e27c819584ea8c4e1fcb4c46a6f7c51ba3bd3f1a8467832fdea9f7d85d10a
ordered_exercise_map: authority/wikiversity-bgk/unit-22/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 34c6c4f31bffe001aad01da4c0e553cdfd5d6c36dd354e9e8f6a90823b555d67
exercise_count: 20
public_solution_count: 1
public_solution_numbers: "19"
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete_semantic_authority_bound
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
rights_ledger: authority/RIGHTS-bgk-unit-22.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-22.json
asset_closure_sha256: e7bf39c238717349b7d2e02a8f05eb252fe6aa39199bce82a8c9f60d1b5ea718
---

# Lembar Kerja 22: Grup Kelas Pembagi {#br-bgk-2019-w22}

Tanda bintang menandai Soal 22.19. Pemeriksaan judul kandidat yang dicatat
oleh QA menemukan bahwa inilah tepat satu soal dengan halaman solusi publik.
Sembilan belas judul kandidat lainnya tidak ada; edisi tidak menciptakan
solusi baru.

<!-- upstream_entity: Ganze Zahlen/Hauptdivisor/1/Aufgabe -->

## Soal 22.1 {#br-bgk-2019-w22-ex01}

Tentukan pembagi utama dari

$$
\frac{1000}{333}
$$

pada $\operatorname{Spek}(\mathbb Z)$.

<!-- upstream_entity: Projektive Gerade/Hauptdivisor/1/Aufgabe -->

## Soal 22.2 {#br-bgk-2019-w22-ex02}

Tentukan pembagi utama dari

$$
f=(t-3)^2(t-1)^{-5}t^2(t+2)^{-1}
$$

pada garis projektif

$$
\mathbb P_K^1=\operatorname{Proj}(K[X,Y]).
$$

<!-- upstream_entity: Projektive Gerade/Hauptdivisor/2/Aufgabe -->

## Soal 22.3 {#br-bgk-2019-w22-ex03}

Tentukan pembagi utama dari

$$
f=\frac{t}{t^2+1}
$$

pada garis projektif

$$
\mathbb P_K^1=\operatorname{Proj}(K[X,Y]),
\qquad t=\frac YX,
$$

untuk lapangan $K=\mathbb R$ dan $K=\mathbb C$.

<!-- upstream_entity: Projektive Gerade/Algebraisch abgeschlossen/Polynom/Hauptdivisor/Summe 0/Aufgabe -->

## Soal 22.4 {#br-bgk-2019-w22-ex04}

Perhatikan garis projektif

$$
\mathbb P_K^1=\operatorname{Proj}(K[X,Y])
$$

di atas suatu lapangan $K$, serta garis afin

$$
\mathbb A_K^1\subseteq\mathbb P_K^1
=D_+(X)\cup\{\infty\}
$$

dengan gelanggang seksi global

$$
K\left[\frac YX\right]=K[t].
$$

Buktikan pernyataan-pernyataan berikut.

1. Pembagi utama suatu polinomial $P\in K[t]$ tidak mempunyai orde negatif
   (tidak mempunyai kutub) di $\mathbb A_K^1$.
2. Orde suatu polinomial $P\in K[t]$ di $\infty$ adalah negatif dari derajat
   $P$.
3. Misalkan
   $$
   D=\sum_P n_P\cdot P
   $$
   dan $K$ tertutup secara aljabar. Maka $D$ merupakan pembagi utama jika
   dan hanya jika
   $$
   \sum_Pn_P=0.
   $$

<!-- upstream_entity: Projektiver Raum/Weildivisor/Graduierter Polynomring/Aufgabe -->

## Soal 22.5 {#br-bgk-2019-w22-ex05}

Misalkan

$$
\mathbb P_K^n
=\operatorname{Proj}(K[X_0,X_1,\ldots,X_n])
$$

ruang projektif di atas lapangan $K$. Buktikan bahwa pembagi-pembagi Weil
efektif pada $\mathbb P_K^n$ bersesuaian dengan polinomial-polinomial
homogen ternormalisasi

$$
P\in K[X_0,X_1,\ldots,X_n].
$$

<!-- upstream_entity: Projektiver Raum/Hyperebenen/Linear äquivalent/Aufgabe -->

## Soal 22.6 {#br-bgk-2019-w22-ex06}

Buktikan bahwa pada ruang projektif $\mathbb P_K^d$ di atas suatu lapangan,
setiap dua hiperbidang

$$
H_1=V_+(a_0X_0+a_1X_0+\cdots+a_dX_d)
$$

dan

$$
H_2=V_+(b_0X_0+b_1X_0+\cdots+b_dX_d)
$$

ekuivalen secara linear.

> **Catatan edisi - variabel yang berulang dalam sumber.** Kedua persamaan
> sumber mencetak $X_0$ pada dua suku pertamanya. Edisi mempertahankan
> rumus itu dan tidak mengganti suku kedua secara diam-diam.

<!-- upstream_entity: Projektiver Raum/Irreduzible Hyperfläche/Hyperebene/Linear äquivalent/Aufgabe -->

## Soal 22.7 {#br-bgk-2019-w22-ex07}

Misalkan

$$
V=V_+(F)\subseteq\mathbb P_K^d
$$

suatu hipermuka tak tereduksi berderajat $d$ dalam ruang projektif di atas
suatu lapangan, yang kita pandang sebagai unsur grup kelas pembagi. Buktikan
bahwa $V$ ekuivalen secara linear dengan $dH$, dengan $H$ menyatakan kelas
suatu hiperbidang.

<!-- upstream_entity: Projektiver Raum/Hyperebenen/Projektiver Raum/Aufgabe -->

## Soal 22.8 {#br-bgk-2019-w22-ex08}

Buktikan bahwa himpunan semua hiperbidang dalam suatu ruang projektif dengan
sendirinya membentuk ruang projektif berdimensi sama.

<!-- upstream_entity: Projektiver Raum/Hyperebenen/Durch Punkte/Aufgabe -->

## Soal 22.9 {#br-bgk-2019-w22-ex09}

Misalkan $P_0,P_1,\ldots,P_N$ adalah titik-titik (tertutup) dalam ruang
projektif $\mathbb P_K^N$ yang tidak semuanya terletak dalam satu
hiperbidang. Misalkan $0\leq r\leq N$.

1. Buktikan bahwa $P_0,P_1,\ldots,P_r$ tidak termuat dalam subruang
   projektif berdimensi $<r$.
2. Buktikan bahwa himpunan semua hiperbidang yang memuat titik-titik
   $P_0,P_1,\ldots,P_r$ membentuk subruang projektif berdimensi
   $N-1-r$ di dalam ruang semua hiperbidang.

<!-- upstream_entity: Normales Schema/Kodimension 2/Divisorenklassengruppe/Aufgabe -->

## Soal 22.10 {#br-bgk-2019-w22-ex10}

Misalkan $X$ skema integral normal dan Noether, dan misalkan
$Z\subset X$ subhimpunan tertutup berkodimensi $\geq 2$. Buktikan bahwa
grup kelas pembagi dari $X$ sama dengan grup kelas pembagi dari
$X\smallsetminus Z$.

<!-- upstream_entity: Normales Schema/Offene Teilmenge/Divisoren/Einschränkung/Divisorenklassengruppe/Aufgabe -->

## Soal 22.11 {#br-bgk-2019-w22-ex11}

Misalkan $X$ skema integral normal dan Noether, dan misalkan
$U\subset X$ subhimpunan terbuka. Buktikan bahwa dengan membuang
pembagi-pembagi prima yang tidak berpotongan dengan $U$, kita memperoleh
homomorfisme grup surjektif

$$
\operatorname{Div}(X)\longrightarrow\operatorname{Div}(U).
$$

Buktikan bahwa pembagi utama dipetakan ke pembagi utama, sehingga terdapat
homomorfisme grup surjektif

$$
\operatorname{DKG}(X)\longrightarrow\operatorname{DKG}(U).
$$

<!-- upstream_entity: Normales Schema/Punkt/Divisoren/Einschränkung/Divisorenklassengruppe/Aufgabe -->

## Soal 22.12 {#br-bgk-2019-w22-ex12}

Misalkan $X$ skema integral normal dan Noether, dan misalkan $x\in X$
suatu titik. Buktikan bahwa dengan membuang pembagi-pembagi prima yang tidak
melalui $x$, kita memperoleh homomorfisme grup surjektif

$$
\operatorname{Div}(X)
\longrightarrow\operatorname{Div}(\mathcal O_{X,x}).
$$

Buktikan bahwa pembagi utama dipetakan ke pembagi utama, sehingga terdapat
homomorfisme grup surjektif

$$
\operatorname{DKG}(X)
\longrightarrow\operatorname{DKG}(\mathcal O_{X,x}).
$$

<!-- upstream_entity: Projektiver Raum/Hyperfläche/Divisor/Invertierbare Untergarbe/Aufgabe -->

## Soal 22.13 {#br-bgk-2019-w22-ex13}

Misalkan

$$
D
=\sum_Ya_Y\cdot Y
=\sum_ja_j\cdot Y_j
=\sum_ja_j\cdot V_+(G_j)
$$

suatu pembagi Weil ruang projektif $\mathbb P_K^d$, dengan pembagi-pembagi
prima yang terlibat dideskripsikan oleh unsur-unsur prima homogen

$$
G_j\in K[X_0,X_1,\ldots,X_d].
$$

Perhatikan polinomial

$$
G:=\prod_jG_j^{a_j}
$$

berderajat

$$
\delta=\sum_ja_j\operatorname{grad}(G_j).
$$

Buktikan bahwa subberkas invertibel $\mathcal L_D$ terkait dalam berkas
lapangan fungsi menurut Teorema 22.9 sama dengan realisasi berkas struktur
terpilin

$$
\mathcal O_{\mathbb P_K^d}(-\delta)
$$

melalui perkalian dengan $G$ dari Contoh 20.9.

> **Catatan edisi - sebutan polinomial dalam sumber.** Sumber menyebut
> $G:=\prod_jG_j^{a_j}$ suatu polinomial, meskipun koefisien $a_j$ dari
> pembagi Weil umum dapat bernilai negatif. Edisi mempertahankan sebutan dan
> rumus sumber tanpa mengasumsikan bahwa pembaginya efektif.

Dalam soal-soal berikutnya, untuk pembagi $D$ kita bekerja dengan

$$
\mathcal O_X(D)=-\mathcal L_D.
$$

Jadi, untuk subhimpunan terbuka $U\subseteq X$,

$$
\mathcal O_X(D)(U)
=\{f\in K\mid\operatorname{ord}_Y(f)\geq-D
\text{ untuk semua }Y\in U\}.
$$

> **Catatan edisi - konvensi yang dicetak sumber.** Sumber menuliskan
> $\mathcal O_X(D)=-\mathcal L_D$ dan membandingkan
> $\operatorname{ord}_Y(f)$ langsung dengan $-D$, tanpa menamai koefisien
> pembagi. Edisi mempertahankan notasi tersebut.

<!-- upstream_entity: Projektives Schema/Lokal faktoriell/Divisor/Linear äquivalente effektive Divisoren/Aufgabe -->

## Soal 22.14 {#br-bgk-2019-w22-ex14}

Misalkan $X$ skema integral projektif yang faktorial lokal di atas lapangan
tertutup secara aljabar $K$, dan misalkan $D$ pembagi Weil pada $X$ dengan
berkas terkait $\mathcal O_X(D)$. Buktikan bahwa terdapat korespondensi
alami antara pembagi-pembagi Weil efektif yang ekuivalen secara linear
dengan $D$ dan seksi-seksi global tak trivial dari $\mathcal O_X(D)$, dengan
dua seksi diidentifikasi jika keduanya berbeda hanya melalui penskalaan.

<!-- upstream_entity: Lokal faktorielles integres Schema/Invertierbare Garbe/Schnitt/Nullstelle/Divisor/Isomorphie/Aufgabe -->

## Soal 22.15 {#br-bgk-2019-w22-ex15}

Misalkan $X$ skema integral Noether yang faktorial lokal dan $\mathcal L$
subberkas invertibel dari berkas lapangan fungsi konstan. Misalkan

$$
s\in\Gamma(X,\mathcal L)
$$

suatu seksi tak trivial. Buktikan bahwa himpunan nol $s$, yaitu

$$
Z(s)=X\smallsetminus X_s,
$$

secara alami merupakan pembagi Weil efektif $D$ pada $X$ sedemikian sehingga

$$
\mathcal L\cong\mathcal O_X(D).
$$

<!-- upstream_entity: Projektiver Raum/Effektiver Divisor/Funktion/Glatte Kurve/Induzierter Divisor/Schnitt/Aufgabe -->

## Soal 22.16 {#br-bgk-2019-w22-ex16}

Misalkan

$$
F=F_1^{a_1}\cdots F_r^{a_r}
$$

faktorisasi prima suatu polinomial homogen

$$
F\in K[X_0,X_1,\ldots,X_d]
$$

berderajat $e$ di atas lapangan tertutup secara aljabar $K$, dengan
polinomial-polinomial prima homogen $F_j$, dan misalkan

$$
D=\sum_{j=1}^n a_jV_+(F_j)
$$

pembagi Weil terkait pada ruang projektif $\mathbb P_K^d$. Buktikan
pernyataan-pernyataan berikut.

1. Setiap pembagi Weil efektif pada ruang projektif dapat disajikan dalam
   bentuk ini, secara unik hingga penskalaan.
2. Secara himpunan berlaku
   $$
   V_+(F)=\bigcup_{j=1}^nV_+(F_i).
   $$
3. Misalkan $C\subseteq\mathbb P_K^d$ kurva projektif mulus yang tidak
   termuat dalam $V_+(F)$. Maka $D$ menginduksi pembagi Weil $D|_C$ pada
   kurva $C$ dengan mengambil, pada setiap titik $P\in C$, orde $F$ dalam
   $\mathcal O_{C,P}$.
4. Restriksi berkas invertibel $\mathcal O_{\mathbb P_K^d}(e)|_C$
   isomorfik dengan berkas invertibel pada $C$ yang terkait dengan $D|_C$.
   Jadi,
   $$
   \mathcal O_{\mathbb P_K^d}(D)|_C
   =\mathcal O_C(D|_C).
   $$
5. Pembagi-pembagi yang ekuivalen secara linear pada ruang projektif
   menginduksi pembagi-pembagi yang ekuivalen secara linear pada kurva.

> **Catatan edisi - indeks dalam sumber.** Faktorisasi sumber memakai $r$
> faktor, sedangkan jumlah dan gabungan memakai batas $n$; pada gabungan,
> indeks yang dijumlahkan adalah $j$ tetapi sukunya dicetak $F_i$. Semua
> indeks tersebut dipertahankan sebagaimana sumber.

<!-- upstream_entity: Projektiver Raum/Effektiver Divisor/Kurve/Durchschnitt/Aufgabe -->

## Soal 22.17 {#br-bgk-2019-w22-ex17}

Misalkan $D$ pembagi Weil efektif dalam ruang projektif $\mathbb P_K^d$
dengan sekurang-kurangnya satu komponen positif. Buktikan bahwa $D$
mempunyai irisan tak kosong dengan setiap kurva projektif
$C\subseteq\mathbb P_K^d$.

Gunakan fakta bahwa $D_+(f)$ afin dan kurva projektif tidak afin.

Khususnya, dua kurva dalam bidang projektif selalu mempunyai irisan tak
kosong. Untuk kurva mulus, kita juga dapat menggunakan Soal 22.16. Sifat ini
sama sekali tidak berlaku untuk semua permukaan projektif, sebagaimana
diperlihatkan oleh contoh-contoh berikut.

<!-- upstream_entity: Standardquadrik/Projektiv/Disjunkte Geraden/Aufgabe -->

## Soal 22.18 {#br-bgk-2019-w22-ex18}

Buktikan bahwa pada permukaan projektif

$$
V_+(XY-ZW)\subseteq\mathbb P_K^3
$$

terdapat garis-garis yang saling lepas, dipandang sebagai objek dalam ruang
projektif.

<!-- upstream_entity: Fermat-Kubik/Projektiv/Disjunkte Geraden/Aufgabe -->

## Soal 22.19 ★ {#br-bgk-2019-w22-ex19}

Buktikan bahwa pada permukaan projektif

$$
V_+(X^3+Y^3-Z^3-W^3)\subseteq\mathbb P_K^3
$$

berderajat $3$ di atas lapangan tertutup secara aljabar $K$ dengan
karakteristik $\ne 3$, terdapat garis-garis yang saling lepas, dipandang
sebagai objek dalam ruang projektif.

<!-- upstream_entity: Projektive Ebene/Konzentrische Kreise/Schnittpunkte/Aufgabe -->

## Soal 22.20 {#br-bgk-2019-w22-ex20}

Misalkan $C_1$ dan $C_2$ dua lingkaran konsentris dalam $\mathbb R^2$
berpusat di $(0,0)$. Tentukan titik-titik perpotongan kedua lingkaran,
dipandang sebagai kurva projektif, dalam bidang projektif
$\mathbb P_{\mathbb C}^2$.
