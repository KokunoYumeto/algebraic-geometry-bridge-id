---
title: "Kuliah 23 - Modul Injektif"
stable_id: br-bgk-2019-l23
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 23"
upstream_pageid: 109027
upstream_revid: 1003752
upstream_timestamp: "2025-06-08T16:35:51Z"
upstream_mediawiki_sha1: 9425b65cf4737b7bb6ef15e87d9c2a637ff93d28
source_url: "https://de.wikiversity.org/w/index.php?oldid=1003752"
course_authority_manifest: authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json
course_authority_manifest_sha256: ea0bf346e261db8ed80b7565f7746e95c79e0c376d25d9fbce5d96879dff7dd8
capture_identity: authority/wikiversity-bgk/unit-23/CAPTURE_IDENTITY.json
capture_identity_sha256: de194d9895b48db11613225072c9995377499c2c7ebf0a010de54bd3e4756c63
authority_manifest: authority/wikiversity-bgk/unit-23/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 96fb36e19dd3e6dcef56149150ce09c238843bee08ff36503d87a55284113775
authority_manifest_status: complete
official_pdf: authority/artifacts/bgk-lecture-23-official.pdf
official_pdf_sha256: dd1ea1b0f25c2d1b3988910761a2c0c4c217a5f8d4cfd8d0d0913c9078a84c3d
official_pdf_status: verified_source_bytes_and_upload_sha1
official_pdf_metadata: authority/wikiversity-bgk/unit-23/official-pdfs-api.json
official_pdf_source_bytes: 88712
official_pdf_source_sha1: 58050b993430d2f097b0c024871af997a3ff95d5
authority_precedence: "Revisi semantik beku mengendalikan teks; PDF resmi lama adalah saksi pelengkap yang tetap dibedakan."
official_course_pdf: authority/artifacts/bgk-course-official.pdf
official_course_pdf_bytes: 2104862
official_course_pdf_pages: 265
official_course_pdf_unit_pages: "200-209"
official_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
lecture_xml: authority/wikiversity-bgk/unit-23/lecture-23.xml
lecture_xml_sha256: db8e794226d9a120bf5eaa62009150a98ea0497160b6cfaa81e8cc070e1b9ca7
lecture_expanded_tex: authority/wikiversity-bgk/unit-23/lecture-23-expanded.tex
lecture_expanded_tex_sha256: dc5e24384944dc71f71640858e6418dcb3bf29aee6a731eb4f507f833857756a
media_credits: source/id-ID/media-credits-bgk-unit-23.md
rights_ledger: authority/RIGHTS-bgk-unit-23.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-23.json
asset_closure_sha256: 00673ca97e9a0caeca0bdf9bc02b1e18881dc5576ce2a9285cf904c503c189a7
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 23: Modul Injektif {#br-bgk-2019-l23}

## Modul injektif {#br-bgk-2019-l23-s01}

<!-- upstream_entity: Kommutativer Ring/Injektiver Modul/Definition -->

### Definisi 23.1: modul injektif {#br-bgk-2019-l23-def-01}

Misalkan $R$ gelanggang komutatif. Suatu modul $R$, $I$, disebut *injektif*
jika untuk setiap modul $R$, $M$, setiap submodul $N\subseteq M$, dan setiap
homomorfisme modul $R$

$$
\varphi:N\longrightarrow I
$$

terdapat suatu perluasan

$$
\widetilde\varphi:M\longrightarrow I.
$$

Di atas suatu lapangan, setiap ruang vektor bersifat injektif. Memang, setiap
subruang vektor di dalam suatu ruang vektor mempunyai komplemen langsung,
dan pemetaan linear tersebut dapat diperluas secara arbitrer pada komplemen
itu. Untuk $R=\mathbb Z$, situasinya sudah lebih rumit.

<!-- upstream_entity: Kommutative Gruppe/Divisibel/Definition -->

### Definisi 23.2: grup divisibel {#br-bgk-2019-l23-def-02}

Suatu grup komutatif $G$ disebut *divisibel* jika untuk setiap
$n\in\mathbb N_+$ dan setiap $g\in G$ terdapat $h\in G$ dengan

$$
g=nh.
$$

Grup $\mathbb Z$ sendiri tidak divisibel. Sebaliknya, $\mathbb Q$ sebagai grup
komutatif bersifat divisibel, sebab untuk setiap $n\in\mathbb N_+$ pemetaan
perkalian

$$
\mathbb Q\longrightarrow\mathbb Q,\qquad x\longmapsto nx,
$$

bersifat surjektif: kita dapat membagi dengan $n$, dan dari sinilah nama
*divisibel* berasal.

<!-- upstream_entity: Divisible Gruppe/Grundlegende Eigenschaften/Fakt -->

### Lema 23.3: grup faktor dari grup divisibel {#br-bgk-2019-l23-lem-01}

Jika $D$ grup divisibel, maka setiap grup faktor $D/H$ juga divisibel.

#### Bukti {#br-bgk-2019-l23-lem-01-proof}

Misalkan $n\in\mathbb N_+$. Untuk setiap $d\in D$ terdapat $e\in D$ dengan
$d=ne$. Maka di dalam $D/H$ juga berlaku

$$
[d]=n[e].
$$

<!-- upstream_entity: Kommutative Gruppe/Einbettung in divisible Gruppe/Fakt -->

### Lema 23.4: penyematan ke dalam grup divisibel {#br-bgk-2019-l23-lem-02}

Untuk setiap grup komutatif $G$, terdapat grup divisibel $D$ dengan
$G\subseteq D$.

#### Bukti {#br-bgk-2019-l23-lem-02-proof}

Kita tulis

$$
G=\mathbb Z^{(J)}/H
$$

untuk suatu himpunan indeks $J$ yang mengindeks sebuah sistem pembangkit
$G$. Grup bebas $\mathbb Z^{(J)}$ dapat disematkan ke dalam grup divisibel
$\mathbb Q^{(J)}$. Karena itu terdapat penyematan

$$
G\subseteq\mathbb Q^{(J)}/H,
$$

dan grup di ruas kanan divisibel menurut Lema 23.3.

Hasil berikut disebutkan tanpa bukti.

<!-- upstream_entity: Kommutative Gruppe/Injektiv/Divisibel/Fakt -->

### Lema 23.5: divisibel tepat ketika injektif {#br-bgk-2019-l23-lem-03}

Suatu grup komutatif $G$ divisibel tepat ketika $G$ injektif.

<!-- upstream_entity: Injektiver Modul/Kurze exakte Sequenz/Spaltung/Fakt -->

### Lema 23.6: barisan eksak pendek yang memuat modul injektif {#br-bgk-2019-l23-lem-04}

Misalkan $I$ modul injektif di atas gelanggang komutatif $R$. Maka setiap
barisan eksak pendek modul $R$

$$
0\longrightarrow I\longrightarrow B\longrightarrow C\longrightarrow 0
$$

terbelah.

#### Bukti {#br-bgk-2019-l23-lem-04-proof}

Identitas $\operatorname{Id}_I:I\to I$ mempunyai perluasan
$\varphi:B\to I$. Pemetaan ini memberikan pembelahan tersebut.

<!-- upstream_entity: Kommutative Algebren/Injektiver Modul/Beziehung/Fakt -->

### Lema 23.7: perubahan gelanggang bagi modul injektif {#br-bgk-2019-l23-lem-05}

Misalkan $R$ gelanggang komutatif, $S$ aljabar komutatif $R$, dan $I$ modul
$R$ yang injektif. Maka modul $S$

$$
\operatorname{Hom}_R(S,I)
$$

juga injektif.

#### Bukti {#br-bgk-2019-l23-lem-05-proof}

Misalkan $A\subseteq B$ modul-modul $S$ dan

$$
\varphi:A\longrightarrow\operatorname{Hom}_R(S,I),
\qquad
a\longmapsto\varphi_a,
$$

suatu homomorfisme modul $S$. Secara eksplisit, hal ini berarti

$$
\varphi_a(s)=\varphi_{as}(1).
$$

Kita pandang $A$ dan $B$ sebagai modul-modul $R$, lalu kita tinjau
homomorfisme modul $R$ komposit

$$
A\xrightarrow{\ \varphi\ }
\operatorname{Hom}_R(S,I)
\xrightarrow{\ \theta\mapsto\theta(1)\ }I.
$$

Karena $I$ injektif sebagai modul $R$, komposit ini mempunyai perluasan
$R$-linear

$$
\widetilde\varphi:B\longrightarrow I.
$$

Kita klaim bahwa pemetaan

$$
B\longrightarrow\operatorname{Hom}_R(S,I),
\qquad
b\longmapsto\bigl(s\longmapsto\widetilde\varphi(sb)\bigr),
$$

merupakan homomorfisme modul $S$. Mula-mula jelas bahwa pemetaan komposit

$$
S\xrightarrow{\ 1\mapsto b\ }B
\xrightarrow{\ \widetilde\varphi\ }I
$$

merupakan unsur $\operatorname{Hom}_R(S,I)$. Penetapan keseluruhannya
$S$-linear berdasarkan struktur modul $S$ pada
$\operatorname{Hom}_R(S,I)$. Untuk $a\in A$ berlaku

$$
\widetilde\varphi(sa)=\varphi_{as}(1)=\varphi_a(s),
$$

sehingga pemetaan tersebut memang merupakan suatu perluasan.

## Resolusi injektif {#br-bgk-2019-l23-s02}

<!-- upstream_entity: Kommutativer Ring/Modul/Injektiver Modul/Fakt -->

### Korolari 23.8: penyematan modul ke dalam modul injektif {#br-bgk-2019-l23-cor-01}

Untuk suatu modul $R$, $M$, di atas gelanggang komutatif $R$, terdapat modul
injektif $I$ dengan $M\subseteq I$.

#### Bukti {#br-bgk-2019-l23-cor-01-proof}

Menurut Lema 23.4, bagi grup komutatif $M$ terdapat grup divisibel $D$ dan
penyematan $M\subseteq D$. Menurut Lema 23.5, $D$ merupakan modul
$\mathbb Z$ yang injektif. Lema 23.7 kemudian menyatakan bahwa modul $R$

$$
\operatorname{Hom}_{\mathbb Z}(R,D)
$$

juga injektif. Sumber menampilkan diagram komutatif

$$
\begin{matrix}
M&\longrightarrow&D\\
\downarrow&&\downarrow\\
\operatorname{Hom}_{\mathbb Z}(R,M)
&\longrightarrow&
\operatorname{Hom}_{\mathbb Z}(R,D).
\end{matrix}
$$

Pemetaan vertikal kiri diberikan oleh

$$
v\longmapsto\bigl(r\longmapsto rv\bigr),
$$

dan pemetaan horizontal bawah diinduksi oleh penyematan $M\hookrightarrow D$.
Keduanya injektif dan merupakan homomorfisme modul $R$. Komposisinya
memberikan submodul $R$

$$
M\subseteq\operatorname{Hom}_{\mathbb Z}(R,D).
$$

> **Catatan edisi - panah vertikal kanan dalam diagram sumber.** Sumber juga
> menyatakan bahwa panah vertikal kanan diberikan oleh
> $v\mapsto(r\mapsto rv)$. Akan tetapi, data yang dinyatakan hanya membuat
> $D$ sebuah grup komutatif divisibel, bukan modul $R$, sehingga panah kanan
> itu tidak terdefinisi tanpa struktur tambahan. Kesimpulan bukti hanya
> memerlukan panah vertikal kiri dan panah horizontal bawah yang terdefinisi
> di atas. Edisi mempertahankan diagram sumber, tetapi memakai komposisi dua
> panah tersebut untuk penyematan yang disimpulkan.

<!-- upstream_entity: Kommutativer Ring/Modul/Injektive Auflösung/Definition -->

### Definisi 23.9: resolusi injektif {#br-bgk-2019-l23-def-03}

Suatu *resolusi injektif* dari modul $R$, $M$, di atas gelanggang komutatif
$R$ adalah kompleks eksak modul-modul $R$

$$
0\longrightarrow M\longrightarrow I_0\longrightarrow I_1
\longrightarrow I_2\longrightarrow\cdots,
$$

dengan $I_n$ injektif untuk setiap $n\geq 0$.

<!-- upstream_entity: Kommutativer Ring/Modul/Injektive Auflösung/Fakt -->

### Lema 23.10: keberadaan resolusi injektif {#br-bgk-2019-l23-lem-06}

Setiap modul $R$, $M$, di atas gelanggang komutatif $R$ mempunyai resolusi
injektif.

#### Bukti {#br-bgk-2019-l23-lem-06-proof}

Menurut Korolari 23.8, terdapat modul injektif $I_0$ dengan $M\subseteq I_0$.
Dengan cara yang sama, bagi modul faktor $I_0/M$ terdapat modul injektif
$I_1$ dengan $I_0/M\subseteq I_1$, dan seterusnya.

<!-- upstream_entity: Modul/Injektive Auflösung/Komplex/Anfangshomomorphismus/Fakt -->

### Lema 23.11: memperluas homomorfisme awal ke kompleks {#br-bgk-2019-l23-lem-07}

Misalkan $L$ dan $M$ modul-modul $R$ di atas gelanggang komutatif $R$.
Misalkan

$$
0\longrightarrow L\longrightarrow L_0\longrightarrow L_1
\longrightarrow\cdots
$$

suatu kompleks eksak,

$$
0\longrightarrow M\longrightarrow I_0\longrightarrow I_1
\longrightarrow\cdots
$$

suatu resolusi injektif, dan

$$
\varphi:L\longrightarrow M
$$

suatu homomorfisme modul $R$. Maka terdapat homomorfisme modul $R$

$$
\varphi_n:L_n\longrightarrow I_n
$$

yang komutatif dengan homomorfisme-homomorfisme dalam kedua kompleks.

#### Bukti {#br-bgk-2019-l23-lem-07-proof}

Keberadaan homomorfisme yang komutatif dibuktikan dengan induksi pada $n$.
Karena $L\subseteq L_0$ dan $I_0$ injektif, homomorfisme
$L\to M\subseteq I_0$ mempunyai perluasan komutatif

$$
\varphi_0:L_0\longrightarrow I_0.
$$

Ini memberikan pangkal induksi. Sekarang andaikan homomorfisme hingga
$\varphi_n$ sudah ada. Kita tinjau diagram komutatif

$$
\begin{matrix}
L_{n-1}&\longrightarrow&L_n&\longrightarrow&L_{n+1}\\
\downarrow\scriptstyle{\varphi_{n-1}}&&
\downarrow\scriptstyle{\varphi_n}&&\downarrow\\
I_{n-1}&\longrightarrow&I_n&\longrightarrow&I_{n+1},
\end{matrix}
$$

dengan panah vertikal kanan masih harus dikonstruksi. Terdapat injeksi

$$
L_n/\operatorname{bild}L_{n-1}\longrightarrow L_{n+1}.
$$

Karena komutativitas, seluruh $L_{n-1}$ dipetakan ke nol di dalam
$I_{n+1}$. Karena itu terdapat homomorfisme

$$
L_n/\operatorname{bild}L_{n-1}\longrightarrow I_{n+1},
$$

dan homomorfisme ini mempunyai perluasan ke $L_{n+1}$.

Secara umum, dalam situasi di atas terdapat beberapa homomorfisme kompleks
rantai. Meskipun demikian, homomorfisme-homomorfisme itu homotop satu sama
lain.

<!-- upstream_entity: Modul/Exakter Komplex und injektive Auflösung/Homotopie/Fakt -->

### Lema 23.12: keunikan hingga homotopi {#br-bgk-2019-l23-lem-08}

Misalkan $M$ modul $R$ di atas gelanggang komutatif $R$. Misalkan

$$
0\longrightarrow M\longrightarrow L_0\longrightarrow L_1
\longrightarrow\cdots
$$

suatu kompleks eksak dan

$$
0\longrightarrow M\longrightarrow I_0\longrightarrow I_1
\longrightarrow\cdots
$$

suatu kompleks dengan semua modul $I_n$ injektif. Jika

$$
\varphi,\psi:L_\bullet\longrightarrow I_\bullet
$$

adalah homomorfisme kompleks rantai, maka $\varphi$ dan $\psi$ homotop.

#### Bukti {#br-bgk-2019-l23-lem-08-proof}

Kita definisikan secara induktif homotopi

$$
\Theta_n:L_{n+1}\longrightarrow I_n
$$

dan tetapkan

$$
\Theta_{-1}:L_0\longrightarrow M=I_{-1}
$$

sebagai pemetaan nol. Perhatikan bahwa $M$ pada umumnya tidak injektif.
Andaikan homotopi hingga dan termasuk $\Theta_{n-1}$ sudah dikonstruksi.
Kita mempunyai diagram

$$
\begin{matrix}
L_{n-1}&\xrightarrow{\ d_n\ }&L_n&
\xrightarrow{\ d_{n+1}\ }&L_{n+1}\\
\downarrow&&\downarrow&&\downarrow\\
I_{n-1}&\xrightarrow{\ e_n\ }&I_n&
\xrightarrow{\ e_{n+1}\ }&I_{n+1},
\end{matrix}
$$

bersama pemetaan diagonal $\Theta_{n-1}:L_n\to I_{n-1}$, dan berlaku

$$
\varphi_{n-1}-\psi_{n-1}
=e_{n-1}\circ\Theta_{n-2}+\Theta_{n-1}\circ d_n.
$$

Kita tinjau homomorfisme

$$
\varphi_n-\psi_n-e_n\circ\Theta_{n-1}
$$

dari $L_n$ ke $I_n$. Untuk $x\in L_{n-1}$ berlaku

$$
\begin{aligned}
&(\varphi_n-\psi_n-e_n\circ\Theta_{n-1})(d_n(x))\\
&\quad=(\varphi_n-\psi_n)(d_n(x))
 -(e_n\circ\Theta_{n-1})(d_n(x))\\
&\quad=(\varphi_n-\psi_n)(d_n(x))
 -e_n(\Theta_{n-1}(d_n(x)))\\
&\quad=(\varphi_n-\psi_n)(d_n(x))
 -e_n\bigl(-e_{n-1}(\Theta_{n-2}(x))
 +\varphi_{n-1}(x)-\psi_{n-1}(x)\bigr)\\
&\quad=\varphi_n(d_n(x))-\psi_n(d_n(x))
 -e_n(\varphi_{n-1}(x))+e_n(\psi_{n-1}(x))\\
&\quad=\varphi_n(d_n(x))-e_n(\varphi_{n-1}(x))
 -\psi_n(d_n(x))+e_n(\psi_{n-1}(x))\\
&\quad=0,
\end{aligned}
$$

sebab $\varphi$ dan $\psi$ komutatif dengan diferensial. Artinya,
$\varphi_n-\psi_n-e_n\circ\Theta_{n-1}$ memetakan citra $d_n$ ke nol.
Jadi kita memperoleh homomorfisme terinduksi

$$
L_n/\operatorname{bild}d_n\longrightarrow I_n.
$$

Karena kompleks $L_\bullet$ eksak, terdapat pemetaan injektif

$$
L_n/\operatorname{bild}d_n\longrightarrow L_{n+1}.
$$

Karena $I_n$ injektif, kita memperoleh suatu perluasan

$$
-\Theta_n:L_{n+1}\longrightarrow I_n.
$$

Dengan demikian,

$$
\varphi_n-\psi_n-e_n\circ\Theta_{n-1}
=-\Theta_n\circ d_{n+1}.
$$

## Berkas injektif dan berkas flasque {#br-bgk-2019-l23-s03}

Menurut definisi, suatu modul injektif dicirikan oleh keberadaan
homomorfisme dalam situasi-situasi tertentu. Karena itu terdapat konsep yang
bersesuaian, yaitu *objek injektif*, dalam setiap kategori tempat kita dapat
berbicara tentang homomorfisme injektif. Kerangka yang lazim di sini adalah
kategori aditif atau kategori abelian; lihat lampiran. Kategori berkas grup
komutatif pada suatu ruang topologis, dan kategori berkas modul pada suatu
ruang berdering, merupakan kategori abelian semacam itu. Hal ini pada
hakikatnya telah dibuktikan dalam Kuliah 5 dan 6. Sekarang kita menunjukkan
bahwa dalam situasi ini pun suatu berkas dapat disematkan ke dalam berkas
injektif.

<!-- upstream_entity: Beringter Raum/Modulgarbe/Einbettung/Injektive Garbe/Fakt -->

### Lema 23.13: penyematan berkas modul ke dalam berkas injektif {#br-bgk-2019-l23-lem-09}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal M$ modul
$\mathcal O_X$. Maka terdapat berkas modul injektif $\mathcal I$ pada $X$
dengan $\mathcal M\subseteq\mathcal I$.

#### Bukti {#br-bgk-2019-l23-lem-09-proof}

Untuk setiap berkas modul $\mathcal M$, pemetaan

$$
\mathcal M\longrightarrow\prod_{x\in X}i_*\mathcal M_x
$$

merupakan homomorfisme modul $\mathcal O_X$ yang injektif. Di sini, untuk
$x\in X$, $i_*\mathcal M_x$ adalah dorong maju modul
$\mathcal O_{X,x}$, $\mathcal M_x$, yang dipandang sebagai berkas pada
$\{x\}$, sepanjang penyematan

$$
i:\{x\}\longrightarrow X.
$$

Menurut Korolari 23.8, bagi $\mathcal M_x$ terdapat modul
$\mathcal O_{X,x}$ yang injektif, $I_x$, pada $x$. Kita tetapkan

$$
\mathcal I:=\prod_{x\in X}i_*I_x.
$$

Dengan demikian, kita memperoleh inklusi modul-modul $\mathcal O_X$

$$
\mathcal M\longrightarrow
\prod_{x\in X}i_*\mathcal M_x
\longrightarrow
\prod_{x\in X}i_*I_x.
$$

Kita harus menunjukkan bahwa $\mathcal I$ injektif. Untuk itu, misalkan
$\mathcal F\subseteq\mathcal G$ modul-modul $\mathcal O_X$ dan diberikan
homomorfisme modul $\mathcal O_X$

$$
\varphi:\mathcal F\longrightarrow\mathcal I.
$$

Menurut Soal 3.18 dan Lema Lampiran 4.3, data ini bersesuaian dengan suatu
unsur

$$
(\varphi_x)\in
\prod_{x\in X}
\operatorname{Hom}_{\mathcal O_X}(\mathcal F,i_*I_x)
=
\prod_{x\in X}
\operatorname{Hom}_{\mathcal O_{X,x}}(\mathcal F_x,I_x).
$$

Setiap $\varphi_x$ mempunyai perluasan
$\widetilde\varphi_x:\mathcal G_x\to I_x$, dan perluasan-perluasan ini
bergabung menjadi suatu perluasan

$$
\widetilde\varphi:\mathcal G\longrightarrow\mathcal I.
$$

Berkas injektif berhubungan erat dengan berkas flasque. Berkas flasque
sering lebih mudah ditangani dalam perhitungan.

<!-- upstream_entity: Topologischer Raum/Welke Garbe/Definition -->

### Definisi 23.14: berkas flasque {#br-bgk-2019-l23-def-04}

Suatu berkas $\mathcal G$ pada ruang topologis disebut *flasque* jika untuk
setiap pasangan subhimpunan terbuka $U\subseteq V$, pemetaan restriksi

$$
\mathcal G(V)\longrightarrow\mathcal G(U)
$$

bersifat surjektif.

Dalam hal suatu berkas flasque, untuk sembarang subhimpunan terbuka
$U\subseteq V$, pemetaan restriksi

$$
\mathcal G(V)\longrightarrow\mathcal G(U)
$$

juga surjektif.

<!-- upstream_entity: Topologischer Raum/Welke Garben/Grundlegende Eigenschaften/Fakt -->

### Lema 23.15: sifat dasar berkas flasque {#br-bgk-2019-l23-lem-10}

Misalkan $X$ ruang topologis dan

$$
0\longrightarrow\mathcal F\longrightarrow\mathcal G
\longrightarrow\mathcal H\longrightarrow 0
$$

barisan eksak pendek berkas grup abelian. Maka berlaku sifat-sifat berikut.

1. Jika $\mathcal F$ flasque, maka evaluasi global

   $$
   \Gamma(X,\mathcal G)\longrightarrow\Gamma(X,\mathcal H)
   $$

   bersifat surjektif.

2. Jika $\mathcal F$ dan $\mathcal G$ flasque, maka $\mathcal H$ juga
   flasque.

#### Bukti {#br-bgk-2019-l23-lem-10-proof}

Untuk (1), misalkan $t\in\Gamma(X,\mathcal H)$ diberikan. Kita menggunakan
Lema Zorn dan mempertimbangkan himpunan

$$
\mathcal M=
\{(U,s)\mid U\subseteq X\text{ terbuka},\
s\in\Gamma(U,\mathcal G),\
s\longmapsto t|_U\}.
$$

Kita memberikan relasi urutan pada $\mathcal M$ dengan menetapkan

$$
(U,s)\preccurlyeq(U',s')
$$

jika $U\subseteq U'$ dan $s'$ merupakan perluasan $s$. Berdasarkan sifat
berkas, himpunan ini terurut induktif. Menurut Lema Zorn, terdapat unsur
maksimal $(U,s)$ dalam $\mathcal M$. Kita harus menunjukkan bahwa $U=X$.

Andaikan $U\ne X$ dan ambil $x\notin U$. Karena morfisme berkas
$\mathcal G\to\mathcal H$ surjektif, terdapat lingkungan terbuka $x\in V$
dan seksi $r\in\Gamma(V,\mathcal G)$ yang dipetakan ke $t|_V$. Karena itu

$$
s|_{U\cap V}-r|_{U\cap V}
$$

dipetakan ke nol dan merupakan unsur $\Gamma(U\cap V,\mathcal F)$. Karena
$\mathcal F$ flasque, terdapat seksi

$$
z\in\Gamma(X,\mathcal F)
$$

yang restriksinya ke $U\cap V$ sama dengan
$s|_{U\cap V}-r|_{U\cap V}$. Kita ganti $r$ dengan

$$
r'=r+z|_V.
$$

Unsur ini tetap dipetakan ke $t|_V$, dan

$$
s|_{U\cap V}-r'|_{U\cap V}=z|_V-z|_V=0.
$$

Jadi $s$ dan $r'$, sebagai seksi $\mathcal G$ masing-masing di atas $U$ dan
$V$, kompatibel dan menentukan suatu seksi

$$
s'\in\Gamma(U\cup V,\mathcal G)
$$

yang dipetakan ke $t$. Hal ini bertentangan dengan kemaksimalan $U$.

> **Catatan edisi - berkas tempat seksi hasil pengeleman.** Sumber beku
> mencetak $s'\in\Gamma(U\cup V,\mathcal F)$. Namun, $s$ dan $r'$ baru saja
> dinyatakan sebagai seksi $\mathcal G$, dan seksi hasil pengeleman harus
> dipetakan ke $t\in\Gamma(X,\mathcal H)$. Karena itu argumen memerlukan
> $s'\in\Gamma(U\cup V,\mathcal G)$, yang dipakai dalam baris di atas.
> Edisi mencatat pergantian simbol ini secara eksplisit dan tidak mengubah
> bagian lain dari bukti.

Pernyataan (2) mengikuti dari (1).

<!-- upstream_entity: Beringter Raum/Modul/Injektiv/Welk/Fakt -->

### Lema 23.16: berkas injektif bersifat flasque {#br-bgk-2019-l23-lem-11}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal I$ modul
$\mathcal O_X$ yang injektif. Maka $\mathcal I$ flasque.

#### Bukti {#br-bgk-2019-l23-lem-11-proof}

Misalkan $U\subseteq X$ subhimpunan terbuka. Kita tinjau praberkas

$$
\mathcal P(V):=
\begin{cases}
\mathcal O_X(V),&\text{jika }V\subseteq U,\\
0,&\text{selain itu},
\end{cases}
$$

dan kita sebut berkasisasinya $\mathcal O_U$. Homomorfisme praberkas alami
$\mathcal P\to\mathcal O_X$ menurut Lema 5.2 (4) menghasilkan homomorfisme
berkas

$$
\mathcal O_U\longrightarrow\mathcal O_X.
$$

Homomorfisme ini injektif. Selain itu,

$$
\operatorname{Hom}(\mathcal O_U,\mathcal I)
=\Gamma(U,\mathcal I).
$$

Karena $\mathcal I$ injektif, setiap unsur di dalamnya dapat diperluas menjadi
unsur

$$
\operatorname{Hom}(\mathcal O_X,\mathcal I)
=\Gamma(X,\mathcal I).
$$

Artinya, pemetaan restriksi

$$
\Gamma(X,\mathcal I)\longrightarrow\Gamma(U,\mathcal I)
$$

bersifat surjektif.
