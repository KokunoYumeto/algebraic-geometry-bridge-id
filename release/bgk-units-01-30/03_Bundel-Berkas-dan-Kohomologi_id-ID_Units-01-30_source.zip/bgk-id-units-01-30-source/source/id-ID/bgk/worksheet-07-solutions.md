---
title: "Cakupan Solusi Publik Lembar Kerja 7"
stable_id: br-bgk-2019-w07-solutions
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
upstream_map: authority/wikiversity-bgk/unit-07/ORDERED_EXERCISE_MAP.json
upstream_map_sha256: 309a1478ffcc6b7fdd02ddb72f29dca37d9d9ca8756737e7723d9bae148365c0
authority_manifest: authority/wikiversity-bgk/unit-07/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 001074c62cedb1efc988d3214416d2d86a02976d5b22dc272f4fe064e72dfc95
candidate_evidence: authority/wikiversity-bgk/unit-07/worksheet-solution-candidates-api.json
candidate_evidence_sha256: c4c95e9dc35a731c42e5f2fd007fcd6d84c22c8836c6c179bbb257c7698a0ad4
exercise_count: 21
public_solution_count: 1
negative_public_solution_count: 20
negative_solution_numbers: "1-13,15-21"
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: source_scope_complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Cakupan Solusi Publik Lembar Kerja 7 {#br-bgk-2019-w07-solutions}

Pada batas revisi yang dibekukan, sumber menyediakan tepat satu solusi publik,
yaitu untuk Soal 7.14. Dua puluh kandidat solusi lainnya (Soal 7.1–7.13 dan
7.15–7.21) berstatus *missing* pada bukti kueri; tidak ada solusi baru yang
dibuat untuk edisi ini.

<!-- upstream_entity: Lokaler Ring/Restklassenring/Einheiten surjektiv/Aufgabe/Lösung -->

## Solusi Soal 7.14 {#br-bgk-2019-w07-sol-ex14}

Jika $\mathfrak a=R$, gelanggang faktor adalah gelanggang nol sehingga
pernyataannya jelas. Jadi anggap $\mathfrak a\subseteq\mathfrak m$, dengan
$\mathfrak m$ ideal maksimal tunggal dari gelanggang lokal $R$.

Ambil $r\in R$ sebagai representasi sebuah satuan dari
$(R/\mathfrak a)^\times$, dan ambil $s\in R$ sedemikian sehingga

$$
rs=1\quad\text{di }R/\mathfrak a.
$$

Ini berarti

$$
rs-1\in\mathfrak a\subseteq\mathfrak m
$$

di $R$. Jika $r$ bukan satuan, maka $rs\in\mathfrak m$; akibatnya

$$
1=(1-rs)+rs\in\mathfrak m,
$$

sebuah kontradiksi. Jadi $r$ sendiri merupakan satuan di $R$, dan setiap
satuan di $R/\mathfrak a$ mempunyai prabayang satuan. Dengan demikian

$$
R^\times\longrightarrow(R/\mathfrak a)^\times
$$

surjektif.

Tidak ada solusi publik untuk dua puluh soal lainnya yang boleh diisi atau
dianggap tersirat; peta soal dan bukti kandidat tetap menjadi rekaman cakupan
sumber.
