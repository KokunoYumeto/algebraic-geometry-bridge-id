---
title: "Lembar Kerja 10 - Skema dan Morfisme Skema"
stable_id: br-bgk-2019-w10
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Marymay0609"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 10"
upstream_pageid: 110217
upstream_revid: 612138
upstream_timestamp: "2020-01-24T13:09:39Z"
upstream_mediawiki_sha1: a4beef842f165681bee727e1e9c959365f09a28c
source_url: "https://de.wikiversity.org/w/index.php?oldid=612138"
authority_manifest: authority/wikiversity-bgk/unit-10/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: a8b6384c316086dde5825b6c776289f93a1a2c4a4654bac57148f9e25a6f197f
worksheet_xml: authority/wikiversity-bgk/unit-10/worksheet-10.xml
worksheet_xml_sha256: 34ced87004246a2772f7bb96993552cc7a876cc52167754d8278ded509598d84
worksheet_expanded_tex: authority/wikiversity-bgk/unit-10/worksheet-10-expanded.tex
worksheet_expanded_tex_sha256: 36959f4a8b6fa759c3d14b459fb21f4adcd613f4d66b663bb4fb6f54663cf703
official_pdf: authority/artifacts/bgk-worksheet-10-official.pdf
official_pdf_sha256: b8af98d8fac212b200909dff694cce7a7ea104b6dc083b3a01e1d60eb9686760
ordered_exercise_map: authority/wikiversity-bgk/unit-10/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 5af4a6aa6a975ec44339526cb40988e5c799f71f7c02eaada77f2fe22dd38ea2
exercise_count: 6
public_solution_count: 0
media_credits: source/id-ID/media-credits-bgk-unit-10.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 10: Skema dan Morfisme Skema {#br-bgk-2019-w10}

Tidak satu pun dari enam soal pada batas revisi yang dibekukan mempunyai
solusi publik. Tanda bintang solusi karena itu tidak digunakan dan edisi ini
tidak menciptakan solusi baru.

<!-- upstream_entity: Quasiaffines Schema/Nicht affin/Aufgabe -->

## Soal 10.1 {#br-bgk-2019-w10-ex01}

Berikan sebuah contoh skema kuasiafin yang bukan skema afin.

<!-- upstream_entity: Quasiaffines Schema/Nicht quasikompakt/Aufgabe -->

## Soal 10.2 {#br-bgk-2019-w10-ex02}

Berikan sebuah contoh skema kuasiafin yang tidak kuasikompak.

<!-- upstream_entity: Lokal beringter Raum/Affiner Raum/Morphismus/Fakt/Beweis/Aufgabe -->

## Soal 10.3 {#br-bgk-2019-w10-ex03}

Misalkan $(X,\mathcal O_X)$ ruang berdering lokal. Buktikan bahwa setiap
tupel fungsi

$$
f_1,\ldots,f_n\in\Gamma(X,\mathcal O_X)
$$

menentukan tepat satu morfisme ruang berdering lokal

$$
X\longrightarrow\mathbb A^n_{\mathbb Z},
$$

yang memetakan variabel $T_i$ dari ruang afin ke $f_i$.

<!-- upstream_entity: Schema/Globaler Schnittring/Morphismus/Affin/Aufgabe -->

## Soal 10.4 {#br-bgk-2019-w10-ex04}

Misalkan $(X,\mathcal O_X)$ sebuah skema. Buktikan bahwa $X$ merupakan skema
afin jika dan hanya jika morfisme kanonik

$$
X\longrightarrow\operatorname{Spek}(\Gamma(X,\mathcal O_X))
$$

adalah isomorfisme.

<!-- upstream_entity: Mannigfaltigkeit/Globaler Schnittring/Morphismus ins Spektrum/Injektiv/Aufgabe -->

## Soal 10.5 {#br-bgk-2019-w10-ex05}

Misalkan $X$ sebuah manifold terdiferensial. Buktikan bahwa morfisme kanonik

$$
X\longrightarrow\operatorname{Spek}(C^1(X,\mathbb R))
$$

injektif.

<!-- upstream_entity: Algebrahomomorphismus/Basisschema/Morphismus/Aufgabe -->

## Soal 10.6 {#br-bgk-2019-w10-ex06}

Misalkan $R$ gelanggang komutatif dan $A,B$ aljabar-$R$ komutatif. Buktikan
bahwa homomorfisme aljabar-$R$

$$
\varphi:A\longrightarrow B
$$

adalah data yang sama dengan morfisme skema

$$
\psi:\operatorname{Spek}(B)\longrightarrow\operatorname{Spek}(A)
$$

di atas $\operatorname{Spek}(R)$.
