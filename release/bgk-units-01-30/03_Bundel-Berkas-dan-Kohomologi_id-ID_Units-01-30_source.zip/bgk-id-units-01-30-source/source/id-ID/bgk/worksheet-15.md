---
title: "Lembar Kerja 15 - Modul pada Skema Projektif"
stable_id: br-bgk-2019-w15
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 15"
upstream_pageid: 110222
upstream_revid: 659926
upstream_timestamp: "2020-10-09T15:16:19Z"
upstream_mediawiki_sha1: fb6863c9257785576180b4d63b1f6c591e87e73a
source_url: "https://de.wikiversity.org/w/index.php?oldid=659926"
authority_manifest: authority/wikiversity-bgk/unit-15/UNIT_AUTHORITY_MANIFEST.json
worksheet_xml: authority/wikiversity-bgk/unit-15/worksheet-15.xml
worksheet_xml_sha256: 4416c81a883bcc2d50d81d911c274417fe590471913414f3ae264b083c85e4f2
worksheet_expanded_tex: authority/wikiversity-bgk/unit-15/worksheet-15-expanded.tex
worksheet_expanded_tex_sha256: f821b74f12c1ef22b1a674563a7d2a74cd343a2ba3cd0d2912422f996b1aceb9
official_pdf: authority/artifacts/bgk-worksheet-15-official.pdf
ordered_exercise_map: authority/wikiversity-bgk/unit-15/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 4d6706d87ab1cadabbf4031ddf900be44eeaaca0636c34ebce24393e80d18e2a
exercise_count: 20
public_solution_count: 0
public_solution_numbers: ""
media_credits: source/id-ID/media-credits-bgk-unit-15.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 15: Modul pada Skema Projektif {#br-bgk-2019-w15}

Peta kandidat yang dibekukan mencatat tepat 20 soal dan tidak menemukan
halaman solusi publik untuk satu pun di antaranya. Karena itu tidak ada tanda
bintang pada lembar kerja ini, dan edisi tidak menciptakan solusi baru.

<!-- upstream_entity: Graduierter Ring/Modul/Vergarbung/Graduierung/Explizit/Aufgabe -->

## Soal 15.1 {#br-bgk-2019-w15-ex01}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$, $M$ modul bergradasi atas
$R$, dan $\widetilde M$ berkas modul terkait pada spektrum
$X=\operatorname{Spek}(R)$. Misalkan $\mathfrak a\subseteq R$ ideal homogen.
Buktikan bahwa

$$
\begin{aligned}
\Gamma(D(\mathfrak a),\widetilde M)_\ell
=\biggl\{s\in\Gamma(D(\mathfrak a),\widetilde M)\ \bigg|\ &
\text{terdapat liputan terbuka }
U=\bigcup_{i\in I}D(f_i)\text{ dengan }f_i\text{ homogen,}\\
&\text{sedemikian sehingga }s\in M_{f_i}
\text{ berderajat }\ell\biggr\}
\end{aligned}
$$

memberi suatu gradasi pada $\Gamma(D(\mathfrak a),\widetilde M)$ yang
membuat homomorfisme-homomorfisme pembatasan alami bersifat homogen.

<!-- upstream_entity: Polynomring/Nenneraufnahme/Nicht homogen/Aufgabe -->

## Soal 15.2 {#br-bgk-2019-w15-ex02}

Dengan menggunakan $R=K[X]$ dan $f=X+1$, jelaskan mengapa tidak terdapat
gradasi pada pelokalan

$$
K[X]_{X+1}
$$

yang memperluas gradasi standar pada gelanggang polinomial secara bermakna.

<!-- upstream_entity: Graduierter Ring/Modul/Prägarbe/Quasikohärenz/Aufgabe -->

## Soal 15.3 {#br-bgk-2019-w15-ex03}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$ dan $M$ modul bergradasi atas
$R$. Buktikan bahwa penetapan

$$
U=D_+(\mathfrak a)
\longmapsto
\operatorname*{colim}_{U\subseteq D_+(f)}(M_f)_0
$$

merupakan praberkas grup komutatif pada $\operatorname{Proj}(R)$ yang
pembentukan berkasnya sama dengan $\widehat M$.

<!-- upstream_entity: Graduierter Ring/Modul/Prägarbe/Explizit/Aufgabe -->

## Soal 15.4 {#br-bgk-2019-w15-ex04}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$ dan $M$ modul bergradasi atas
$R$. Buktikan bahwa berkas modul $\mathcal O_Y$ terkait $\widehat M$ pada
$Y=\operatorname{Proj}(R)$ diberikan oleh

$$
\begin{aligned}
\Gamma(U,\widehat M)=\biggl\{&(s_{\mathfrak p})_{\mathfrak p\in U}
\in\prod_{\mathfrak p\in U}M_{(\mathfrak p)}\ \bigg|\\
&\text{untuk setiap }\mathfrak p\in U\text{ terdapat unsur homogen }
b\in R\text{ dan }t\in M\text{ dengan }\\
&\mathfrak p\in D_+(b)\subseteq U
\text{ dan }s_{\mathfrak q}=\frac tb\text{ dalam }M_{(\mathfrak q)}
\text{ untuk setiap }\mathfrak q\in D_+(b)\biggr\}.
\end{aligned}
$$

<!-- upstream_entity: Graduierter Integritätsbereich/Proj/Funktionenkörper/Aufgabe -->

## Soal 15.5 {#br-bgk-2019-w15-ex05}

Misalkan $R$ gelanggang integral bergradasi $\mathbb Z$ dan

$$
M=R_H
$$

pelokalan pada semua unsur homogen yang berderajat $\neq0$. Buktikan bahwa
$\widehat M$ merupakan medan fungsi skema integral
$\operatorname{Proj}(R)$.

<!-- upstream_entity: Graduierter Ring/Gerade/Projektiver Punkt/Garbe/Aufgabe -->

## Soal 15.6 {#br-bgk-2019-w15-ex06}

Misalkan

$$
R=K[X_0,X_1,\ldots,X_d]/\mathfrak a
$$

gelanggang bergradasi standar dan

$$
(a_0,a_1,\ldots,a_d)\in V(\mathfrak a)=\mathbb A_K^{d+1}
$$

suatu titik-$K$ tak nol ($\neq0$) dari $R$, dengan ideal prima homogen terkait

$$
\mathfrak p=(a_iX_j-a_jX_i,\,),
$$

yang merupakan titik tertutup dalam

$$
\operatorname{Proj}(R)=V_+(\mathfrak a)\subseteq\mathbb P_K^d.
$$

Buktikan bahwa $\widehat{R/\mathfrak p}$ merupakan modul kuasikoheren pada
$\operatorname{Proj}(R)$ (dan pada $\mathbb P_K^d$) yang dukungannya sama
dengan $\{\mathfrak p\}$.

<!-- upstream_entity: Graduierter Ring/Moduln/Realisierung auf Proj/Aufgabe -->

## Soal 15.7 {#br-bgk-2019-w15-ex07}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$ dan
$Y=\operatorname{Proj}(R)$. Buktikan bahwa modul-modul $R$ bergradasi $M$
dan $N$ yang tidak isomorfik dapat menghasilkan modul-modul $\mathcal O_Y$
$\widehat M$ dan $\widehat N$ yang isomorfik.

<!-- upstream_entity: Polynomring/Projektiver Raum/Restklassenring/Proj/Vorschub/Aufgabe -->

## Soal 15.8 {#br-bgk-2019-w15-ex08}

Misalkan

$$
R=K[X_0,X_1,\ldots,X_d]/\mathfrak a
$$

dengan $\mathfrak a$ ideal homogen, dan misalkan

$$
Y=\operatorname{Proj}(R)\subseteq\mathbb P_K^d.
$$

Buktikan bahwa

$$
i_*\mathcal O_Y=\widehat R
$$

pada $\mathbb P_K^d$.

<!-- upstream_entity: Graduierter Ring/Z/Moduln/Exakte Sequenz/Neutraler Grad/Aufgabe -->

## Soal 15.9 {#br-bgk-2019-w15-ex09}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$ dan

$$
0\longrightarrow L\longrightarrow M\longrightarrow N\longrightarrow0
$$

barisan eksak pendek modul-modul $R$ bergradasi $\mathbb Z$ dengan
homomorfisme-homomorfisme homogen. Buktikan bahwa pada setiap tingkat
terdapat barisan eksak pendek modul-modul $R_0$

$$
0\longrightarrow L_k\longrightarrow M_k\longrightarrow N_k
\longrightarrow0.
$$

<!-- upstream_entity: Graduierter Ring/Moduln/Exakte Sequenz/Punktiert/Quasikohärente Moduln/Aufgabe -->

## Soal 15.10 {#br-bgk-2019-w15-ex10}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$, dan misalkan $L,M,N$ modul
$R$ bergradasi $\mathbb Z$ dengan homomorfisme-homomorfisme homogen

$$
\varphi:L\longrightarrow M,
\qquad
\psi:M\longrightarrow N.
$$

Untuk setiap ideal prima $\mathfrak p$ dengan
$R_+\nsubseteq\mathfrak p$, andaikan barisan

$$
0\longrightarrow L_{\mathfrak p}
\xrightarrow{\varphi}M_{\mathfrak p}
\xrightarrow{\psi}N_{\mathfrak p}
\longrightarrow0
$$

eksak. Buktikan bahwa terdapat barisan eksak pendek

$$
0\longrightarrow\widehat L\longrightarrow\widehat M
\longrightarrow\widehat N\longrightarrow0
$$

pada $Y=\operatorname{Proj}(R)$.

<!-- upstream_entity: Z-graduierter Ring/Verschiebung/Modul/Aufgabe -->

## Soal 15.11 {#br-bgk-2019-w15-ex11}

Misalkan $R$ gelanggang bergradasi $\mathbb Z$. Buktikan bahwa modul $R$
yang digeser, $R(n)$, merupakan gelanggang bergradasi hanya untuk $n=0$.

<!-- upstream_entity: Getwistete Strukturgarbe/Projektive Ebene/Grad 3/Basis/Aufgabe -->

## Soal 15.12 {#br-bgk-2019-w15-ex12}

Berikan basis eksplisit untuk

$$
\Gamma\left(\mathbb P_K^2,
\mathcal O_{\mathbb P_K^2}(3)\right)
$$

di atas suatu lapangan $K$, dan tentukan dimensinya.

<!-- upstream_entity: Projektives Spektrum/Getwistete Strukturgarben/Tensorierung/Aufgabe -->

## Soal 15.13 {#br-bgk-2019-w15-ex13}

Misalkan $Y=\operatorname{Proj}(R)$ spektrum projektif gelanggang
bergradasi standar $R$. Buktikan bahwa untuk berkas struktur terpuntir
$\mathcal O_Y(\ell)$ berlaku

$$
\mathcal O_Y(\ell)\otimes_{\mathcal O_Y}\mathcal O_Y(m)
\cong\mathcal O_Y(\ell+m).
$$

<!-- upstream_entity: Projektives Spektrum/Getwistete Strukturgarben/Homomorphismengarbe/Aufgabe -->

## Soal 15.14 {#br-bgk-2019-w15-ex14}

Misalkan $Y=\operatorname{Proj}(R)$ spektrum projektif gelanggang
bergradasi standar $R$. Buktikan bahwa untuk berkas-berkas struktur terpuntir
berlaku

$$
\mathcal{H}om(\mathcal O_Y(\ell),\mathcal O_Y(m))
\cong\mathcal O_Y(m-\ell).
$$

<!-- upstream_entity: Projektives Spektrum/Getwistete Strukturgarbe/Idealgarbe/Aufgabe -->

## Soal 15.15 {#br-bgk-2019-w15-ex15}

Misalkan $Y=\operatorname{Proj}(R)$ spektrum projektif gelanggang
bergradasi standar $R$. Buktikan bahwa berkas struktur terpuntir
$\mathcal O_Y(\ell)$ untuk $\ell\leq0$ dapat direalisasikan sebagai berkas
ideal pada $Y$. Buktikan juga bahwa, secara umum, terdapat lebih dari satu
cara untuk melakukannya.

<!-- upstream_entity: Kommutativer Ring/Graduiert/Z/Graduierter Modul/Homogene Surjektion/Fakt/Beweis/Aufgabe -->

## Soal 15.16 {#br-bgk-2019-w15-ex16}

Misalkan

$$
R=\bigoplus_{d\in\mathbb Z}R_d
$$

gelanggang komutatif bergradasi $\mathbb Z$, dan

$$
M=\bigoplus_{d\in\mathbb Z}M_d
$$

modul bergradasi $\mathbb Z$ atas $R$ yang dibangkitkan secara hingga. Buktikan bahwa
$M$ juga dibangkitkan oleh sejumlah hingga unsur homogen dan bahwa terdapat
homomorfisme modul homogen surjektif berbentuk

$$
\bigoplus_{i=1}^k R(-d_i)\longrightarrow M.
$$

<!-- upstream_entity: Schema/Modulgarbe/Von globalen Schnitten erzeugt/Fakt/Beweis/Aufgabe -->

## Soal 15.17 {#br-bgk-2019-w15-ex17}

Misalkan $(X,\mathcal O_X)$ suatu skema. Buktikan pernyataan-pernyataan
berikut.

1. Berkas struktur $\mathcal O_X$ dibangkitkan oleh seksi global.

2. Modul kuasikoheren $\mathcal M$ dibangkitkan oleh seksi global jika dan
   hanya jika terdapat homomorfisme modul surjektif

   $$
   \mathcal O_X^{(I)}\longrightarrow\mathcal M.
   $$

3. Pada skema afin, setiap modul kuasikoheren dibangkitkan oleh seksi global.

4. Jika $\mathcal M$ dibangkitkan oleh seksi global dan
   $\mathcal M\to\mathcal N$ surjektif, maka $\mathcal N$ juga dibangkitkan
   oleh seksi global.

<!-- upstream_entity: Projektiver Raum/Getwistete Strukturgarbe/Von globalen Schnitten erzeugt/Fakt/Beweis/Aufgabe -->

## Soal 15.18 {#br-bgk-2019-w15-ex18}

Buktikan bahwa pada ruang projektif $\mathbb P_R^d$ di atas gelanggang
komutatif $R$, berkas struktur terpuntir
$\mathcal O_{\mathbb P_R^d}(k)$ dibangkitkan oleh seksi global untuk
$k\geq0$, dan tidak dibangkitkan oleh seksi global untuk $k<0$ dan
$d\geq1$.

<!-- upstream_entity: Schema/Modulgarbe/Von globalen Schnitten erzeugt/Affin/Aufgabe -->

## Soal 15.19 {#br-bgk-2019-w15-ex19}

Misalkan $(X,\mathcal O_X)$ suatu skema dan $\mathcal M$ modul kuasikoheren
pada $X$. Buktikan bahwa $\mathcal M$ dibangkitkan oleh seksi global jika dan
hanya jika terdapat liputan terbuka afin

$$
X=\bigcup_{i\in I}U_i
$$

dan seksi-seksi $s_j\in\Gamma(X,\mathcal M)$ untuk $j\in J$ sedemikian
sehingga pembatasan

$$
\rho_{U_i}(s_j)\in\Gamma(U_i,\mathcal M)
$$

membentuk sistem pembangkit $\Gamma(U_i,\mathcal O_X)$ bagi
$\Gamma(U_i,\mathcal M)$.

<!-- upstream_entity: Projektives Spektrum/Getwistete Strukturgarben/Global erzeugt/Aufgabe -->

## Soal 15.20 {#br-bgk-2019-w15-ex20}

Misalkan $Y=\operatorname{Proj}(R)$ spektrum projektif gelanggang
bergradasi standar $R$. Buktikan bahwa berkas struktur terpuntir
$\mathcal O_Y(\ell)$ untuk $\ell\geq0$ dibangkitkan oleh seksi global.
