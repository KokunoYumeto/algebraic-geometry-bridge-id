---
title: "Lembar Kerja 25 - Kohomologi Berkas"
stable_id: br-bgk-2019-w25
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 25"
upstream_pageid: 110234
upstream_revid: 613127
upstream_timestamp: "2020-01-27T15:28:07Z"
upstream_mediawiki_sha1: 45f8aa55eae6ae2447eb9783f5329b25eeb50519
source_url: "https://de.wikiversity.org/w/index.php?oldid=613127"
authority_manifest: authority/wikiversity-bgk/unit-25/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: f454cb2f8ada795015dcf78d4ad56a54107d9773705b7113a1ef1600b341e26d
authority_manifest_status: "Bekuan authority terminal lengkap; 33 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
worksheet_xml: authority/wikiversity-bgk/unit-25/worksheet-25.xml
worksheet_xml_sha256: 37a26281d72997f22d841319e204ec793d6eac8cf4b387392f4d344c9e8aaa9f
worksheet_expanded_tex: authority/wikiversity-bgk/unit-25/worksheet-25-expanded.tex
worksheet_expanded_tex_sha256: 2ccc656c99f53228b9a5cc564a2f2ac5098e37a3c0c729654142e577c84817f7
official_pdf: authority/artifacts/bgk-worksheet-25-official.pdf
official_pdf_sha256: 8909d39c3a3d0fe800a41f63aedcade07de8f558e2b9c6f053cf51cd724e0c40
official_pdf_source_bytes: 56663
official_pdf_source_sha1: e902ef47db2e116d1fde03cca818c4e8132decf8
official_pdf_metadata: authority/wikiversity-bgk/unit-25/official-pdfs-api.json
official_pdf_metadata_sha256: f49c28f3f600974f8cd7bcf29377dbad5429e789769d0953fc28075adce5c767
authority_precedence: "Revisi semantik Wikiversity yang dibekukan mengendalikan teks; PDF resmi dipertahankan sebagai saksi historis tanpa menimpa revisi yang lebih baru."
ordered_exercise_map: authority/wikiversity-bgk/unit-25/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 03b696f0c666352947f89c01a2c1ca0c1c5fb38bae0af77693cf21021b6b381b
candidate_evidence: authority/wikiversity-bgk/unit-25/worksheet-solution-candidates-api.json
candidate_evidence_sha256: 37ce99c2c415ef9bc13592e6e9d0537322c4fcf0b83b3112f8b6d1796828c939
exercise_count: 13
public_solution_count: 1
public_solution_numbers: "1"
media_credits: source/id-ID/media-credits-bgk-unit-25.md
media_credits_sha256: c0367344876a648ab7141eb306e6a9a02f14c47b3b57a03012073940f4297037
rights_ledger: authority/RIGHTS-bgk-unit-25.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-25.json
asset_closure_sha256: b897e839fc6999e5c149e1bf065a634b96246b563860d46f0a16ddb82ae1c9d5
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF adalah saksi authority, bukan teks edisi; metadata Commons CC BY-SA 4.0 dan pemberitahuan tertanam CC-by-sa 3.0 dipertahankan tanpa pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 25: Kohomologi Berkas {#br-bgk-2019-w25}

Tanda bintang menunjukkan tepat satu soal dengan solusi publik yang dibekukan,
yaitu Soal 25.1. Dua belas soal lainnya mempunyai hasil kandidat negatif;
edisi tidak menciptakan solusi baru.

<!-- upstream_entity: Intervall/Intervallüberdeckung/2/Stetige Funktion/Differenz/Aufgabe -->

## Soal 25.1 ★ {#br-bgk-2019-w25-ex01}

Misalkan $I\subseteq\mathbb R$ suatu interval real dan
$I=U\cup V$ suatu penutup oleh interval-interval yang terbuka di dalam $I$.
Buktikan bahwa suatu fungsi kontinu

$$
f:U\cap V\longrightarrow\mathbb R
$$

dapat ditulis sebagai

$$
f=g\big|_{U\cap V}-h\big|_{U\cap V}
$$

dengan fungsi-fungsi kontinu $g:U\to\mathbb R$ dan
$g:V\to\mathbb R$.

> **Catatan edisi - nama fungsi pada sumber.** Baris terakhir sumber cetak
> menamai kedua fungsi itu $g$, sedangkan rumus memakai $g$ dan $h$. Edisi
> mempertahankan pernyataan yang tercetak dan tidak mengganti nama fungsi
> kedua secara diam-diam.

<!-- upstream_entity: Intervall/Intervallüberdeckung/2/Funktionen modulo stetige Funktionen/Global surjektiv/Aufgabe -->

## Soal 25.2 {#br-bgk-2019-w25-ex02}

Misalkan $I\subseteq\mathbb R$ suatu interval real. Pada $I$ kita meninjau
barisan berkas eksak pendek

$$
0\longrightarrow C^0(-,\mathbb R)
\longrightarrow\operatorname{Abb}(-,\mathbb R)
\longrightarrow\operatorname{Abb}(-,\mathbb R)/C^0(-,\mathbb R)
\longrightarrow 0.
$$

Misalkan $I=U\cup V$ suatu penutup oleh interval-interval yang terbuka di
dalam $I$. Misalkan pula diberikan suatu seksi global pada berkas hasil bagi
$\operatorname{Abb}(-,\mathbb R)/C^0(-,\mathbb R)$ yang direpresentasikan oleh
seksi $s\in\operatorname{Abb}(U,\mathbb R)$ dan
$t\in\operatorname{Abb}(V,\mathbb R)$. Buktikan bahwa seksi ini
direpresentasikan oleh suatu pemetaan
$r\in\operatorname{Abb}(I,\mathbb R)$.

<!-- upstream_entity: Abgeschlossenes Intervall/Funktionen modulo stetige Funktionen/Global surjektiv/Aufgabe -->

## Soal 25.3 {#br-bgk-2019-w25-ex03}

Misalkan $I\subseteq\mathbb R$ suatu interval real tertutup. Pada $I$ kita
meninjau barisan berkas eksak pendek

$$
0\longrightarrow C^0(-,\mathbb R)
\longrightarrow\operatorname{Abb}(-,\mathbb R)
\longrightarrow\operatorname{Abb}(-,\mathbb R)/C^0(-,\mathbb R)
\longrightarrow 0.
$$

Buktikan bahwa

$$
\operatorname{Abb}(-,\mathbb R)
\longrightarrow\operatorname{Abb}(-,\mathbb R)/C^0(-,\mathbb R)
$$

surjektif.

<!-- upstream_entity: Abgeschlossenes Intervall/Stetige Funktionen/Garbe/1. Kohomologie/Aufgabe -->

## Soal 25.4 {#br-bgk-2019-w25-ex04}

Misalkan $I\subseteq\mathbb R$ suatu interval real tertutup. Buktikan bahwa

$$
H^1(I,C^0(-,\mathbb R))=0.
$$

<!-- upstream_entity: Kreis/Diskrete Gruppe/Lokal konstante Garbe/Überdeckung/Erste Garbenkohomologie/Aufgabe -->

## Soal 25.5 {#br-bgk-2019-w25-ex05}

Misalkan $G$ grup topologis diskret dengan setidaknya dua unsur
$a\ne b$. Pada $S^1$ kita meninjau barisan berkas eksak

$$
0\longrightarrow G\longrightarrow\operatorname{Abb}(-,G)
\longrightarrow\operatorname{Abb}(-,G)/G\longrightarrow 0,
$$

dengan $G$ di sini menyatakan berkas fungsi konstan lokal bernilai $G$, yaitu
$C^0(-,G)$. Misalkan $S^1=U\cup V$ suatu penutup terbuka lingkaran satuan oleh
dua segmen lingkaran yang saling bertumpang tindih sedemikian sehingga irisan
$U\cap V$ terdiri atas dua segmen lingkaran saling lepas, $A$ dan $B$.

Misalkan

$$
h\in\Gamma\bigl(S^1,\operatorname{Abb}(-,G)/G\bigr)
$$

suatu seksi yang pada $V$ direpresentasikan oleh pemetaan nol
$0\in\operatorname{Abb}(V,G)$ dan pada $U$ direpresentasikan oleh suatu
pemetaan $g\in\operatorname{Abb}(U,G)$ yang bernilai konstan $a$ pada $A$ dan
bernilai konstan $b$ pada $B$. Buktikan bahwa seksi ini tidak dapat
direpresentasikan oleh suatu unsur $\operatorname{Abb}(S^1,G)$, dan akibatnya

$$
H^1(S^1,G)\ne 0.
$$

<!-- upstream_entity: Topologischer Raum/Komplexe Exponentialsequenz/Stetig/Beispiel/Erste Garbenkohomologie/Aufgabe -->

## Soal 25.6 {#br-bgk-2019-w25-ex06}

Dengan menggunakan Contoh 6.6, buktikan bahwa

$$
H^1(\mathbb C^\times,\mathbb Z)\ne 0.
$$

Di sini $\mathbb Z$ menyatakan berkas fungsi kontinu bernilai dalam grup
topologis diskret $\mathbb Z$.

<!-- upstream_entity: Topologischer Raum/Lokal/Keine Garbenkohomologie/Aufgabe -->

## Soal 25.7 {#br-bgk-2019-w25-ex07}

Misalkan $X$ ruang topologis dengan sifat bahwa terdapat suatu titik
$x\in X$ yang satu-satunya lingkungan terbukanya adalah seluruh ruang.

1. Buktikan bahwa spektrum suatu gelanggang lokal mempunyai sifat ini.
2. Buktikan bahwa setiap berkas grup komutatif $\mathcal G$ pada $X$ tidak
   mempunyai kohomologi tak trivial.
3. Buktikan bahwa tidak semua berkas pada $\operatorname{Spek}(R)$ untuk suatu
   gelanggang lokal $R$ bersifat flasid.

<!-- upstream_entity: Integritätsbereich/Idealgarbe/Erste Kohomologie/Aufgabe -->

## Soal 25.8 {#br-bgk-2019-w25-ex08}

Misalkan $R$ daerah integral dan $I$ suatu ideal dalam $R$, dengan berkas
ideal kuasikoheren $\widetilde I$ yang terkait pada
$\operatorname{Spek}(R)$. Dengan menggunakan Lema 25.7, buktikan bahwa

$$
H^1(\operatorname{Spek}(R),\widetilde I)=0.
$$

<!-- upstream_entity: Punktierte Ebene/Koszul/Garbeninterpretation/Aufgabe -->

## Soal 25.9 {#br-bgk-2019-w25-ex09}

Misalkan $R=K[X,Y]$ gelanggang polinomial di atas lapangan $K$, dengan ideal
maksimal $\mathfrak m=(X,Y)$. Kita meninjau barisan eksak pendek modul $R$

$$
0\longrightarrow R
\xrightarrow{\ e\mapsto(Y,-X)\ }R^2
\xrightarrow{\ e_1\mapsto X,\ e_2\mapsto Y\ }\mathfrak m
\longrightarrow 0.
$$

1. Rumuskan barisan berkas eksak pendek dari modul-modul kuasikoheren yang
   terkait pada $\mathbb A_K^2=\operatorname{Spek}(R)$.
2. Buktikan bahwa evaluasi barisan berkas dari (1) pada
   $U=D(X,Y)\subset\mathbb A_K^2$ tidak eksak.
3. Apa citra

   $$
   1\in R=\Gamma(U,\mathcal O_X)=\Gamma(U,\widetilde{\mathfrak m})
   $$

   di dalam $H^1(U,\mathcal O_X)$ di bawah homomorfisme penghubung?

<!-- upstream_entity: Schema/Integer/Einheitengarbe/Funktionenkörpergruppe/Erste Kohomologie/Fakt/Beweis/Aufgabe -->

## Soal 25.10 {#br-bgk-2019-w25-ex10}

Misalkan $(X,\mathcal O_X)$ skema integral dengan lapangan fungsi $K$.
Misalkan $\mathcal O_X^\times$ berkas satuan pada $X$, dan misalkan
$\mathcal U$ berkas konstan untuk $K^\times$. Buktikan bahwa

$$
H^1(X,\mathcal O_X^\times)
=\Gamma(X,\mathcal U/\mathcal O_X^\times)
/\operatorname{im}\bigl(K^\times\longrightarrow
\Gamma(X,\mathcal U/\mathcal O_X^\times)\bigr).
$$

<!-- upstream_entity: Faktorieller Integritätsbereich/Einheitengarbe/Erste Kohomologie/Aufgabe -->

## Soal 25.11 {#br-bgk-2019-w25-ex11}

Misalkan $R$ daerah faktorial. Buktikan bahwa

$$
H^1(\operatorname{Spek}(R),\mathcal O_X^\times)=\{1\}.
$$

<!-- upstream_entity: Ganzheitsring/Wurzel -5/Einheitengarbe/Erste Kohomologie nicht trivial/Aufgabe -->

## Soal 25.12 {#br-bgk-2019-w25-ex12}

Kita meninjau gelanggang bilangan kuadratik

$$
R=A_{-5}=\mathbb Z[\sqrt{-5}]
\cong\mathbb Z[T]/(T^2+5).
$$

Dengan menggunakan Contoh 14.6, buktikan bahwa

$$
H^1(\operatorname{Spek}(R),
\mathcal O_{\operatorname{Spek}(R)}^\times)\ne\{1\}.
$$

<!-- upstream_entity: Stetige Abbildung/Vorgeschobene Garbe/Linksexakt/Aufgabe -->

## Soal 25.13 {#br-bgk-2019-w25-ex13}

Misalkan $f:X\to Y$ pemetaan kontinu antara ruang-ruang topologis. Buktikan
bahwa dorong maju

$$
\mathcal G\longmapsto f_*\mathcal G
$$

merupakan funktor kovarian eksak-kiri dari kategori berkas grup komutatif pada
$X$ ke kategori berkas grup komutatif pada $Y$.

**Catatan.** Funktor-funktor turunan kanan yang terkait disebut *berkas citra
lebih tinggi*.
