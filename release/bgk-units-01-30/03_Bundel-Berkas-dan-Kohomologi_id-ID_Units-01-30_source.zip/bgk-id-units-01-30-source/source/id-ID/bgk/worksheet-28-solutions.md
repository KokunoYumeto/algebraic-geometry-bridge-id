---
title: "Solusi Publik dan Cakupan Lembar Kerja 28"
stable_id: br-bgk-2019-w28-solutions
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
worksheet_upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 28"
worksheet_upstream_pageid: 110237
worksheet_upstream_revid: 793599
worksheet_upstream_parentid: 619250
worksheet_upstream_timestamp: "2022-08-25T06:21:18Z"
worksheet_upstream_mediawiki_sha1: ea85b787c20468bfd111f5afe6022adb84c3e3d7
worksheet_export_sha1_base36: re7oxf3napk67u971f3615hmym46jfb
worksheet_frozen_revision_contributor: "Arbota"
worksheet_frozen_revision_contributor_id: 36910
worksheet_url: "https://de.wikiversity.org/wiki/Kurs:B%C3%BCndel,_Garben_und_Kohomologie_(Osnabr%C3%BCck_2019-2020)/Arbeitsblatt_28"
worksheet_revision_url: "https://de.wikiversity.org/w/index.php?oldid=793599"
upstream_map: authority/wikiversity-bgk/unit-28/ORDERED_EXERCISE_MAP.json
upstream_map_sha256: 00380c3c1746989c8e7e12a8058732b96cd631c88a22750de4b174a5c884755e
authority_manifest: authority/wikiversity-bgk/unit-28/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 1ab20936afe74fcfdde3318452f2211f2458911ff0a77c554fba894de49f4b9f
candidate_evidence: authority/wikiversity-bgk/unit-28/worksheet-solution-candidates-api.json
candidate_evidence_sha256: 807394ba76bba601f12d945c2cfbc3bc6579d4db2d2be826e071fa3158765166
selection_rule: "Untuk setiap judul halaman soal resmi, calon literal '<soal>/Lösung' diperiksa secara langsung; ketiadaan tautan yang tampak pada lembar kerja tidak dipakai sebagai bukti negatif."
solution_ex06_upstream_title: "Ebene/Drei Vektoren/Transformierbar/Aufgabe/Lösung"
solution_ex06_url: "https://de.wikiversity.org/wiki/Ebene/Drei_Vektoren/Transformierbar/Aufgabe/L%C3%B6sung"
solution_ex06_revision_url: "https://de.wikiversity.org/w/index.php?title=Ebene/Drei_Vektoren/Transformierbar/Aufgabe/L%C3%B6sung&oldid=1096087"
solution_ex06_upstream_pageid: 97324
solution_ex06_upstream_revid: 1096087
solution_ex06_mediawiki_sha1: d6a97c258f8c8bb412ae9882f3cadb995feace03
solution_ex06_frozen_revision_contributor: "Arbota"
solution_ex06_revision_timestamp: "2026-06-15T07:54:14Z"
solution_ex06_revision_timestamp_display: "09:54, 15 Juni 2026"
solution_ex06_xml: authority/wikiversity-bgk/unit-28/solution-ex06.xml
solution_ex06_xml_sha256: e06231e25c906968a28314cea9fbb24a305ffa1bd539fa43b5bd99dfe5f936bb
solution_ex06_html: authority/wikiversity-bgk/unit-28/solution-ex06.html
solution_ex06_html_sha256: a98d8bd5d73123530002aac1f0846e96435293214c215afbd686d62344fac3d7
exercise_count: 14
candidate_page_count: 14
existing_candidate_count: 1
missing_candidate_count: 13
public_solution_count: 1
public_solution_numbers: "6"
negative_public_solution_count: 13
negative_solution_numbers: "1-5, 7-14"
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

```{=latex}
\clearpage
```

# Solusi Publik dan Cakupan Lembar Kerja 28 {#br-bgk-2019-w28-solutions}

Untuk masing-masing dari 14 judul halaman soal resmi, halaman calon literal
`<soal>/Lösung` diperiksa secara langsung. Pemeriksaan ini menemukan tepat satu
halaman solusi publik, yaitu solusi Soal 28.6. Ketiga belas calon lainnya
beralih ke tampilan pembuatan halaman resmi yang menyatakan bahwa halaman
tersebut belum ada. Ketiadaan tautan yang tampak pada halaman lembar kerja
tidak digunakan sebagai bukti negatif.

## Solusi Soal 28.6 {#br-bgk-2019-w28-sol-ex06}

Karena $v_1,v_2$ dan $w_1,w_2$ merupakan basis, menurut teorema penentuan
terdapat sebuah pemetaan linear bijektif

$$
\psi:V\longrightarrow V
$$

dengan

$$
\phi(v_1)=w_1
\qquad\text{dan}\qquad
\phi(v_2)=w_2.
$$

Di bawah $\psi$, asumsi bahwa setiap pasangan bebas linear tetap berlaku.

Oleh karena itu, kita hanya perlu meninjau situasi dua keluarga vektor yang
berbentuk $v_1,v_2,y$ dan $v_1,v_2,z$. Misalkan

$$
y=av_1+bv_2
$$

dan

$$
z=cv_1+dv_2.
$$

Di sini

$$
a,b,c,d\ne 0,
$$

sebab jika tidak demikian, $y$, masing-masing $z$, akan bergantung linear
dengan salah satu $v_i$. Sekarang kita meninjau pemetaan linear $\phi$ yang
diberikan oleh

$$
v_1\longmapsto \frac ca v_1
\qquad\text{dan}\qquad
v_2\longmapsto \frac db v_2.
$$

Maka

$$
\begin{aligned}
\phi(y)
&=\phi(av_1+bv_2)\\
&=a\phi(v_1)+b\phi(v_2)\\
&=a\frac ca v_1+b\frac db v_2\\
&=cv_1+bv_2\\
&=z.
\end{aligned}
$$

Dengan demikian, $\phi$ memenuhi syarat yang diminta.

> **Catatan edisi (sumber).** Solusi sumber memperkenalkan pemetaan $\psi$
> tetapi menuliskan nilai-nilai basis dan pemetaan lanjutan dengan lambang
> $\phi$ tanpa menjelaskan komposisinya. Pada baris terakhir sumber juga
> tertulis $cv_1+bv_2=z$, padahal sebelumnya $z=cv_1+dv_2$; agar kesamaan itu
> benar, koefisien kedua harus $d$. Edisi ini mempertahankan dua ketidaktepatan
> tersebut di badan solusi dan mengungkapkannya di sini.

## Hasil negatif yang dibuktikan calon langsung {#br-bgk-2019-w28-solutions-negative}

Halaman calon literal `<soal>/Lösung` saat ini tidak ada untuk Soal 28.1,
28.2, 28.3, 28.4, 28.5, 28.7, 28.8, 28.9, 28.10, 28.11, 28.12, 28.13,
dan 28.14. Setiap URL calon tersebut beralih ke tampilan pembuatan halaman
resmi yang menyatakan, “Diese Seite existiert noch nicht” (“Halaman ini belum
ada”). Pernyataan ini mencatat cakupan halaman sumber, bukan klaim bahwa solusi
matematis tidak ada.
