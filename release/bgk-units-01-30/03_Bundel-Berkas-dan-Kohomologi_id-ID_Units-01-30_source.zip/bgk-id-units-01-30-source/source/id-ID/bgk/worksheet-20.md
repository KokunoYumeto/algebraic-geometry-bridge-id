---
title: "Lembar Kerja 20 - Grup Picard"
stable_id: br-bgk-2019-w20
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 20"
upstream_pageid: 110229
upstream_revid: 1069949
upstream_timestamp: "2026-02-06T08:22:42Z"
upstream_mediawiki_sha1: deebce0847dc537e97deb2cccbd5eb87000a92c1
source_url: "https://de.wikiversity.org/w/index.php?oldid=1069949"
authority_manifest: authority/wikiversity-bgk/unit-20/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: a59a4536a441cfdbcd579525119112156fcc5dc8041ba97d4834e18db55cd658
authority_manifest_status: "Bekuan authority terminal lengkap; 32 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
worksheet_xml: authority/wikiversity-bgk/unit-20/worksheet-20.xml
worksheet_xml_sha256: 577758f4198bd4095caa4b44f18ceb55d037f80f7378a9ec1eec89630c6a26aa
worksheet_expanded_tex: authority/wikiversity-bgk/unit-20/worksheet-20-expanded.tex
worksheet_expanded_tex_sha256: 02ea49af16ac9adb623fae14e9af088c7349f6c2b903d3dd4e79b24dd4d7c68d
official_pdf: authority/artifacts/bgk-worksheet-20-official.pdf
official_pdf_sha256: e477498aa6c1b82e4ae1ec37e9f2c814db79734f04583b0da77ca00cc2423daf
official_pdf_status: "Saksi PDF resmi lokal; 53.758 byte, 5 halaman, dan SHA-1 unggahan a826ee89acd343a57ccd7102d7b5eadc9c2569b9 telah diverifikasi."
official_pdf_metadata: authority/wikiversity-bgk/unit-20/official-pdfs-api.json
official_pdf_source_bytes: 53758
official_pdf_source_sha1: a826ee89acd343a57ccd7102d7b5eadc9c2569b9
older_course_pdf: authority/artifacts/bgk-course-official.pdf
older_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
authority_precedence: "Revisi semantik Wikiversity yang dibekukan mengendalikan teks; PDF seluruh kursus tahun 2020 hanya saksi historis."
ordered_exercise_map: authority/wikiversity-bgk/unit-20/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 3c424a95222b09ffe0c26d0f5fb18d3408922fa95487ef176cf310bb5c17582a
exercise_count: 13
public_solution_count: 0
media_credits: source/id-ID/media-credits-bgk-unit-20.md
rights_ledger: authority/RIGHTS-bgk-unit-20.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-20.json
asset_closure_sha256: 2cdfc5e32e86b5f704f1f00f6d5690166967464fbe2c6474086e28e470463b40
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF adalah saksi authority, bukan teks edisi; metadata Commons CC BY-SA 4.0 dan pemberitahuan tertanam CC-by-sa 3.0 dipertahankan tanpa pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 20: Grup Picard {#br-bgk-2019-w20}

Tidak satu pun dari 13 soal pada batas revisi yang dibekukan mempunyai solusi
publik. Tanda bintang solusi karena itu tidak digunakan dan edisi ini tidak
menciptakan solusi baru.

<!-- upstream_entity: Schemamorphismus/Picardgruppe/Funktoriell/Aufgabe -->

## Soal 20.1 {#br-bgk-2019-w20-ex01}

Misalkan

$$
\varphi:X\longrightarrow Y
$$

sebuah morfisme skema. Buktikan bahwa penetapan

$$
\mathcal L\longmapsto\varphi^*\mathcal L
$$

menentukan homomorfisme grup

$$
\operatorname{Pic}(Y)\longrightarrow\operatorname{Pic}(X).
$$

Untuk dua soal berikut, perhatikan Catatan 20.3.

<!-- upstream_entity: Schemamorphismus/Picardgruppe/Funktoriell/Cech-Beschreibung/Aufgabe -->

## Soal 20.2 {#br-bgk-2019-w20-ex02}

Misalkan

$$
\varphi:X\longrightarrow Y
$$

sebuah morfisme skema. Buktikan bahwa homomorfisme grup

$$
\operatorname{Pic}(Y)\longrightarrow\operatorname{Pic}(X),
\qquad
\mathcal L\longmapsto\varphi^*\mathcal L,
$$

dapat dideskripsikan dengan bantuan deskripsi kokikel dalam Catatan 20.2
sebagai berikut. Kokikel

$$
r_{ij}\in\left(\Gamma(V_i\cap V_j,\mathcal O_Y)\right)^\times,
\qquad i<j,
$$

untuk suatu penutup terbuka

$$
Y=\bigcup_{i\in I}V_i
$$

dipetakan ke kokikel

$$
\theta_{ij}(r_{ij})
\in
\left(\Gamma\!\left(
\varphi^{-1}(V_i)\cap\varphi^{-1}(V_j),\mathcal O_X
\right)\right)^\times,
\qquad i<j,
$$

terhadap penutup

$$
X=\bigcup_{i\in I}\varphi^{-1}(V_i),
$$

dengan

$$
\theta_{ij}:\Gamma(V_i\cap V_j,\mathcal O_Y)
\longrightarrow
\Gamma\!\left(\varphi^{-1}(V_i\cap V_j),\mathcal O_X\right)
$$

menyatakan homomorfisme gelanggang yang terkait.

<!-- upstream_entity: Projektives Spektrum/Getwistete Strukturgarbe/Cech-Beschreibung/Kegelabbildung/Aufgabe -->

## Soal 20.3 {#br-bgk-2019-w20-ex03}

Misalkan

$$
A=K[X_1,\ldots,X_n]/\mathfrak a
$$

gelanggang bergradasi standar, dengan penutup terbuka

$$
U=\operatorname{Spek}(A)\setminus\{A_+\}
=\bigcup_{i=1}^nD(X_i)
\subseteq\operatorname{Spek}(R)=X
$$

dari spektrum tertusuk dan penutup terbuka

$$
Y=\operatorname{Proj}(A)
=\bigcup_{i=1}^nD_+(X_i)
$$

dari spektrum projektif yang bersangkutan. Misalkan $\ell\in\mathbb Z$.
Buktikan pernyataan-pernyataan berikut.

1. Keluarga unit

   $$
   X_i^\ell\in\left(\Gamma(D(X_i),\mathcal O_X)\right)^\times,
   \qquad i=1,\ldots,n,
   $$

   menentukan kokikel

   $$
   X_j^\ell X_i^{-\ell}
   \in\left(\Gamma(D(X_iX_j),\mathcal O_X)\right)^\times,
   \qquad i<j,
   $$

   yang merepresentasikan berkas invertibel trivial pada $U$.

2. Kokikel dari bagian (1) dapat dipandang sebagai kokikel pada spektrum
   projektif $Y$.

3. Berkas invertibel yang ditentukan pada $Y$ oleh kokikel dari bagian (2)
   isomorfik dengan berkas struktur terpuntir $\mathcal O_Y(\ell)$ (atau
   dengan $\mathcal O_Y(-\ell)$; di sini terdapat pilihan tanda).

4. Tarik balik sebuah berkas struktur terpuntir di bawah pemetaan kerucut
   $U\to Y$ bersifat trivial.

> **Catatan edisi - simbol gelanggang pada sumber.** Sumber mendefinisikan
> $A=K[X_1,\ldots,X_n]/\mathfrak a$, tetapi pada penutup spektrum tertusuk
> mencetak $\operatorname{Spek}(R)=X$. Edisi mempertahankan simbol $R$ itu
> dan tidak menggantinya secara diam-diam dengan $A$.

<!-- upstream_entity: Faktorieller Integritätsbereich/Exponent/Lokalisierung/Fakt/Beweis/Aufgabe -->

## Soal 20.4 {#br-bgk-2019-w20-ex04}

Misalkan $R$ domain faktorisasi tunggal. Buktikan pernyataan-pernyataan
berikut.

1. Untuk $f\in R$, $f\ne0$, berlaku

   $$
   (f)R_{(p)}=(p^s)
   $$

   jika dan hanya jika $p$ muncul dengan eksponen $s$ dalam faktorisasi
   prima $f$.

2. Dua ideal utama $(f)$ dan $(g)$ sama jika dan hanya jika, untuk setiap
   unsur prima $p$, ideal

   $$
   (f)R_{(p)}
   \quad\text{dan}\quad
   (g)R_{(p)}
   $$

   sama di dalam pelokalan $R_{(p)}$.

Soal berikut menjadi pengantar bagi Lema 20.13.

<!-- upstream_entity: Faktorieller Integritätsbereich/D(f,g)/Picardgruppe/Aufgabe -->

## Soal 20.5 {#br-bgk-2019-w20-ex05}

Misalkan $R$ domain faktorisasi tunggal dan $f,g\in R$. Dengan menggunakan
Catatan 20.2, buktikan bahwa grup Picard dari

$$
D(f,g)\subseteq\operatorname{Spek}(R)
$$

bersifat trivial.

<!-- upstream_entity: Integritätsbereich/Lokal faktoriell/Offene Teilmenge/Picardgruppe/Ausdehnbarkeit/Kodimension/Aufgabe -->

## Soal 20.6 {#br-bgk-2019-w20-ex06}

Misalkan $R$ domain integral Noether sedemikian sehingga semua pelokalan
$R_{\mathfrak p}$ bersifat faktorial. Misalkan
$U\subseteq\operatorname{Spek}(R)$ suatu himpunan terbuka dan
$\mathfrak p\notin U$ suatu titik berkodimensi $\geq2$ (jadi ideal prima
$\mathfrak p$ mempunyai tinggi $\geq2$). Buktikan bahwa sebuah berkas
invertibel $\mathcal L$ pada $U$ memiliki perluasan unik ke suatu himpunan
terbuka $U'$ yang memuat $U$ dan $\mathfrak p$.

<!-- upstream_entity: Ganzheitsring/Wurzel -5/Lokal faktoriell/Mehrere Ausdehnungen/Aufgabe -->

## Soal 20.7 {#br-bgk-2019-w20-ex07}

Kita meninjau gelanggang bilangan kuadratik

$$
R=\mathbb Z[\sqrt{-5}]
$$

dengan himpunan terbuka $D(2)\subseteq\operatorname{Spek}(R)$. Buktikan
bahwa berkas struktur pada $D(2)$ dapat diperluas dengan lebih dari satu cara
menjadi berkas invertibel pada $\operatorname{Spek}(R)$.

<!-- upstream_entity: An-Singularität/Punktiert/Lokal/Picardgruppe/Aufgabe -->

## Soal 20.8 {#br-bgk-2019-w20-ex08}

Buktikan bahwa grup Picard dari spektrum tertusuk

$$
U=D(X,Y,Z)
\subseteq
\operatorname{Spek}\!\left(
K[X,Y,Z]/(XY-Z^n)_{(X,Y,Z)}
\right)
$$

dari gelanggang lokal

$$
K[X,Y,Z]/(XY-Z^n)_{(X,Y,Z)}
$$

sama dengan $\mathbb Z/(n)$ (bandingkan Contoh 20.15).

> **Catatan edisi - cakupan pelokalan pada formula sumber.** Dalam kedua
> tampilan Soal 20.8, sumber menempatkan subskrip $(X,Y,Z)$ langsung pada
> $(XY-Z^n)$ di dalam hasil bagi. Edisi mempertahankan pengelompokan tercetak
> itu dan tidak memindahkan subskrip secara diam-diam ke seluruh gelanggang
> kelas sisa.

<!-- upstream_entity: An-Singularität/Punktiert/Invertierbare Garben/Nicht ausdehnbar/Aufgabe -->

## Soal 20.9 {#br-bgk-2019-w20-ex09}

Buktikan bahwa pada spektrum tertusuk

$$
U=D(X,Y,Z)
\subseteq
\operatorname{Spek}\!\left(K[X,Y,Z]/(XY-Z^n)\right),
$$

untuk $n\geq2$, terdapat berkas-berkas invertibel yang tidak dapat diperluas
menjadi berkas invertibel pada

$$
\operatorname{Spek}\!\left(K[X,Y,Z]/(XY-Z^n)\right).
$$

<!-- upstream_entity: An-Singularität/Punktiert/Invertierbare Garben/Kohärente Ausdehnung/Aufgabe -->

## Soal 20.10 {#br-bgk-2019-w20-ex10}

Buktikan bahwa berkas-berkas invertibel pada spektrum tertusuk

$$
U=D(X,Y,Z)
\subseteq
\operatorname{Spek}\!\left(K[X,Y,Z]/(XY-Z^n)\right)
$$

merupakan restriksi berkas ideal koheren yang terkait dengan ideal-ideal

$$
(X,Z^i),
\qquad i=0,\ldots,n-1,
$$

di dalam $K[X,Y,Z]/(XY-Z^n)$.

<!-- upstream_entity: An-Singularität/Punktiert/Invertierbare Garben/Ausdehnung als Gruppenschema/Aufgabe -->

## Soal 20.11 {#br-bgk-2019-w20-ex11}

Misalkan

$$
R=K[X,Y,Z]/(XY-Z^n).
$$

Untuk $i=0,1,\ldots,n-1$, tinjau aljabar-aljabar $R$

$$
A_i=R[S,T]/(SX+TZ^i)
$$

dan pemetaan spektrum yang terkait

$$
\pi_i:\operatorname{Spek}(A_i)
\longrightarrow\operatorname{Spek}(R).
$$

Buktikan bahwa, di atas

$$
U=D(X,Y,Z)
\subseteq
\operatorname{Spek}\!\left(K[X,Y,Z]/(XY-Z^n)\right),
$$

pemetaan-pemetaan $\pi_i$ merupakan bundel garis yang tidak trivial untuk
$i\ne0$. Buktikan pula bahwa untuk $i\ne0$,
$\operatorname{Spek}(A_i)$ bukan bundel garis di atas
$\operatorname{Spek}(R)$.

<!-- upstream_entity: Projektiver Raum/D_+(X,Y)/Picardgruppe/Aufgabe -->

## Soal 20.12 {#br-bgk-2019-w20-ex12}

Misalkan

$$
\mathbb P_K^d
=\operatorname{Proj}(K[X_0,X_1,\ldots,X_d])
$$

ruang projektif di atas lapangan $K$. Buktikan bahwa grup Picard dari
himpunan terbuka

$$
D_+(X_i,X_j)\subseteq\mathbb P_K^d,
\qquad i\ne j,
$$

isomorfik dengan $\mathbb Z$.

<!-- upstream_entity: Projektiver Raum/Picardgruppe/Aufgabe -->

## Soal 20.13 {#br-bgk-2019-w20-ex13}

Misalkan

$$
\mathbb P_K^d
=\operatorname{Proj}(K[X_0,X_1,\ldots,X_d])
$$

ruang projektif di atas lapangan $K$. Buktikan bahwa untuk $d\geq1$, grup
Picard dari $\mathbb P_K^d$ isomorfik dengan $\mathbb Z$.
