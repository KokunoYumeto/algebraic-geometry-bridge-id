---
title: "Kuliah 30 - Teorema Riemann–Roch"
stable_id: br-bgk-2019-l30
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 30"
upstream_pageid: 109034
upstream_revid: 793624
upstream_timestamp: "2022-08-25T06:25:28Z"
upstream_mediawiki_sha1: 18925f7cd309e5a1f414208fad07124d8680ea79
source_url: "https://de.wikiversity.org/w/index.php?oldid=793624"
authority_manifest: authority/wikiversity-bgk/unit-30/UNIT_AUTHORITY_MANIFEST.json
official_course_pdf: authority/artifacts/bgk-course-official.pdf
media_credits: source/id-ID/media-credits-bgk-unit-30.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponennya sendiri; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 30: Teorema Riemann–Roch {#br-bgk-2019-l30}

## Derajat berkas struktur terpilin pada kurva bidang {#br-bgk-2019-l30-s01}

### Lema 30.1 {#br-bgk-2019-l30-lem-01}

Misalkan

$$
C=V_+(F)\subseteq\mathbb P^2_K
$$

kurva bidang projektif mulus berderajat $d=\deg(F)$ di atas lapangan tertutup
secara aljabar. Pembatasan $\mathcal O_{\mathbb P^2_K}(e)$ ke $C$ berderajat $de$.

#### Bukti {#br-bgk-2019-l30-lem-01-proof}

Cukup mengambil $e=1$, sebab tarik balik berkas kompatibel dengan hasil kali
tensor dan, menurut Soal 29.15, derajat aditif terhadap hasil kali tensor
berkas invertibel. Misalkan

$$
G\in\Gamma(\mathbb P^2_K,\mathcal O_{\mathbb P^2_K}(1))
=K[X,Y,Z]_1
$$

suatu seksi yang, sebagai polinomial dalam $K[X,Y,Z]$, bukan kelipatan $F$.
Maka $G$ juga dapat dipandang sebagai seksi tak nol dalam

$$
\Gamma(C,\mathcal O_{\mathbb P^2_K}(1)|_C)
=\Gamma(C,\mathcal O_C(1)).
$$

Kita harus menghitung derajat divisor nol $G$ pada $C=V_+(F)$. Misalkan
$P=(a,b,c)\in V_+(F)$. Orde nol suatu seksi berkas invertibel dapat dihitung
pada lingkungan afin titik itu. Tanpa mengurangi keumuman, ambil $c=1$ dan
$P\in D_+(Z)$. Persamaan afin kurva adalah dehomogenisasi $F'$ terhadap $Z$,
dan di bawah identifikasi

$$
\mathcal O_{\mathbb P^2_K}|_{D_+(Z)}
\longrightarrow
\mathcal O_{\mathbb P^2_K}(1)|_{D_+(Z)},
\qquad 1\longmapsto Z,
$$

seksi tersebut menjadi dehomogenisasi $G'$ dari $G$. Gelanggang lokal kurva
adalah

$$
\mathcal O_{C,P}
=\left(K\!\left[\frac XZ,\frac YZ\right]/(F')\right)_{
(X/Z-a,\,Y/Z-b)}.
$$

Menurut Lema 21.9, orde $G'$ dalam gelanggang ini sama dengan dimensi
$K$ dari

$$
\mathcal O_{C,P}/(G')
=\left(K\!\left[\frac XZ,\frac YZ\right]/(F')\right)_{
(X/Z-a,\,Y/Z-b)}/(G')
=K\!\left[\frac XZ,\frac YZ\right]_{(X/Z-a,\,Y/Z-b)}/(F',G').
$$

Deskripsi ini simetris dalam $F$ dan $G$. Jadi derajat divisor nol $G$ pada
$V_+(F)$ sama dengan derajat divisor nol $F$ pada
$V_+(G)=\mathbb P^1_K$. Untuk polinomial homogen berderajat $d$ pada garis
projektif, jumlah semua orde nolnya adalah $d$. $\square$

## Teorema Riemann–Roch untuk berkas invertibel {#br-bgk-2019-l30-s02}

Misalkan $C=V_+(F)\subseteq\mathbb P^2_K$ kurva bidang projektif berderajat
$d$ di atas lapangan tertutup secara aljabar $K$, dan misalkan

$$
\mathcal L=\mathcal O_C(e)=\mathcal O_{\mathbb P^2_K}(e)|_C.
$$

Kita ingin menghitung banyaknya seksi global $\mathcal O_C(e)$. Tinjau
barisan eksak pendek

$$
0\longrightarrow\mathcal O_{\mathbb P^2_K}(e-d)
\xrightarrow{\ F\ }
\mathcal O_{\mathbb P^2_K}(e)
\longrightarrow\mathcal O_C(e)\longrightarrow0
$$

pada bidang projektif dan awal barisan eksak panjang kohomologi yang terkait:

$$
0\longrightarrow
H^0(\mathbb P^2_K,\mathcal O_{\mathbb P^2_K}(e-d))
\longrightarrow
H^0(\mathbb P^2_K,\mathcal O_{\mathbb P^2_K}(e))
\longrightarrow
H^0(\mathbb P^2_K,\mathcal O_C(e))
\longrightarrow
H^1(\mathbb P^2_K,\mathcal O_{\mathbb P^2_K}(e-d))=0.
$$

Kesamaan di kanan mengikuti dari Teorema 27.4. Untuk $e\ge d$, dimensi ruang
vektor yang terlibat dapat dihitung langsung dengan Soal 11.4:

$$
\begin{aligned}
\dim_K H^0(\mathbb P^2_K,\mathcal O_C(e))
&=\dim_K H^0(\mathbb P^2_K,\mathcal O_{\mathbb P^2_K}(e))
-\dim_K H^0(\mathbb P^2_K,\mathcal O_{\mathbb P^2_K}(e-d))\\
&=\binom{e+2}{2}-\binom{e-d+2}{2}\\
&=\frac{(e+2)(e+1)-(e+2-d)(e+1-d)}{2}\\
&=\frac{2de+3d-d^2}{2}\\
&=de-\frac{(d-1)(d-2)}{2}+1.
\end{aligned}
$$

Menurut Teorema 27.6,
$H^0(\mathbb P^2_K,\mathcal O_C(e))=H^0(C,\mathcal O_C(e))$. Menurut
Lema 30.1, $de$ adalah derajat $\mathcal O_C(e)$, dan menurut Teorema 29.5,
$(d-1)(d-2)/2$ adalah genus kohomologis $g$ kurva. Jadi untuk $e\ge d$,

$$
\dim_K H^0(C,\mathcal O_C(e))
=\deg(\mathcal O_C(e))-g+1.
$$

Untuk $e<0$ rumus ini tidak mungkin benar: ruas kiri nol, sedangkan ruas
kanan dapat menjadi sebarang negatif. Teorema Riemann–Roch menunjukkan bahwa
rumus serupa berlaku untuk berkas invertibel $\mathcal L$ pada kurva projektif
mulus $C$, tetapi ruas kiri harus diganti dengan

$$
\dim_K H^0(C,\mathcal L)-\dim_K H^1(C,\mathcal L).
$$

Jadi kohomologi pertama muncul sebagai suku koreksi.

### Teorema 30.2: Riemann–Roch {#br-bgk-2019-l30-thm-02}

Misalkan $C$ kurva projektif mulus tak tereduksi ber-genus $g$ di atas
lapangan tertutup secara aljabar $K$, dan $\mathcal L$ berkas invertibel pada $C$.
Maka

$$
h^0(C,\mathcal L)-h^1(C,\mathcal L)
=\deg(\mathcal L)+1-g.
$$

#### Bukti {#br-bgk-2019-l30-thm-02-proof}

Pernyataan benar untuk berkas struktur. Untuk titik tertutup $P\in C$, tinjau
barisan eksak pendek

$$
0\longrightarrow\mathcal I_P
\longrightarrow\mathcal O_C
\longrightarrow\kappa(P)\longrightarrow0,
$$

dengan $\mathcal I_P=\mathcal O_C(-P)$ berkas ideal invertibel tereduksi
untuk $P$, dan $\kappa(P)$ berkas struktur pada titik itu, dipandang sebagai
berkas pencakar langit pada $C$. Menensor barisan ini dengan berkas invertibel
$\mathcal L$ memberi

$$
0\longrightarrow\mathcal I_P\otimes\mathcal L
\longrightarrow\mathcal L
\longrightarrow\kappa(P)\otimes\mathcal L=\kappa(P)
\longrightarrow0.
$$

Barisan ini menghubungkan dua berkas invertibel yang berbeda sebesar titik
$P$. Barisan eksak panjang kohomologi memberikan

$$
h^0(C,\mathcal L)-h^1(C,\mathcal L)
=h^0(C,\mathcal I_P\otimes\mathcal L)
-h^1(C,\mathcal I_P\otimes\mathcal L)+1,
$$

sebab $h^0(C,\kappa(P))=1$ dan $h^1(C,\kappa(P))=0$, karena dukungannya
berdimensi nol. Karena $\deg(\mathcal I_P)=-1$, kita juga mempunyai

$$
\deg(\mathcal L)=\deg(\mathcal I_P\otimes\mathcal L)+1.
$$

Jadi derajat berubah tepat seperti selisih dimensi kohomologi ke-nol dan
ke-satu. Rumus Riemann–Roch berlaku untuk $\mathcal L$ tepat ketika berlaku
untuk $\mathcal I_P\otimes\mathcal L$. Menurut Korolari 22.11, setiap berkas
invertibel pada kurva berbentuk $\mathcal O_C(-D)$ untuk suatu divisor Weil
$D$. Karena itu, setiap berkas invertibel dapat diperoleh dari berkas struktur
dengan menambah atau mengurangi berhingga banyak titik. Rumus berlaku untuk
semua berkas invertibel. $\square$

### Korolari 30.3 {#br-bgk-2019-l30-cor-03}

Misalkan $C$ kurva projektif mulus tak tereduksi ber-genus $g$ di atas
lapangan tertutup secara aljabar $K$, dan $\mathcal L$ berkas invertibel pada $C$.
Maka

$$
h^0(C,\mathcal L)\ge\deg(\mathcal L)+1-g.
$$

Jika derajat $\mathcal L$ sedikitnya sama dengan genus kurva, maka
$\mathcal L$ mempunyai seksi global tak trivial.

#### Bukti {#br-bgk-2019-l30-cor-03-proof}

Pernyataan mengikuti langsung dari Teorema 30.2. $\square$

### Korolari 30.4 {#br-bgk-2019-l30-cor-04}

Misalkan $C$ kurva projektif mulus tak tereduksi di atas lapangan tertutup
secara aljabar. Untuk setiap titik tertutup $P\in C$ terdapat fungsi rasional tak
konstan $f\in Q(C)$ yang terdefinisi di luar $P$.

#### Bukti {#br-bgk-2019-l30-cor-04-proof}

Menurut Korolari 30.3, untuk $n$ cukup besar berkas invertibel
$\mathcal O_C(nP)$ mempunyai seksi global tak trivial, dan jumlahnya tak
terbatas ketika $n$ bertambah. Seksi-seksi ini bersesuaian dengan fungsi
rasional pada $C$ yang divisor utamanya lebih besar atau sama dengan $-nP$.
Fungsi demikian paling jauh mempunyai kutub di $P$, sehingga terdefinisi pada
$C\setminus\{P\}$. Di antaranya terdapat fungsi tak konstan. $\square$

## Teorema Riemann–Roch untuk berkas bebas lokal {#br-bgk-2019-l30-s03}

Kita akan memperumum teorema Riemann–Roch ke berkas bebas lokal. Mula-mula
kita harus mendefinisikan derajat berkas bebas lokal.

### Definisi 30.5 {#br-bgk-2019-l30-def-05}

Misalkan $C$ kurva projektif mulus di atas lapangan tertutup secara aljabar $K$.
Derajat berkas bebas lokal $\mathcal G$ ber-rank $r$ pada $C$ didefinisikan
sebagai derajat berkas determinan

$$
\bigwedge^r\mathcal G.
$$

### Teorema 30.6 {#br-bgk-2019-l30-thm-06}

Misalkan $C$ kurva projektif mulus di atas lapangan tertutup secara aljabar $K$.
Derajat berkas bebas lokal pada $C$ bersifat aditif untuk barisan eksak
pendek.

#### Bukti {#br-bgk-2019-l30-thm-06-proof}

Pernyataan mengikuti dari Teorema 16.11. $\square$

Jadi kita mempunyai tiga invarian aditif untuk berkas bebas lokal pada kurva
projektif mulus: rank, derajat, dan karakteristik Euler.

### Lema 30.7 {#br-bgk-2019-l30-lem-07}

Misalkan $C$ kurva projektif mulus tak tereduksi di atas lapangan tertutup
secara aljabar $K$. Setiap berkas ideal koheren tak nol
$\mathcal I\subseteq\mathcal O_C$ bersifat invertibel.

#### Bukti {#br-bgk-2019-l30-lem-07-proof}

Karena invertibilitas dapat diuji secara lokal pada tangkai
$\mathcal O_{C,x}$, pernyataan mengikuti dari fakta bahwa gelanggang lokal
tersebut adalah gelanggang valuasi diskret, sehingga merupakan domain ideal
utama. $\square$

### Teorema 30.8 {#br-bgk-2019-l30-thm-08}

Misalkan $C$ kurva projektif mulus tak tereduksi di atas lapangan tertutup
secara aljabar $K$, dan $\mathcal F$ berkas bebas lokal ber-rank $r$ pada $C$. Maka
terdapat filtrasi

$$
0=\mathcal F_0\subset\mathcal F_1\subset\cdots
\subset\mathcal F_{r-1}\subset\mathcal F_r=\mathcal F
$$

oleh berkas-berkas bebas lokal $\mathcal F_i$ sedemikian sehingga berkas hasil
bagi $\mathcal F_{i+1}/\mathcal F_i$ invertibel untuk $0\le i<r$.

> **Catatan edisi (sumber).** Pernyataan sumber menghilangkan lambang $r$
> sesudah “ber-rank” dan mencetak filtrasi mulai dengan
> $0=\mathcal F_1$, sehingga berkas ber-rank $r$ hanya mempunyai $r-1$
> hasil bagi. Edisi ini menampilkan parameter rank $r$ dan pengindeksan
> $\mathcal F_0,\ldots,\mathcal F_r$ yang konsisten dengan induksi dan jumlah
> faktor ber-rank satu.

#### Bukti {#br-bgk-2019-l30-thm-08-proof}

Untuk $n$ cukup besar, Teorema 15.12 memberikan seksi global tak trivial
$s\in\Gamma(C,\mathcal F^*(n))$. Seksi ini bersesuaian dengan homomorfisme
modul tak trivial

$$
\mathcal O_C\longrightarrow\mathcal F^*(n).
$$

Mendualkannya memberikan homomorfisme modul tak trivial

$$
\mathcal F(-n)\longrightarrow\mathcal O_C.
$$

Citranya adalah berkas ideal $\mathcal I\ne0$, yang menurut rujukan sumber
“Lema 30.6” bersifat invertibel. Jadi terdapat homomorfisme berkas surjektif

$$
\mathcal F(-n)\longrightarrow\mathcal I,
$$

dan karena itu homomorfisme berkas surjektif

$$
\mathcal F\longrightarrow
\mathcal I\otimes\mathcal O_C(n)=:\mathcal L.
$$

Karena $\mathcal L$ invertibel, kernel $\mathcal G\subset\mathcal F$ menurut
Teorema 16.7 bebas lokal dengan rank lebih kecil. Terapkan prosedur ini secara
induktif pada $\mathcal F_{r-1}:=\mathcal G$ untuk memperoleh filtrasi.
$\square$

> **Catatan edisi (sumber).** Bukti sumber merujuk “Lema 30.6” untuk
> invertibilitas berkas ideal koheren tak nol. Hasil tersebut bernomor Lema
> 30.7 dalam kuliah ini; nomor yang dicetak sumber dipertahankan di badan bukti.

### Teorema 30.9 {#br-bgk-2019-l30-thm-09}

Misalkan $C$ kurva projektif mulus tak tereduksi ber-genus $g$ di atas
lapangan tertutup secara aljabar $K$, dan $\mathcal F$ berkas bebas lokal ber-rank
$r$ pada $C$. Maka

$$
h^0(C,\mathcal F)-h^1(C,\mathcal F)
=\deg(\mathcal F)+r(1-g).
$$

#### Bukti {#br-bgk-2019-l30-thm-09-proof}

Kita memakai induksi pada rank $r$. Kasus awal $r=1$ adalah Teorema 30.2.
Untuk berkas bebas lokal ber-rank $r$, gunakan filtrasi dari Teorema 30.8,

$$
0=\mathcal F_0\subset\mathcal F_1\subset\cdots
\subset\mathcal F_{r-1}\subset\mathcal F_r.
$$

Khususnya terdapat barisan eksak pendek

$$
0\longrightarrow\mathcal F_{r-1}
\longrightarrow\mathcal F
\longrightarrow\mathcal F_r/\mathcal F_{r-1}
\longrightarrow0.
$$

Menurut hipotesis induksi, rumus Riemann–Roch berlaku untuk
$\mathcal F_{r-1}$, dan menurut Teorema 30.2 berlaku untuk berkas invertibel
$\mathcal F_r/\mathcal F_{r-1}$. Karakteristik Euler

$$
\chi(\mathcal G)=h^0(C,\mathcal G)-h^1(C,\mathcal G)
$$

bersifat aditif untuk barisan eksak pendek menurut Lema 27.9, dan sumber
merujuk “Teorema 30.7” untuk aditivitas derajat berkas bebas lokal pada
barisan eksak pendek. Karena itu rumus juga berlaku untuk $\mathcal F$.
$\square$

> **Catatan edisi (sumber).** Hasil aditivitas derajat yang dirujuk pada bukti
> di atas bernomor Teorema 30.6, bukan Teorema 30.7. Edisi ini mempertahankan
> nomor sumber di badan bukti dan mengungkapkan silang-rujuk yang keliru di
> sini.
