---
title: "Lembar Kerja 26 - Kohomologi Čech"
stable_id: br-bgk-2019-w26
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 26"
upstream_pageid: 110235
upstream_revid: 619292
upstream_timestamp: "2020-02-17T10:05:10Z"
upstream_mediawiki_sha1: 1d06dfb2baf64dec2ba57276ae62c90a99d239e1
source_url: "https://de.wikiversity.org/w/index.php?oldid=619292"
worksheet_xml: authority/wikiversity-bgk/unit-26/worksheet-26.xml
worksheet_xml_sha256: a1237075d1c6c2e9c640cd70db62b1cc189dd3c2b76c8094c6803353fa8b0249
worksheet_expanded_tex: authority/wikiversity-bgk/unit-26/worksheet-26-expanded.tex
worksheet_expanded_tex_sha256: 38f0c59409cde291c78bdf19cafe7ce406c9d9f35ee37a6ab84524543b56fe72
ordered_exercise_map: authority/wikiversity-bgk/unit-26/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: cfe90a0669c135507097265ba5f5b392fe82d2fcf074d94110d3733fe0f53cc3
candidate_evidence: authority/wikiversity-bgk/unit-26/worksheet-solution-candidates-api.json
candidate_evidence_sha256: db25b84749b9fcc9805ac6fd43f72519ef208a989ed45be7ed5b3361c7fe935b
official_pdf_metadata: authority/wikiversity-bgk/unit-26/official-pdfs-api.json
official_pdf_metadata_sha256: c209d22600d20ebfe6f1479b1b6a9a0f20295711dab60905e6d35039c3ca6262
official_course_pdf: authority/artifacts/bgk-course-official.pdf
official_course_pdf_bytes: 2104862
official_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
official_course_pdf_printed_pages: "231-232"
course_authority_manifest: authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json
course_authority_manifest_sha256: ea0bf346e261db8ed80b7565f7746e95c79e0c376d25d9fbce5d96879dff7dd8
exercise_count: 8
public_solution_count: 0
public_solution_numbers: ""
negative_public_solution_count: 8
negative_solution_numbers: "1-8"
media_credits: source/id-ID/media-credits-bgk-unit-26.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
authority_manifest: authority/wikiversity-bgk/unit-26/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 7ed3c9a3a480daeb4332e9de8ff2251e43d3a43845df5744ef16aabac5f2c6b4
authority_manifest_status: "Bekuan authority terminal lengkap; 29 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
official_pdf: authority/artifacts/bgk-worksheet-26-official.pdf
official_pdf_sha256: 082b40cf5174191581ab19561d7080a2519c1ddc67a2546e0ff4572e91227499
official_pdf_source_bytes: 42483
official_pdf_source_sha1: 9fc70f7c9c14609c747d19c3f6142cdc6ea47f5b
official_pdf_status: "Saksi PDF resmi lokal; identitas byte, SHA-256, SHA-1 unggahan, dan pemberitahuan hak komponen telah diverifikasi."
asset_closure: authority/ASSET_CLOSURE-bgk-unit-26.json
asset_closure_sha256: e9c1c7cf41349d4ae9d66f2e04cb9a214e5b453f41f536832a2af4103d55c1e3
media_rights: authority/RIGHTS-bgk-unit-26.csv
media_rights_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
media_credits_sha256: 3cfc1664f010b72c0ac540cbd35b74412a434788662fdc7c0f2a4cfe49abdcba
---

# Lembar Kerja 26: Kohomologi Čech {#br-bgk-2019-w26}

Tidak ada satu pun dari delapan soal yang mempunyai solusi publik pada batas
revisi yang dibekukan. Edisi tidak menciptakan solusi baru.

<!-- upstream_entity: Spektrum/Z/Garbe/Nichttriviale Kohomologie/Aufgabe -->

## Soal 26.1 {#br-bgk-2019-w26-ex01}

Definisikan suatu berkas pada $\operatorname{Spek}(\mathbb Z)$ yang mempunyai
kohomologi pertama tak trivial.

<!-- upstream_entity: Cech-Kohomologie/0/Globale Auswertung/Aufgabe -->

## Soal 26.2 {#br-bgk-2019-w26-ex02}

Misalkan

$$
X=\bigcup_{i\in I}U_i
$$

penutup terbuka suatu ruang topologis $X$, dan misalkan $\mathcal G$ berkas
grup komutatif pada $X$. Buktikan bahwa

$$
\check H^0(U_i,\ i\in I,\ \mathcal G)=\Gamma(X,\mathcal G).
$$

<!-- upstream_entity: Cech-Kohomologie/Eine Komponente/Bild/Aufgabe -->

## Soal 26.3 {#br-bgk-2019-w26-ex03}

Misalkan

$$
X=\bigcup_{i\in I}U_i
$$

penutup terbuka suatu ruang topologis $X$, dan misalkan $\mathcal G$ berkas
grup komutatif pada $X$. Misalkan

$$
s\in\check C^k(U_i,\mathcal G)
$$

suatu kokikel Čech yang untuk suatu

$$
J=\{i_0,i_1,\ldots,i_k\}\subseteq I
$$

tertentu bernilai

$$
a\in\Gamma(U_J,\mathcal G),
$$

dan bernilai $0$ untuk semua subhimpunan lain $J'\ne J$ yang beranggotakan
$(k+1)$ unsur. Tentukan

$$
\delta(s)\in\check C^{k+1}(U_i,\mathcal G).
$$

<!-- upstream_entity: Projektive Gerade/Einheitengarbe/Erste Kohomologie/Endlicher Raum/Vergleich/Aufgabe -->

## Soal 26.4 {#br-bgk-2019-w26-ex04}

Misalkan $K$ lapangan dan

$$
\mathbb P_K^1=\operatorname{Proj}(K[X,Y])
$$

garis projektif di atas $K$. Tentukan kohomologi Čech pertama

$$
\check H^1\!\left(D_+(X),D_+(Y),\mathcal O_{\mathbb P_K^1}^{\times}\right).
$$

Apa hubungannya dengan Contoh 26.1?

<!-- upstream_entity: Cech-Kohomologie/Abgeleitete Kohomologie/Endliche azyklische Überdeckung/Übereinstimmung/Details/Aufgabe -->

## Soal 26.5 {#br-bgk-2019-w26-ex05}

Buktikan bahwa penetapan dalam bukti Lema 26.8, yang kepada suatu seksi

$$
t\in\Gamma(X,\mathcal H),
$$

memasangkan suatu kelas kohomologi Čech bagi $\mathcal F$, tidak bergantung
pada wakil lokal dalam $\mathcal I$ yang dipilih dan merupakan homomorfisme
grup.

<!-- upstream_entity: Irreduzibler Raum/Konstante Garbe/Cech-Kohomologie/Aufgabe -->

## Soal 26.6 {#br-bgk-2019-w26-ex06}

Misalkan $X$ ruang topologis tak tereduksi dan $\mathcal G$ berkas konstan
yang berasal dari grup komutatif $G$. Tentukan kompleks Čech dan kohomologi
Čech bagi $\mathcal G$ terhadap penutup terbuka hingga

$$
X=\bigcup_{i\in I}U_i.
$$

<!-- upstream_entity: Beringter Raum/Modul/Cech-Komplex und Kohomologie/Modul/Aufgabe -->

## Soal 26.7 {#br-bgk-2019-w26-ex07}

Misalkan $(X,\mathcal O_X)$ ruang berdering,

$$
X=\bigcup_{i\in I}U_i
$$

penutup terbuka, dan $\mathcal F$ suatu modul $\mathcal O_X$. Buktikan bahwa
kompleks Čech bagi $\mathcal F$ terhadap penutup tersebut merupakan kompleks
modul $\Gamma(X,\mathcal O_X)$, sehingga kohomologi Čech yang bersangkutan
juga merupakan modul $\Gamma(X,\mathcal O_X)$.

<!-- upstream_entity: Affines Schema/Zweierüberdeckung/Strukturgabe/Cech-Kohomologie/Aufgabe -->

## Soal 26.8 {#br-bgk-2019-w26-ex08}

Misalkan $R$ gelanggang komutatif dan

$$
X=\operatorname{Spek}(R)=D(f)\cup D(g)
$$

dengan $f,g\in R$. Buktikan bahwa

$$
\check H^1(\{D(f),D(g)\},\mathcal O_X)=0.
$$
