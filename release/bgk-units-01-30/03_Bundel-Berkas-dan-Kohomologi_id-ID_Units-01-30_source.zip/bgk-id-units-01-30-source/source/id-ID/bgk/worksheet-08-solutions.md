---
title: "Solusi Publik dan Cakupan Lembar Kerja 8"
stable_id: br-bgk-2019-w08-solutions
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
upstream_map: authority/wikiversity-bgk/unit-08/ORDERED_EXERCISE_MAP.json
upstream_map_sha256: 97c9bf59cae3e34263681875e74c4ad2f0626b87f19a6e0490d127ac4c921f1a
authority_manifest: authority/wikiversity-bgk/unit-08/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: cadebf48e67a54a238f4b22e0abf806fbf1f81821b6d012993739ecf50dd8d32
candidate_evidence: authority/wikiversity-bgk/unit-08/worksheet-solution-candidates-api.json
candidate_evidence_sha256: 7e83e1e34c1ff1ee8c6d30dbc90b984c5cbf5e410ecccb26aad6c9825c9143bf
solution_ex03_xml: authority/wikiversity-bgk/unit-08/solution-ex03.xml
solution_ex03_xml_sha256: 95631c033a53318f85076d46db80ee24662cf91b4caa50593862ffabb284c65a
solution_ex03_html: authority/wikiversity-bgk/unit-08/solution-ex03.html
solution_ex03_html_sha256: c9b41307429cea7a1e840940572f168e2f6a17cfb729aa12c01e29aabc4cac48
solution_ex03_upstream_title: "Kommutative Ringtheorie/Primideal/Charakterisierung mit Restklassenring/Fakt/Beweis/Aufgabe/Lösung"
solution_ex03_upstream_pageid: 86076
solution_ex03_upstream_revid: 485196
solution_ex03_upstream_timestamp: "2017-01-22T18:50:39Z"
solution_ex03_mediawiki_sha1: ea019f083d8af1fe044923f7dd6f86f675ee9624
solution_ex03_source_url: "https://de.wikiversity.org/w/index.php?oldid=485196"
solution_ex03_frozen_revision_contributor: "Bocardodarapti"
solution_ex04_xml: authority/wikiversity-bgk/unit-08/solution-ex04.xml
solution_ex04_xml_sha256: a5fbd50569e2cef3662039eb4bfd79cb96995eafb529543d67e7722d564cb9da
solution_ex04_html: authority/wikiversity-bgk/unit-08/solution-ex04.html
solution_ex04_html_sha256: ff35251b5ea2b7aaacdb81681a277e956eae5e4309873ae737d9266679e1c39c
solution_ex04_upstream_title: "Primideal/Charakterisierung als Kern nach Körper/Aufgabe/Lösung"
solution_ex04_upstream_pageid: 169650
solution_ex04_upstream_revid: 1112909
solution_ex04_upstream_timestamp: "2026-08-22T08:09:40Z"
solution_ex04_mediawiki_sha1: c7ed44201f6b8d4051a567567c5a54b411976815
solution_ex04_source_url: "https://de.wikiversity.org/w/index.php?oldid=1112909"
solution_ex04_frozen_revision_contributor: "Bocardodarapti"
solution_ex11_xml: authority/wikiversity-bgk/unit-08/solution-ex11.xml
solution_ex11_xml_sha256: 4522b73edc7e16b6abd0b81f3486eb10d3ef7f9a04e57142f9ef708691600e36
solution_ex11_html: authority/wikiversity-bgk/unit-08/solution-ex11.html
solution_ex11_html_sha256: 05ab4922040e2ada71b8cc1ac54a376bbdc5419f12a5523cdbae322f46d01a85
solution_ex11_upstream_title: "Integre endlich erzeugte Algebren/Lokaler Isomorphismus/In Umgebung/Aufgabe/Lösung"
solution_ex11_upstream_pageid: 21576
solution_ex11_upstream_revid: 1112864
solution_ex11_upstream_timestamp: "2026-08-21T18:05:32Z"
solution_ex11_mediawiki_sha1: 45f4d65002a1d754f687c2e62392bb1d3c90c456
solution_ex11_source_url: "https://de.wikiversity.org/w/index.php?oldid=1112864"
solution_ex11_frozen_revision_contributor: "Bocardodarapti"
exercise_count: 22
public_solution_count: 3
public_solution_numbers: "3, 4, 11"
negative_public_solution_count: 19
negative_solution_numbers: "1-2, 5-10, 12-22"
license: "Frozen semantic course text and this translation: CC BY-SA 4.0."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

```{=latex}
\clearpage
```

# Solusi Publik dan Cakupan Lembar Kerja 8 {#br-bgk-2019-w08-solutions}

Pada batas revisi yang dibekukan, sumber menyediakan tepat tiga solusi publik
di antara 22 soal pada Lembar Kerja 8, yaitu solusi Soal 8.3, 8.4, dan 8.11.
Peta soal dan bukti kandidat yang dibekukan mencatat hasil negatif untuk Soal
8.1-8.2, 8.5-8.10, dan 8.12-8.22. Tidak ada solusi baru yang dibuat untuk
edisi ini.

## Solusi sumber untuk Soal 8.3 {#br-bgk-2019-w08-ex03-solution}

Mula-mula, misalkan $\mathfrak p$ ideal prima. Khususnya,

$$
\mathfrak p\subsetneq R,
$$

sehingga gelanggang hasil bagi $R/\mathfrak p$ bukan gelanggang nol.
Andaikan $fg=0$ dalam $R/\mathfrak p$, dengan $f$ dan $g$ direpresentasikan
oleh unsur-unsur $R$. Maka $fg\in\mathfrak p$, sehingga
$f\in\mathfrak p$ atau $g\in\mathfrak p$. Dalam $R/\mathfrak p$, ini tepat
berarti $f=0$ atau $g=0$.

Sebaliknya, andaikan $R/\mathfrak p$ domain integral. Gelanggang ini bukan
gelanggang nol, sehingga $\mathfrak p\ne R$. Ambil
$f,g\notin\mathfrak p$. Maka $f,g\ne0$ dalam $R/\mathfrak p$ dan, karena
gelanggang tersebut domain integral,

$$
fg\ne0
$$

dalam $R/\mathfrak p$. Jadi $fg\notin\mathfrak p$, yang membuktikan bahwa
$\mathfrak p$ ideal prima.

## Solusi sumber untuk Soal 8.4 {#br-bgk-2019-w08-ex04-solution}

Mula-mula, misalkan $\mathfrak a$ ideal prima. Maka $R/\mathfrak a$ adalah
domain integral, sehingga lapangan pecahannya

$$
Q(R/\mathfrak a)
$$

ada. Proyeksi kanonik yang disusul dengan penyertaan ke lapangan pecahan,

$$
\begin{aligned}
\varphi:R&\longrightarrow Q(R/\mathfrak a),\\
x&\longmapsto[x],
\end{aligned}
$$

merupakan homomorfisme gelanggang ke suatu lapangan dengan

$$
\ker\varphi=\mathfrak a.
$$

Sebaliknya, kernel homomorfisme gelanggang

$$
\varphi:R\longrightarrow K
$$

selalu merupakan ideal. Jika $ab\in\ker\varphi$, maka

$$
0=\varphi(ab)=\varphi(a)\varphi(b).
$$

Karena lapangan $K$ tidak mempunyai pembagi nol, kita memperoleh
$\varphi(a)=0$ atau $\varphi(b)=0$. Ini ekuivalen dengan
$a\in\ker\varphi$ atau $b\in\ker\varphi$. Dengan demikian
$\ker\varphi$ adalah ideal prima.

## Solusi sumber untuk Soal 8.11 {#br-bgk-2019-w08-ex11-solution}

Pertama-tama kita menunjukkan bahwa, untuk $f\in R$ yang sesuai, pemetaan

$$
R_f\longrightarrow S_{\varphi(f)}
$$

surjektif. Ambil sistem pembangkit aljabar-$K$
$x_1,\ldots,x_n$ dari $S$. Karena pemetaan lokal pada hipotesis surjektif,
ada unsur

$$
y_i=\frac{r_i}{g_i},
\qquad g_i\notin\mathfrak m,
$$

dengan $\varphi(y_i)=x_i$ dalam $S_{\mathfrak n}$. Ini berarti
$y_ig_i=r_i$ untuk $i=1,\ldots,n$. Dengan

$$
f=g_1\cdots g_n,
$$

semua $y_i$ dapat dituliskan dengan penyebut utama bersama $f$; jadi
$y_i\in R_f$. Pemetaan $R_f\to S_{\varphi(f)}$ surjektif karena suatu sistem
pembangkit berada dalam citranya dan penyebut-penyebut
$\varphi(f)^n$ adalah citra dari $f^n$.

Kita klaim bahwa pemetaan tersebut juga injektif. Andaikan $q\in R_f$
dipetakan ke nol. Maka $q$ juga nol dalam $S_{\mathfrak n}$ dan berasal dari
$q\in R_{\mathfrak m}$. Karena pemetaan lokal adalah isomorfisme,
$q=0$ dalam $R_{\mathfrak m}$. Karena $R$ merupakan domain integral menurut
hipotesis, hal ini juga mengakibatkan $q=0$ dalam $R_f$. Jadi pemetaan itu
injektif dan dengan demikian merupakan isomorfisme.
