---
title: "Solusi Publik dan Cakupan Lembar Kerja 29"
stable_id: br-bgk-2019-w29-solutions
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
worksheet_url: "https://de.wikiversity.org/wiki/Kurs:B%C3%BCndel,_Garben_und_Kohomologie_(Osnabr%C3%BCck_2019-2020)/Arbeitsblatt_29"
worksheet_permalink: "https://de.wikiversity.org/w/index.php?title=Kurs:B%C3%BCndel,_Garben_und_Kohomologie_(Osnabr%C3%BCck_2019-2020)/Arbeitsblatt_29&oldid=1069438"
worksheet_upstream_pageid: 110238
worksheet_upstream_revid: 1069438
worksheet_upstream_timestamp: "2026-02-05T20:36:09Z"
worksheet_upstream_mediawiki_sha1: fe4fc776bdfd80cb3337cfb807de3168abe73d09
worksheet_frozen_revision_contributor: "Bocardodarapti"
worksheet_revision_timestamp_display: "21:36 CET, 5 Februari 2026"
upstream_map: authority/wikiversity-bgk/unit-29/ORDERED_EXERCISE_MAP.json
upstream_map_sha256: 1ee8ba36620cda1bb7b7da82f277d42c0284c0c3858f368d517fc0206c00889c
authority_manifest: authority/wikiversity-bgk/unit-29/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 376380a874b545579d61c100d1f66eac11bad854d76f7e586b10cd621e7a54f7
candidate_evidence: authority/wikiversity-bgk/unit-29/worksheet-solution-candidates-api.json
candidate_evidence_sha256: c59b055e355a4622417b3bb3341b8c36221c7d5726348a62796cd9a43c8f4bda
solution_ex05_url: "https://de.wikiversity.org/wiki/Projektion_weg_von_Punkt/Ebene/Generischer_Grad/Aufgabe/L%C3%B6sung"
solution_ex05_permalink: "https://de.wikiversity.org/w/index.php?title=Projektion_weg_von_Punkt/Ebene/Generischer_Grad/Aufgabe/L%C3%B6sung&oldid=1096531"
solution_ex05_upstream_pageid: 96768
solution_ex05_upstream_revid: 1096531
solution_ex05_mediawiki_sha1: a29ee211b9f7695de50dab32bbf7d363844eded6
solution_ex05_frozen_revision_contributor: "Arbota"
solution_ex05_revision_timestamp_display: "11:05, 15 Juni 2026"
solution_ex05_xml: authority/wikiversity-bgk/unit-29/solution-ex05.xml
solution_ex05_xml_sha256: 119bb8ead8b4a00f4c0cd8c405d5b3b0248ba21a0264172e49604a4cf63b38e8
solution_ex05_html: authority/wikiversity-bgk/unit-29/solution-ex05.html
solution_ex05_html_sha256: 99bc2e356cdb143feea7f3d7d38afcc91128e99f9acf676ab5e44c087e634273
solution_ex12_url: "https://de.wikiversity.org/wiki/Projektive_Gerade/Rationale_Funktion/u%2Bu_invers/Aufgabe/L%C3%B6sung"
solution_ex12_permalink: "https://de.wikiversity.org/w/index.php?title=Projektive_Gerade/Rationale_Funktion/u%2Bu_invers/Aufgabe/L%C3%B6sung&oldid=1095413"
solution_ex12_upstream_pageid: 116035
solution_ex12_upstream_revid: 1095413
solution_ex12_mediawiki_sha1: 3a7d36bb78a33db5ca7e00800b142cd643302e61
solution_ex12_frozen_revision_contributor: "Arbota"
solution_ex12_revision_timestamp_display: "20:37, 14 Juni 2026"
solution_ex12_xml: authority/wikiversity-bgk/unit-29/solution-ex12.xml
solution_ex12_xml_sha256: 1c775f102fbbff3abebe06129a1bc963c64f3ff446163aff22fa6832390c6a0c
solution_ex12_html: authority/wikiversity-bgk/unit-29/solution-ex12.html
solution_ex12_html_sha256: c2a5f0a4a22795e0072ac6ccd96b18c5ea421347c266c390cf761c9196198b56
exercise_count: 15
public_solution_count: 2
public_solution_numbers: "5, 12"
negative_public_solution_count: 13
negative_solution_numbers: "1-4, 6-11, 13-15"
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

```{=latex}
\clearpage
```

# Solusi Publik dan Cakupan Lembar Kerja 29 {#br-bgk-2019-w29-solutions}

Pada revisi halaman resmi yang dibekukan, sumber menyediakan tepat dua solusi
publik di antara 15 soal, yaitu solusi Soal 29.5 dan 29.12. Halaman ketiga belas
soal lainnya hanya menawarkan pembuatan solusi baru. Ketiadaan halaman solusi
publik tidak diubah menjadi solusi buatan.

## Solusi Soal 29.5 {#br-bgk-2019-w29-sol-ex05}

Kita meninjau sebuah garis $V_+(L)$ yang melalui titik $P$ beserta komplemen
afinnya yang bersesuaian,

$$
D_+(L)\cong \mathbb A_K^2.
$$

Tanpa mengurangi keumuman, ambil

$$
P=(1,0,0)
$$

dan $L=Z$. Dengan demikian, kita dapat menganggap bahwa yang dibahas adalah
proyeksi afin

$$
\mathbb A_K^2\cong D_+(Z)
\longrightarrow
\mathbb A_K^1\cong D_+(Z),
\qquad
(x,y)\longmapsto y,
$$

dan bahwa tersedia suatu kurva afin $V(F)$ berderajat $d$. Suku $X^d$ muncul
dalam $F$, sebab jika tidak demikian maka $P\in C$. Kita memandang polinomial
$F$ sebagai

$$
F=G_dX^d+G_{d-1}X^{d-1}+\cdots+G_1X+G_0
\in K[Y][X]\subset K(Y)[X].
$$

Di sini $G_i\in K[Y]$, sedangkan $G_d$ konstan. Karena kurva tersebut tak
tereduksi, berlaku $G_0\ne 0$ apabila $d\geq 2$ (untuk $d=1$, keseluruhan
pernyataan jelas dengan sendirinya). Kita harus menunjukkan bahwa, untuk semua
kecuali berhingga banyak $y\in K$, polinomial

$$
F(y)=G_d(y)X^d+G_{d-1}(y)X^{d-1}+\cdots+G_1(y)X+G_0(y)
$$

mempunyai $d$ akar yang berbeda. Karena $F\in K(Y)[X]$ merupakan polinomial tak
tereduksi dan kita berada dalam karakteristik $0$, polinomial $F$ separabel.
Jadi $F$ dan $F'$ saling prima, dengan $F'$ menyatakan turunan formal terhadap
$X$. Oleh karena itu, terdapat $S,T\in K(Y)$ sedemikian sehingga

$$
SF+TF'=1.
$$

Ini berarti bahwa terdapat polinomial $A,B,C\in K[Y]$ yang memenuhi

$$
AF+BF'=C
$$

dengan $C\ne 0$. Polinomial $C$ hanya mempunyai berhingga banyak akar. Untuk
$y\in K$ dengan $C(y)\ne 0$, berlaku

$$
A(y)F(y)+B(y)F(y)'=C(y),
$$

yang berarti bahwa $F(y)$ dan $F(y)'=F'(y)$ saling prima di $K[X]$. Maka
$F(y)$ dan turunannya $F(y)'$ tidak mempunyai akar bersama, sehingga tidak ada
akar $F(y)$ yang berkelipatan.

## Solusi Soal 29.12 {#br-bgk-2019-w29-sol-ex12}

1. Sistem linear tersebut bukan sistem linear lengkap, karena di
   $\Gamma(\mathbb P_K^1,\mathcal O_{\mathbb P_K^1}(2))$ terdapat tiga
   penampang yang bebas linear, yaitu

   $$
   WZ,\qquad W^2,\qquad Z^2.
   $$

2. Menurut definisi, morfisme yang bersesuaian dengan suatu keluarga penampang
   global didefinisikan pada lokus tempat penampang-penampang itu dapat
   dibalik. Lokus-lokus tersebut adalah $D_+(WZ)$ dan
   $D_+(W^2+Z^2)$. Pada lokus pertama, pemetaan diberikan oleh

   $$
   D_+(WZ)\cong \mathbb A_K^1\setminus\{(0)\}
   \longrightarrow
   D_+(X)\cong \mathbb A_K^1,
   $$

   dengan

   $$
   \frac{Y}{X}
   \longmapsto
   \frac{W^2+Z^2}{WZ}
   =\frac{W}{Z}+\frac{Z}{W}
   =u^{-1}+u.
   $$

   Pada lokus kedua, pemetaan diberikan oleh (di sini $\mathrm i$ menyatakan
   suatu akar kuadrat dari $-1$)

   $$
   D_+(W^2+Z^2)
   \cong
   \mathbb P_K^1\setminus\{(1,\mathrm i),(1,-\mathrm i)\}
   \longrightarrow
   D_+(Y)\cong \mathbb A_K^1,
   $$

   dengan

   $$
   \frac{X}{Y}
   \longmapsto
   \frac{WZ}{W^2+Z^2}
   =\frac{1}{u+u^{-1}}
   =\frac{u}{u^2+1}.
   $$

3. Sistem tersebut bebas titik dasar, karena kedua himpunan $D_+(WZ)$ dan
   $D_+(W^2+Z^2)$ menutupi garis projektif. Memang, jika

   $$
   P\notin D_+(WZ)\cup D_+(W^2+Z^2),
   $$

   mula-mula salah satu koordinat harus sama dengan $0$, tetapi kemudian
   koordinat yang kedua juga sama dengan $0$.

4. Ekstensi lapangan fungsi

   $$
   K(t)\subseteq K(u)
   $$

   diberikan oleh $t\mapsto u+u^{-1}$. Derajatnya adalah $2$, sebab $u$
   memenuhi persamaan kuadrat

   $$
   u^2-(u+u^{-1})u+1=0
   $$

   atas $K(t)$. Ekstensi ini tidak mungkin merupakan ekstensi identitas, sebab,
   sebagai contoh, $u\mapsto u^{-1}$ memberikan automorfisme lapangan
   $K(u)$ di atas $K(t)$ yang tak trivial.

5. Ambil $(x,y)\in\mathbb P_K^1$, dan mula-mula anggap kedua koordinatnya
   tidak nol. Kita memakai deskripsi afin di atas, yaitu pemetaan

   $$
   \mathbb A_K^1\setminus\{0\}
   \longrightarrow
   \mathbb A_K^1,
   \qquad
   u\longmapsto u+u^{-1}.
   $$

   Pracitra suatu titik $b$ terdiri atas solusi persamaan $u+u^{-1}=b$, yakni

   $$
   u^2-bu+1=0,
   $$

   sehingga

   $$
   u=\pm\frac12\sqrt{b^2-4}+\frac b2.
   $$

   Misalkan $b\ne 2,-2$ dan $a$ merupakan suatu pracitra dari $b$. Untuk
   homomorfisme gelanggang lokal

   $$
   K[t]_{(t-b)}\longrightarrow K[u]_{(u-a)},
   \qquad
   t\longmapsto u+u^{-1},
   $$

   berlaku

   $$
   t-b
   =u+u^{-1}-b
   =\frac1u(u^2-bu+1)
   =\frac1u(u+a)(u-a).
   $$

   Faktor $\frac1u(u+a)$ adalah suatu unit, sedangkan $u-a$ adalah parameter
   penyeragam di $K[u]_{(u-a)}$. Oleh karena itu, orde ramifikasinya sama
   dengan $1$. Untuk

   $$
   b=2,-2,
   $$

   hanya terdapat pracitra $1$, masing-masing $-1$. Untuk homomorfisme
   gelanggang lokal

   $$
   K[t]_{(t-2)}\longrightarrow K[u]_{(u-1)},
   $$

   berlaku

   $$
   t-2
   =u+u^{-1}-2
   =\frac1u(u^2-2u+1)
   =\frac1u(u-1)^2,
   $$

   dan orde ramifikasinya adalah $2$. Hal yang sama berlaku untuk $b=-2$.

   Pracitra titik nol di $D_+(X)$, yaitu $(1,0)$ (atau $(Y)$), terdiri atas
   $(W-\mathrm iZ)$ dan $(W+\mathrm iZ)$. Homomorfisme gelanggang lokalnya
   adalah

   $$
   K[t]_{(t)}\longrightarrow K[u]_{(u-\mathrm i)},
   $$

   dan karena

   $$
   t=u+u^{-1}
   =\frac1u(u^2+1)
   =\frac1u(u+\mathrm i)(u-\mathrm i),
   $$

   orde ramifikasinya adalah $1$. Pracitra titik di tak hingga, yaitu
   $(0,1)$ atau $(Y)$, terdiri atas $(1,0)$, masing-masing $(0,1)$.
   Homomorfisme gelanggang lokalnya, di satu sisi, adalah

   $$
   K[t^{-1}]_{(t^{-1})}\longrightarrow K[u]_{(u)},
   $$

   dengan

   $$
   t^{-1}=\frac{u}{u^2+1},
   $$

   sehingga indeks ramifikasinya adalah $1$, dan, di sisi lain,

   $$
   K[t^{-1}]_{(t^{-1})}
   \longrightarrow
   K[u^{-1}]_{(u^{-1})},
   $$

   dengan

   $$
   t^{-1}
   =\frac{u}{u^2+1}
   =\frac{u\cdot u^{-2}}{(u^2+1)\cdot u^{-2}}
   =\frac{u^{-1}}{1+u^{-2}},
   $$

   dan ini juga mempunyai orde ramifikasi $1$.

   > **Catatan edisi (sumber).** Untuk akar $a$ dari
   > $u^2-bu+1$, solusi sumber memfaktorkan polinomial itu sebagai
   > $(u+a)(u-a)$, yang tidak benar secara umum; tampilan tersebut
   > dipertahankan di atas. Sumber juga menyebut titik $(0,1)$ sebagai
   > ideal $(Y)$ tepat setelah memakai konvensi yang mengidentifikasi
   > $(Y)$ dengan $(1,0)$; dalam konvensi itu, $(0,1)$ semestinya
   > ditentukan oleh $(X)$.

6. Yang perlu dilakukan adalah menentukan divisor utama dari $u+u^{-1}$ pada
   garis projektif. Jika

   $$
   u=0,\infty,
   $$

   terdapat sebuah kutub, masing-masing berorde $1$. Selain itu,
   $u+u^{-1}$ terdefinisi dan mempunyai dua akar sederhana, yaitu $\mathrm i$
   dan $-\mathrm i$. Jadi divisor utamanya adalah, dalam notasi koordinat yang
   dilihat dari garis afin $D_+(W)$,

   $$
   1\cdot(\mathrm i)+1\cdot(-\mathrm i)
   -1\cdot(0)-1\cdot(\infty),
   $$

   atau, dinyatakan dengan ideal prima homogen berketinggian $1$,

   $$
   1\cdot(W-\mathrm iZ)+1\cdot(W+\mathrm iZ)
   -1\cdot(W)-1\cdot(Z).
   $$

## Hasil negatif yang dibekukan {#br-bgk-2019-w29-solutions-negative}

Tidak ada halaman solusi publik pada revisi halaman soal yang diperiksa untuk
Soal 29.1, 29.2, 29.3, 29.4, 29.6, 29.7, 29.8, 29.9, 29.10, 29.11,
29.13, 29.14, atau 29.15. Pada masing-masing halaman itu, kontrol solusi
bertuliskan “Eine Lösung erstellen” (“Buat sebuah solusi”). Pernyataan ini
adalah hasil pemeriksaan tautan resmi, bukan klaim bahwa solusi matematis tidak
ada.
