---
title: "Lembar Kerja 28 - Morfisme ke Ruang Projektif"
stable_id: br-bgk-2019-w28
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 28"
upstream_pageid: 110237
upstream_revid: 793599
upstream_timestamp: "2022-08-25T06:21:18Z"
upstream_mediawiki_sha1: ea85b787c20468bfd111f5afe6022adb84c3e3d7
source_url: "https://de.wikiversity.org/w/index.php?oldid=793599"
authority_manifest: authority/wikiversity-bgk/unit-28/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 1ab20936afe74fcfdde3318452f2211f2458911ff0a77c554fba894de49f4b9f
worksheet_xml: authority/wikiversity-bgk/unit-28/worksheet-28.xml
worksheet_xml_sha256: 56c469f5194deedc36448313ba7056ac42e3dae859c87095f9e833ae8bae66fc
worksheet_expanded_tex: authority/wikiversity-bgk/unit-28/worksheet-28-expanded.tex
worksheet_expanded_tex_sha256: 4bb944ec5c5519518f1b5983de082ca0bcd4e149a788ecc57ec2da2633b769b8
official_pdf: authority/artifacts/bgk-worksheet-28-official.pdf
official_pdf_sha256: 663106b4ccb3fff4ef022fad226e0e9765deec1a39fa8e1d1c2b873886a728df
ordered_exercise_map: authority/wikiversity-bgk/unit-28/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 00380c3c1746989c8e7e12a8058732b96cd631c88a22750de4b174a5c884755e
exercise_count: 14
public_solution_count: 1
public_solution_numbers: "6"
official_course_pdf: authority/artifacts/bgk-course-official.pdf
media_credits: source/id-ID/media-credits-bgk-unit-28.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponennya sendiri; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 28: Morfisme ke Ruang Projektif {#br-bgk-2019-w28}

## Soal latihan {#br-bgk-2019-w28-s01}

<!-- upstream_entity: Kegelabbildung/Lineares System/Aufgabe -->
### Soal 28.1 {#br-bgk-2019-w28-ex01}

Jelaskan pemetaan kerucut

$$
\mathbb A^{d+1}_K\setminus\{(0,0,\ldots,0)\}
\longrightarrow\mathbb P^d_K
$$

dengan menggunakan suatu sistem linear dalam sebuah berkas invertibel.

<!-- upstream_entity: Projektion weg von einem Punkt/Lineares System/Aufgabe -->
### Soal 28.2 {#br-bgk-2019-w28-ex02}

Jelaskan proyeksi menjauhi sebuah titik dengan menggunakan suatu sistem linear
dalam sebuah berkas invertibel.

<!-- upstream_entity: Projektiver Raum/Bijektive lineare Abbildung/Automorphismus/Aufgabe -->
### Soal 28.3 {#br-bgk-2019-w28-ex03}

Misalkan $K$ lapangan dan $\mathbb P^n_K$ ruang projektif yang terkait.
Misalkan $\varphi:K^{n+1}\to K^{n+1}$ pemetaan linear bijektif.

1. Buktikan bahwa $\varphi$ menginduksi automorfisme
   $$
   \varphi:\mathbb P^n_K\longrightarrow\mathbb P^n_K,
   \qquad
   (x_0,x_1,\ldots,x_n)\longmapsto
   \varphi(x_0,x_1,\ldots,x_n).
   $$
2. Tentukan pracitra $D_+(X_i)$ dalam situasi pada bagian (1). Bagaimana
   bentuk morfisme pada himpunan-himpunan afin ini?
3. Buktikan bahwa $\varphi_1$ dan $\varphi_2$ menginduksi automorfisme yang
   sama pada ruang projektif tepat ketika keduanya saling diperoleh melalui
   perkalian dengan suatu skalar tak nol.
4. Apakah setiap pemetaan linear
   $\varphi:K^{n+1}\to K^{n+1}$ menginduksi morfisme
   $\varphi:\mathbb P^n_K\to\mathbb P^n_K$?

Dalam situasi di atas kita berbicara tentang *automorfisme linear projektif*.

<!-- upstream_entity: Projektiver Raum/Bijektive lineare Abbildung/Lineares System/Aufgabe -->
### Soal 28.4 {#br-bgk-2019-w28-ex04}

Jelaskan suatu automorfisme linear projektif

$$
\mathbb P^d_K\longrightarrow\mathbb P^d_K
$$

dengan menggunakan sistem linear dalam sebuah berkas invertibel.

<!-- upstream_entity: Projektiver Raum/Zwei Punkte/Automorphismus/Aufgabe -->
### Soal 28.5 {#br-bgk-2019-w28-ex05}

Misalkan $P,Q\in\mathbb P^n_K$ titik-titik dalam ruang projektif di atas
lapangan $K$. Buktikan bahwa terdapat automorfisme
$\varphi:\mathbb P^n_K\to\mathbb P^n_K$ dengan $\varphi(P)=Q$.

<!-- upstream_entity: Ebene/Drei Vektoren/Transformierbar/Aufgabe -->
### Soal 28.6 ★ {#br-bgk-2019-w28-ex06}

Misalkan $V$ ruang vektor berdimensi dua di atas lapangan $K$. Misalkan
$v_1,v_2,v_3$ dan $w_1,w_2,w_3$ adalah vektor-vektor dalam $V$, dan dalam
masing-masing keluarga setiap dua vektor bebas linear. Buktikan bahwa terdapat
pemetaan linear bijektif $\varphi:V\to V$ sedemikian sehingga

$$
\varphi(v_i)\in Kw_i
$$

untuk $i=1,2,3$.

<!-- upstream_entity: Projektive Gerade/Drei Punkte/Automorphismus/Aufgabe -->
### Soal 28.7 {#br-bgk-2019-w28-ex07}

Misalkan $P_1,P_2,P_3\in\mathbb P^1_K$ dan
$Q_1,Q_2,Q_3\in\mathbb P^1_K$ masing-masing merupakan tiga titik yang saling
berbeda pada garis projektif di atas lapangan $K$. Buktikan bahwa terdapat
$K$-automorfisme $\varphi:\mathbb P^1_K\to\mathbb P^1_K$ dengan
$\varphi(P_i)=Q_i$ untuk $i=1,2,3$.

<!-- upstream_entity: Projektiver Raum/Automorphismus/Aufgabe -->
### Soal 28.8 {#br-bgk-2019-w28-ex08}

Misalkan $K$ lapangan. Buktikan bahwa setiap $K$-automorfisme ruang projektif
$\mathbb P^n_K$ ke dirinya sendiri bersifat linear projektif.

Gunakan fakta bahwa berkas hasil tarik balik dari
$\mathcal O_{\mathbb P^n_K}(1)$ juga harus merupakan
$\mathcal O_{\mathbb P^n_K}(1)$.

<!-- upstream_entity: Lineares System/Basiswechsel/Projektiver Automorphismus/Aufgabe -->
### Soal 28.9 {#br-bgk-2019-w28-ex09}

Misalkan $X$ skema di atas lapangan $K$, $\mathcal L$ berkas invertibel pada
$X$, dan $s_0,s_1,\ldots,s_n\in\Gamma(X,\mathcal L)$ seksi global yang
menentukan sistem linear

$$
\langle s_0,s_1,\ldots,s_n\rangle
\subseteq\Gamma(X,\mathcal L).
$$

Misalkan $t_0,t_1,\ldots,t_n$ sistem pembangkit lain bagi sistem linear yang
sama. Buktikan pernyataan berikut.

1. $\bigcup_{i=0}^{n}X_{s_i}=\bigcup_{i=0}^{n}X_{t_i}$.
2. Untuk morfisme yang diberikan oleh kedua sistem pembangkit itu, terdapat
   automorfisme linear projektif
   $$
   \theta:\mathbb P^n_K\longrightarrow\mathbb P^n_K
   $$
   sedemikian sehingga
   $$
   \theta\circ\varphi_{s_0,s_1,\ldots,s_n}
   =\varphi_{t_0,t_1,\ldots,t_n}.
   $$

<!-- upstream_entity: Projektive Gerade/O(1)/Lineare Einbettung/Aufgabe -->
### Soal 28.10 {#br-bgk-2019-w28-ex10}

Tinjau garis projektif $\mathbb P^1_K$ dan sistem linear lengkap

$$
L:=\langle s,t\rangle
=\Gamma(\mathbb P^1_K,\mathcal O_{\mathbb P^1_K}(1)).
$$

Buktikan bahwa pemilihan suatu sistem pembangkit $L$ yang terdiri atas tiga
unsur, hingga perkalian skalar, bersesuaian dengan embedding garis projektif
ke bidang projektif sebagai sebuah garis. Bagaimana garis citra itu dapat
dijelaskan?

<!-- upstream_entity: Projektive Gerade/O(2)/3 Schnitte/Einbettung/Aufgabe -->
### Soal 28.11 {#br-bgk-2019-w28-ex11}

Tinjau garis projektif $\mathbb P^1_K$ dan sistem linear lengkap

$$
L:=\langle s^2,st,t^2\rangle
=\Gamma(\mathbb P^1_K,\mathcal O_{\mathbb P^1_K}(2)).
$$

Buktikan bahwa pemilihan suatu basis $L$, hingga perkalian skalar,
bersesuaian dengan embedding garis projektif ke bidang projektif. Bagaimana
kurva citranya dapat dijelaskan?

<!-- upstream_entity: Projektive Gerade/O(4)/4 Schnitte/Veronese-Einbettung/Aufgabe -->
### Soal 28.12 {#br-bgk-2019-w28-ex12}

Tinjau garis projektif $\mathbb P^1_K$ dan sistem linear lengkap

$$
L:=\langle s^3,s^2t,st^2,t^3\rangle
=\Gamma(\mathbb P^1_K,\mathcal O_{\mathbb P^1_K}(3)).
$$

Buktikan bahwa pemetaan yang terkait

$$
\mathbb P^1_K\longrightarrow\mathbb P^3_K
$$

memberikan embedding garis projektif ke ruang projektif. Berikan sebanyak
mungkin persamaan yang dipenuhi kurva citra.

> **Catatan edisi (sumber).** Judul halaman soal yang ditransklusikan memuat
> segmen `O(4)`, tetapi pernyataan soal sendiri memakai empat seksi kubik dan
> $\mathcal O(3)$. Edisi ini mempertahankan rumus yang tampil pada soal; judul
> sumber persisnya tetap dicatat dalam penanda entitas di atas.

<!-- upstream_entity: Schema über R/Invertierbare Garbe/Schnitte/Morphismus in projektiven Raum/Über affinen Kegel/Aufgabe -->
### Soal 28.13 {#br-bgk-2019-w28-ex13}

Misalkan $X$ skema di atas gelanggang komutatif $R$, $\mathcal L$ berkas
invertibel pada $X$, dan $s_0,s_1,\ldots,s_n\in\Gamma(X,\mathcal L)$ seksi
global. Misalkan $L\to X$ adalah bundel garis dalam pengertian Teorema 17.10
untuk berkas invertibel dual $\mathcal L^*$, sehingga $s_i$ dapat dipandang
sebagai morfisme

$$
L\longrightarrow X\times\mathbb A^1_R\longrightarrow\mathbb A^1_R.
$$

Buktikan bahwa terdapat diagram komutatif

$$
\begin{CD}
L @>{(s_0,s_1,\ldots,s_n)}>>
\mathbb A^{n+1}_R\supseteq\displaystyle\bigcup_{i=0}^{n}D(x_i)\\
@VVV @VV{\pi}V\\
X\supseteq\displaystyle\bigcup_{i=0}^{n}X_{s_i}
@>{\varphi_{s_0,s_1,\ldots,s_n,\mathcal L}}>> \mathbb P^n_R,
\end{CD}
$$

dengan pemetaan kerucut pada sisi kanan.

> **Catatan edisi (sumber).** Pada kedua gabungan di diagram sumber, indeks
> tercetak mulai dari $i=1$, walaupun keluarga seksinya adalah
> $s_0,\ldots,s_n$ dan pemetaan kerucut memakai semua koordinat. Edisi ini
> menampilkan batas $i=0,\ldots,n$ yang konsisten dengan pernyataan.

<!-- upstream_entity: Schema über R/Invertierbare Garbe/Schnitte/Morphismus in projektiven Raum/Global definiert/Fakt/Beweis/Aufgabe -->
### Soal 28.14 {#br-bgk-2019-w28-ex14}

Misalkan $X$ skema di atas gelanggang komutatif $R$, $\mathcal L$ berkas
invertibel pada $X$, dan $s_0,s_1,\ldots,s_n\in\Gamma(X,\mathcal L)$ seksi
global. Buktikan bahwa pernyataan berikut ekuivalen.

1. $X=\bigcup_{i=0}^{n}X_{s_i}$.
2. Morfisme ke $\mathbb P^n_R$ yang diberikan oleh sistem linear
   $(s_0,s_1,\ldots,s_n)$ terdefinisi pada seluruh $X$.
3. Sistem linear $(s_0,s_1,\ldots,s_n)$ bebas titik basis.
