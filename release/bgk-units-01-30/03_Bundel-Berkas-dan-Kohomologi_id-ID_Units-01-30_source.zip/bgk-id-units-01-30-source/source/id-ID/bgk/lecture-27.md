---
title: "Kuliah 27 - Kohomologi pada Skema Projektif"
stable_id: br-bgk-2019-l27
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 27"
upstream_pageid: 109031
upstream_revid: 1070036
upstream_timestamp: "2026-02-06T08:44:57Z"
upstream_mediawiki_sha1: a18e6d008d7f2611f624cd1fae3c768a6c61585f
source_url: "https://de.wikiversity.org/w/index.php?oldid=1070036"
authority_manifest: authority/wikiversity-bgk/unit-27/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: b6c2a7687ee2fcc20e6f2b5f58f1f97a665a8c1f9201d11308bb84f62a79c089
authority_manifest_status: "Bekuan authority terminal lengkap; 30 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
official_pdf: authority/artifacts/bgk-lecture-27-official.pdf
official_pdf_sha256: 5b9a2585247113ae4f0d7d10c66124c4fba1831891abf3836f9939a47d9a3a99
official_pdf_source_bytes: 93474
official_pdf_source_sha1: d842b6fdfc2c226877f0eb2d5652738e3dd2e028
official_pdf_pages: 7
authority_precedence: "Revisi semantik Wikiversity yang dibekukan mengendalikan teks; PDF resmi adalah saksi historis, bukan pengganti revisi semantik."
pdf_component_rights: "Metadata Commons CC BY-SA 4.0 dan pemberitahuan tertanam CC-by-sa 3.0 dipertahankan tanpa pelisensian ulang menyeluruh."
media_credits: source/id-ID/media-credits-bgk-unit-27.md
media_credits_sha256: dc3afa2d1b2e7c78a604bb54965bc45e4c56058c7585341e927d0e8e4a03f406
rights_ledger: authority/RIGHTS-bgk-unit-27.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-27.json
asset_closure_sha256: 0eb449063c5dab73703a381246847c4deac31a20327bbe2a8a4c17b082e915ab
lecture_xml: authority/wikiversity-bgk/unit-27/lecture-27.xml
lecture_xml_sha256: d0ac75985445f09f76b9fc1d9d93a04b677e102979f9431c02a29afdd19c4ff7
lecture_expanded_tex: authority/wikiversity-bgk/unit-27/lecture-27-expanded.tex
lecture_expanded_tex_sha256: ee29b146c2ad0c14c25ea7c97662c294a2ec0424791999580bece98448531316
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 27: Kohomologi pada Skema Projektif {#br-bgk-2019-l27}

## Kohomologi Čech pada gelanggang polinomial {#br-bgk-2019-l27-s01}

Misalkan $R$ gelanggang komutatif dan

$$
A=R[X_1,\ldots,X_n]
$$

gelanggang polinomial dalam $n$ variabel di atas $R$. Secara khusus, kita
dapat membayangkan kasus ketika $R$ adalah lapangan. Kita tinjau himpunan
terbuka

$$
U=\mathbb A_R^n\setminus V(X_1,\ldots,X_n)
=D(X_1,\ldots,X_n)
=\bigcup_{i=1}^nD(X_i),
$$

dan akan menggunakan liputan afin yang ditampilkan, dengan
$D(X_i)=\operatorname{Spek}(A_{X_i})$. Untuk suatu $A$-modul $M$, kompleks
Čech berkas $\widetilde M$ pada $U$ terhadap liputan ini berbentuk

$$
\prod_{1\leq i\leq n}M_{X_i}
\longrightarrow
\prod_{1\leq i<j\leq n}M_{X_iX_j}
\longrightarrow
\prod_{1\leq i<j<k\leq n}M_{X_iX_jX_k}
\longrightarrow\cdots
\longrightarrow M_{X_1\cdots X_n}
\longrightarrow0.
$$

Jadi

$$
\check C^p(D(X_i),\widetilde M)
=\prod_{1\leq i_0<i_1<\cdots i_p\leq n}
M_{X_{i_0}\cdots X_{i_p}},
$$

> **Catatan edisi - tanda relasi yang hilang.** Sumber yang dibekukan
> menampilkan `i_1<\cdots i_p`, tanpa tanda `<` lain sebelum `i_p`. Edisi
> mempertahankan tampilan itu persis dan tidak menyisipkan relasi yang tidak
> ada dalam sumber.

dan kohomologi Čech ke-$p$ adalah homologi kompleks yang dituliskan di atas.
Pada setiap komponen, pemetaannya hanyalah pemetaan kanonis ke dalam
pelokalan: pada tiap langkah satu variabel tambahan dijadikan penyebut.
Namun, pemetaan-pemetaan ini masih diberi tanda sesuai dengan definisi
kompleks Čech.

Kita akan mendeskripsikan kompleks ini dengan lebih terperinci untuk berkas
struktur, yakni ketika $M=A$. Untuk itu, berguna memecah kompleks menjadi
kompleks-kompleks yang lebih sederhana melalui gradasi monomial halus oleh
grup $\mathbb Z^n$. Mula-mula kita tinjau dimensi-dimensi kecil.

<!-- upstream_entity: Polynomring/2/Cech-Kohomologie/Beispiel -->

### Contoh 27.1: dua variabel {#br-bgk-2019-l27-exm-01}

Misalkan $A=R[X,Y]$. Kompleks Čech berkas struktur
$\mathcal O_{\mathbb A_R^2}$ pada
$U=D(X)\cup D(Y)\subset\mathbb A_R^2$ adalah

$$
0\longrightarrow A_X\times A_Y
\longrightarrow A_{XY}\longrightarrow0.
$$

Kompleks ini kompatibel dengan gradasi monomial halus. Komponen yang
bersesuaian dengan $(\alpha,\beta)\in\mathbb Z^2$ pada dasarnya bergantung
pada apakah kedua eksponen itu negatif atau tak negatif.

Jika $\alpha$ dan $\beta$ keduanya tak negatif, keseluruhan kompleks pada
komponen tersebut adalah

$$
(A_X\times A_Y)_{(\alpha,\beta)}
=R\cdot X^\alpha Y^\beta\oplus R\cdot X^\alpha Y^\beta
\longrightarrow R\cdot X^\alpha Y^\beta\longrightarrow0.
$$

Kompleks ini eksak pada suku di sebelah kanan, sedangkan kernel pada suku di
sebelah kiri isomorfik dengan $R\cdot X^\alpha Y^\beta$.

Jika $\alpha$ negatif dan $\beta$ tak negatif, atau sebaliknya, keseluruhan
kompleks adalah

$$
(A_X\times A_Y)_{(\alpha,\beta)}
=R\cdot X^\alpha Y^\beta\oplus0
\longrightarrow R\cdot X^\alpha Y^\beta\longrightarrow0,
$$

dan kompleks ini eksak. Jika $\alpha$ dan $\beta$ keduanya negatif,
keseluruhan kompleks adalah

$$
(A_X\times A_Y)_{(\alpha,\beta)}
=0\oplus0\longrightarrow R\cdot X^\alpha Y^\beta\longrightarrow0,
$$

dan homologi pada suku di sebelah kanan adalah $R\cdot X^\alpha Y^\beta$.
Dengan demikian,

$$
\check H^0(D(X),D(Y),\mathcal O_{\mathbb A_R^2})
=\bigoplus_{(\alpha,\beta)\in\mathbb N^2}
R\cdot X^\alpha Y^\beta=A
$$

dan

$$
\check H^1(D(X),D(Y),\mathcal O_{\mathbb A_R^2})
=\bigoplus_{(\alpha,\beta)\in\mathbb Z_-^2}
R\cdot X^\alpha Y^\beta.
$$

<!-- upstream_entity: Polynomring/3/Cech-Kohomologie/Beispiel -->

### Contoh 27.2: tiga variabel {#br-bgk-2019-l27-exm-02}

Misalkan $A=R[X,Y,Z]$. Kompleks Čech berkas struktur adalah

$$
0\longrightarrow A_X\times A_Y\times A_Z
\longrightarrow A_{XY}\times A_{XZ}\times A_{YZ}
\longrightarrow A_{XYZ}\longrightarrow0.
$$

Kompleks ini kompatibel dengan gradasi monomial halus. Di sini
$\check H^0=A$, lalu $\check H^1=0$ (lihat Teorema 27.3), dan
$\check H^2$ adalah modul $R$ bebas dengan basis

$$
X^iY^jZ^k,
\qquad (i,j,k)\in\mathbb Z_-^3.
$$

<!-- upstream_entity: Polynomring/n/Cech-Kohomologie/Berechnung/Fakt -->

### Teorema 27.3: kohomologi liputan tertusuk {#br-bgk-2019-l27-thm-01}

Misalkan $R$ gelanggang komutatif dan
$A=R[X_1,\ldots,X_n]$ gelanggang polinomial dalam $n\geq2$ variabel di atas
$R$. Maka kohomologi Čech berkas struktur pada himpunan terbuka
$U=D(X_1,\ldots,X_n)$ terhadap liputan
$D(X_i)$, $i=1,\ldots,n$, adalah

$$
\check H^p(D(X_i),\mathcal O_{\mathbb A_R^n})
=
\begin{cases}
A,&p=0,\\
0,&1\leq p\leq n-2,\\
\displaystyle\bigoplus_{\alpha\in\mathbb Z_-^n}
R\cdot X^\alpha,&p=n-1.
\end{cases}
$$

#### Bukti {#br-bgk-2019-l27-thm-01-proof}

Kita tinjau kompleks Čech dengan gradasi halus $\mathbb Z^n$ yang diberikan
oleh monomial. Untuk tupel tetap

$$
\alpha=(\alpha_1,\ldots,\alpha_n)\in\mathbb Z^n,
$$

misalkan $N=N_\alpha\subseteq\{1,\ldots,n\}$ himpunan indeks yang
komponennya negatif. Untuk $\alpha$ ini,

$$
\begin{aligned}
\bigl(\check C^p(D(X_i),\mathcal O_{\mathbb A^n})\bigr)_\alpha
&=\left(
\prod_{1\leq i_0<i_1<\cdots<i_p\leq n}
A_{X_{i_0}X_{i_1}\cdots X_{i_p}}
\right)_\alpha\\
&=\prod_{\substack{N\subseteq L\\\#(L)=p+1}}
R\cdot e_L\\
&\cong
\prod_{\substack{J\subseteq\{1,\ldots,n\}\setminus N\\
\#(J)=p+1-\#(N)}}R\cdot e_J.
\end{aligned}
$$

Identifikasi di tengah didasarkan pada fakta bahwa komponen dari
$A_{\prod_{i\in L}X_i}$ bernilai $0$ ketika $N\nsubseteq L$ dan bernilai
$R\cdot X^\alpha$ ketika $N\subseteq L$. Monomial $X^\alpha$ dalam
pelokalan ini bersesuaian dengan $e_L$. Dalam identifikasi di sebelah kanan,
$e_J$ bersesuaian dengan unsur basis $e_L=e_{N\cup J}$.

Jadi kompleks pada indeks $\alpha$ bersesuaian dengan kompleks binomial
menaik untuk himpunan indeks $\{1,\ldots,n\}\setminus N$ di atas gelanggang
$R$ (bukan $\mathbb Z$), tetapi tanpa satu suku bebas di sebelah kiri untuk
himpunan kosong.

Untuk $p=0$ dan sekurang-kurangnya satu eksponen negatif, di sebelah kanan
paling banyak terdapat satu $R\cdot X^\alpha$ yang terisolasi. Namun, karena
$n\geq2$, suku ini tidak dipetakan ke $0$, sehingga tidak menyumbang kepada
$H^0$. Sebaliknya, jika semua eksponen tak negatif, unsur-unsurnya berbentuk

$$
(c_1X^\alpha,\ldots,c_nX^\alpha),
$$

dan unsur ini dipetakan ke $0$ tepat ketika semua koefisien $c_i\in R$ sama.
Jadi kohomologi Čech ke-nol adalah gelanggang polinomial

$$
A=\bigoplus_{\alpha\in\mathbb N^n}R\cdot X^\alpha.
$$

Sekarang misalkan $p\geq1$. Jika $N\ne\{1,\ldots,n\}$, situasinya
isomorfik dengan kompleks binomial menaik pada himpunan indeks tak kosong.
Karena itu, menurut Lema Lampiran 8.11, homologinya trivial. Maka homologi
trivial untuk setiap $p$ di antara $1$ dan $n-2$.

Tinggal kasus $p=n-1$ dan $N=\{1,\ldots,n\}$. Ini tepat merupakan semua
$\alpha$ yang seluruh eksponennya negatif. Kompleksnya, yang bersesuaian
dengan kompleks binomial menaik pada himpunan kosong, adalah

$$
0\longrightarrow R\cdot X^\alpha\longrightarrow0.
$$

Oleh karena itu,

$$
H^{n-1}=\bigoplus_{\alpha\in\mathbb Z_-^n}R\cdot X^\alpha.
$$

## Kohomologi pada skema projektif {#br-bgk-2019-l27-s02}

<!-- upstream_entity: Projektiver Raum/Getwistete Strukturgarbe/Garbenkohomologie/Fakt -->

### Teorema 27.4: kohomologi berkas struktur terpuntir {#br-bgk-2019-l27-thm-02}

Misalkan $R$ gelanggang komutatif,
$A=R[X_0,X_1,\ldots,X_d]$ gelanggang polinomial dalam $d+1\geq2$ variabel
di atas $R$, dan

$$
\mathbb P_R^d=\operatorname{Proj}(A)
$$

ruang projektif yang bersesuaian. Maka kohomologi berkas struktur terpuntir
$\mathcal O_{\mathbb P_R^d}(n)$ adalah

$$
\check H^p(\mathbb P_R^d,\mathcal O_{\mathbb P_R^d}(n))
=
\begin{cases}
A_n,&p=0,\\
0,&1\leq p\leq d-1,\\
\displaystyle
\bigoplus_{\substack{\alpha\in\mathbb Z_-^{d+1}\\
\sum_{j=1}^{d+1}\alpha_j=n}}
R\cdot X^\alpha,&p=d.
\end{cases}
$$

#### Bukti {#br-bgk-2019-l27-thm-02-proof}

Pernyataan ini mengikuti dari Teorema 27.3.

Secara khusus, untuk berkas kanonis
$\mathcal O_{\mathbb P_R^d}(-d-1)$ (bandingkan Korolari 19.10),

$$
H^d(\mathbb P_R^d,\mathcal O_{\mathbb P_R^d}(-d-1))
=RX_0^{-1}X_1^{-1}\cdots X_n^{-1}\cong R,
$$

dan

$$
H^d(\mathbb P_R^d,\mathcal O_{\mathbb P_R^d}(n))=0
$$

untuk $n>-d-1$.

> **Catatan edisi - indeks pada pembangkit kanonis.** Sumber yang dibekukan
> menetapkan variabel $X_0,\ldots,X_d$, tetapi pembangkit pada tampilan di
> atas berakhir dengan $X_n^{-1}$. Edisi mempertahankan $n$ persis seperti
> sumber dan tidak menggantinya secara diam-diam dengan $d$.

<!-- upstream_entity: Projektiver Raum/Kohärente Garbe/Endlichkeitssatz/Fakt -->

### Teorema 27.5: keterhinggaan kohomologi pada ruang projektif {#br-bgk-2019-l27-thm-03}

Misalkan $\mathbb P_R^n$ ruang projektif di atas gelanggang Noether $R$ dan
$\mathcal F$ berkas koheren pada $\mathbb P_R^n$. Maka
$H^i(\mathbb P_R^n,\mathcal F)$ merupakan modul $R$ yang dibangkitkan secara
hingga.

#### Bukti {#br-bgk-2019-l27-thm-03-proof}

Untuk berkas struktur terpuntir $\mathcal O_{\mathbb P_R^n}(\ell)$,
pernyataan ini mengikuti dari Teorema 27.4. Karena itu, pernyataan yang sama
berlaku bagi jumlah langsung hingga berkas-berkas seperti itu.

Kita buktikan kasus umum dengan induksi menurun pada indeks kohomologis $i$.
Jika indeks ini lebih besar daripada $n$, menurut Teorema 26.10 hanya ada
kohomologi trivial. Jika $R$ berdimensi hingga, hal yang sama juga dapat
disimpulkan dari Teorema 25.12. Ini memberikan awal induksi.

Jadi, misalkan pernyataan telah dibuktikan untuk suatu $i$ dan setiap berkas
koheren. Ambil berkas koheren $\mathcal F$. Menurut Teorema 15.13, terdapat
jumlah langsung hingga

$$
\bigoplus_{j\in J}\mathcal O_{\mathbb P_R^n}(\ell_j)
$$

dan homomorfisme modul $\mathcal O_{\mathbb P_R^d}$ yang surjektif

$$
\bigoplus_{j\in J}\mathcal O_{\mathbb P_R^n}(\ell_j)
\longrightarrow\mathcal F.
$$

Misalkan $\mathcal G$ kernel pemetaan ini; menurut Soal 14.20, $\mathcal G$
juga koheren. Barisan kohomologi eksak panjang yang bersesuaian dengan barisan
pendek eksak berkas

$$
0\longrightarrow\mathcal G\longrightarrow
\bigoplus_{j\in J}\mathcal O_{\mathbb P_R^n}(\ell_j)
\longrightarrow\mathcal F\longrightarrow0
$$

memuat bagian

$$
\cdots\longrightarrow
H^{i-1}\!\left(\mathbb P_R^n,
\bigoplus_{j\in J}\mathcal O_{\mathbb P_R^n}(\ell_j)\right)
\xrightarrow{\epsilon}
H^{i-1}(\mathbb P_R^n,\mathcal F)
\xrightarrow{\delta}
H^i(\mathbb P_R^n,\mathcal G)
\longrightarrow\cdots.
$$

Darinya diperoleh barisan pendek eksak modul $R$

$$
0\longrightarrow\operatorname{im}\epsilon
=\ker\delta\longrightarrow
H^{i-1}(\mathbb P_R^n,\mathcal F)
\longrightarrow\operatorname{im}\delta\longrightarrow0.
$$

Menurut pengamatan sebelumnya dan hipotesis induksi,

$$
H^{i-1}\!\left(\mathbb P_R^n,
\bigoplus_{j\in J}\mathcal O_{\mathbb P_R^n}(\ell_j)\right)
\quad\text{dan}\quad
H^i(\mathbb P_R^n,\mathcal G)
$$

merupakan modul $R$ yang dibangkitkan secara hingga. Karena itu,
$\operatorname{im}\epsilon$ dan, menurut Teorema 10.4 dalam *Kurva Aljabar
(Osnabrück 2025-2026)*, $\ker\delta$ juga dibangkitkan secara hingga.
Menurut Lema 23.2 dalam *Aljabar Komutatif*,
$H^{i-1}(\mathbb P_R^n,\mathcal F)$ juga dibangkitkan secara hingga.

> **Catatan edisi - dua ketidakselarasan dalam bukti sumber.** Sumber menyebut
> homomorfisme yang ditampilkan sebagai homomorfisme modul
> $\mathcal O_{\mathbb P_R^d}$ meskipun sumber dan targetnya berada pada
> $\mathbb P_R^n$. Sumber juga menyatakan keterhinggaan
> $\ker\delta=\operatorname{im}\epsilon$, sedangkan suku hasil bagi dalam
> barisan pendek yang ditampilkan adalah $\operatorname{im}\delta$. Edisi
> mempertahankan kedua pernyataan sumber tanpa mengganti indeks atau objek
> secara diam-diam.

<!-- upstream_entity: Projektive Varietät/Quasikohärente Garbe/Vorschub/Fakt -->

### Teorema 27.6: kohomologi di bawah pembenaman tertutup {#br-bgk-2019-l27-thm-04}

Misalkan $X$ skema projektif di atas gelanggang Noether $R$, dengan
pembenaman tertutup $X\subseteq\mathbb P_R^n$ ke dalam suatu ruang
projektif. Misalkan $\mathcal G$ berkas kuasikoheren pada $X$, dan
$j_*\mathcal G$ berkas dorong majunya. Maka

$$
H^i(X,\mathcal G)=H^i(\mathbb P_R^n,j_*\mathcal G)
$$

untuk setiap $i$.

#### Bukti {#br-bgk-2019-l27-thm-04-proof}

Berkas dorong maju tersebut juga kuasikoheren. Menurut Teorema 26.10, kedua
ruas dapat dihitung dengan kohomologi Čech terhadap liputan afin standar
$D_+(X_s)$ pada ruang projektif dan liputan $X\cap D_+(X_s)$ pada $X$.
Seluruh kompleks Čech yang diperoleh sama, dan karena itu kohomologi Čechnya
juga sama.

<!-- upstream_entity: Projektive Varietät/Kohärente Garbe/Endlichkeitssatz/Fakt -->

### Teorema 27.7: keterhinggaan kohomologi pada skema projektif {#br-bgk-2019-l27-thm-05}

Misalkan $X$ skema projektif di atas gelanggang Noether $R$ dan
$\mathcal G$ berkas koheren pada $X$. Maka $H^i(X,\mathcal G)$ merupakan
modul $R$ yang dibangkitkan secara hingga.

#### Bukti {#br-bgk-2019-l27-thm-05-proof}

Pernyataan ini mengikuti dari Teorema 27.6 dan Teorema 27.5.

Perhatikan bahwa yang dibicarakan adalah modul $R$, bukan modul atas
gelanggang koordinat $X$. Dalam kasus terpenting, ketika $R=K$ adalah
lapangan, grup-grup kohomologi ini merupakan ruang vektor berdimensi hingga
di atas $K$. Dimensi-dimensinya adalah bilangan asli yang dikaitkan dengan
berkas koheren pada $X$ dan, dalam arti tertentu, mencirikan berkas tersebut.
Jika kita mengambil berkas struktur atau berkas tangen pada $X$, kita
memperoleh bilangan-bilangan, yakni invarian, yang mencirikan $X$ sendiri.
Dalam konteks ini digunakan singkatan

$$
h^i(\mathcal F)=\dim_K\bigl(H^i(X,\mathcal F)\bigr).
$$

Sebagai contoh, untuk kurva projektif mulus $X$ di atas lapangan $K$ yang
tertutup secara aljabar, dimensi ruang vektor $H^1(X,\mathcal O_X)$ disebut
*genus* kurva. Ini adalah invarian terpenting. Dalam kasus kompleks, terdapat
hubungan langsung dengan bentuk topologis kurva sebagai manifold kompleks
berdimensi satu dan manifold real berdimensi dua.

> **Catatan edisi - salah ketik pada sumber.** Dalam kalimat tentang modul di
> atas gelanggang koordinat, sumber Jerman menulis *Koordinatening*. Terjemahan
> menampilkan makna istilah tersebut sebagai "gelanggang koordinat" tanpa
> mengubah isi matematisnya.

## Karakteristik Euler {#br-bgk-2019-l27-s03}

<!-- upstream_entity: Projektives Schema/Körper/Garbe/Euler-Charakteristik/Definition -->

### Definisi 27.8: karakteristik Euler {#br-bgk-2019-l27-def-01}

Misalkan $X$ skema projektif di atas lapangan $K$. Untuk berkas koheren
$\mathcal G$, bilangan

$$
\chi(\mathcal G)
:=\sum_{i=0}^{\dim(X)}(-1)^ih^i(X,\mathcal G)
$$

disebut *karakteristik Euler* dari $\mathcal G$.

Menurut Teorema 27.7, ungkapan ini merupakan bilangan bulat yang
terdefinisi dengan baik. Karena kohomologi bernilai $0$ di atas dimensi,
jumlah berselang-seling tersebut juga dapat dijalankan hingga tak terhingga.

<!-- upstream_entity: Projektives Schema/Körper/Garbe/Euler-Charakteristik/Additivität/Fakt -->

### Lema 27.9: aditivitas karakteristik Euler {#br-bgk-2019-l27-lem-01}

Misalkan $X$ skema projektif di atas lapangan $K$. Karakteristik Euler berkas
koheren pada $X$ bersifat aditif terhadap barisan pendek eksak. Artinya,
untuk barisan pendek eksak berkas koheren

$$
0\longrightarrow\mathcal F\longrightarrow\mathcal G
\longrightarrow\mathcal H\longrightarrow0,
$$

berlaku

$$
\chi(\mathcal G)=\chi(\mathcal F)+\chi(\mathcal H).
$$

#### Bukti {#br-bgk-2019-l27-lem-01-proof}

Pernyataan ini mengikuti dari barisan kohomologi eksak panjang yang bersesuaian,
Teorema 25.12, dan rumus dimensi.
