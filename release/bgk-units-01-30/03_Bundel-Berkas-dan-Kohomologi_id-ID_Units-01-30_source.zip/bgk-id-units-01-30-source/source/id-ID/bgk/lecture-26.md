---
title: "Kuliah 26 - Kohomologi Čech"
stable_id: br-bgk-2019-l26
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 26"
upstream_pageid: 109030
upstream_revid: 793619
upstream_timestamp: "2022-08-25T06:24:38Z"
upstream_mediawiki_sha1: 006e9f6caaf060c5ec70ba24ce3d86023c0d7521
source_url: "https://de.wikiversity.org/w/index.php?oldid=793619"
lecture_xml: authority/wikiversity-bgk/unit-26/lecture-26.xml
lecture_xml_sha256: 2cb61aa26b63d6dc928cc69098e21f7f47edc1ffdf7330a647324ccf66f177f0
lecture_expanded_tex: authority/wikiversity-bgk/unit-26/lecture-26-expanded.tex
lecture_expanded_tex_sha256: 7ea6ff36700d0e25bc150052db32b312c4328653d54009cf10ebfc4bef713a8b
official_pdf_metadata: authority/wikiversity-bgk/unit-26/official-pdfs-api.json
official_pdf_metadata_sha256: c209d22600d20ebfe6f1479b1b6a9a0f20295711dab60905e6d35039c3ca6262
official_course_pdf: authority/artifacts/bgk-course-official.pdf
official_course_pdf_bytes: 2104862
official_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
official_course_pdf_printed_pages: "223-231"
course_authority_manifest: authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json
course_authority_manifest_sha256: ea0bf346e261db8ed80b7565f7746e95c79e0c376d25d9fbce5d96879dff7dd8
media_credits: source/id-ID/media-credits-bgk-unit-26.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
authority_manifest: authority/wikiversity-bgk/unit-26/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 7ed3c9a3a480daeb4332e9de8ff2251e43d3a43845df5744ef16aabac5f2c6b4
authority_manifest_status: "Bekuan authority terminal lengkap; 29 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
official_pdf: authority/artifacts/bgk-lecture-26-official.pdf
official_pdf_sha256: 4420d1401134f2d5871c4c5252531425c9c49bbfdcad513f6fcfe20bdcce94f5
official_pdf_source_bytes: 109882
official_pdf_source_sha1: 9e1bc7da807404defd70ceeaf558e9e63a6024aa
official_pdf_status: "Saksi PDF resmi lokal; identitas byte, SHA-256, SHA-1 unggahan, dan pemberitahuan hak komponen telah diverifikasi."
asset_closure: authority/ASSET_CLOSURE-bgk-unit-26.json
asset_closure_sha256: e9c1c7cf41349d4ae9d66f2e04cb9a214e5b453f41f536832a2af4103d55c1e3
media_rights: authority/RIGHTS-bgk-unit-26.csv
media_rights_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
media_credits_sha256: 3cfc1664f010b72c0ac540cbd35b74412a434788662fdc7c0f2a4cfe49abdcba
---

# Kuliah 26: Kohomologi Čech {#br-bgk-2019-l26}

Kita bertanya apakah pada ruang topologis hingga, yaitu ruang yang hanya
memiliki berhingga banyak titik, dapat terdapat kohomologi tak trivial. Jika
ruang itu diskret, yakni setiap titik terbuka sekaligus tertutup, hal itu tidak
mungkin karena setiap berkas pada ruang tersebut bersifat flasid. Pada spektrum
gelanggang valuasi diskret pun - dan, secara umum, pada ruang lokal seperti
spektrum gelanggang lokal - tidak mungkin terdapat kohomologi tak trivial.
Namun, kohomologi sudah muncul pada ruang dengan tiga unsur, seperti
ditunjukkan contoh berikut.

<!-- upstream_entity: Endlicher Raum/3 Punkte/Einer generisch/Generisch Z/Kohomologie/Beispiel -->

### Contoh 26.1: kohomologi pada ruang tiga titik {#br-bgk-2019-l26-exm-01}

Kita tinjau ruang topologis

$$
X=\{a,b,c\}
$$

dengan himpunan-himpunan terbuka

$$
\emptyset,\quad X,\quad U=\{a,c\},\quad V=\{b,c\},\quad
U\cap V=\{c\}.
$$

Ruang ini memiliki dua titik tertutup $a$ dan $b$, bersifat tak tereduksi,
dan $c$ adalah titik generiknya. Selain himpunan kosong, himpunan-himpunan
terbukanya membentuk diagram inklusi

$$
\begin{matrix}
X&\longleftarrow&U\\
\uparrow&&\uparrow\\
V&\longleftarrow&U\cap V.
\end{matrix}
$$

Suatu berkas grup komutatif pada $X$ diberikan dengan memasangkan grup dan
homomorfisme restriksi kepada subhimpunan-subhimpunan ini, kemudian memeriksa
syarat kompatibilitas. Kita tinjau berkas $\mathcal F$ yang diberikan oleh

$$
\begin{matrix}
0&\longrightarrow&0\\
\downarrow&&\downarrow\\
0&\longrightarrow&\mathbb Z.
\end{matrix}
$$

Berkas ini dapat dibenamkan ke dalam berkas konstan $\mathcal G$ (dengan
pemetaan identitas)

$$
\begin{matrix}
\mathbb Z&\longrightarrow&\mathbb Z\\
\downarrow&&\downarrow\\
\mathbb Z&\longrightarrow&\mathbb Z.
\end{matrix}
$$

Catatan edisi: sumber menamai berkas konstan pada kalimat ini `\mathcal F`,
tetapi segera memakai `\mathcal G/\mathcal F` dan `\Gamma(X,\mathcal G)`
sesudahnya. Edisi memakai `\mathcal G` untuk berkas konstan agar peran kedua
berkas tidak rancu.

Berkas hasil bagi $\mathcal G/\mathcal F$ diberikan oleh

$$
\begin{matrix}
\mathbb Z\times\mathbb Z&\xrightarrow{\ p_2\ }&\mathbb Z\\
{p_1}\downarrow&&\downarrow\\
\mathbb Z&\longrightarrow&0.
\end{matrix}
$$

Nilai pada $U\cap V$, $U$, dan $V$ langsung diperoleh dengan membentuk kelas
hasil bagi; berkasisasi tidak mengubahnya. Pada $X$ kita memperoleh produk
$\mathbb Z\times\mathbb Z$, sebab seksi pada $U$ dan $V$ otomatis kompatibel.
Karena itu pemetaan global

$$
\Gamma(X,\mathcal G)=\mathbb Z
\longrightarrow
\Gamma(X,\mathcal G/\mathcal F)=\mathbb Z\times\mathbb Z
$$

tidak surjektif. Barisan eksak panjang kohomologinya justru berbentuk

$$
0\longrightarrow 0\longrightarrow\mathbb Z
\longrightarrow\mathbb Z\times\mathbb Z
\xrightarrow{\ \delta\ }
H^1(X,\mathcal F)=\mathbb Z\longrightarrow 0.
$$

Di bagian depan, pemetaannya adalah $n\mapsto(n,n)$, sedangkan di bagian
belakang pemetaannya adalah $(r,s)\mapsto(r-s)$; hal terakhir mengikuti dari
keeksakan.

Pertanyaan penting dalam arah sebaliknya ialah apakah kohomologi suatu ruang
topologis yang rumit dapat ditangkap dan dihitung melalui data hingga. Dalam
banyak situasi hal ini memang dapat dilakukan melalui kohomologi Čech, yang
mengacu pada suatu penutup terbuka hingga beserta semua irisannya.

<!-- upstream_entity: Invertierbare Garbe/Übergangsabbildung/Motivation für Cech-Kohomologie/2/Beispiel -->

### Contoh 26.2: data pengeleman sebagai kompleks Čech {#br-bgk-2019-l26-exm-02}

Kita melanjutkan Catatan 20.2. Misalkan $(X,\mathcal O_X)$ ruang berdering,
dan kita tertarik pada berkas invertibel pada $X$, khususnya berkas yang
memiliki trivialisasi terhadap penutup terbuka tetap

$$
X=\bigcup_{i\in I}U_i.
$$

Berkas invertibel ini bersesuaian dengan kumpulan data

$$
\left(
U_i,
r_{ij}\in\Gamma(U_i\cap U_j,\mathcal O_X^\times)
\ \text{dengan}\
r_{kj}\,r_{ki}^{-1}\,r_{ji}=1
\ \text{di}\
\Gamma(U_i\cap U_j\cap U_k,\mathcal O_X^\times)
\right).
$$

Namun, kumpulan data seperti itu harus dipandang trivial jika terdapat
unsur-unsur

$$
s_i\in\Gamma(U_i,\mathcal O_X^\times)
$$

dengan

$$
s_i\,s_j^{-1}=r_{ij}
$$

untuk semua $i,j$. Seluruh situasi ini dapat dinyatakan melalui kompleks

$$
\prod_{i\in I}\Gamma(U_i,\mathcal O_X^\times)
\longrightarrow
\prod_{i<j}\Gamma(U_i\cap U_j,\mathcal O_X^\times)
\longrightarrow
\prod_{i<j<k}\Gamma(U_i\cap U_j\cap U_k,\mathcal O_X^\times),
$$

dengan menetapkan suatu urutan total pada $I$. Pemetaan pertama diberikan
oleh

$$
(s_i)\longmapsto(s_j s_i^{-1})_{i<j},
$$

dan pemetaan kedua oleh

$$
(r_{ij})\longmapsto(r_{jk}r_{ik}^{-1}r_{ij}).
$$

Suatu unsur di tengah termasuk kernel pemetaan kedua tepat ketika memenuhi
syarat kokikel, dan termasuk citra pemetaan pertama tepat ketika mewakili
berkas invertibel trivial.

## Kohomologi Čech {#br-bgk-2019-l26-s01}

Misalkan

$$
X=\bigcup_{i\in I}U_i
$$

penutup terbuka suatu ruang topologis $X$. Untuk subhimpunan $J\subseteq I$,
kita tetapkan

$$
U_J:=\bigcap_{i\in J}U_i.
$$

Jika $J\subseteq L\subseteq I$, maka $U_L\subseteq U_J$. Untuk berkas grup
komutatif $\mathcal G$ pada $X$, kita tinjau nilai-nilai
$\mathcal G(U_J)$ bagi berbagai $J$; kepada $J\subseteq L$ bersesuaian
pemetaan restriksi

$$
\mathcal G(U_J)\longrightarrow\mathcal G(U_L).
$$

Untuk $s\in\mathcal G(U_J)$, kita menulis secara ringkas

$$
s|_L=s|_{U_L},
$$

dan sering hanya menulis $s$. Kita tetapkan suatu urutan baik pada $I$
(terutama yang diperlukan ialah kasus $I$ hingga). Sekarang kita dapat
mendefinisikan kompleks Čech dan kohomologi Čech, yang merupakan alat penting
untuk menghitung kohomologi berkas.

<!-- upstream_entity: Garbe/Überdeckung/Cech-Komplex/Definition -->

### Definisi 26.3: kompleks Čech {#br-bgk-2019-l26-def-01}

Misalkan

$$
X=\bigcup_{i\in I}U_i
$$

penutup terbuka suatu ruang topologis $X$, dan $\mathcal G$ berkas grup
komutatif pada $X$. Untuk $k\in\mathbb N$, tetapkan

$$
\check C^k(\mathcal U,\mathcal G)
=
\prod_{\{J\mid \#(J)=k+1\}}\mathcal G(U_J),
$$

dan definisikan homomorfisme grup

$$
\delta_k:\check C^k(\mathcal U,\mathcal G)
\longrightarrow
\check C^{k+1}(\mathcal U,\mathcal G),
\qquad
s=(s_J)_J\longmapsto
\delta_k(s)=(\delta_k(s)_L)_L,
$$

melalui

$$
(\delta_k(s))_L
=\sum_{\ell=0}^{k+1}(-1)^\ell
s|_{L\setminus\{i_\ell\}},
$$

dengan $L=\{i_0,i_1,\ldots,i_{k+1}\}$ ditulis mengikuti urutan pada $I$.
Kompleks

$$
\check C^\bullet(\mathcal U,\mathcal G)
=
\bigl(\check C^k(\mathcal U,\mathcal G),\ k\geq 0,\ \delta_k\bigr)
$$

disebut *kompleks Čech* untuk berkas $\mathcal G$ dan penutup tersebut.

Untuk $k=0$ berlaku

$$
\check C^0(\mathcal U,\mathcal G)
=\prod_{i\in I}\mathcal G(U_i),
$$

dan untuk $k=\#(I)$ berlaku

$$
\check C^k(\mathcal U,\mathcal G)
=
\mathcal G\!\left(\bigcap_{i\in I}U_i\right).
$$

Jika $k>\#(I)$, himpunan indeks bagi $\check C^k(\mathcal U,\mathcal G)$
kosong dan suku tersebut sama dengan $0$. Untuk $k$ negatif, kompleks itu
juga ditetapkan sama dengan $0$. Bagi penutup dengan dua himpunan terbuka
$U$ dan $V$, kompleksnya adalah

$$
0\longrightarrow
\Gamma(U,\mathcal G)\times\Gamma(V,\mathcal G)
\longrightarrow
\Gamma(U\cap V,\mathcal G)
\longrightarrow 0.
$$

Bagi penutup dengan tiga himpunan terbuka $U,V,W$, kompleksnya adalah

$$
\begin{aligned}
0\longrightarrow{}&
\Gamma(U,\mathcal G)\times\Gamma(V,\mathcal G)\times
\Gamma(W,\mathcal G)\\
\longrightarrow{}&
\Gamma(V\cap W,\mathcal G)\times
\Gamma(U\cap W,\mathcal G)\times
\Gamma(U\cap V,\mathcal G)\\
\longrightarrow{}&
\Gamma(U\cap V\cap W,\mathcal G)
\longrightarrow 0.
\end{aligned}
$$

Untuk memahami homomorfisme-homomorfisme itu, bahkan dalam kedua kasus ini
berguna untuk memakai nama bernomor $U_1,U_2,U_3$.

<!-- upstream_entity: Garbe/Überdeckung/Cech-Komplex/Ist Komplex/Fakt -->

### Lema 26.4: kompleks Čech memang sebuah kompleks {#br-bgk-2019-l26-lem-01}

Kompleks Čech benar-benar merupakan sebuah kompleks.

#### Bukti {#br-bgk-2019-l26-lem-01-proof}

Misalkan $(s_J)_J\in\check C^k(\mathcal U,\mathcal G)$ suatu tupel. Untuk
himpunan indeks tetap

$$
L=\{i_0,i_1,\ldots,i_k,i_{k+1},i_{k+2}\},
$$

kita memperoleh

$$
\begin{aligned}
(\delta(\delta s))_L
&=\sum_{p=0}^{k+2}(-1)^p(\delta s)|_{L\setminus\{i_p\}}\\
&=\sum_{p=0}^{k+2}(-1)^p
\left(
\sum_{q=0}^{p-1}(-1)^q
s|_{(L\setminus\{i_p\})\setminus\{i_q\}}
+
\sum_{q=p+1}^{k+1}(-1)^{q+1}
s|_{(L\setminus\{i_p\})\setminus\{i_q\}}
\right)\\
&=\sum_{\{i_p,i_q\}\subseteq J}(-1)^{p+q}
\left(
s|_{L\setminus\{i_p,i_q\}}
-s|_{L\setminus\{i_p,i_q\}}
\right)\\
&=0.
\end{aligned}
$$

Perhatikan bahwa tanda di dalam kurung bergantung pada posisi $i_q$ dalam
$L\setminus\{i_p\}$.

<!-- upstream_entity: Garbe/Überdeckung/Cech-Kohomologie/Definition -->

### Definisi 26.5: kohomologi Čech {#br-bgk-2019-l26-def-02}

Misalkan

$$
X=\bigcup_{i\in I}U_i
$$

penutup terbuka suatu ruang topologis $X$, dan $\mathcal G$ berkas grup
komutatif pada $X$. Untuk $k\in\mathbb N$, *kohomologi Čech ke-$k$*

$$
\check H^k(\mathcal U,\mathcal G)
$$

didefinisikan sebagai homologi ke-$k$ dari kompleks Čech
$\check C^\bullet(\mathcal U,\mathcal G)$.

Seperti pada homologi setiap kompleks, pada tiap tempat kompleks kita
membentuk grup faktor kernel modulo citra. Unsur-unsur kernel ke-$k$ disebut
juga *kokikel Čech*, dan unsur-unsur citra ke-$k$ disebut juga *kobatas Čech*.
Unsur kohomologi Čech ke-$k$ yang berasal dari suatu kokikel Čech disebut
juga *kelas kohomologi Čech*. Grup kohomologi Čech ke-nol hanyalah
$\mathcal G(X)$, sebagaimana langsung mengikuti sifat berkas; lihat Soal
26.2.

<!-- upstream_entity: Kreis/Überdeckung/Möbiuszykel/Komplexe stetige Trivialisierung/Beispiel -->

### Contoh 26.6: kokikel pada lingkaran {#br-bgk-2019-l26-exm-03}

Pada lingkaran, kita tinjau penutup oleh dua segmen lingkaran terbuka, yang
masing-masing homeomorfik dengan interval real,

$$
S^1=U\cup V,
$$

dengan irisan

$$
U\cap V=S\cup T
$$

berupa gabungan dua interval. Kita tinjau beberapa berkas grup komutatif,
yang ditulis secara multiplikatif. Misalkan $h$ fungsi pada $U\cap V$ yang
bernilai konstan $1$ pada $S$ dan bernilai $-1$ pada $T$. Fungsi ini adalah
kokikel Čech tak trivial bagi berkas fungsi konstan lokal dengan nilai dalam
grup satuan $K^\times$ dari suatu lapangan $K$. Hal yang sama berlaku bagi
berkas fungsi kontinu dengan nilai dalam $\mathbb K^\times$, dengan
$\mathbb K=\mathbb R$ atau $\mathbb C$.

Apakah kokikel ini menentukan kelas kohomologi Čech tak trivial dalam

$$
\check H^1(\{U,V\},\mathcal G)
$$

ekuivalen dengan pertanyaan apakah terdapat fungsi - konstan lokal atau
kontinu, sesuai kasusnya -

$$
f:U\longrightarrow K^\times,
\qquad
g:V\longrightarrow K^\times
$$

dengan $h=fg^{-1}$. Dalam kasus konstan lokal, hal ini mustahil karena
fungsi konstan lokal pada segmen terhubung $U$ dan $V$ adalah konstan;
akibatnya $fg^{-1}$ pun konstan, jadi tidak sama dengan $h$. Untuk berkas
fungsi kontinu bernilai real yang tidak pernah nol, hal ini juga mustahil.
Dalam kasus tersebut, $f$ dan $g$ bertanda konstan, sehingga $fg^{-1}$ hanya
sesuai dengan $h$ pada tepat satu interval dari irisannya. Kelas kohomologi
Čech pertama tak trivial yang bersangkutan,

$$
[h]\in\check H^1(\{U,V\},C^0(-,\mathbb R^\times)),
$$

mewakili pita Möbius di atas lingkaran satuan.

Sebaliknya, dalam kasus kompleks, $h$ dapat ditulis sebagai hasil bagi dua
fungsi kontinu bernilai kompleks yang tidak pernah nol. Kita dapat mengambil
$g=1$ dan memilih $f$ yang bernilai konstan $1$ pada $S$, bernilai konstan
$-1$ pada $T$, dan di antaranya - yaitu pada $U\setminus\{S\cup T\}$ -
memilih nilai secara kontinu di sepanjang lingkaran satuan kompleks.

<!-- upstream_entity: Quasiaffines Schema/Modul/Cech-Komplex/Beispiel -->

### Contoh 26.7: kompleks Čech untuk modul pada skema kuasiafin {#br-bgk-2019-l26-exm-04}

Untuk gelanggang komutatif $R$ dan unsur-unsur $f_1,\ldots,f_n\in R$ yang
membangkitkan ideal $\mathfrak a$, terdapat penutup terbuka

$$
D(\mathfrak a)=\bigcup_{i=1}^nD(f_i)
$$

dari skema kuasiafin $D(\mathfrak a)\subseteq\operatorname{Spek}(R)$. Untuk
$R$-modul $M$, kompleks Čech berkas modul $\widetilde M$ pada
$D(\mathfrak a)$ dapat ditulis langsung tanpa memperhatikan proses
berkasisasi. Menurut Lema 14.5, bagi himpunan terbuka yang relevan berlaku

$$
\Gamma\!\left(
D\!\left(\prod_{i\in J}f_i\right),\widetilde M
\right)
=M_{\prod_{i\in J}f_i}.
$$

Karena itu kompleks Čech tersebut adalah

$$
0\longrightarrow
\prod_{1\leq i\leq n}M_{f_i}
\longrightarrow
\prod_{1\leq i<j\leq n}M_{f_if_j}
\longrightarrow
\prod_{1\leq i<j<k\leq n}M_{f_if_jf_k}
\longrightarrow\cdots.
$$

Menghitung homologi kompleks ini pada umumnya masih sulit, tetapi kini
sepenuhnya merupakan masalah aljabar komutatif.

## Kohomologi Čech dan kohomologi berkas {#br-bgk-2019-l26-s02}

Sekarang kita membahas situasi ketika kohomologi Čech untuk penutup tertentu
sama dengan kohomologi berkas yang “sebenarnya”, yakni yang didefinisikan
melalui resolusi injektif.

<!-- upstream_entity: Cech-Kohomologie/Abgeleitete Kohomologie/Endliche azyklische Überdeckung/Übereinstimmung/Fakt -->

### Lema 26.8: kohomologi Čech pertama dan kohomologi berkas {#br-bgk-2019-l26-lem-02}

Misalkan $\mathcal F$ berkas grup komutatif pada ruang topologis $X$, dan

$$
X=\bigcup_{i\in I}U_i
$$

penutup terbuka dengan

$$
H^1(U_i,\mathcal F)=0
\qquad\text{dan}\qquad
H^1(U_i\cap U_j,\mathcal F)=0
$$

untuk semua $i,j$. Maka

$$
\check H^1(U_i,\mathcal F)=H^1(X,\mathcal F).
$$

#### Bukti {#br-bgk-2019-l26-lem-02-proof}

Misalkan $\mathcal F\subseteq\mathcal I$ suatu pembenaman ke dalam berkas
injektif, dan

$$
0\longrightarrow\mathcal F\longrightarrow\mathcal I
\longrightarrow\mathcal H\longrightarrow 0
$$

barisan eksak pendek yang bersangkutan. Berdasarkan barisan eksak panjang
kohomologi - lihat Korolari 25.2 (3) - dan Teorema 24.8, berlaku

$$
H^1(X,\mathcal F)
=
\Gamma(X,\mathcal H)
/
\operatorname{bild}\bigl(
\Gamma(X,\mathcal I)\longrightarrow\Gamma(X,\mathcal H)
\bigr).
$$

Pertama-tama kita definisikan homomorfisme

$$
\Gamma(X,\mathcal H)
\longrightarrow
\check H^1(U_i,\mathcal F).
$$

Suatu seksi $t\in\Gamma(X,\mathcal H)$ menentukan restriksi
$t_i=t|_{U_i}$. Karena $\mathcal F$ tidak memiliki kohomologi pada $U_i$,
terdapat

$$
s_i\in\Gamma(U_i,\mathcal I)
$$

yang dipetakan ke $t_i$. Unsur-unsur, untuk $i<j$,

$$
r_{ij}:=s_i-s_j
$$

dipetakan ke $0$ dalam $\Gamma(U_i\cap U_j,\mathcal H)$, sehingga

$$
r_{ij}\in\Gamma(U_i\cap U_j,\mathcal F).
$$

Untuk indeks $i<j<k$ berlaku

$$
r_{ij}-r_{ik}+r_{jk}
=s_i-s_j-(s_i-s_k)+s_j-s_k=0.
$$

Jadi syarat kokikel terpenuhi. Keluarga $(r_{ij})_{i<j}$ merupakan kokikel
Čech dan menentukan unsur dalam $\check H^1(U_i,\mathcal F)$. Penetapan ini
tidak bergantung pada pilihan $s_i$ dan merupakan homomorfisme grup; lihat
Soal 26.5.

Sekarang misalkan $t\in\Gamma(X,\mathcal H)$ adalah citra suatu unsur global
$s\in\Gamma(X,\mathcal I)$. Kita dapat mengambil $s_i=s|_{U_i}$, sehingga
semua $r_{ij}$ yang dibangun dari $t$ sama dengan $0$. Jadi unsur seperti itu
dipetakan ke $0$. Menurut Teorema 47.4 (Lineare Algebra (Osnabrück
2024-2025)), kita memperoleh faktorisasi

$$
H^1(X,\mathcal F)
=
\Gamma(X,\mathcal H)
/
\operatorname{bild}\bigl(
\Gamma(X,\mathcal I)\longrightarrow\Gamma(X,\mathcal I)
\bigr)
\longrightarrow
\check H^1(U_i,\mathcal F).
$$

Sebaliknya, misalkan diberikan kokikel Čech pertama dari $\mathcal F$, yang
diwakili oleh

$$
(r_{ij})_{i<j}\in\Gamma(U_i\cap U_j,\mathcal F)
$$

dengan $r_{ij}-r_{ik}+r_{jk}=0$. Kita pandang $r_{ij}$ sebagai unsur dalam
$\mathcal I$, bahkan sebagai unsur global; hal ini dimungkinkan karena
sifat flasid berkas injektif. Kita definisikan

$$
s_i:=r_{i1}
$$

dengan $s_1=0$, dan memandangnya sebagai unsur dalam
$\Gamma(U_i,\mathcal I)$. Seksi-seksi ini memenuhi

$$
s_i-s_j=r_{i1}-r_{j1}=r_{ij}.
$$

Unsur-unsur $s_i$ menentukan unsur

$$
t_i\in\Gamma(U_i,\mathcal H).
$$

Karena selisihnya berasal dari $\mathcal F$, unsur-unsur itu kompatibel dan
menentukan unsur global

$$
t\in\Gamma(X,\mathcal H).
$$

Melalui homomorfisme penghubung $\delta$, ini menentukan kelas kohomologi

$$
\delta(t)\in H^1(X,\mathcal F).
$$

Jika kokikel Čech $r_{ij}$ diwakili oleh unsur-unsur lain
$s_i'\in\Gamma(X,\mathcal I)$, maka unsur-unsur $s_i-s_i'$, $i\in I$,
kompatibel karena

$$
(s_i-s_i')-(s_j-s_j')
=s_i-s_j-(s_i'-s_j')
=r_{ij}-r_{ij}=0,
$$

dan menentukan unsur global dalam $\Gamma(X,\mathcal I)$. Karena itu selisih
kedua representasi tersebut dipetakan ke $0$ dalam $H^1(X,\mathcal F)$.
Secara keseluruhan kita memperoleh pemetaan terdefinisi dengan baik

$$
\check Z^1(U_i,\mathcal F)
\longrightarrow
H^1(X,\mathcal F)
=
\Gamma(X,\mathcal H)
/
\operatorname{bild}\bigl(
\Gamma(X,\mathcal I)\longrightarrow\Gamma(X,\mathcal H)
\bigr).
$$

Sekarang misalkan kokikel Čech itu menentukan kelas nol dalam kohomologi Čech
pertama. Menurut definisi, terdapat unsur

$$
r_i\in\Gamma(U_i,\mathcal F)
$$

dengan

$$
r_i-r_j=r_{ij}.
$$

Sekali lagi kita pandang unsur-unsur itu sebagai unsur global dalam
$\mathcal I$, dan $r_i$ dapat langsung mengambil peran $s_i$ di atas. Maka
semua $t_i$ sama dengan $0$, sehingga citranya dalam $H^1(X,\mathcal F)$ juga
sama dengan $0$. Dengan demikian terdapat pemetaan

$$
\check H^1(U_i,\mathcal F)
\longrightarrow
H^1(X,\mathcal F).
$$

Pemetaan ini merupakan homomorfisme grup dan invers dari pemetaan yang
dibangun sebelumnya.

<!-- upstream_entity: Cech-Kohomologie/Abgeleitete Kohomologie/Endliche azyklische Überdeckung/Verbindender Homomorphismus/Übereinstimmung/Fakt -->

### Lema 26.9: perbandingan melalui resolusi asiklik {#br-bgk-2019-l26-lem-03}

Misalkan $\mathcal F=\mathcal F_0$ berkas grup komutatif pada ruang topologis
$X$, dan diberikan resolusi asiklik $\mathcal Z^\bullet$ dari $\mathcal F$
dengan barisan-barisan eksak pendek yang bersangkutan

$$
0\longrightarrow\mathcal F_n
\longrightarrow\mathcal Z_n
\longrightarrow\mathcal F_{n+1}
\longrightarrow 0.
$$

Misalkan

$$
X=\bigcup_{i\in I}U_i
$$

penutup terbuka dengan

$$
H^k\!\left(\bigcap_{i\in J}U_i,\mathcal F_n\right)=0
$$

untuk semua subhimpunan tak kosong $J\subseteq I$, semua $n\in\mathbb N$,
dan semua $k\in\mathbb N_+$. Maka

$$
\check H^k(U_i,\mathcal F)=H^k(X,\mathcal F).
$$

#### Bukti {#br-bgk-2019-l26-lem-03-proof}

Kita melakukan induksi pada $k$, serentak untuk semua $n$. Kasus $k=1$
telah ditangani dalam Lema 26.8, dan argumen berikut mengikuti lema itu. Kita
tinjau barisan eksak pendek

$$
0\longrightarrow\mathcal F
\longrightarrow\mathcal Z_0
\longrightarrow\mathcal F_1=\mathcal H
\longrightarrow 0
$$

beserta isomorfisme-isomorfisme

$$
H^k(X,\mathcal F)
=H^{k-1}(X,\mathcal H)
=\check H^{k-1}(U_i,\mathcal H).
$$

Isomorfisme kiri berasal dari homomorfisme penghubung dan sifat asiklik
$\mathcal Z_0$, sedangkan isomorfisme kanan berasal dari hipotesis induksi
yang diterapkan pada $\mathcal H$. Jadi tinggal ditunjukkan adanya
isomorfisme

$$
\check H^{k-1}(U_i,\mathcal H)
=\check H^k(U_i,\mathcal F).
$$

Suatu kelas di ruas kiri diwakili oleh tupel

$$
(t_J)\in
\prod_{\#(J)=k}\Gamma(U_J,\mathcal H)
$$

dengan syarat

$$
\sum_{\ell=0}^{k+1}(-1)^i
t_{L\setminus\{i_\ell\}}=0
$$

untuk semua subhimpunan $L\subseteq I$ yang beranggotakan $k+1$ unsur.
Karena penutup itu asiklik bagi $\mathcal F$, terdapat tupel

$$
(s_J)\in
\prod_{\#(J)=n}\Gamma(U_J,\mathcal Z)
$$

yang dipetakan ke $(t_J)$. Tupel ini selanjutnya menentukan tupel selisih
$(r_L)$, dengan $L$ menjelajahi subhimpunan $I$ yang beranggotakan $k+1$
unsur, melalui

$$
r_L:=\sum_{\ell=0}^{k+1}(-1)^\ell
s_{L\setminus\{i_\ell\}}.
$$

Karena $s_J$ dipetakan ke $t_J$, berdasarkan syarat di atas semua $r_L$
dipetakan ke $0$. Jadi

$$
(r_L)_L\in
\prod_{\#(L)=k+1}\Gamma(U_L,\mathcal F).
$$

Pertimbangan lebih lanjut menunjukkan bahwa tupel ini merupakan kokikel,
bahwa pemetaannya terdefinisi dengan baik, dan bahwa pemetaan itu merupakan
homomorfisme grup bijektif.

<!-- upstream_entity: Projektives Schema/Quasikohärente Garbe/Azyklische Überdeckung/Cech-Kohomologie/Fakt -->

### Teorema 26.10: kohomologi pada skema projektif {#br-bgk-2019-l26-thm-01}

Misalkan $(X,\mathcal O_X)$ skema projektif di atas gelanggang komutatif $R$,
dan misalkan $\mathcal F$ modul kuasikoheren pada $X$. Maka kohomologi berkas
$\mathcal F$ sama dengan kohomologi Čech terhadap penutup afin oleh
himpunan-himpunan $D_+(X_i)$.

#### Bukti {#br-bgk-2019-l26-thm-01-proof}

Misalkan $X_0,X_1,\ldots,X_n$ variabel-variabel gelanggang koordinat homogen
dari skema projektif $X$, sehingga

$$
X=\operatorname{Proj}(R[X_0,X_1,\ldots,X_n]/\mathfrak a).
$$

Semua irisan

$$
\bigcap_{i\in J}D_+(X_i)
=D_+\!\left(\prod_{i\in J}X_i\right)
$$

bersifat afin menurut Lema 12.9. Untuk $\mathcal F$ terdapat berkas
kuasikoheren flasid $\mathcal Z$ dengan barisan eksak pendek

$$
0\longrightarrow\mathcal F
\longrightarrow\mathcal Z
\longrightarrow\mathcal H
\longrightarrow 0.
$$

Menurut Soal 14.21, berkas hasil baginya kembali kuasikoheren. Menurut
Teorema 25.11, berkas kuasikoheren pada skema afin tidak mempunyai
kohomologi. Karena itu kita dapat menerapkan Lema 26.9.

Pernyataan yang sama berlaku untuk skema kuasiafin. Sifat yang menentukan
ialah bahwa irisan subhimpunan-subhimpunan afin kembali afin. Hal ini sering
berlaku, tetapi tidak berlaku bagi setiap skema.
