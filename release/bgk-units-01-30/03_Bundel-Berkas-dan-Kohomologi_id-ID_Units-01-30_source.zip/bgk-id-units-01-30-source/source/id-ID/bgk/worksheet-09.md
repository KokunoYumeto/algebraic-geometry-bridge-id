---
title: "Lembar Kerja 9 - Skema Afin"
stable_id: br-bgk-2019-w09
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Bocardodarapti"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 9"
upstream_pageid: 110216
upstream_revid: 612139
upstream_timestamp: "2020-01-24T13:09:58Z"
upstream_mediawiki_sha1: a70fb42219bb50825083085945efaa6970121bb4
source_url: "https://de.wikiversity.org/w/index.php?oldid=612139"
authority_manifest: authority/wikiversity-bgk/unit-09/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: 553255a52a560f0c4e14cf761409077d2b6788f2f8c9ace3e65b52743bfa3254
worksheet_xml: authority/wikiversity-bgk/unit-09/worksheet-09.xml
worksheet_xml_sha256: 3e54b9e5cd858ec47f05e0f36f8feb00a1afdaa5b971d70d7fa7221e888a135a
worksheet_expanded_tex: authority/wikiversity-bgk/unit-09/worksheet-09-expanded.tex
worksheet_expanded_tex_sha256: 6cf28466531ac280fb02918d082d502f3e052f64aa5077112ea28da64d4d1426
official_pdf: authority/artifacts/bgk-worksheet-09-official.pdf
official_pdf_sha256: 924a768074d08980319a8ca4d74d50a5716adaf6d35ea2dd74d6d45cf3438823
ordered_exercise_map: authority/wikiversity-bgk/unit-09/ORDERED_EXERCISE_MAP.json
ordered_exercise_map_sha256: 9d68f421350cc114427a681e7fc8c3b5701e535e0ba61f007b8fc654ebb38e3a
exercise_count: 13
public_solution_count: 0
media_credits: source/id-ID/media-credits-bgk-unit-09.md
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF resmi mempertahankan pemberitahuan komponen yang tercatat; tidak ada klaim pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Lembar Kerja 9: Skema Afin {#br-bgk-2019-w09}

Tidak satu pun dari 13 soal pada batas revisi yang dibekukan mempunyai solusi
publik. Tanda bintang solusi karena itu tidak digunakan dan edisi ini tidak
menciptakan solusi baru.

<!-- upstream_entity: Z/Spektrum/Globale Ringe/Halme/Aufgabe -->

## Soal 9.1 {#br-bgk-2019-w09-ex01}

Tentukan subgelanggang-subgelanggang $\mathbb Q$ yang muncul sebagai
gelanggang seksi pada $\operatorname{Spek}(\mathbb Z)$, dan tentukan
subgelanggang-subgelanggang yang muncul sebagai tangkai pada
$\operatorname{Spek}(\mathbb Z)$.

<!-- upstream_entity: Primzahlen/Teilmenge/Unterring von Q/Aufgabe -->

## Soal 9.2 {#br-bgk-2019-w09-ex02}

Misalkan $T\subseteq\mathbb P$ adalah subhimpunan bilangan-bilangan prima.
Buktikan bahwa

$$
R_T=\left\{
q\in\mathbb Q\ \middle|\
q\text{ dapat ditulis dengan penyebut yang hanya memuat bilangan prima dari }T
\right\}
$$

merupakan subgelanggang $\mathbb Q$. Apa yang diperoleh untuk

$$
T=\varnothing,
\qquad T=\{3\},
\qquad T=\{2,5\},
\qquad T=\mathbb P?
$$

<!-- upstream_entity: Unterringe von Q/Von 2/3 erzeugt/Aufgabe -->

## Soal 9.3 {#br-bgk-2019-w09-ex03}

Misalkan

$$
R=\mathbb Z\!\left[\frac{2}{3}\right]
$$

adalah subgelanggang $\mathbb Q$ yang dibangkitkan oleh $\mathbb Z$ dan
$2/3$. Buktikan bahwa $R$ memuat semua bilangan rasional yang dapat ditulis
dengan suatu pangkat $3$ sebagai penyebut.

<!-- upstream_entity: Kommutative Ringtheorie/Nenneraufnahme/Ein Element/Restklassendarstellung/Aufgabe -->

## Soal 9.4 {#br-bgk-2019-w09-ex04}

Misalkan $R$ gelanggang komutatif dan $f\in R$. Untuk pelokalan $R_f$ yang
terkait, buktikan isomorfisme aljabar-$R$

$$
R_f\cong R[T]/(Tf-1).
$$

<!-- upstream_entity: Nenneraufnahme/Element/Beziehung/Aufgabe -->

## Soal 9.5 {#br-bgk-2019-w09-ex05}

Misalkan $R$ gelanggang komutatif dan $f,g\in R$. Buktikan bahwa sifat-sifat
berikut ekuivalen.

1. $D(f)\subseteq D(g)$ di dalam spektrum $R$.
2. $\operatorname{rad}((f))\subseteq\operatorname{rad}((g))$.
3. $f\in\operatorname{rad}((g))$.
4. Ada $n\in\mathbb N$ dengan $f^n\in(g)$.
5. Unsur $g$ membagi suatu pangkat $f$.
6. Unsur $g$ merupakan satuan di $R_f$.
7. Ada homomorfisme aljabar-$R$

   $$
   R_g\longrightarrow R_f.
   $$

<!-- upstream_entity: Nenneraufnahme/f/Nilpotent/Aufgabe -->

## Soal 9.6 {#br-bgk-2019-w09-ex06}

Misalkan $R$ gelanggang komutatif, $f\in R$, dan $R_f$ pelokalan yang
terkait. Buktikan bahwa $f$ nilpoten tepat ketika $R_f$ adalah gelanggang
nol.

<!-- upstream_entity: Integritätsbereich/Schnittring/Durchschnitt von einfachen Nenneraufnahmen/Aufgabe -->

## Soal 9.7 {#br-bgk-2019-w09-ex07}

Misalkan $R$ domain integral dan

$$
U\subseteq X=\operatorname{Spek}(R)
$$

suatu himpunan terbuka. Buktikan bahwa

$$
\Gamma(U,\mathcal O_X)
=\bigcap_{\substack{f\ne0\\D(f)\subseteq U}}R_f,
$$

dengan irisan diambil di dalam lapangan pecahan $Q(R)$.

<!-- upstream_entity: Hauptidealbereich/Zwischenring in Quotientenkörper/Ist Nenneraufnahme/Aufgabe -->

## Soal 9.8 {#br-bgk-2019-w09-ex08}

Misalkan $R$ domain ideal utama dengan lapangan pecahan $Q=Q(R)$. Buktikan
bahwa setiap gelanggang antara

$$
R\subseteq S\subseteq Q
$$

merupakan suatu pelokalan dari $R$.

<!-- upstream_entity: Achsenkreuz/Punktiert/Hauptmenge/Aufgabe -->

## Soal 9.9 {#br-bgk-2019-w09-ex09}

Buktikan bahwa himpunan terbuka $U$ pada Contoh 9.6 memenuhi

$$
U=D(X+Y).
$$

Deskripsikan fungsi yang dibahas pada contoh tersebut dengan penyebut
$X+Y$.

> **Catatan edisi — predikat eliptis pada sumber.** Kalimat sumber secara
> harfiah berhenti pada padanan “buktikan bahwa untuk himpunan terbuka ...
> berlaku”. Tampilan yang menyusul adalah $U=D(X+Y)$; edisi menjadikannya
> predikat kalimat tanpa mengubah tugas.

<!-- upstream_entity: Faktorieller Integritätsbereich/Dimension ab 2/Punktiertes Spektrum/Schnittring/Aufgabe -->

## Soal 9.10 {#br-bgk-2019-w09-ex10}

Misalkan $R$ domain faktorisasi tunggal dan $\mathfrak m$ ideal maksimal
dengan tinggi

$$
\operatorname{ht}(\mathfrak m)\ge2.
$$

Buktikan bahwa pemetaan restriksi

$$
R=\Gamma(X,\mathcal O_X)
\longrightarrow
\Gamma(X\setminus\{\mathfrak m\},\mathcal O_X)
$$

bijektif.

<!-- upstream_entity: A-Singularität/Globale Funktionen/Aufgabe -->

## Soal 9.11 {#br-bgk-2019-w09-ex11}

Untuk

$$
R=K[X,Y,Z]/(XY-Z^n)
$$

dan

$$
U=D(X,Z)\subseteq\operatorname{Spek}(R),
$$

carilah fungsi-fungsi rasional yang terdefinisi pada $U$ tetapi tidak dapat
ditulis dengan satu penyebut optimal.

<!-- upstream_entity: Spektrum/Basismenge/Invertierbarkeitsmenge/Aufgabe -->

## Soal 9.12 {#br-bgk-2019-w09-ex12}

Misalkan

$$
X=\operatorname{Spek}(R)
$$

adalah spektrum gelanggang komutatif $R$ dan

$$
f\in R=\Gamma(X,\mathcal O_X).
$$

Buktikan bahwa $D(f)$ sama dengan lokus keterbalikan $X_f$.

<!-- upstream_entity: Ringhomomorphismus/Spektrumsabbildung/Morphismus lokal beringter Räume/Aufgabe -->

## Soal 9.13 {#br-bgk-2019-w09-ex13}

Misalkan

$$
\varphi:R\longrightarrow S
$$

homomorfisme gelanggang di antara gelanggang komutatif. Buktikan bahwa
pemetaan spektrum

$$
\varphi^*:\operatorname{Spek}(S)
\longrightarrow\operatorname{Spek}(R)
$$

dapat dilengkapi secara alami menjadi morfisme ruang berdering lokal.
