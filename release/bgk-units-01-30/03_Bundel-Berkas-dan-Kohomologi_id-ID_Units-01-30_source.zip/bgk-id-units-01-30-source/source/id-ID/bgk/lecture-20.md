---
title: "Kuliah 20 - Grup Picard"
stable_id: br-bgk-2019-l20
language: id-ID
source_course: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)"
source_author: "Holger Brenner"
frozen_revision_contributor: "Arbota"
upstream_title: "Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 20"
upstream_pageid: 109024
upstream_revid: 1070035
upstream_timestamp: "2026-02-06T08:44:37Z"
upstream_mediawiki_sha1: 69eee548900d7b7e00c3b3bd10e297a700800a89
source_url: "https://de.wikiversity.org/w/index.php?oldid=1070035"
authority_manifest: authority/wikiversity-bgk/unit-20/UNIT_AUTHORITY_MANIFEST.json
authority_manifest_sha256: a59a4536a441cfdbcd579525119112156fcc5dc8041ba97d4834e18db55cd658
authority_manifest_status: "Bekuan authority terminal lengkap; 32 catatan berkas telah dihitung ulang tanpa ketidakcocokan."
lecture_xml: authority/wikiversity-bgk/unit-20/lecture-20.xml
lecture_xml_sha256: 89f2acd9ed5baf48e76b4bedda9767e45546a9b9e725417401879012b277593b
lecture_expanded_tex: authority/wikiversity-bgk/unit-20/lecture-20-expanded.tex
lecture_expanded_tex_sha256: d6da653cd6ac86d23ed59507119788b38091b953ef26202512d3ce668c587e82
official_pdf: authority/artifacts/bgk-lecture-20-official.pdf
official_pdf_sha256: fae4d603a9f8f19f106c0e4e0c5960076c112796ec0d14dfb7f1e9e0c8c01cd9
official_pdf_status: "Saksi PDF resmi lokal; 96.088 byte, 7 halaman, dan SHA-1 unggahan 21addd9a85777481565a4bb28602c5f64fb9d966 telah diverifikasi."
official_pdf_metadata: authority/wikiversity-bgk/unit-20/official-pdfs-api.json
official_pdf_source_bytes: 96088
official_pdf_source_sha1: 21addd9a85777481565a4bb28602c5f64fb9d966
older_course_pdf: authority/artifacts/bgk-course-official.pdf
older_course_pdf_sha256: 87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c
authority_precedence: "Revisi semantik Wikiversity yang dibekukan mengendalikan teks; PDF seluruh kursus tahun 2020 hanya saksi historis."
media_credits: source/id-ID/media-credits-bgk-unit-20.md
rights_ledger: authority/RIGHTS-bgk-unit-20.csv
rights_ledger_sha256: 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d
asset_closure: authority/ASSET_CLOSURE-bgk-unit-20.json
asset_closure_sha256: 2cdfc5e32e86b5f704f1f00f6d5690166967464fbe2c6474086e28e470463b40
license: "Teks kursus semantik yang dibekukan dan terjemahan ini: CC BY-SA 4.0. PDF adalah saksi authority, bukan teks edisi; metadata Commons CC BY-SA 4.0 dan pemberitahuan tertanam CC-by-sa 3.0 dipertahankan tanpa pelisensian ulang menyeluruh."
non_endorsement: "Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun."
translation_status: complete
translation_provenance: "OpenAI Codex gpt-5.6-sol, Ultra."
---

# Kuliah 20: Grup Picard {#br-bgk-2019-l20}

## Grup Picard {#br-bgk-2019-l20-s01}

<!-- upstream_entity: Beringter Raum/Picardgruppe/Definition -->

### Definisi 20.1: grup Picard {#br-bgk-2019-l20-def-01}

Untuk ruang berdering $(X,\mathcal O_X)$, himpunan kelas isomorfisme
berkas-berkas invertibel pada $X$, dengan hasil kali tensor sebagai operasi,
berkas dual sebagai unsur invers, dan berkas struktur sebagai unsur netral,
disebut *grup Picard* dari $X$. Grup ini dilambangkan dengan

$$
\operatorname{Pic}(X).
$$

Pembahasan berikut mengenai data pengeleman suatu berkas invertibel di satu
sisi berkaitan dengan Soal 2.19 dan di sisi lain mengarah ke kohomologi
Čech.

<!-- upstream_entity: Invertierbare Garbe/Übergangsabbildung/Datensatz/Bemerkung -->

### Catatan 20.2: data transisi sebagai kokikel {#br-bgk-2019-l20-rem-01}

Misalkan $(X,\mathcal O_X)$ ruang berdering dan $\mathcal L$ berkas
invertibel pada $X$. Ini berarti terdapat penutup terbuka

$$
X=\bigcup_{i\in I}U_i
$$

dan trivialisasi-trivialisasi

$$
\varphi_i:\mathcal L|_{U_i}
\longrightarrow\mathcal O_X|_{U_i}.
$$

Untuk dua himpunan terbuka $U_i,U_j$, pada $U_i\cap U_j$ diperoleh pemetaan
transisi

$$
\varphi_i|_{U_i\cap U_j}
\circ
\varphi_j^{-1}|_{U_i\cap U_j}
:
\mathcal O_X|_{U_i\cap U_j}
\longrightarrow
\mathcal O_X|_{U_i\cap U_j}.
$$

Isomorfisme-isomorfisme ini diberikan (bandingkan Soal 13.8) oleh perkalian
dengan unit

$$
r_{ij}\in\Gamma(U_i\cap U_j,\mathcal O_X^\times).
$$

Karena data tersebut berasal dari satu berkas invertibel $\mathcal L$,
berlaku syarat kokikel

$$
r_{kj}r_{ji}=r_{ki},
$$

yang juga dapat ditulis sebagai

$$
r_{kj}r_{ki}^{-1}r_{ji}=1.
$$

Sebaliknya, suatu kumpulan data seperti itu kembali menentukan berkas
invertibel melalui pengeleman.

Jika berkas invertibel tersebut trivial, terdapat isomorfisme
$\mathcal O_X$-modul global

$$
\psi:\mathcal O_X\longrightarrow\mathcal L.
$$

Pada $U_i$ terdapat isomorfisme-isomorfisme

$$
\mathcal O_X|_{U_i}
\xrightarrow{\ \psi|_{U_i}\ }
\mathcal L|_{U_i}
\xrightarrow{\ \varphi_i\ }
\mathcal O_X|_{U_i},
$$

yang seluruhnya ditentukan oleh unit

$$
s_i\in\Gamma(U_i,\mathcal O_X^\times).
$$

Untuk unit-unit ini berlaku

$$
s_i s_j^{-1}
=(\varphi_i\circ\psi)\circ(\varphi_j\circ\psi)^{-1}
=r_{ij}
$$

untuk semua $i,j$. Sebaliknya, jika tersedia unit-unit $s_i$ yang
merealisasikan relasi tersebut, maka

$$
\psi|_{U_i}:=\varphi_i^{-1}\circ s_i
$$

menentukan isomorfisme modul pada $U_i$ yang kompatibel, sehingga semuanya
mengeleman menjadi isomorfisme global antara $\mathcal O_X$ dan
$\mathcal L$.

Jadi, berkas invertibel dapat diidentifikasi dengan kumpulan data
$(U_i,r_{ij})$ yang memenuhi syarat-syarat di atas; kumpulan data seperti itu
dipandang trivial apabila terdapat unit-unit $s_i$ dengan

$$
r_{ij}=s_i s_j^{-1}.
$$

<!-- upstream_entity: Invertierbare Garbe/Übergangsabbildung/Datensatz/Vorzeichenproblem/Bemerkung -->

### Catatan 20.3: persoalan tanda dalam deskripsi kokikel {#br-bgk-2019-l20-rem-02}

Identifikasi dalam Catatan 20.2 antara berkas invertibel dan kokikel di
dalam berkas unit tidak bersifat kanonik karena terdapat persoalan tanda.
Hal ini bergantung pada apakah trivialisasi lokal berkas invertibel terhadap
berkas struktur diambil dalam arah

$$
\varphi_i:\mathcal L|_{U_i}\longrightarrow\mathcal O_X|_{U_i}
$$

atau dalam arah sebaliknya, dan pada cara himpunan indeks diurutkan.

<!-- upstream_entity: Invertierbare Garbe/Übergangsabbildung/Datensatz/Multiplikation/Bemerkung -->

### Catatan 20.4: hasil kali tensor pada data transisi {#br-bgk-2019-l20-rem-03}

Pembentukan hasil kali tensor berkas-berkas invertibel $\mathcal L$ dan
$\mathcal L'$ dapat dilaksanakan pada tingkat kumpulan data dari Catatan 20.2.
Untuk itu, ambil
suatu penghalusan penutup bersama dan anggap kedua berkas mempunyai
trivialisasi terhadap satu penutup $U_i$, $i\in I$. Kumpulan data

$$
r_{ij}\cdot r'_{ij}
$$

kemudian mendeskripsikan hasil kali tensor.

Selanjutnya kita membatasi pembahasan pada skema.

<!-- upstream_entity: Lokaler Ring/Picardgruppe/Trivial/Fakt -->

### Lema 20.5: grup Picard gelanggang lokal {#br-bgk-2019-l20-lem-01}

Untuk gelanggang lokal $R$, grup Picard dari $\operatorname{Spek}(R)$
bersifat trivial.

#### Bukti {#br-bgk-2019-l20-lem-01-proof}

Hal ini trivial.

<!-- upstream_entity: Integres Schema/Invertierbar/Einbettung in Funktionenkörper/Fakt -->

### Lema 20.6: pembenaman ke dalam berkas lapangan fungsi {#br-bgk-2019-l20-lem-02}

Misalkan $(X,\mathcal O_X)$ skema integral. Setiap berkas invertibel pada $X$
isomorfik dengan suatu $\mathcal O_X$-submodul dari berkas lapangan fungsi
konstan.

#### Bukti {#br-bgk-2019-l20-lem-02-proof}

Misalkan $K$ lapangan fungsi $X$ dan $\mathcal K$ berkas yang terkait. Untuk
suatu berkas invertibel $\mathcal L$, tangkai di titik generik $\eta$
merupakan ruang vektor berdimensi satu atas $K$. Tetapkan suatu
isomorfisme-$K$

$$
\mathcal L_\eta=\mathcal K_\eta=K.
$$

Untuk setiap himpunan terbuka $U\subseteq X$, terdapat pemetaan alami

$$
\Gamma(U,\mathcal L)
\longrightarrow\mathcal L_\eta
\longrightarrow K.
$$

Pemetaan-pemetaan ini injektif (bandingkan bukti Lema 11.16) dan
mendefinisikan suatu submodul dari $\mathcal K$.

<!-- upstream_entity: Integres Schema/Invertierbarer Untermodul/Beschreibung/Bemerkung -->

### Catatan 20.7: deskripsi submodul invertibel {#br-bgk-2019-l20-rem-04}

Suatu submodul invertibel $\mathcal L$ dari berkas lapangan fungsi konstan
diberikan oleh suatu penutup terbuka $U_i$, $i\in I$, dari $X$, bersama
unsur-unsur tak nol $q_i\in Q$ yang memenuhi

$$
\frac{q_i}{q_j}
\in\left(\Gamma(U_i\cap U_j,\mathcal O_X)\right)^\times.
$$

Jika digunakan penutup $U_i$ yang men-trivialkan berkas, maka

$$
\mathcal L|_{U_i}\cong q_i\mathcal O_{U_i},
$$

dan dari pemetaan transisi pada irisan-irisan itu mengikuti bahwa hasil bagi
$q_i/q_j$ harus merupakan unit. Sebaliknya, jika tersedia kumpulan data
$(U_i,q_i)$ seperti itu, maka

$$
q_i\mathcal O_{U_i}\subseteq\mathcal Q_{U_i}
$$

merupakan subberkas trivial yang menentukan suatu subberkas invertibel pada
$X$.

Sudut pandang lain diperoleh dari barisan eksak berkas

$$
0\longrightarrow\mathcal O_X^\times
\longrightarrow\mathcal Q^\times
\longrightarrow\mathcal Q^\times/\mathcal O_X^\times
\longrightarrow0.
$$

Menurut Lema 5.9, kumpulan data yang dideskripsikan di atas merupakan seksi
global dari berkas hasil bagi
$\mathcal Q^\times/\mathcal O_X^\times$.

<!-- upstream_entity: Integres affines Schema/Invertierbar/Ideal/Fakt -->

### Lema 20.8: realisasi sebagai berkas ideal {#br-bgk-2019-l20-lem-03}

Misalkan $R$ domain integral. Setiap berkas invertibel pada

$$
X=\operatorname{Spek}(R)
$$

isomorfik dengan suatu berkas ideal.

#### Bukti {#br-bgk-2019-l20-lem-03-proof}

Menurut Lema 20.6, kita dapat langsung menganggap bahwa terdapat submodul
invertibel

$$
L\subseteq K
$$

dari lapangan pecahan $K=Q(R)$. Menurut Teorema 16.2, invertibilitas berarti
bahwa terdapat keluarga

$$
f_1,\ldots,f_k\in R
$$

sedemikian sehingga

$$
L_{f_i}\cong R_{f_i}\cdot q_i
$$

dengan $q_i\in K\setminus\{0\}$. Misalkan $b$ suatu penyebut bersama bagi
semua $q_i$. Pemetaan perkalian

$$
K\longrightarrow K,
\qquad q\longmapsto qb,
$$

yang merupakan isomorfisme $R$-modul dari $K$, memetakan submodul $L$ ke
suatu submodul isomorfik $L'$. Pada penutup yang diberikan, $L'$ merupakan
submodul berkas struktur, dan dengan
demikian merupakan suatu ideal.

Secara umum, terdapat banyak cara untuk merealisasikan suatu berkas
invertibel sebagai subberkas lapangan fungsi. Memang, dari satu realisasi
dapat diperoleh realisasi baru hanya dengan mengalikannya dengan suatu
$f\in K$.

<!-- upstream_entity: Projektiver Raum/Getwistete Strukturgarben/Untergarbe/Funktionenkörper/Beispiel -->

### Contoh 20.9: berkas struktur terpuntir di dalam berkas lapangan fungsi {#br-bgk-2019-l20-exm-01}

Pada ruang projektif $\mathbb P_K^d$ di atas lapangan $K$, suatu berkas
struktur terpuntir $\mathcal O_{\mathbb P_K^d}(\ell)$ dapat dibenamkan ke
dalam berkas lapangan fungsi $\mathcal Q$ sebagai berikut. Misalkan

$$
G\in K(X_0,\ldots,X_n)_{-\ell}
$$

unsur homogen berderajat $-\ell$. Pada setiap himpunan terbuka
$U\subseteq\mathbb P_K^d$, pemetaan alami

$$
\Gamma\!\left(U,\mathcal O_{\mathbb P_K^d}(\ell)\right)
\longrightarrow Q(\mathbb P_K^d),
\qquad s\longmapsto sG,
$$

merupakan suatu realisasi sebagai submodul.

> **Catatan edisi - indeks ruang dan variabel.** Sumber menamai ruang
> $\mathbb P_K^d$, tetapi menulis lapangan fungsi rasional dengan variabel
> $X_0,\ldots,X_n$. Edisi mempertahankan kedua indeks itu sebagaimana sumber.

<!-- upstream_entity: Integres Schema/Invertierbare Untergarben/Tensorierung und Produkt/Fakt -->

### Lema 20.10: hasil kali tensor dan hasil kali subberkas {#br-bgk-2019-l20-lem-04}

Misalkan $X$ skema integral dan

$$
\mathcal L,\mathcal M\subseteq\mathcal Q
$$

subberkas-subberkas invertibel dari berkas konstan $\mathcal Q$ untuk lapangan
fungsi $Q(X)$. Maka

$$
\mathcal L\otimes\mathcal M\cong\mathcal L\cdot\mathcal M,
$$

dengan $\mathcal L\cdot\mathcal M$ menyatakan subberkas dari $\mathcal Q$
yang, pada setiap titik $P\in X$, dibangkitkan pada tangkai oleh semua hasil
kali $fg$ dengan $f\in\mathcal L_P$ dan $g\in\mathcal M_P$.

#### Bukti {#br-bgk-2019-l20-lem-04-proof}

Untuk lapangan pecahan $Q$ dari suatu domain integral $R$, perkalian alami
memberi

$$
Q\otimes_RQ=Q.
$$

Karena itu, pada skema integral berlaku isomorfisme

$$
\mathcal Q\otimes_{\mathcal O_X}\mathcal Q\cong\mathcal Q.
$$

Dengan demikian terdapat homomorfisme alami

$$
\mathcal L\otimes_{\mathcal O_X}\mathcal M
\longrightarrow\mathcal Q
$$

melalui perkalian. Karena $\mathcal L$ dan $\mathcal M$ invertibel, pemetaan
ini secara lokal, dan karenanya secara global, merupakan isomorfisme ke
berkas citranya.

## Grup Picard dalam kasus faktorial {#br-bgk-2019-l20-s02}

<!-- upstream_entity: Faktorieller Integritätsbereich/Exponent/Lokalisierung/Fakt -->

### Lema 20.11: eksponen prima dapat dibaca setelah pelokalan {#br-bgk-2019-l20-lem-05}

Misalkan $R$ domain faktorisasi tunggal. Pernyataan-pernyataan berikut berlaku.

1. Untuk $f\in R$, $f\ne0$, berlaku

   $$
   (f)R_{(p)}=(p^s)
   $$

   jika dan hanya jika $p$ muncul dengan eksponen $s$ dalam faktorisasi
   prima $f$.

2. Dua ideal utama $(f)$ dan $(g)$ sama jika dan hanya jika, untuk setiap
   unsur prima $p$, ideal

   $$
   (f)R_{(p)}
   \quad\text{dan}\quad
   (g)R_{(p)}
   $$

   sama di dalam pelokalan $R_{(p)}$.

#### Bukti {#br-bgk-2019-l20-lem-05-proof}

Lihat Soal 20.4.

<!-- upstream_entity: Integres affines Schema/Faktoriell/Picardgruppe/Fakt -->

### Teorema 20.12: grup Picard domain faktorisasi tunggal {#br-bgk-2019-l20-thm-01}

Grup Picard suatu domain faktorisasi tunggal bersifat trivial.

#### Bukti {#br-bgk-2019-l20-thm-01-proof}

Misalkan $I\subseteq R$ ideal invertibel, dan misalkan

$$
X=\bigcup_{i=1}^nD(f_i)
$$

suatu penutup terbuka sedemikian sehingga $IR_{f_i}$ merupakan ideal utama.
Secara khusus, untuk setiap unsur prima $p$, ideal

$$
I_{(p)}\subseteq R_{(p)}
$$

merupakan ideal utama dan dengan demikian berbentuk $p^{s_p}$, karena
$R_{(p)}$ merupakan gelanggang valuasi diskret. Hanya berhingga banyak
$s_p$ yang tak nol. Memang, untuk suatu unsur $g\in I$, $g\ne0$, hanya ada
berhingga banyak pembagi prima, sedangkan untuk semua unsur prima $q$ yang
lain, $g$ merupakan unit di $R_{(q)}$.

Kita klaim bahwa $I$ sama dengan ideal utama yang dibangkitkan oleh

$$
h=\prod_pp^{s_p}.
$$

Karena kesamaan ideal dapat diuji secara lokal pada suatu penutup, kita dapat
berargumen di dalam $R_{f_i}$. Pernyataan tersebut kemudian mengikuti dari
Lema 20.11.

<!-- upstream_entity: Integres affines Schema/Noethersch/Faktoriell/Offene Teilmenge/Picardgruppe/Fakt -->

### Lema 20.13: grup Picard himpunan terbuka dalam kasus faktorial {#br-bgk-2019-l20-lem-06}

Misalkan $R$ domain faktorisasi tunggal dan Noether, dan
$U\subseteq\operatorname{Spek}(R)$ suatu himpunan terbuka. Maka grup Picard
dari $U$ bersifat trivial.

#### Bukti {#br-bgk-2019-l20-lem-06-proof}

Tuliskan

$$
U=D(f_1,\ldots,f_n).
$$

Kita melakukan induksi pada $n$; langkah awal jelas menurut Teorema 20.12.
Jadi, kita dapat menganggap bahwa $\mathcal L$ trivial pada

$$
D(f_1,\ldots,f_{n-1}).
$$

Menurut Catatan 20.2, berkas invertibel tersebut ditentukan oleh sebuah unit
di atas

$$
D(f_1,\ldots,f_{n-1})\cap D(f_n).
$$

Menurut Teorema 9.8, dalam kasus faktorial berkas struktur, dan dengan
demikian juga berkas unit, berbentuk sangat sederhana: suatu unsur $h\in R$
merupakan unit pada $U$ tepat ketika

$$
U\subseteq D(h).
$$

Karena itu, unit pada himpunan terbuka secara umum berbentuk

$$
h=u p_1^{r_1}\cdots p_s^{r_s},
$$

dengan $p_j\in R$ unsur-unsur prima, $u$ suatu unit dalam $R$, dan
$r_j\in\mathbb Z$. Unsur $h$ merupakan unit pada

$$
D(f_1,\ldots,f_{n-1})\cap D(f_n)
=D(f_1f_n,\ldots,f_{n-1}f_n)
$$

tepat ketika unsur-unsur $p_j$ yang terlibat, yakni yang mempunyai eksponen
$r_j\ne0$, membagi $f_if_n$. Ini berarti bahwa $p_j$ membagi $f_n$ atau
membagi semua unsur $f_1,\ldots,f_{n-1}$. Dalam kedua kasus, $h$ dapat
ditulis sebagai hasil kali suatu unit pada $D(f_1,\ldots,f_{n-1})$ dan suatu
unit pada $D(f_n)$. Dengan unit-unit tersebut, berkas dapat ditrivialkan.

<!-- upstream_entity: Integres Schema/Noethersch/Offene Teilmenge/Lokal faktoriell/Picardgruppe/Fortsetzung/Fakt -->

### Korolari 20.14: memperluas berkas invertibel {#br-bgk-2019-l20-cor-01}

Misalkan $(X,\mathcal O_X)$ skema integral Noether dan $U\subseteq X$ suatu
himpunan terbuka. Untuk setiap titik $P\in X\setminus U$, andaikan gelanggang
lokal $\mathcal O_{X,P}$ bersifat faktorial. Maka setiap berkas invertibel
$\mathcal L$ pada $U$ dapat diperluas menjadi berkas invertibel pada $X$.

#### Bukti {#br-bgk-2019-l20-cor-01-proof}

Misalkan $\mathcal L$ berkas invertibel pada $U$ dan $P\in X\setminus U$.
Ambil lingkungan afin terbuka

$$
W=\operatorname{Spek}(R)
$$

dari $P$, dengan $P$ bersesuaian dengan ideal prima $\mathfrak p$. Menurut
hipotesis, $R_{\mathfrak p}$ bersifat faktorial. Kita meninjau morfisme skema
injektif

$$
\operatorname{Spek}(R_{\mathfrak p})
\longrightarrow W\longrightarrow X.
$$

Himpunan terbuka $U$ beririsan tak kosong dengan $W$ dan dengan
$\operatorname{Spek}(R_{\mathfrak p})$; tuliskan irisan terakhir sebagai

$$
V\subseteq\operatorname{Spek}(R_{\mathfrak p}),
$$

karena titik generik $X$ bersesuaian dengan ideal nol dari
$R_{\mathfrak p}$. Berkas tarik balik pada $V$ trivial menurut Lema 20.13
dan berasal dari suatu $R_{\mathfrak p}$-modul, serta juga dari suatu
$R$-modul $L$. Karena dapat ditrivialkan, terdapat isomorfisme
$R_{\mathfrak p}$-modul

$$
R_{\mathfrak p}\longrightarrow L_{\mathfrak p}.
$$

Isomorfisme ini dapat diperluas ke suatu lingkungan terbuka

$$
P\in D(f)=W'\subseteq W.
$$

Dengan demikian diperoleh suatu perluasan $\mathcal L$ pada $U\cap W'$.
Karena itu, himpunan terbuka dapat diganti berturut-turut dengan himpunan
terbuka yang lebih besar tempat suatu perluasan tersedia. Karena sifat
Noether, proses ini berakhir pada seluruh ruang.

> **Catatan edisi - operasi himpunan dalam bukti sumber.** Kalimat sumber
> menyatakan bahwa perluasan ditemukan pada $U\cap W'$, lalu segera
> memperbesar himpunan terbuka. Edisi mempertahankan tanda irisan tersebut;
> secara logis, langkah memperbesar himpunan biasanya memerlukan
> $U\cup W'$.

Di bawah hipotesis di atas, homomorfisme restriksi alami

$$
\operatorname{Pic}(X)\longrightarrow\operatorname{Pic}(U)
$$

dengan demikian surjektif.

<!-- upstream_entity: An-Singularität/Picardgruppe/Beispiel -->

### Contoh 20.15: grup Picard singularitas $A_n$ yang tertusuk {#br-bgk-2019-l20-exm-02}

Tinjau gelanggang komutatif

$$
R=K[X,Y,Z]/(XY-Z^n)
$$

di atas lapangan $K$, dengan ideal maksimal

$$
\mathfrak m=(X,Y,Z),
$$

dan himpunan terbuka

$$
U=D(X,Y)=D(X)\cup D(Y)
=\operatorname{Spek}(R)\setminus\{\mathfrak m\}
\subseteq\operatorname{Spek}(R).
$$

Kita mempunyai

$$
R_X\cong K[X,X^{-1},Z]
$$

melalui $Y=Z^n/X$. Gelanggang ini merupakan domain faktorisasi tunggal;
karena itu, menurut Teorema 20.12, semua berkas invertibel pada $D(X)$
trivial, dan demikian pula pada $D(Y)$. Selanjutnya,

$$
R_{XY}=R_Z\cong K[X,X^{-1},Z,Z^{-1}].
$$

Jadi, suatu berkas invertibel pada $U$ ditentukan oleh isomorfisme

$$
K[X,X^{-1},Z,Z^{-1}]
\cong\mathcal O_U|_{D(XY)}
\longrightarrow
K[X,X^{-1},Z,Z^{-1}]
\cong\mathcal O_U|_{D(XY)},
$$

yang pada gilirannya bersesuaian dengan suatu unit dalam
$K[X,X^{-1},Z,Z^{-1}]$. Misalkan

$$
cX^iZ^j
$$

suatu unit seperti itu. Unit-unit yang berasal dari $R_X$ atau $R_Y$, dan
kombinasi multiplikatifnya, melalui Catatan 20.2 menghasilkan berkas
invertibel trivial. Grup kelas sisanya terdiri atas

$$
Z^j,
\qquad j=0,1,\ldots,n-1,
$$

sehingga grup Picard $U$ sama dengan $\mathbb Z/(n)$.

<!-- upstream_entity: Projektive Gerade/Picardgruppe/Beispiel -->

### Contoh 20.16: grup Picard garis projektif {#br-bgk-2019-l20-exm-03}

Tinjau garis projektif $\mathbb P_K^1$ di atas lapangan $K$ dengan penutup
standar

$$
\mathbb P_K^1=D_+(X)\cup D_+(Y),
$$

yang terdiri atas dua garis afin

$$
D_+(X)
=\operatorname{Spek}\!\left(K\left[\frac YX\right]\right)
\cong\mathbb A_K^1
$$

dan

$$
D_+(Y)
=\operatorname{Spek}\!\left(K\left[\frac XY\right]\right)
\cong\mathbb A_K^1.
$$

Menurut Teorema 20.12 dan Catatan 20.2, grup Picard garis projektif dapat
dihitung dengan mengambil unit-unit dalam

$$
\Gamma\!\left(D_+(XY),\mathcal O_{\mathbb P_K^1}\right)
=K\left[\frac XY,\frac YX\right]
$$

modulo unit-unit pada kedua potongan afin tersebut. Hasilnya ialah grup

$$
\left\{\left(\frac XY\right)^k\mathrel{\middle|}k\in\mathbb Z\right\},
$$

sehingga grup Picard isomorfik dengan $\mathbb Z$.

Pernyataan terakhir ini berlaku secara umum untuk ruang projektif
$\mathbb P_K^d$ dengan $d\geq1$; lihat Teorema 22.12.
