# Kredit media BGK Unit 8 {#agc-bgk-media-credits-unit-08}

Sumber kursus: **Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)**, Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 8 dan Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 8.

Sumber mendeklarasikan satu ilustrasi, `File:Spektrum_von_Z._xcf`, dengan pencipta `Bocardodarapti` dan label lisensi sebaris `CC-by-sa 4.0`. API Commons resmi mengembalikan halaman tersebut sebagai *missing*, HTML sumber menampilkannya sebagai media rusak, dan PDF resmi tidak memuat gambarnya. Karena tidak ada biner yang dapat diverifikasi, edisi tidak mengklaim telah memulihkan aset sumber.

Keterangan sumber yang dipertahankan: **Visualisasi spektrum bilangan bulat: titik-titik prima diskret, titik nol tebal sebagai titik rapat, dan garis penghubung yang menunjukkan objek berdimensi satu**. Teks alternatif edisi: Garis konseptual dengan titik-titik prima diskret dan titik nol yang ditebalkan untuk menggambarkan spektrum bilangan bulat.

Dua PDF resmi dibekukan hanya sebagai saksi authority; identitas, atribusi, lisensi, revisi, ukuran, dan hash keduanya tercatat dalam penutupan aset, bukan sebagai media pembaca.
