# Kredit media BGK Unit 29 {#br-bgk-2019-media-credits-unit-29}

Sumber kursus: **Kurs:Bündel, Garben und Kohomologie (Osnabrück
2019-2020)**, Kuliah 29. Tiga posisi media substantif mempertahankan identitas
Commons dan hak komponennya. Dua PDF resmi adalah saksi otoritas, bukan posisi
media pembaca tambahan.

1. **Torus, permukaan bergenus satu** — [File:Torus illustration.png](https://commons.wikimedia.org/wiki/File:Torus_illustration.png); pencipta/atribusi: Oleg Alexandrov; lisensi/status hak: Public domain.
   Teks alternatif: Permukaan torus berwarna hijau dengan satu pegangan, yaitu permukaan bergenus satu.
   Catatan hak: Label sebaris Wikiversity adalah PD; metadata Commons yang dibekukan menawarkan Public domain. Penggunaan ulang edisi ini mengikat opsi Commons tersebut.

2. **Torus ganda, permukaan bergenus dua** — [File:Double torus illustration.png](https://commons.wikimedia.org/wiki/File:Double_torus_illustration.png); pencipta/atribusi: Oleg Alexandrov; lisensi/status hak: Public domain.
   Teks alternatif: Permukaan torus ganda berwarna hijau dengan dua pegangan, yaitu permukaan bergenus dua.
   Catatan hak: Label sebaris Wikiversity adalah PD; metadata Commons yang dibekukan menawarkan Public domain. Penggunaan ulang edisi ini mengikat opsi Commons tersebut.

3. **Bola dengan tiga pegangan, permukaan bergenus tiga** — [File:Sphere with three handles.png](https://commons.wikimedia.org/wiki/File:Sphere_with_three_handles.png); pencipta/atribusi: Oleg Alexandrov; lisensi/status hak: Public domain.
   Teks alternatif: Permukaan hijau menyerupai bola dengan tiga pegangan, yaitu permukaan bergenus tiga.
   Catatan hak: Label sebaris Wikiversity adalah PD; metadata Commons yang dibekukan menawarkan Public domain. Penggunaan ulang edisi ini mengikat opsi Commons tersebut.
