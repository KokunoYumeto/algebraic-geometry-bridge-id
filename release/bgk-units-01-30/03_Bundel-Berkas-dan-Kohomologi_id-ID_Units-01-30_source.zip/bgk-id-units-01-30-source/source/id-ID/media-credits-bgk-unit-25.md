# Kredit media BGK Unit 25 {#br-bgk-2019-media-credits-unit-25}

Sumber kursus: Holger Brenner (Bocardodarapti), **Bündel, Garben und Kohomologie (Osnabrück 2019-2020)**. Identitas yang dibekukan: [Kuliah 25, revisi 1003754](https://de.wikiversity.org/w/index.php?oldid=1003754) dan [Lembar Kerja 25, revisi 613127](https://de.wikiversity.org/w/index.php?oldid=613127).

Unit ini tidak memiliki posisi media substantif untuk pembaca, sehingga tidak ada keterangan gambar atau teks alternatif komponen yang perlu ditambahkan. Dua berkas PDF resmi yang muncul pada permukaan parse dibekukan hanya sebagai saksi authority; identitas, atribusi, lisensi, revisi, ukuran, dan hash keduanya tercatat dalam penutupan aset, bukan sebagai media pembaca.

[Solusi publik Soal 25.1, revisi 1096264](https://de.wikiversity.org/w/index.php?oldid=1096264) mencantumkan atribusi sumber **im Wesentlichen Tarek Emmrich**; kontributor revisi yang dibekukan adalah Arbota. Kredit penulis dan kontributor sumber tetap dipertahankan.

Teks kursus semantik yang dibekukan dan terjemahan ini menggunakan CC BY-SA 4.0. Metadata Commons untuk kedua PDF resmi menyatakan CC BY-SA 4.0, sedangkan pemberitahuan yang tertanam dalam PDF menyatakan CC-by-sa 3.0. Kedua fakta komponen ini dipertahankan; edisi tidak membuat klaim pelisensian ulang menyeluruh.

Edisi Indonesia independen ini tidak menyiratkan dukungan dari penulis, Wikiversity, Wikimedia Foundation, atau lembaga sumber mana pun. Provenans terjemahan: OpenAI Codex gpt-5.6-sol, Ultra.
