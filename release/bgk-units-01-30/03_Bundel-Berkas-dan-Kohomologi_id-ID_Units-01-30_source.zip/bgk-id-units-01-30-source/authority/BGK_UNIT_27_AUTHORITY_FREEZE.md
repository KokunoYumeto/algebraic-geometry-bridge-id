# BGK Unit 27 - terminal authority freeze

Status: PASS. Scope: Brenner's *Bündel, Garben und Kohomologie (Osnabrück 2019-2020)*, not classical Unit 27. Frozen official semantic revisions remain controlling; historical PDFs do not replace them.

Lecture page 109031, revision 1070036, timestamp 2026-02-06T08:44:57Z, MediaWiki SHA-1 a18e6d008d7f2611f624cd1fae3c768a6c61585f; worksheet page 110236, revision 1070033, timestamp 2026-02-06T08:44:17Z, SHA-1 7e45c57c5d18d8ea176bc77a7b140587dbcc3bc1. All 131 lecture and 99 worksheet transclusions close without missing pages; all 30 manifest file records are rehashed.

The official lecture PDF has 7 pages and upload SHA-1 d842b6fdfc2c226877f0eb2d5652738e3dd2e028. The worksheet PDF has 5 pages and upload SHA-1 df5362a3e67d6cfb70f5a3656a698aacebd59d3e. Both byte counts, SHA-256 values, upload SHA-1 values, page counts, and embedded rights notices pass. Current Commons metadata states CC BY-SA 4.0; embedded PDF notices state CC-by-sa 3.0. Both component facts are preserved without blanket relicensing. The PDFs are authority witnesses, not reader-media positions. Reader media and local assets are zero; metadata, rights ledger, credits, and asset closure all bind exactly.

The unchanged Indonesian bodies preserve 9 lecture entities, 6 proofs, 14 ordered semantic exercises, no public source solutions, 14 explicit negative solution candidates, and 37 unique Unit 27 heading IDs. Historical course-PDF worksheet pages 238-239 have ten exercises; the current semantic worksheet has fourteen. The complete prior semantic/visual audit, its corrections, and all seven source anomalies remain in the translation QA. Five visible source-error notes are unchanged. All three post-YAML body hashes are identical before and after metadata repair; no mathematics, prose, identifiers, exercise, or solution content was rewritten.

Exact provenance: OpenAI Codex gpt-5.6-sol, Ultra. Original source-author/contributor credit, component rights, CC BY-SA 4.0 translation license, and non-endorsement remain intact.

Replay: python scripts/qa_bgk_unit_27_terminal.py --unit 27. This terminal record supersedes historical missing-tail observations and preflights. It makes no cumulative reader-build or publication claim.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| authority/wikiversity-bgk/unit-27/UNIT_AUTHORITY_MANIFEST.json | 103,610 | b6c2a7687ee2fcc20e6f2b5f58f1f97a665a8c1f9201d11308bb84f62a79c089 |
| authority/artifacts/bgk-lecture-27-official.pdf | 93,474 | 5b9a2585247113ae4f0d7d10c66124c4fba1831891abf3836f9939a47d9a3a99 |
| authority/artifacts/bgk-worksheet-27-official.pdf | 54,066 | 4c816be8bc38979b50742b9208a15ba1a338ddc46efa07bd5eef222535abccab |
| authority/commons-imageinfo-bgk-unit-27.json | 7,069 | c81933214661046a7899d80dec72324697ce7747f3e8068eb6463d6b5cbb6f2a |
| authority/RIGHTS-bgk-unit-27.csv | 1,051 | 87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d |
| authority/ASSET_CLOSURE-bgk-unit-27.json | 6,152 | 0eb449063c5dab73703a381246847c4deac31a20327bbe2a8a4c17b082e915ab |
| source/id-ID/bgk/lecture-27.md | 18,118 | 0f55bb4a49c1aeed5bfb75ff4e26c5ab33242ab6963bcd2d0c0a8455beb797f8 |
| source/id-ID/bgk/worksheet-27.md | 10,690 | 5284fff47e114ae4c7d1dee94378e9a017753d464275bb0be8e210b64348ef8d |
| source/id-ID/bgk/worksheet-27-solutions.md | 8,602 | 35e954258893337e82d9f543dc80d3802850dd577a737901f2c0e2af906ac627 |
| source/id-ID/media-credits-bgk-unit-27.md | 673 | dc3afa2d1b2e7c78a604bb54965bc45e4c56058c7585341e927d0e8e4a03f406 |
| qa/BGK_UNIT_27_AUTHORITY_QA.json | 3,949 | ced65e055c147c437b6beb3dfe464e8627230a4ed76840c762f1242055205900 |
| qa/BGK_UNIT_27_TRANSLATION_QA.json | 26,525 | 06b1cfd7f767e4c5a6f7b77472dae4346c5b968d003280ad16822ed33185ed98 |
