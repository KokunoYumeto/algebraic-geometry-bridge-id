# BGK Unit 22 — terminal authority freeze

Status: PASS. Official Holger Brenner, Bündel, Garben und Kohomologie (Osnabrück 2019–2020); BGK only, not classical Unit 22.

Lecture page 109026 / revision 1003751 / MediaWiki SHA-1 c81e7984c77ecb9624a5aa799029d3bbd3e80823; worksheet page 110230 / revision 1069409 / MediaWiki SHA-1 47f103239ec0db5780bf211ea257e727d72f3098. Terminal QA checks every declared manifest record, both transclusion closures, ordered exercise map, captured public solution 22.19, negative candidates, official PDF bytes/upload SHA-1/SHA-256 and embedded notices, and zero-media rights closure.

The Indonesian unit preserves 12 lecture entities, seven proofs, 20 ordered exercises, one public solution, 19 negative candidates, 47 unique heading IDs, and ten visible source-anomaly notes. The older official course PDF has 18 exercises: current 22.8–22.9 are subsequent semantic additions; the precise reconciliation remains in preserved semantic QA. All three mathematical bodies are byte-identical to the prior full semantic audit. Only source-binding metadata changes. Pandoc AST parses and provenance/license/non-endorsement checks pass.

Semantic text and translation: CC BY-SA 4.0. Commons PDF metadata: CC BY-SA 4.0; embedded PDF component notice: CC-by-sa 3.0. Preserve both facts without blanket relicensing. Reader-media positions: zero. Original author and revision-contributor credit and independent/non-endorsement statements remain intact. Exact provenance: OpenAI Codex gpt-5.6-sol, Ultra.

Replay: `python scripts/qa_bgk_unit_22_terminal.py`. Historical missing-tail observations are superseded by this terminal closure, not erased.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-22/UNIT_AUTHORITY_MANIFEST.json` | 123385 | `98e1716c4a8e95d42a19fd6a8b9efb04e222687e5bb6dc296ae42496baab1e39` |
| `authority/artifacts/bgk-lecture-22-official.pdf` | 98019 | `710a732e3683593615ad9a6a005504e207b173248f06b46539e20b9018dd886e` |
| `authority/artifacts/bgk-worksheet-22-official.pdf` | 59834 | `2d0e27c819584ea8c4e1fcb4c46a6f7c51ba3bd3f1a8467832fdea9f7d85d10a` |
| `authority/commons-imageinfo-bgk-unit-22.json` | 7069 | `20a06cbd9e680ee3372eef6f08d69e75d7ba25d368ad1cdce2ed526038f3ed96` |
| `authority/RIGHTS-bgk-unit-22.csv` | 1051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| `authority/ASSET_CLOSURE-bgk-unit-22.json` | 6152 | `e7bf39c238717349b7d2e02a8f05eb252fe6aa39199bce82a8c9f60d1b5ea718` |
| `source/id-ID/bgk/lecture-22.md` | 20513 | `e48d5e5b15a436f6705f19790b7d16b7db0bcaf83a234ce7970d3082691c9448` |
| `source/id-ID/bgk/worksheet-22.md` | 13891 | `6d61851d2c60390d43b276f4a81f8abf88c9c75791ac148349586ce658a5a4cb` |
| `source/id-ID/bgk/worksheet-22-solutions.md` | 4077 | `377c30a64386af9a36dd054c45ad4607e251da84a24e50ea2d1053667397d5a1` |
| `source/id-ID/media-credits-bgk-unit-22.md` | 673 | `7891001b0e40aef6f212c99aa0c1921d976a3e60049475f82272c8eda6a53b7f` |
| `qa/BGK_UNIT_22_AUTHORITY_QA.json` | 3964 | `ff315b48ce1e3fd1173ae00991c2d6042bfa79fa0621c3e42cad972f453310af` |
| `qa/BGK_UNIT_22_TRANSLATION_QA.json` | 29577 | `4259445c9e4f3a247e33079d8c2802198bdc5a6ffde193dd0f068444093b51a6` |
