# BGK Unit 7 authority freeze

Status: complete, bounded, and reproducible semantic/source authority for
Unit 7 of Holger Brenner's *Bündel, Garben und Kohomologie (Osnabrück
2019–2020)*. This document freezes the source identity and component surfaces;
it is not a translated reader and is not a publication by itself. The
deterministic authority QA receipt is `qa/BGK_UNIT_07_AUTHORITY_QA.json`.

## Semantic source identity

- Source project/API: German Wikiversity, namespace `Kurs`,
  `https://de.wikiversity.org/w/api.php`.
- Lecture: *Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019–2020)/Vorlesung
  7*, page 109011, revision 1003731, timestamp `2025-06-08T15:30:36Z`,
  MediaWiki SHA-1 `b0b4d8ab050e0948ecc6e3f8cb86a1c7091c1f3d`, oldid URL
  `https://de.wikiversity.org/w/index.php?oldid=1003731`.
- Worksheet: *Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019–2020)/
  Arbeitsblatt 7*, page 110212, revision 618943, timestamp
  `2020-02-16T12:35:13Z`, MediaWiki SHA-1
  `fe0e1a1fd6c0ca988bc7aea5d9f262f55f785aa1`, oldid URL
  `https://de.wikiversity.org/w/index.php?oldid=618943`.
- The complete recursive semantic closures contain 135/135 requested lecture
  transclusions and 111/111 requested worksheet transclusions, with zero
  missing pages. Exact API, XML, HTML, parse, expanded-TeX, and transclusion
  witnesses are under `authority/wikiversity-bgk/unit-07/`.
- Terminal `/latex` witnesses are lecture page 110015 revision 807074 and
  worksheet page 117162 revision 807044. Their derived terminal TeX witnesses
  are `lecture-07-expanded.tex` (19,238 bytes, SHA-256
  `b321142f917f6bf95e169b293cbd407288d59cd21266f09ad0174f0547a47189`) and
  `worksheet-07-expanded.tex` (9,508 bytes, SHA-256
  `5318e77fd0a3d79dbd08281bca06b39c6639940901fbf6aaf13fac16fd60d898`).
  These are terminal-byte witnesses; no recursive wrapper-template rebuild is
  claimed.
- Manifest:
  `authority/wikiversity-bgk/unit-07/UNIT_AUTHORITY_MANIFEST.json`, 108,655
  bytes, SHA-256
  `001074c62cedb1efc988d3214416d2d86a02976d5b22dc272f4fe064e72dfc95`.
  It declares 33 files; every declared byte count and SHA-256 was recomputed
  and matched. The capture identity is
  `authority/wikiversity-bgk/unit-07/CAPTURE_IDENTITY.json`.

## Exercises and lawful solutions

`ORDERED_EXERCISE_MAP.json` is 7,702 bytes, SHA-256
`309a1478ffcc6b7fdd02ddb72f29dca37d9d9ca8756737e7723d9bae148365c0`. It
contains exactly 21 worksheet exercises in source order. The frozen candidate
evidence records one public source solution, Exercise 7.14 (revision 1095144,
oldid `https://de.wikiversity.org/w/index.php?oldid=1095144`); the other 20
candidate solution pages are explicitly missing. The Indonesian edition
reproduces that one solution only and does not invent the remaining solutions.

## Official PDF witnesses and visual boundary

- Lecture PDF `authority/artifacts/bgk-lecture-07-official.pdf`: 86,367 bytes,
  SHA-256 `9be947907e8d819612a7c824fc7dd949ca447887547732769f967f27f19df43a`;
  Commons upload SHA-1 `832fd61cd9532edf2f5344cde13ab103dee69dba`; 7 A4 pages
  (612 × 792 points).
- Worksheet PDF `authority/artifacts/bgk-worksheet-07-official.pdf`: 50,692
  bytes, SHA-256 `a0cacead1e51ae62e560992c04bb9e519a1aaa85c8fd007d6756602bd594693f`;
  Commons upload SHA-1 `6e4581889133d19aef90e7172c787173f798b579`; 5 A4 pages
  (612 × 792 points).
- pypdf and Poppler agree on page counts and page boxes. Each final page
  carries the source image index and the embedded `CC-by-sa 3.0` notice naming
  Holger Brenner alias Bocardodarapti.

## Media and component rights

The parse surfaces expose only the two official PDFs; there are zero
substantive reader-media positions. The Commons rights freezer produced an
explicit zero-media closure:

- `authority/commons-imageinfo-bgk-unit-07.json`: current Commons metadata
  response, SHA-256 recorded in the closure below.
- `authority/RIGHTS-bgk-unit-07.csv`: empty reader-media ledger with its header
  and exact hash recorded in the closure below.
- `authority/ASSET_CLOSURE-bgk-unit-07.json`: `reader_media_positions=0` and
  `assets=[]`.
- `source/id-ID/media-credits-bgk-unit-07.md`: Indonesian credit note stating
  that the PDFs are authority witnesses rather than reader-media positions.

The current Commons descriptions identify the PDF components separately from
the embedded PDF notice. The semantic course and Indonesian derivative remain
bound to the course's CC BY-SA 4.0 terms with attribution, share-alike, and
non-endorsement. No blanket relicensing or endorsement claim is made.

## Bounded source findings for translation

1. The lecture begins with the source heading *Beringte Räume* and uses the
   related terms *beringter Raum*, *lokal beringter Raum*, *Halm*,
   *Restekörper*, *Auswertung*, and *Invertierbarkeitsort*. The Indonesian
   glossary keeps these as `ruang berdering`, `ruang berdering lokal`, `tangkai`,
   `lapangan residu`, `evaluasi`, and `lokus keterbalikan`, respectively.
2. The lecture's prose contains the capitalized source typo `IN einem lokal
   beringten Raum`; the translation records it as a source note while using
   normal Indonesian prose.
3. The lecture's gluing lemma writes the compatibility map as a homomorphism
   from `U_{ik} \cap U_{ij}` to `U_k`; the display is retained verbatim in
   mathematical content and explained without changing the source's indices.
4. The lecture's final lemma uses locality of the induced stalk homomorphism;
   the translation makes the implication explicit but does not add a new
   theorem or solution.

The correction and terminology ledgers retain the original wording, source
identity, and reason for every reader-facing clarification.

## Reproducibility checks

The accompanying QA receipt records exact source identity; complete
transclusion closure; terminal TeX witnesses; 21 ordered exercises with one
public solution and 20 negative candidates; exact PDF bytes, page geometry,
and embedded rights; zero reader media and separate component rights; a
complete manifest file closure; and `git_used=false` / `upstream_contacted=false`.
Model provenance for the receipt and subsequent translation is exactly
`OpenAI Codex gpt-5.6-sol, Ultra.`

Next action: translate this frozen Unit 7 in source order, preserving all 21
exercises, the single public solution, formulas, stable IDs, rights, and the
four visible source treatments; then run the per-unit translation gate before
the next cumulative BGK reader/backend/release cycle.
