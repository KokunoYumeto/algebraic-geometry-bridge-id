# BGK Unit 26 - terminal authority freeze

Status: PASS. This is Unit 26 of Holger Brenner's *Bündel, Garben und Kohomologie (Osnabrück 2019-2020)*, not classical Unit 26.

Lecture: page 109030, revision 793619, timestamp 2022-08-25T06:24:38Z, MediaWiki SHA-1 `006e9f6caaf060c5ec70ba24ce3d86023c0d7521`; worksheet: page 110235, revision 619292, timestamp 2020-02-17T10:05:10Z, MediaWiki SHA-1 `1d06dfb2baf64dec2ba57276ae62c90a99d239e1`. Both match the frozen complete course index. All 29 manifest records were rehashed; all 143 lecture and 69 worksheet transclusions close without missing pages.

Both official PDF witnesses are local and match the recorded source byte counts, upload SHA-1, and local SHA-256: lecture 109,882 bytes, 11 pages, upload SHA-1 `9e1bc7da807404defd70ceeaf558e9e63a6024aa`; worksheet 42,483 bytes, 3 pages, upload SHA-1 `9fc70f7c9c14609c747d19c3f6142cdc6ea47f5b`. Their embedded rights pages identify Holger Brenner alias Bocardodarapti and CC-by-sa 3.0. Current Commons metadata says CC BY-SA 4.0. Both facts are preserved separately; no blanket relicensing is inferred. The semantic course and Indonesian translation remain CC BY-SA 4.0 with original attribution and independent-edition non-endorsement.

The terminal replay preserves 10 numbered lecture entities, four proofs, eight ordered exercises, zero public source solutions, and eight explicit negative solution candidates. The three reader texts have 28 unique semantic heading IDs; the unchanged generated zero-media credit supplies the 29th Unit 26 heading. All 258 lecture and 40 worksheet Math nodes retain the exact ordered inventory hashes in the complete prior semantic audit. All three raw post-YAML bodies remain byte-identical; only YAML source-binding metadata changed. The prior full audit and eleven source anomalies are embedded unchanged as historical evidence. The visible Example 26.1 F/G disambiguation note remains intact. This replay does not claim to have repeated the previous rendered-course-PDF review of printed pages 223-232; it binds that review to unchanged bodies and validates the new dedicated source PDF identities and notices.

Reader media: zero. Manifest, Commons, rights ledger, generated credit, and asset-closure byte/hash bindings pass. Exact provenance: OpenAI Codex gpt-5.6-sol, Ultra.

Replay: `python scripts/qa_bgk_unit_26_terminal.py`. The initial mechanical source-metadata bind uses `--bind-metadata`; it preserves the original body and delimiter bytes. This terminal record supersedes earlier missing-capture-tail observations without rewriting their history. Shared integration, cumulative builds, backend QA, and publication remain owner work.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-26/UNIT_AUTHORITY_MANIFEST.json` | 93,476 | `7ed3c9a3a480daeb4332e9de8ff2251e43d3a43845df5744ef16aabac5f2c6b4` |
| `authority/artifacts/bgk-lecture-26-official.pdf` | 109,882 | `4420d1401134f2d5871c4c5252531425c9c49bbfdcad513f6fcfe20bdcce94f5` |
| `authority/artifacts/bgk-worksheet-26-official.pdf` | 42,483 | `082b40cf5174191581ab19561d7080a2519c1ddc67a2546e0ff4572e91227499` |
| `authority/commons-imageinfo-bgk-unit-26.json` | 7,071 | `e41861da6838c40493e953bebbad0075bb4d8772098d885c6bcc377379502577` |
| `authority/RIGHTS-bgk-unit-26.csv` | 1,051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| `authority/ASSET_CLOSURE-bgk-unit-26.json` | 6,155 | `e9c1c7cf41349d4ae9d66f2e04cb9a214e5b453f41f536832a2af4103d55c1e3` |
| `source/id-ID/bgk/lecture-26.md` | 24,267 | `bac98776ed886175e363777debd82bf58617c120332d56b41c8eddd037a1d55f` |
| `source/id-ID/bgk/worksheet-26.md` | 6,882 | `aa49d4f53eb0efa3f55326f3eaa154808eaa5905c3f36b87762d0576da385816` |
| `source/id-ID/bgk/worksheet-26-solutions.md` | 3,410 | `288508c8185d2962f207ecabd3092735674ba468b10153272c32e9e4bccaebf0` |
| `source/id-ID/media-credits-bgk-unit-26.md` | 673 | `3cfc1664f010b72c0ac540cbd35b74412a434788662fdc7c0f2a4cfe49abdcba` |
| `qa/BGK_UNIT_26_AUTHORITY_QA.json` | 3,945 | `1e9a3646ef9acbec9c410e825b07b6fdacb3f782f21841dbed7fc5f2b4200135` |
| `qa/BGK_UNIT_26_TRANSLATION_QA.json` | 27,917 | `fa851bd3c7cfcaf16eb948a047112823156a903e1335b6cddd92c0376376982d` |
| `scripts/qa_bgk_unit_26_terminal.py` | 13,759 | `f5f03d4ffb05dcf8c8158ed076976ee316caa76afa38d92857a9c3b85f74d354` |
