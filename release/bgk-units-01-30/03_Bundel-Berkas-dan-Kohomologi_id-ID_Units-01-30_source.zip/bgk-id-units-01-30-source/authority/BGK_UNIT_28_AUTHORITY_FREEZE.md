# BGK Unit 28 authority freeze

Status: admitted immutable source boundary for Unit 28 of Holger Brenner's
*Bündel, Garben und Kohomologie (Osnabrück 2019--2020)*. The complete
machine-readable closure is controlling; this note is its human-readable
index.

## Exact official source identity

- Course root: German Wikiversity `Kurs:Bündel, Garben und Kohomologie
  (Osnabrück 2019-2020)`, frozen root revision 1052895.
- Lecture: page 109032, revision 793621, timestamp
  `2022-08-25T06:24:58Z`, MediaWiki SHA-1
  `e7e7f2f42fcdd2f5fe1f284396867bf05a9ab815`, oldid URL
  `https://de.wikiversity.org/w/index.php?oldid=793621`.
- Worksheet: page 110237, revision 793599, timestamp
  `2022-08-25T06:21:18Z`, MediaWiki SHA-1
  `ea85b787c20468bfd111f5afe6022adb84c3e3d7`, oldid URL
  `https://de.wikiversity.org/w/index.php?oldid=793599`.
- Recursively expanded terminal TeX witnesses are
  `authority/wikiversity-bgk/unit-28/lecture-28-expanded.tex` (23,867 bytes,
  SHA-256
  `85df8cce341d0d4fe6d95086d52e1954ce90415f5eb556669f466f77457f6814`)
  and `authority/wikiversity-bgk/unit-28/worksheet-28-expanded.tex` (10,248
  bytes, SHA-256
  `4bb944ec5c5519518f1b5983de082ca0bcd4e149a788ecc57ec2da2633b769b8`).
  The closures contain 133/133 lecture and 100/100 worksheet transclusions,
  with zero missing terminal pages.
- Complete manifest:
  `authority/wikiversity-bgk/unit-28/UNIT_AUTHORITY_MANIFEST.json`, 103,052
  bytes, 32 declared files, SHA-256
  `1ab20936afe74fcfdde3318452f2211f2458911ff0a77c554fba894de49f4b9f`.

## Exercise and solution closure

`authority/wikiversity-bgk/unit-28/ORDERED_EXERCISE_MAP.json` proves exactly
14 exercises in worksheet order (5,748 bytes, SHA-256
`00380c3c1746989c8e7e12a8058732b96cd631c88a22750de4b174a5c884755e`).
Exactly Exercise 6 has a public solution; all other 13 literal candidate pages
are explicit negative results in
`worksheet-solution-candidates-api.json` (3,445 bytes, SHA-256
`807394ba76bba601f12d945c2cfbc3bc6579d4db2d2be826e071fa3158765166`).
The Exercise 6 solution is page 97324, revision 1096087, timestamp
`2026-06-15T07:54:14Z`, MediaWiki SHA-1
`d6a97c258f8c8bb412ae9882f3cadb995feace03`; its XML and HTML hashes are
`e06231e25c906968a28314cea9fbb24a305ffa1bd539fa43b5bd99dfe5f936bb`
and `a98d8bd5d73123530002aac1f0846e96435293214c215afbd686d62344fac3d7`.
No other source solution may be inferred or authored.

## Official PDF and component rights

- Lecture PDF: 91,578 bytes, seven pages, upload SHA-1
  `5ef810c1725a610856897801ebd53e876f35a8cf`, local SHA-256
  `f38e9f12ad1d5a6d715389f28e942b2e6ae93c2f336a8e97a9b1795cbafb392f`.
- Worksheet PDF: 57,192 bytes, five pages, upload SHA-1
  `7336c7f2c0afc12ba1cf18eceaf9e42d68966d54`, local SHA-256
  `663106b4ccb3fff4ef022fad226e0e9765deec1a39fa8e1d1c2b873886a728df`.
- The semantic pages' two image entries are these PDF witnesses, so Unit 28
  has zero substantive reader-media positions. Raw Commons metadata, the
  header-only rights ledger, Indonesian credits, and the asset closure have
  SHA-256 values
  `c21e90558886024f6820855b51f3e0c8bbd2bbdfc418af941eb66b44d1282342`,
  `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d`,
  `c8fcb670b164d17e5a1899ddd96aff706c64609d0916a1b12ca22a52c7f4c947`,
  and `0f6ca193721292bae43fd6b840b1aa7ca86280008377da039e2549fbbb42a282`.
- The semantic course surface is CC BY-SA 4.0. The official PDFs retain their
  own embedded component notice. The edition preserves those notices and
  makes no blanket relicensing claim.

## Source findings

The Indonesian unit retains 13 numbered lecture entities and five proof
bodies, all 14 exercises, and the sole public solution. Five visible source
notes disclose: a temporary restriction from `X_i` to `U` and a mismatched
projective-base subscript in the lecture; an `O(4)` title versus `O(3)` body;
an index starting at 1 although `s_0` is used; the proof of Theorem 28.8
switching without definition from base `R` to base `K`; and the solution's
unexplained `psi`/`phi` switch plus `b`/`d` coefficient slip. The displayed
mathematical treatment is stated explicitly and no defect is repaired silently.

Authority QA is `qa/BGK_UNIT_28_AUTHORITY_QA.json`, 3,961 bytes, SHA-256
`3975a233145e9ca5d8bf177e0063b5716dd80fb4c2e132adf1f6886abac8612d`,
status `PASS_COMPLETE_SEMANTIC_AUTHORITY_PDF_RIGHTS_ZERO_MEDIA`.
No Git command, upstream contact, credential access, build, or publication
occurred at this boundary. Derived-work provenance is
`OpenAI Codex gpt-5.6-sol, Ultra.`
