# BGK Unit 23 - terminal authority freeze

Status: PASS. Bound to the frozen official Brenner *Bündel, Garben und Kohomologie (Osnabrück 2019-2020)* course; not classical Unit 23.

Lecture page 109027, revision 1003752, MediaWiki SHA-1 `9425b65cf4737b7bb6ef15e87d9c2a637ff93d28`; worksheet page 110231, revision 991889, MediaWiki SHA-1 `ade4a516931ededdb1c721b98df2cf02dc9bac0c`. All 150 lecture and 94 worksheet transclusions close without missing pages. All 30 manifest file records are rehashed. Both official PDF witnesses match source bytes, upload SHA-1, and SHA-256 (9 lecture pages; 5 worksheet pages).

The semantic translation preserves 16 lecture entities, 11 proofs, 21 ordered exercises, no public source solutions, and 21 explicit negative solution candidates. All 55 semantic heading IDs are unique. All three post-YAML bodies remain byte-identical to the complete semantic translation audited on 2026-08-30. Only source-binding metadata was updated. Four visible source-error treatments and prior semantic audit evidence are retained in the translation QA, not silently discarded.

Reader media: zero. The semantic course text and translation are CC BY-SA 4.0; current Commons PDF metadata is CC BY-SA 4.0, while embedded PDF notices state CC-by-sa 3.0. Both component facts are preserved without blanket relicensing. Exact provenance: OpenAI Codex gpt-5.6-sol, Ultra. Original author/contributor credits and non-endorsement remain intact.

Replay: `python scripts/qa_bgk_unit_23_terminal.py`. This terminal record supersedes all earlier missing-tail preflights without changing their historical observations.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-23/UNIT_AUTHORITY_MANIFEST.json` | 105,713 | `96fb36e19dd3e6dcef56149150ce09c238843bee08ff36503d87a55284113775` |
| `authority/artifacts/bgk-lecture-23-official.pdf` | 88,712 | `dd1ea1b0f25c2d1b3988910761a2c0c4c217a5f8d4cfd8d0d0913c9078a84c3d` |
| `authority/artifacts/bgk-worksheet-23-official.pdf` | 43,316 | `35711c9254b2e357f190bf8bcb56b931edf68ec0b8e86e8b601cfbb25caca799` |
| `authority/commons-imageinfo-bgk-unit-23.json` | 7,069 | `a7e78b09989524110e60fc7b13aa68744434192d56ccb03f9b0dc23c1255af74` |
| `authority/RIGHTS-bgk-unit-23.csv` | 1,051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| `authority/ASSET_CLOSURE-bgk-unit-23.json` | 6,152 | `00673ca97e9a0caeca0bdf9bc02b1e18881dc5576ce2a9285cf904c503c189a7` |
| `source/id-ID/bgk/lecture-23.md` | 21,437 | `0b2c95d073a070863bb97646b83d596f5534a0b2739fedc1c39d1f9ee80131c0` |
| `source/id-ID/bgk/worksheet-23.md` | 9,817 | `567b343228c67a81bde1405e42ea543e25a2f06cc0b9a94e9d272d500840649b` |
| `source/id-ID/bgk/worksheet-23-solutions.md` | 2,211 | `aa2f9c056431bf9a7182d1ea011704274c949782af5c870efd99188061ee2d77` |
| `source/id-ID/media-credits-bgk-unit-23.md` | 673 | `d4dc96480e9f450ea3ab26af2ae90894daed1ee9369738acb0acacc96d71343f` |
| `qa/BGK_UNIT_23_AUTHORITY_QA.json` | 3,948 | `212a16c5f7f34c0e30fc82697fad46a3db6964b6f3355e601d158c87ab3ff99c` |
| `qa/BGK_UNIT_23_TRANSLATION_QA.json` | 14,351 | `f894185cec66619cbd99ca736515250199ebd96b2f5bdb909923504f9c2f8176` |
