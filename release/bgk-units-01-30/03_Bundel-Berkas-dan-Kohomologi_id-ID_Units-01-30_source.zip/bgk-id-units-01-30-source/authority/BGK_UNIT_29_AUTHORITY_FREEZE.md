# BGK Unit 29 authority freeze

Status: **PASS_COMPLETE_SEMANTIC_AUTHORITY_PDF_RIGHTS_MEDIA_COMPLETE**.

Audit snapshot: `2026-08-30T23:08:27.0262523Z`.

This narrative is limited to Unit 29 of Holger Brenner's German Wikiversity
course *Bündel, Garben und Kohomologie (Osnabrück 2019-2020)*. It describes
the already frozen authority and its current deterministic QA state. It does
not create a new capture, alter a translation, rebuild an artifact, or change
another unit.

## Frozen identity and closure

| Evidence | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json` | 34,279 | `ea0bf346e261db8ed80b7565f7746e95c79e0c376d25d9fbce5d96879dff7dd8` |
| `authority/wikiversity-bgk/unit-29/CAPTURE_IDENTITY.json` | 677 | `3c5b05da3599f81e9d5bbb29c7aca5f4df1dd4ad6a450dcca5d752833b06687a` |
| `authority/wikiversity-bgk/unit-29/UNIT_AUTHORITY_MANIFEST.json` | 125,779 | `376380a874b545579d61c100d1f66eac11bad854d76f7e586b10cd621e7a54f7` |
| `qa/BGK_UNIT_29_AUTHORITY_QA.json` | 4,581 | `985128685901f67d9b9ccc3882fffece159021a729d8ed7b3873d1bbaa964778` |

The unit manifest has schema `brenner-bgk-unit-authority-freeze-v1`, unit
number 29, authority namespace `authority/wikiversity-bgk`, artifact prefix
`bgk`, and frozen time `2026-08-31T00:32:34.477995+02:00`. It declares 37
non-manifest files. All 37 current file records were recomputed against the
unit directory with zero missing files, byte mismatches, or SHA-256
mismatches; the directory contains those 37 files plus the manifest itself.

The exact entry revisions are:

- Lecture: `Kurs:Bündel, Garben und Kohomologie (Osnabrück
  2019-2020)/Vorlesung 29`, page 109033, revision 1069570, timestamp
  `2026-02-06T07:06:34Z`, MediaWiki SHA-1
  `6c3afd8d6d4c0a4fac5ed90903c46b10ccab0aaa`.
- Worksheet: `Kurs:Bündel, Garben und Kohomologie (Osnabrück
  2019-2020)/Arbeitsblatt 29`, page 110238, revision 1069438, timestamp
  `2026-02-05T20:36:09Z`, MediaWiki SHA-1
  `fe4fc776bdfd80cb3337cfb807de3168abe73d09`.

## Semantic witnesses

| Surface | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-29/lecture-29.xml` | 7,987 | `2b6d1a6b75858ecfa71730685caa7499ec878ca4326208c9dfe38edbc2902a5b` |
| `authority/wikiversity-bgk/unit-29/lecture-29.html` | 116,219 | `345bc453e25f4684551e10b0a4959f23bbc1065f86ece3ee44be107f9925d9fe` |
| `authority/wikiversity-bgk/unit-29/lecture-29-expanded.tex` | 23,339 | `019ac2495bb9c5b2347c44c0332a8212b2946953dbd1aa519e7248c53103f06c` |
| `authority/wikiversity-bgk/unit-29/worksheet-29.xml` | 4,924 | `b298ec1566a1a1c1a3ba3bbc2606679ffba8ad2dfe9c8cd3d1269fc0c96e2ce4` |
| `authority/wikiversity-bgk/unit-29/worksheet-29.html` | 63,857 | `ebe56ba5a923835e889971450b8eba8108414dc0306fdecc557451c5c3649ae6` |
| `authority/wikiversity-bgk/unit-29/worksheet-29-expanded.tex` | 12,460 | `2243dc1483422ccc3747f4d924abf46f29e1d67cd6cd66ed06a3b9587ae79429` |

The lecture closure requested and captured all 161 exact template titles in
seven batches; the worksheet closure requested and captured all 129 exact
template titles in six batches. Both missing-page counts are zero. These
surfaces, rather than a reconstructed or current live page, control the
semantic source.

## PDF authority

| PDF witness | Pages | Bytes | SHA-256 | Frozen upload SHA-1 |
|---|---:|---:|---|---|
| `authority/artifacts/bgk-course-official.pdf` | 265 | 2,104,862 | `87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c` | Bound through the course manifest |
| `authority/artifacts/bgk-lecture-29-official.pdf` | 7 | 107,957 | `d612185a0afbeddd66a3c434dddac48679c00947723565a2367c08d2bc76dd15` | `e580ae1b185c39a37fa5df4180389669d43ea2f7` |
| `authority/artifacts/bgk-worksheet-29-official.pdf` | 5 | 59,987 | `112cba176b947010eb3e4ff2123b7b04756f06c579b61bb3826c284cff3533f0` | `09fa576a740f92fa0c4e619003bf695c50a5f734` |

`authority/wikiversity-bgk/unit-29/official-pdfs-api.json` is 1,983 bytes,
SHA-256
`5431a9d26306d4bd3591d3ab934752a566aac2e114d533bac0c2ea10c385d329`.
Its lecture upload timestamp is `2020-02-27T13:14:05Z`; its worksheet upload
timestamp is `2020-03-03T10:44:14Z`. The local byte counts equal the frozen
source byte counts.

Unit 29 occupies printed course-PDF pages 249--258, inclusive. All ten pages
were rendered and inspected in this audit:

- page 249 starts with the end of Unit 28, then begins Lecture 29, Definition
  29.1, the three genus images, and Example 29.2;
- page 255 ends the lecture at Definition 29.14 and begins Worksheet 29;
- pages 256 and 257 visibly mark Exercises 29.5 and 29.12 with stars;
- page 258 contains Exercises 29.13--29.15, after which Lecture 30 begins.

The relevant pages have no clipped content, overlap, missing formulas, broken
glyphs, or omitted Unit 29 exercise. The shared boundary pages are disclosed
so the range is not misrepresented as containing Unit 29 exclusively.

The unit PDFs retain an embedded `CC-by-sa 3.0` course notice on their final
pages (lecture page 7 and worksheet page 5). Their current frozen Commons
description metadata says `CC BY-SA 4.0`. Both component facts are preserved;
the PDFs are authority witnesses and are not counted as reader-media
positions.

## Exercise and public-solution closure

The worksheet has 15 ordered exercises. Public solutions exist for exactly
**Exercises 29.5 and 29.12** - the requested `5/12` coverage - and no others.
The remaining 13 exact `/Lösung` candidates, Exercises 29.1--29.4,
29.6--29.11, and 29.13--29.15, are frozen negative results. No solution was
invented.

| Closure evidence | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-29/ORDERED_EXERCISE_MAP.json` | 6,692 | `1ee8ba36620cda1bb7b7da82f277d42c0284c0c3858f368d517fc0206c00889c` |
| `authority/wikiversity-bgk/unit-29/worksheet-solution-candidates-api.json` | 12,320 | `c59b055e355a4622417b3bb3341b8c36221c7d5726348a62796cd9a43c8f4bda` |
| `authority/wikiversity-bgk/unit-29/solution-ex05.xml` | 6,154 | `119bb8ead8b4a00f4c0cd8c405d5b3b0248ba21a0264172e49604a4cf63b38e8` |
| `authority/wikiversity-bgk/unit-29/solution-ex05.html` | 18,588 | `99bc2e356cdb143feea7f3d7d38afcc91128e99f9acf676ab5e44c087e634273` |
| `authority/wikiversity-bgk/unit-29/solution-ex12.xml` | 9,900 | `1c775f102fbbff3abebe06129a1bc963c64f3ff446163aff22fa6832390c6a0c` |
| `authority/wikiversity-bgk/unit-29/solution-ex12.html` | 42,876 | `c2a5f0a4a22795e0072ac6ccd96b18c5ea421347c266c390cf761c9196198b56` |

The Exercise 29.5 solution is page 96768, revision 1096531, timestamp
`2026-06-15T09:05:05Z`, MediaWiki SHA-1
`a29ee211b9f7695de50dab32bbf7d363844eded6`. The Exercise 29.12 solution is
page 116035, revision 1095413, timestamp `2026-06-14T18:37:49Z`, MediaWiki
SHA-1 `3a7d36bb78a33db5ca7e00800b142cd643302e61`.

## Three public-domain reader assets and exact source positions

All three reader-media positions occur together on printed course-PDF page
249, immediately after Definition 29.1's definition of genus and before
Example 29.2. The hash-bound expanded source places them in this order at
`lecture-29-expanded.tex:57-77`; the frozen HTML places them at
`lecture-29.html:29-31`; the Indonesian target preserves the same order at
`source/id-ID/bgk/lecture-29.md:52-56`.

| Order | Frozen Commons component and source label | Local reader asset | Dimensions | Bytes | SHA-256 | Rights |
|---:|---|---|---:|---:|---|---|
| 1 | `File:Torus illustration.png`; `Torus illustration.png` | `authority/assets/bgk-torus-illustration-500.png` | 500 x 330 | 80,109 | `bc41c24f82c089084af3cedb0c03c5810d68e449be14507f74ba1b8df1c0394c` | Public domain; Oleg Alexandrov; `{{PD-self}}` |
| 2 | `File:Double torus illustration.png`; `Double torus illustration.png` | `authority/assets/bgk-double-torus-illustration-500.png` | 500 x 547 | 112,276 | `072f31ce4314f68943b5ad887972dc9bc499a17c07f43a5c0f1129ce3cfdba13` | Public domain; Oleg Alexandrov; `{{PD-self}}` |
| 3 | `File:Sphere with three handles.png`; `Sphere with three handles.png` | `authority/assets/bgk-sphere-with-three-handles-500.png` | 500 x 384 | 113,133 | `f8262902f0a343f01bee76890218d42ca6fb282dcd95228af97cef302df5714a` | Public domain; Oleg Alexandrov; `{{PD-self}}` |

These are the official Commons 500-pixel PNG thumbnails, each a single-frame
bitmap. The original upload identities retained by the rights ledger are:

- torus: 150,645 bytes, upload SHA-1
  `40b8981eb5d3c98f12109b57b0f281e7a0f6dbc0`;
- double torus: 266,030 bytes, upload SHA-1
  `87ef1565f0a904b7ff52022b44a3ca2265339c58`;
- sphere with three handles: 398,740 bytes, upload SHA-1
  `6890fd8dbe8f2a238b2629531380e3dcbaa792eb`.

The source course labels all three `PD`; the frozen Commons descriptions say
`Public domain` and contain `{{PD-self}}`. The closure binds the Commons option
for reuse rather than treating the course-wide CC license as a blanket
relicense of these components.

| Media/right evidence | Bytes | SHA-256 |
|---|---:|---|
| `authority/commons-imageinfo-bgk-unit-29.json` | 21,876 | `cf5bf32d60d9016d291b8a7f168fe73f58cf762752aa40640164e48b4e12c4c8` |
| `authority/RIGHTS-bgk-unit-29.csv` | 5,740 | `23b9e508c44e8c0645857850e760daf06b23f46cf51fc490b1f2ee5ef402ad43` |
| `authority/ASSET_CLOSURE-bgk-unit-29.json` | 12,019 | `059d46bfd920bc91189676244eb563d217765772cb20e54dd14e97eb9420c421` |
| `source/id-ID/media-credits-bgk-unit-29.md` | 1,820 | `c73bf04a8da39c6cc692f0c11352d709fb227c8ee33e0f253333248272945dfe` |

The asset closure's live reader-credit pointer now records the same 1,820
bytes and SHA-256 shown above. The current authority QA was rerun after that
correction and binds the current closure SHA-256, so there is no remaining
stale cross-reference in the evidence chain.

## Translation audit boundary

Translation is complete, but this authority narrative does not modify it.
`qa/BGK_UNIT_29_TRANSLATION_QA.json` is 3,302 bytes, SHA-256
`6a74948d82d5786772e4c31a4f733da9d41522e3f061d5de60470c42074bccc1`,
status `PASS`. It binds:

| Current Indonesian target | Bytes | SHA-256 |
|---|---:|---|
| `source/id-ID/bgk/lecture-29.md` | 16,941 | `35374bf83dfbe3a33567d8fa99acad12cca79968e629f13ad5ec156fd7af0b99` |
| `source/id-ID/bgk/worksheet-29.md` | 9,571 | `9fc3540416b3665a9459bef784baca84a6f6d96d9a413c2740fdc7d15b17ad75` |
| `source/id-ID/bgk/worksheet-29-solutions.md` | 11,242 | `9e507a69b75997f4d496649fb179fd15b7b0ca5c65ca463b55a6aaa6e3c1bee6` |

The translation QA records 14 numbered lecture entities, four semantic proof
bodies, all 15 exercises, two translated public solutions (29.5 and 29.12),
13 negative solution candidates, zero invented solutions, three reader-media
positions, three unique local assets, and zero heading-ID collisions.

## Truthful terminal status

The frozen semantic authority, 37-file manifest closure, complete course-PDF
span, two unit PDFs, exact `5/12` public-solution topology, three public-domain
reader assets, component rights, media credits, and both current QA receipts
are present and hash-consistent. The current deterministic status is therefore
`PASS_COMPLETE_SEMANTIC_AUTHORITY_PDF_RIGHTS_MEDIA_COMPLETE` for Unit 29.
