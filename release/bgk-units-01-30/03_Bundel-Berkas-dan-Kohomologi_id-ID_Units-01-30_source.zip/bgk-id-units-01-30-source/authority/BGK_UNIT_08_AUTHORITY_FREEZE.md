# BGK Unit 8 authority freeze

Status: complete, bounded, and reproducible semantic/source authority for
Unit 8 of Holger Brenner's *Bündel, Garben und Kohomologie (Osnabrück
2019–2020)*. This freezes source identity and component surfaces; it is not a
translated reader or publication. The deterministic receipt is
`qa/BGK_UNIT_08_AUTHORITY_QA.json`.

## Semantic source identity

- Source project/API: German Wikiversity, namespace `Kurs`,
  `https://de.wikiversity.org/w/api.php`.
- Lecture: *Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019–2020)/Vorlesung
  8*, page 109012, revision 793632, timestamp `2022-08-25T06:26:28Z`,
  MediaWiki SHA-1 `dedf36ef3494817e0d35ddb9ff305a5adedd92d7`, oldid URL
  `https://de.wikiversity.org/w/index.php?oldid=793632`.
- Worksheet: *Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019–2020)/
  Arbeitsblatt 8*, page 109250, revision 767578, timestamp
  `2022-08-15T16:40:27Z`, MediaWiki SHA-1
  `825abbae5b4bf1875f24cd915f2b37819f30d7d4`, oldid URL
  `https://de.wikiversity.org/w/index.php?oldid=767578`.
- The complete recursive semantic closures contain 130/130 requested lecture
  transclusions and 116/116 requested worksheet transclusions, with zero
  missing pages. Exact API, XML, HTML, parse, expanded-TeX, and transclusion
  witnesses are under `authority/wikiversity-bgk/unit-08/`.
- Terminal `/latex` witnesses are lecture page 110016 revision 807075 and
  worksheet page 117163 revision 807045. Their terminal TeX witnesses are
  `lecture-08-expanded.tex` (31,588 bytes, SHA-256
  `926cd9ff6e41b384d89b2b63e9c1f7dab7d37dca34a864bd1fd045b6a565db11`)
  and `worksheet-08-expanded.tex` (11,761 bytes, SHA-256
  `57d8a50579be711720d8125d4f7d3308ed9e07a588445d4c9ad4a40188a41b85`).
  These are terminal-byte witnesses; no recursive wrapper-template rebuild is
  claimed.
- Manifest:
  `authority/wikiversity-bgk/unit-08/UNIT_AUTHORITY_MANIFEST.json`, 110,580
  bytes, SHA-256
  `cadebf48e67a54a238f4b22e0abf806fbf1f81821b6d012993739ecf50dd8d32`.
  It declares 37 files; every declared byte count and SHA-256 was recomputed
  and matched.

The capture implementation now gives case-variant transclusion titles an
explicit secondary code-point ordering after `casefold()`. Two consecutive
resume replays produced the identical manifest hash above. The exact freezer
is `scripts/freeze_brenner_unit.py`, 24,246 bytes, SHA-256
`77aa14f7afd2d9eb2b35fd3a9cd6a4324d1e15f5c08672990bf2be393da50c70`.

## Exercises and lawful solutions

`ORDERED_EXERCISE_MAP.json` is 9,087 bytes, SHA-256
`97c9bf59cae3e34263681875e74c4ad2f0626b87f19a6e0490d127ac4c921f1a`.
It contains exactly 22 worksheet exercises in source order. The frozen
candidate evidence records public source solutions only for Exercises 8.3,
8.4, and 8.11:

- Exercise 8.3: page 86076, revision 485196, MediaWiki SHA-1
  `ea019f083d8af1fe044923f7dd6f86f675ee9624`.
- Exercise 8.4: page 169650, revision 1112909, MediaWiki SHA-1
  `c7ed44201f6b8d4051a567567c5a54b411976815`.
- Exercise 8.11: page 21576, revision 1112864, MediaWiki SHA-1
  `45f4d65002a1d754f687c2e62392bb1d3c90c456`.

The other 19 candidate solution pages are explicitly missing. The Indonesian
edition reproduces only these three source solutions and invents none.

## Official PDF witnesses

- Lecture PDF `authority/artifacts/bgk-lecture-08-official.pdf`: 89,600 bytes,
  SHA-256 `4907b8a1438d786d326667256e9b4c3f8124f4b170d53c782a5f58f68cc09727`;
  Commons upload SHA-1 `e102d55aecd3b42fb39e0d89b3943b0d89605946`; 9 pages at
  612 × 792 points.
- Worksheet PDF `authority/artifacts/bgk-worksheet-08-official.pdf`: 55,903
  bytes, SHA-256
  `f32f11e7fd3ec9d3ba2f6a20a89ab23c3652b4e8026db037278d2022108208bf`;
  Commons upload SHA-1 `4d5098e08f5ae7242c616fa62e0077cbbbe658c7`; 5 pages at
  612 × 792 points.
- pypdf verifies all 14 page boxes and the final embedded rights pages, which
  name Holger Brenner alias Bocardodarapti and state `CC-by-sa 3.0`.

## Missing source media and component rights

The semantic lecture declares `File:Spektrum_von_Z._xcf` with inline creator
`Bocardodarapti` and license label `CC-by-sa 4.0`. The official Commons API
normalizes that name to `File:Spektrum von Z. xcf` and returns it as missing.
The frozen HTML displays a broken media reference, and the official lecture
PDF retains the surrounding Example 8.8 prose but no image binary. No
verifiable source binary was recovered, no reader-media asset was fabricated,
and no restoration claim is made.

The edition preserves the declared creator and license label, the source
caption meaning, a descriptive alternative, and the missing-binary fact in
`source/id-ID/media-credits-bgk-unit-08.md`. Any later editorial reconstruction
must be identified separately from the source. The closure is exact:

- `authority/commons-imageinfo-bgk-unit-08.json`: 7,242 bytes, SHA-256
  `f4a1bdc2448e006a403f1ab45c3e539a6e2cd2c01752b808ce154c8197a364c8`.
- `authority/RIGHTS-bgk-unit-08.csv`: 1,051-byte header-only reader-media
  ledger, SHA-256
  `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d`.
- `authority/ASSET_CLOSURE-bgk-unit-08.json`: 7,029 bytes, SHA-256
  `d56af73bd63be9a734b4d1b2fce34af52ae04001c3054ced3770c19f273c980e`,
  with zero reader positions, zero recovered assets, and one disclosed broken
  source reference.
- `source/id-ID/media-credits-bgk-unit-08.md`: 1,222 bytes, SHA-256
  `5437b13c0c2fa373f97defa4b0c427940b1dad00c4bbbb3530ba8ff6ff268e3e`.

Current Commons description metadata labels the two official PDF files CC
BY-SA 4.0; each PDF's embedded course notice states CC-by-sa 3.0. Both are
preserved as component evidence. The semantic course and Indonesian
derivative remain bound to CC BY-SA 4.0 with attribution, share-alike, and
non-endorsement. No blanket relicensing claim is made.

## Bounded translation boundary

Unit 8 introduces spectra of commutative rings, prime ideals and their points,
the Zariski topology, morphisms induced by ring homomorphisms, and affine
schemes. Translation must preserve all definitions, examples, propositions,
proofs, 22 exercises, the three lawful public solutions, and the disclosed
missing-image treatment. Terminology and any source quirks found during close
translation are recorded in the lane ledgers rather than silently normalized.

## Reproducibility checks

The accompanying QA receipt verifies exact source identities, complete
transclusion closures, terminal TeX witnesses, all 22 ordered exercises, three
public and 19 negative solution results, official PDF byte identity and page
geometry, the disclosed unrecoverable XCF reference, separate component
rights, the complete 37-file manifest, deterministic resume replay, and
`git_used=false` / `upstream_contacted=false`. Model provenance is exactly
`OpenAI Codex gpt-5.6-sol, Ultra.`

Next action: translate Unit 8 from these frozen witnesses in source order,
preserving mathematics, IDs, the three public solutions, rights, and the
disclosed missing-image boundary; then run the per-unit translation gate before
the next cumulative BGK reader/backend/release milestone.
