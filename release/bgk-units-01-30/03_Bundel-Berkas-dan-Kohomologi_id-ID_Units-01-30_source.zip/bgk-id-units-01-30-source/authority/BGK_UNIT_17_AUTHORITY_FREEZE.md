# BGK Unit 17 - terminal authority freeze

Status: PASS. Bound to the frozen official Brenner *Bündel, Garben und Kohomologie (Osnabrück 2019-2020)* course; not classical Unit 17.

Lecture page `109021`, revision `1019984`, timestamp `2025-08-09T13:37:26Z`, MediaWiki SHA-1 `b4e1dbede8d862ac8bd1b25d94157448625ff938`; worksheet page `110224`, revision `1003886`, timestamp `2025-06-10T09:38:13Z`, MediaWiki SHA-1 `3f58772722e8d02548107ad7a0dde0f0f472f1fa`. All 137 lecture and 120 worksheet transclusions close without missing pages. All 31 manifest file records and every transclusion page/revision/wikitext SHA-1 were replayed from local bytes.

Both dedicated official PDF witnesses have `%PDF-` signatures and match their frozen upload byte counts, upload SHA-1, local SHA-256, and page counts: lecture 96,487 bytes, SHA-1 `583a63cef01d8c7ef948f3b69ed860f31de8b6ac`, nine pages; worksheet 65,250 bytes, SHA-1 `2b3b1063d7795c7b063584d0d872d5792105af9f`, seven pages. Commons description revisions, canonical extended-metadata hashes, and embedded-rights-page text hashes also match the asset closure.

The semantic translation preserves 11 lecture entities, four explicit proofs, 24 ordered exercises, no public source solutions, and 24 explicit negative solution candidates. All 46 semantic heading IDs are unique (47 including media credits). Pandoc parses every target without warnings and counts 192/118/0 math nodes. All three post-YAML bodies remain byte-identical to the complete pre-metadata-repair semantic translation. Only source-binding frontmatter changed; Indonesian prose, formulas, IDs, exercise order, and the negative-solution scope did not change. The malformed printed factor, quantified-point/fiber-letter discrepancy, punctuation-only treatments, earlier deterministic corrections, and prior course-PDF visual audit evidence are retained in the translation QA.

Reader media: zero. The semantic course text and translation are CC BY-SA 4.0; current Commons PDF metadata is CC BY-SA 4.0, while embedded PDF notices state CC-by-sa 3.0. Both component facts are preserved without blanket relicensing. Exact provenance: OpenAI Codex gpt-5.6-sol, Ultra. Original author/contributor credits and non-endorsement remain intact.

This offline terminal record supersedes all earlier Unit 17 missing-tail preflight, stage, and worklog observations without rewriting those historical observations. No network, build, Git, or publication action was run for this closure. Final source identities and complete semantic/authority checks are in `qa/BGK_UNIT_17_TRANSLATION_QA.json` and `qa/BGK_UNIT_17_AUTHORITY_QA.json`; no source changes remain required for this Unit 17 closure.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-17/UNIT_AUTHORITY_MANIFEST.json` | 116,318 | `b896a47254cbbea5f77f5eecaa1f8db99fe24c662fc9ba56e10f9db1be186b99` |
| `authority/artifacts/bgk-lecture-17-official.pdf` | 96,487 | `d451a9af49bf0734c3d212a5b07e7152b9b6c067d6b87fe9c9cd3923f7cb4a3b` |
| `authority/artifacts/bgk-worksheet-17-official.pdf` | 65,250 | `82fed9c1839a719786d9c79068d30a25259f7090447d7dfee64320b1a0c480a6` |
| `authority/commons-imageinfo-bgk-unit-17.json` | 7,069 | `de5a5c061f5b4337150638582282fa010ba5a7db8b8be1f9ef9280a7d512334b` |
| `authority/RIGHTS-bgk-unit-17.csv` | 1,051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| `authority/ASSET_CLOSURE-bgk-unit-17.json` | 6,152 | `1173bbfd2583a146d58bee689a94fdaa143b543da0b3f4dbc89fe869d57037cb` |
| `source/id-ID/bgk/lecture-17.md` | 18,839 | `37e224dc2573d94cc283ea002b7dac7bde5d31953f2103ba2b29bc89130089a2` |
| `source/id-ID/bgk/worksheet-17.md` | 14,198 | `c5bf5f19290a0041cc9b9b2b69464ad519d4b37e1c8662ec90340de2b9415795` |
| `source/id-ID/bgk/worksheet-17-solutions.md` | 1,972 | `e1521f72d7b4dbd2ca9c2103b0eceef3696b3b3b7050d2e2451803bbc7452622` |
| `source/id-ID/media-credits-bgk-unit-17.md` | 673 | `d69fc0bea8ad6bb1f589a03abfc9942fc00d586ae7882c88be16368030d30adc` |
| `qa/BGK_UNIT_17_AUTHORITY_QA.json` | 3,950 | `7c571c89f02890c6d163b6261f8bfeb986078e5f9606ae5c3130de77c9fac448` |
| `qa/BGK_UNIT_17_TRANSLATION_QA.json` | 26,407 | `c9f16460576aa94f87c83f6ab8538991513abd63bca676256390c1cb0967f6a3` |
