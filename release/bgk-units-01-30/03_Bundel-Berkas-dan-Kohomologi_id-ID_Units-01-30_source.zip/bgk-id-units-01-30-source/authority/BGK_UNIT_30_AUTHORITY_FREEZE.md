# BGK Unit 30 authority freeze

Status: **PASS - complete semantic, PDF, negative-solution, component-rights,
zero-reader-media, and Indonesian translation authority closure**.

This record binds Unit 30 of `Kurs:Bündel, Garben und Kohomologie
(Osnabrück 2019-2020)` to the exact frozen artifacts below. It distinguishes
the current semantic transclusion capture from the older official compiled PDF
witnesses. The Indonesian edition uses both: semantic pages establish entity
identity and current structure, while the PDFs establish what was visibly
printed. Where those witnesses expose a defect or differ, the edition uses an
explicit visible source note rather than silently rewriting the historical
witness.

## Frozen boundary

Every byte count and SHA-256 in this table was recomputed from a regular,
non-symlink file immediately before this record was created.

| Role | Path | Bytes | SHA-256 |
|---|---|---:|---|
| Course authority manifest | `authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json` | 34,279 | `ea0bf346e261db8ed80b7565f7746e95c79e0c376d25d9fbce5d96879dff7dd8` |
| Official aggregate course PDF | `authority/artifacts/bgk-course-official.pdf` | 2,104,862 | `87655cf7e96dc0eaa185ca49a374dc9e25f4b739670495f423279aa332fce66c` |
| Unit capture identity | `authority/wikiversity-bgk/unit-30/CAPTURE_IDENTITY.json` | 677 | `b4749a9ec383eb528051884806cc745676d2c6d9071365508ef64135c0c5a5a5` |
| Frozen official-PDF API identities | `authority/wikiversity-bgk/unit-30/official-pdfs-api.json` | 1,982 | `095a4c635b887442ef2006202cc7f6ae91641060deeb9c55b0c60e96e4b7d150` |
| Unit authority manifest | `authority/wikiversity-bgk/unit-30/UNIT_AUTHORITY_MANIFEST.json` | 88,861 | `956990c5550c5fa417f3441dc1bb8f093acbdbb8fe1064ae37c384fa17b8fcb0` |
| Expanded lecture TeX | `authority/wikiversity-bgk/unit-30/lecture-30-expanded.tex` | 20,850 | `387a737286c3201879a51dd2948fc56f91d8197653e422669741ef4eea372d29` |
| Expanded worksheet TeX | `authority/wikiversity-bgk/unit-30/worksheet-30-expanded.tex` | 3,816 | `9d216d39585a7615ea6a46e9f276b33cd205b1c37ea8baced8f37a9f3bb8ddf1` |
| Official lecture PDF | `authority/artifacts/bgk-lecture-30-official.pdf` | 79,352 | `c733eb734087986717565e9f90419193c8930e0572836186f9fb7c1b1357eea6` |
| Official worksheet PDF | `authority/artifacts/bgk-worksheet-30-official.pdf` | 40,296 | `ad0552839c9fb1b756ae1d1c254e3c3242c12ff691f8e3112584a02ce771f3fe` |
| Ordered exercise/solution map | `authority/wikiversity-bgk/unit-30/ORDERED_EXERCISE_MAP.json` | 2,733 | `3bbf65672ab614c8f88caa438f06230328a87849a245447ae3207be682a59ecc` |
| Negative solution-candidate response | `authority/wikiversity-bgk/unit-30/worksheet-solution-candidates-api.json` | 540 | `3ffdcede4d7bb2407ad0028ad3f8e18046b6142814bb7dcfe89dd3551a4b498a` |
| Commons PDF component metadata | `authority/commons-imageinfo-bgk-unit-30.json` | 7,069 | `b7370d41a7386442ab298509a206bae65373c907be70055b7c32472dcbc08878` |
| Reader-media rights ledger | `authority/RIGHTS-bgk-unit-30.csv` | 1,051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| Zero-media asset closure | `authority/ASSET_CLOSURE-bgk-unit-30.json` | 6,151 | `cdc8fb5179ff340867c2305cbac417e991813261405e9dfb49199720b5d7179b` |
| Indonesian media-credit boundary | `source/id-ID/media-credits-bgk-unit-30.md` | 673 | `851df7adad1f78948d0698c68c0b972dbf581bed62413a30acfb86fb75258cd7` |

The unit manifest has schema `brenner-bgk-unit-authority-freeze-v1`, frozen
timestamp `2026-08-30T22:51:48.864321+00:00`, and exactly 29 declared member
files. All 29 paths, byte counts, and SHA-256 values were recomputed and passed.
The aggregate course PDF has 265 pages; the authority QA binds Unit 30 to pages
258-264.

## Source identity and semantic closure

The source project is German Wikiversity, course namespace `Kurs` (captured
namespace ID 106), with API `https://de.wikiversity.org/w/api.php`.

| Component | Exact title | Page ID | Revision ID | Parent ID | Timestamp | MediaWiki SHA-1 |
|---|---|---:|---:|---:|---|---|
| Lecture | `Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 30` | 109034 | 793624 | 728325 | `2022-08-25T06:25:28Z` | `18925f7cd309e5a1f414208fad07124d8680ea79` |
| Worksheet | `Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 30` | 110239 | 991891 | 834041 | `2025-01-23T14:50:11Z` | `fd0f75147d3f8a494f1238b4cf4b400b35fcc871` |

The lecture requested and captured 139 transclusions; the worksheet requested
and captured 60. Both missing-page counts are zero. The closure contains nine
numbered lecture entities, eight semantic proof bodies, and five ordered
worksheet exercises.

## Official PDF witnesses

The official PDFs are authority witnesses, not extra reader-media positions.
Their upload identities and local bytes agree:

| Kind | Exact source file title | Upload timestamp | Upload SHA-1 | Pages | Local path |
|---|---|---|---|---:|---|
| Lecture | `Datei:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)Vorlesung30.pdf` | `2020-02-27T13:18:56Z` | `da1e5b9e690b0f6da735ca912bb5f80371619b0e` | 7 | `authority/artifacts/bgk-lecture-30-official.pdf` |
| Worksheet | `Datei:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)Arbeitsblatt30.pdf` | `2020-03-03T10:46:45Z` | `80a2b276f8cb052e25d7cf8745b8fcfa3b83b1e0` | 3 | `authority/artifacts/bgk-worksheet-30-official.pdf` |

Visual and extracted-text checks confirm the lecture and worksheet identities,
page counts, formulas, and final `Abbildungsverzeichnis` rights pages. Current
Commons descriptions identify `User:Bocardodarapti`, `Own work`, and CC BY-SA
4.0. Each PDF's embedded final page instead states `Holger Brenner alias
Bocardodarapti` and `CC-by-sa 3.0`. Both records are preserved; the closure
flags the discrepancy and does not claim a blanket relicensing.

## Four visible source treatments

The final Indonesian lecture contains three visible `Catatan edisi (sumber)`
notes and the worksheet contains one. The solution-scope file contains none.
These are the four admitted treatments.

### 1. Theorem 30.8: rank parameter and filtration indexing

Official lecture PDF page 4 prints a locally free sheaf “vom Rang auf C”, with
the rank parameter missing, and begins the filtration at
`0 = F_1 \subset F_2 \subset \cdots \subset F_r = F`. The captured current
semantic statement `Glatte projektive Kurve/Lokal freie
Garbe/Filtration/Fakt` (page ID 108954, revision 1087970, timestamp
`2026-05-30T16:09:23Z`, MediaWiki SHA-1
`8543e83e6c249770c0ec167a404ae44146c6525b`) retains the same defect.

The Indonesian edition visibly restores rank `r` and displays
`0 = F_0 \subset F_1 \subset \cdots \subset F_r = F`, with invertible
quotients `F_{i+1}/F_i` for `0 <= i < r`. This is mathematically forced by a
rank-`r` filtration into `r` rank-one factors and by the proof's induction on
the rank through `F_{r-1}`. The repair is disclosed immediately after the
statement.

### 2. Theorem 30.8 proof: obsolete Lemma 30.6 reference

Official lecture PDF page 5 says that the nonzero coherent ideal sheaf is
invertible “nach Lemma 30.6”. The relevant result printed immediately before
Theorem 30.8 is Lemma 30.7. The current semantic proof
`Glatte projektive Kurve/Lokal freie Garbe/Filtration/Fakt/Beweis` (page ID
108979, revision 1101220, timestamp `2026-06-17T14:17:27Z`, MediaWiki SHA-1
`d2f27f70f80e79becf0569782e59eeddb27afac4`) links the correct ideal-sheaf
invertibility entity and now resolves as Lemma 30.7.

The translation preserves the historical PDF's printed “Lema 30.6” in the
proof as an explicitly attributed source reference, then states visibly that
the correct in-unit number is Lema 30.7. Thus the historical byte witness and
the semantic correction are both recoverable.

### 3. Theorem 30.9 proof: obsolete Theorem 30.7 reference

Official lecture PDF page 5 cites “Satz 30.7” for additivity of the degree of
locally free sheaves in short exact sequences. The actual additivity result is
Theorem 30.6; Lemma 30.7 concerns invertibility of nonzero coherent ideal
sheaves. The current semantic Riemann-Roch proof (page ID 108957, revision
1086367, timestamp `2026-05-30T11:40:55Z`, MediaWiki SHA-1
`1b3a369d50d1558aa3e169634b638da39e4c138c`) links the additivity entity and
now resolves as Theorem 30.6.

The Indonesian proof preserves the historical printed “Teorema 30.7” as a
source quotation and follows it with a visible note identifying Teorema 30.6
as the mathematically correct reference.

### 4. Exercise 30.3: omitted degree value

Official worksheet PDF page 1 asks for rank-2 locally free sheaves “vom Grad
derart”, with the value after `Grad` missing. The exact entity title is
`Projektive Gerade/Rang 2/Grad 0/Schnitte/Aufgabe`, and its current semantic
page (page ID 116025, revision 1082048, timestamp `2026-05-29T17:16:42Z`,
MediaWiki SHA-1 `24ef20a3720fcb13f48a8ffbc2f3571a9e00e517`) explicitly contains degree
`0`.

The Indonesian worksheet restores degree `0` and discloses the repair. The
value is not conjectural: it is fixed independently by both the entity title
and the current semantic content.

## Exercise and negative-solution closure

The ordered map records five exercises and zero public solutions. The frozen
candidate response returns each exact `/Lösung` page as missing:

| No. | Exercise entity | Exact candidate solution title | Result |
|---:|---|---|---|
| 1 | `Projektive Gerade/Riemann-Roch/Direkt/Aufgabe` | `Projektive Gerade/Riemann-Roch/Direkt/Aufgabe/Lösung` | Missing |
| 2 | `Glatte Ebene Kurve/Syzygienbündel/Gradberechnung/Aufgabe` | `Glatte Ebene Kurve/Syzygienbündel/Gradberechnung/Aufgabe/Lösung` | Missing |
| 3 | `Projektive Gerade/Rang 2/Grad 0/Schnitte/Aufgabe` | `Projektive Gerade/Rang 2/Grad 0/Schnitte/Aufgabe/Lösung` | Missing |
| 4 | `Projektive Ebene/Kotangentialbündel/Einschränkung/Gerade/Aufgabe` | `Projektive Ebene/Kotangentialbündel/Einschränkung/Gerade/Aufgabe/Lösung` | Missing |
| 5 | `Projektive Ebene/Kotangentialbündel/Einschränkung/Quadrik/Aufgabe` | `Projektive Ebene/Kotangentialbündel/Einschränkung/Quadrik/Aufgabe/Lösung` | Missing |

Consequently the Indonesian solution-scope file records zero translated
public solutions and invents none. Absence is based on exact page-level
existence evidence, not on stars, typography, or an inference from missing
worksheet links.

## Zero-reader-media and rights closure

The two PDF filenames occur on the parse surfaces, but there are no
non-PDF/substantive reader-media names. The closure therefore records:

- reader media positions: 0;
- animated HTML positions: 0;
- primary, companion, and total local reader assets: 0;
- broken source-media references: 0;
- official PDF component-rights witnesses: 2.

`RIGHTS-bgk-unit-30.csv` is intentionally header-only because there are zero
reader-media components. It is not an incomplete ledger. The media-credit file
uses stable ID `br-bgk-2019-media-credits-unit-30` and explains the zero-media/PDF
witness boundary.

## Canonical Indonesian files and QA receipts

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `source/id-ID/bgk/lecture-30.md` | 13,265 | `2799f282fde84e81af927623f9195e4a8a00bd3aa56a3de49c933248575f4e60` |
| `source/id-ID/bgk/worksheet-30.md` | 4,514 | `70ec06abbdb03c004afc6e5f1720518914e9653471ca330fc28a5190e47e5464` |
| `source/id-ID/bgk/worksheet-30-solutions.md` | 4,520 | `f477048da4989aae293f2b7c99cba62ca7e1a2ebf7e313374bfed504b0f11bbe` |
| `qa/BGK_UNIT_30_AUTHORITY_QA.json` | 3,943 | `90d5b48a275c85b736d0ce60adeb1a8af812409861ade1e8580bfa3c2c43f18e` |
| `qa/BGK_UNIT_30_TRANSLATION_QA.json` | 5,251 | `6881174dde54067027552d4f83fd6a6825d437a7191a08c068ec07cffed9d3cd` |

The authority receipt status is
`PASS_COMPLETE_SEMANTIC_AUTHORITY_PDF_RIGHTS_ZERO_MEDIA`; the translation
receipt status is `PASS`. The latter confirms nine numbered lecture entities,
eight proof bodies, five source and translated exercises, zero source and
translated public solutions, five negative candidates, zero invented
solutions, 30 unique heading IDs, zero image nodes, and four visible source
notes. Pandoc AST parsing, protected formula witnesses, provenance, language,
license, non-endorsement, and placeholder/control-character checks all pass.
Translation provenance is `OpenAI Codex gpt-5.6-sol, Ultra.`

Both worksheet frontmatters additionally bind the exact ordered map
`3bbf65672ab614c8f88caa438f06230328a87849a245447ae3207be682a59ecc`
and negative candidate evidence
`3ffdcede4d7bb2407ad0028ad3f8e18046b6142814bb7dcfe89dd3551a4b498a`;
the worksheet also binds exercise count 5, public-solution count 0, and the
empty public-solution list. These fields were mechanically checked before the
final QA rerun.

## Boundary

This authority freeze does not modify or authorize translation changes,
capture replay, shared-ledger changes, builds, Git operations, publication, or
upstream contact. It records the already-frozen Unit 30 boundary and its
current deterministic PASS receipts.
