# BGK Unit 18 — authority freeze

Status: **PASS — terminal semantic and authority closure.** Frozen from the
official 2019–2020 Wikiversity/Commons surfaces on `2026-08-31`; this record
is scoped to BGK and excludes the classical Unit 18 tree.

## Source identity

- Lecture: page `109022`, revision `1069569`, timestamp
  `2026-02-06T07:06:24Z`, MediaWiki SHA-1
  `2278e6ac498280b0903b3eb4d27293a2647401b5`.
- Worksheet: page `110225`, revision `1008805`, timestamp
  `2025-07-10T16:33:18Z`, MediaWiki SHA-1
  `9d122888e407ae4a211bdff1a5368dd467ac9ff6`.
- Transclusions: 251 lecture and 97 worksheet pages captured with zero
  missing rows. The ordered map has 25 exercises and public solutions 18.6,
  18.17, and 18.18; 22 candidates are explicitly negative.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-18/UNIT_AUTHORITY_MANIFEST.json` | 150,748 | `f0014846fe068d3b1bfd4488c1db66fdd6039fa2d70ff7b8a213875a56d39495` |
| `authority/artifacts/bgk-lecture-18-official.pdf` | 99,940 | `95c36781fe3c5df56320e7cc7992ddff2a9c548e4099d811c768bc29c37ebfc9` |
| `authority/artifacts/bgk-worksheet-18-official.pdf` | 56,337 | `2d9a8cb439babbb5bb4f671ded98614d86f29871f26ae689e5d7b3280f6f8bb1` |
| `authority/commons-imageinfo-bgk-unit-18.json` | 7,069 | `52ef7d4163c0597b08cc66b931935dd82d4887d58361852f2f12885ed75e9a48` |
| `authority/RIGHTS-bgk-unit-18.csv` | 1,051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| `authority/ASSET_CLOSURE-bgk-unit-18.json` | 6,152 | `33d6804e99934e11b06f7d05a732646e9371a51dd6fbbb35d642da28080caa77` |

Both PDFs pass byte, upload-SHA-1, page-count, and embedded-rights checks.
Commons metadata is CC BY-SA 4.0 while the embedded notice is CC-by-sa 3.0;
both facts are preserved without blanket relicensing. PDFs are authority
witnesses, not reader-media positions; reader-media count is zero.

## Indonesian targets and QA

| Target | Bytes | SHA-256 |
|---|---:|---|
| `source/id-ID/bgk/lecture-18.md` | 33,635 | `c2c655dff9b37020fc3c6cd7309c88c16ddf6b1ae061a98e2d037e062415c72d` |
| `source/id-ID/bgk/worksheet-18.md` | 11,083 | `a51cee1cbaae59b2f5eb7edb2061129c6a3f04239fafc8e775a0b094bf28535b` |
| `source/id-ID/bgk/worksheet-18-solutions.md` | 5,365 | `a61ef2b53cdb0cc0555d7c7ac32f11bdfda2a2fc6160a2a454ab80ce5d058dab` |
| `source/id-ID/media-credits-bgk-unit-18.md` | 673 | `637be57504b2c74f624e74e1f97564237b6b2bbca3a7a26e11e50b0f7de93c57` |
| `qa/BGK_UNIT_18_AUTHORITY_QA.json` | 3,982 | `78b7fe3752ffba6aea754782088a9c60c287137a6e2795a65a0371706a43e34e` |
| `qa/BGK_UNIT_18_TRANSLATION_QA.json` | 3,105 | `7017792dadcb1b687196be9f21cb895738168b569a42c2ba9cb672310d11fe05` |

QA is deterministic `PASS`: 19 lecture entities, 12 proofs, 25 ordered
exercises, three public solutions, 66 target IDs, zero source-note exceptions,
balanced Pandoc parses, exact provenance `OpenAI Codex gpt-5.6-sol, Ultra.`,
and complete license/non-endorsement fields. Source inconsistencies and
semantic repairs are disclosed in the target files. The current target hashes
include the metadata-only replacement of obsolete pre-capture `null` fields
with the verified manifest, official-PDF, rights-ledger, asset-closure, and
ordered-map identities; mathematical prose, formulas, IDs, exercises, and
solutions were not changed by that repair.
