# BGK Unit 15 — authority freeze

Status: **PASS — terminal semantic and authority closure.** Frozen from the
official Wikiversity/Commons surfaces on `2026-08-31` for the 2019–2020
`Bündel, Garben und Kohomologie` course. This file is scoped to BGK and does
not certify the unrelated classical `authority/wikiversity/unit-15` lane.

## Source identity

- Lecture: page `109019`, revision `1003744`, timestamp
  `2025-06-08T15:41:44Z`, MediaWiki SHA-1
  `35b2de7ebb7276afe88784ffa590aae83faa8788`.
- Worksheet: page `110222`, revision `659926`, timestamp
  `2020-10-09T15:16:19Z`, MediaWiki SHA-1
  `fb6863c9257785576180b4d63b1f6c591e87e73a`.
- Lecture transclusions: 153 captured / 153 requested; worksheet: 124 / 124.
- Ordered map: 20 exercises, zero public solution pages; all 20 negative
  candidates are preserved. Parse images are the two official PDFs only; no
  substantive reader media exists.

## Terminal authority artifacts

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-15/UNIT_AUTHORITY_MANIFEST.json` | 119,560 | `72d54d10452a64b9702bfd56edf58a716a04a0185b77d8b2cd029dd7fbb88b95` |
| `authority/artifacts/bgk-lecture-15-official.pdf` | 88,923 | `8a6846f8cf0f080cc4b59748c8a1bb7bdf8daa21cca472652917d7a60002fa6d` |
| `authority/artifacts/bgk-worksheet-15-official.pdf` | 61,699 | `51f26b9c956fbd65ff234fea7124875fbff397059f3a00931f20e286f16cd353` |
| `authority/commons-imageinfo-bgk-unit-15.json` | 7,069 | `8eda0ce261b32459bbb6046091583524f4b6422a42379d1adcb88e682668b1ce` |
| `authority/RIGHTS-bgk-unit-15.csv` | 1,051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| `authority/ASSET_CLOSURE-bgk-unit-15.json` | 6,152 | `bbdcfab2d5d1b058930406c66ebd234276f351c90a019328b80e9c0cfbf80742` |

Both PDF witnesses pass byte, upload-SHA-1, page-count, and embedded-rights
checks. Commons metadata says CC BY-SA 4.0 while the embedded notice says
CC-by-sa 3.0; both facts remain visible and no blanket relicensing is claimed.

## QA

`qa/BGK_UNIT_15_AUTHORITY_QA.json` (`3,949` bytes,
`c9a96b61467f05ee9f87bc6130b1672df51cd9dcbc0e33ce92b4d97dbd5be23a`) and
`qa/BGK_UNIT_15_TRANSLATION_QA.json` (`3,103` bytes,
`8acbdd491a3eb5c5450d6cb05c3036c3eddab81757dd435de4f525f991ed33ce`) are
deterministic `PASS` receipts. They bind 13 lecture entities, 8 proofs, 20
ordered exercises, zero public solutions, 47 target IDs, zero source-note
exceptions, balanced math/Pandoc parses, exact CC BY-SA 4.0 and
non-endorsement text, and provenance `OpenAI Codex gpt-5.6-sol, Ultra.`
