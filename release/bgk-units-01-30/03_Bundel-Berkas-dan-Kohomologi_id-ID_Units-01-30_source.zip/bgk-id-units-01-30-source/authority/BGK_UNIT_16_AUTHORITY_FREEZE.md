# BGK Unit 16 — authority freeze

Status: **PASS — terminal semantic and authority closure.** Frozen from the
official 2019–2020 Wikiversity/Commons surfaces on `2026-08-31`. This record
is BGK-only and does not certify the unrelated classical Unit 16 lane.

## Source identity and closure

- Lecture: page `109020`, revision `1003746`, timestamp
  `2025-06-08T15:43:34Z`, MediaWiki SHA-1
  `2be1b6927bfef758198ff94dd1e90dc52c4630f2`.
- Worksheet: page `110223`, revision `619454`, timestamp
  `2020-02-17T16:19:33Z`, MediaWiki SHA-1
  `24134a0ca04b3c50ce0559772d5870e22c79401a`.
- Transclusions: 193 lecture and 143 worksheet pages captured with zero
  missing rows. The ordered map records 23 exercises and exactly one public
  solution (Exercise 16.12); the remaining 22 candidates are negative.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-16/UNIT_AUTHORITY_MANIFEST.json` | 142,406 | `9d7b0bd724382f25959c45ef76462a6ca8b1ee95d00a5efd27c1bd5115d97ced` |
| `authority/artifacts/bgk-lecture-16-official.pdf` | 94,835 | `90f008de278ef3188c540ae6075bb000afc7980e6f728ec6a5cf3546af88b0b4` |
| `authority/artifacts/bgk-worksheet-16-official.pdf` | 53,795 | `1f9bcba3cc4da19c4ccbd39b2fb7ed82439ef1ca9e6cd80eb22d0971d3fcabc6` |
| `authority/commons-imageinfo-bgk-unit-16.json` | 7,069 | `790943c4354d4e5077895f3cfb86e0953414a77dbfd7531bc8ad32f1bf01a8a6` |
| `authority/RIGHTS-bgk-unit-16.csv` | 1,051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| `authority/ASSET_CLOSURE-bgk-unit-16.json` | 6,152 | `f7bad0656d142c9166b9714270640f42b15bad487e8339506fb644fc75c2e7f6` |

Both PDF witnesses pass byte, upload-SHA-1, page-count, and embedded-rights
checks. Their Commons metadata is CC BY-SA 4.0 while the embedded notice is
CC-by-sa 3.0; both are preserved without a blanket relicensing claim. The
PDFs are authority witnesses, not reader media; the unit has zero substantive
reader-media positions.

## Indonesian targets and QA

| Target | Bytes | SHA-256 |
|---|---:|---|
| `source/id-ID/bgk/lecture-16.md` | 21,606 | `69f8c8aba25b415d6e01bf66d791553da1aed6eef3c9f48c63505d6dbf6a90d5` |
| `source/id-ID/bgk/worksheet-16.md` | 11,858 | `6b4039ab17a5058fb2fe4baec3099090d0dd14dc20f681d4d8a9d8ce4ea7dd4d` |
| `source/id-ID/bgk/worksheet-16-solutions.md` | 3,917 | `fcb1e9dd7ed5002f4212e4fd81e0b3c1e46085ee85fe416a2e2593d8b8771ba4` |
| `source/id-ID/media-credits-bgk-unit-16.md` | 673 | `bee229f75e2c46e1cfec26e6d1e9911f9bbfc82cc11aad904a4e5814811c8a71` |
| `qa/BGK_UNIT_16_AUTHORITY_QA.json` | 3,963 | `431fc47f627f1fd0914127e35d4dd63e938ec6cf906b58f93716281c3e234170` |
| `qa/BGK_UNIT_16_TRANSLATION_QA.json` | 3,104 | `bd751c8ae7b51c247dcea4d49768caf1a09ac18fb2127a9adb4da761e1555a4b` |

The deterministic QA is `PASS`: 12 lecture entities, 6 proofs, 23 ordered
exercises, one public solution, 48 target IDs, zero source-note exceptions,
balanced Pandoc parses, exact provenance `OpenAI Codex gpt-5.6-sol, Ultra.`,
and complete rights/non-endorsement fields. Source discrepancies remain
explicitly disclosed rather than silently normalized.
