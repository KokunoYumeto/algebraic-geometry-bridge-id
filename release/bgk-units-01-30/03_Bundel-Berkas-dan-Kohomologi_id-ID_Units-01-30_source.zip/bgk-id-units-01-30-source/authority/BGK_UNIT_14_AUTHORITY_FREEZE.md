# BGK Unit 14 — authority freeze

Status: **PASS — terminal semantic and authority closure.** Frozen from the
official 2019–2020 Wikiversity/Commons surfaces on `2026-08-31`. This record
is BGK-only and does not certify the unrelated classical Unit 14 lane.

## Source identity and closure

- Lecture: page `109018`, revision `1019980`, timestamp
  `2025-08-09T13:36:46Z`, MediaWiki SHA-1
  `f6d1200be466cd501f566a755ab3009dedda8b3e`.
- Worksheet: page `110221`, revision `1005264`, timestamp
  `2025-06-23T17:55:24Z`, MediaWiki SHA-1
  `86f9f44b4b41b187f66c06e15294d4b2a3d11517`.
- Transclusions: 144 lecture and 138 worksheet pages captured with zero
  missing rows. The ordered map records 26 exercises and zero public solution
  pages; all 26 negative candidates are preserved.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-14/UNIT_AUTHORITY_MANIFEST.json` | 122,954 | `c6d5c2fc64d18c759795a55c7ef618acfba3d112a58ac44ff2b3badcb133e038` |
| `authority/wikiversity-bgk/unit-14/ORDERED_EXERCISE_MAP.json` | 8,616 | `5e5e8e176197359fb6726abc791fc58ad61051ad150859b24f746e83cb91cac4` |
| `authority/artifacts/bgk-lecture-14-official.pdf` | 99,803 | `25ebbed78f0a734f0c996cdad0ac0fbc7a4903d468112598cfe9c7395f220b7c` |
| `authority/artifacts/bgk-worksheet-14-official.pdf` | 66,349 | `157e8dd6add4b0c33f9a72bdc26cfb414fa292e93ccc298c08c135b6588d0375` |
| `authority/commons-imageinfo-bgk-unit-14.json` | 7,069 | `965bfc75703a633bcc251d85145825b32f874fd86b2816f385ee7aad8cf66e62` |
| `authority/RIGHTS-bgk-unit-14.csv` | 1,051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| `authority/ASSET_CLOSURE-bgk-unit-14.json` | 6,152 | `fda2cee674069ed8320fbc378fbe940a95b1adad894c65db9c99e754e42c7267` |

Both PDF witnesses pass byte, SHA-256, upload-SHA-1, page, and embedded-rights
checks. Commons metadata says CC BY-SA 4.0 while the embedded notice says
CC-by-sa 3.0; both are preserved without a blanket relicensing claim. The
PDFs are authority witnesses, not reader media; the unit has zero substantive
reader-media positions.

## Indonesian targets and QA

| Target | Bytes | SHA-256 |
|---|---:|---|
| `source/id-ID/bgk/lecture-14.md` | 19,377 | `66d1f5b051465b9a9477e064a846400402633c93c3b026baeac3209cd83eb4c5` |
| `source/id-ID/bgk/worksheet-14.md` | 15,317 | `ff3ff7f40742b85a51d623963be6c5f253d233b15dc36304b289798daefc35ec` |
| `source/id-ID/bgk/worksheet-14-solutions.md` | 1,827 | `bc9d68d00778a42f205545c20704813825c69ed1ffd397dcf2fccefd7292036a` |
| `source/id-ID/media-credits-bgk-unit-14.md` | 673 | `39f51128bcc3bd1627f1a7b0bd152e83c65ff9e8088f4d344f847b4b902ab8c2` |
| `qa/BGK_UNIT_14_AUTHORITY_QA.json` | 3,950 | `1ff6d146436647983fd4caf76a07b9d97e132f38f2af4e69c78be19aa446c8a8` |
| `qa/BGK_UNIT_14_TRANSLATION_QA.json` | 3,103 | `4b32d305bf580d88b4a7b37fa9f51b75c52cee64ba4ebcfd157155466bb3af7f` |

The deterministic receipts bind 13 lecture entities, 7 proofs, 26 ordered
exercises, zero public solutions, 52 unique target IDs, zero reader media,
balanced Pandoc parses, exact provenance
`OpenAI Codex gpt-5.6-sol, Ultra.`, and complete license/non-endorsement fields.
Documented source-notation defects remain visible instead of being silently
normalized.
