# BGK Unit 11 authority freeze

Status: complete, bounded, and reproducible semantic/source authority for
Unit 11 of Holger Brenner's *Bündel, Garben und Kohomologie (Osnabrück
2019-2020)*. This freezes source identity and component surfaces; it is not a
translated reader or a publication. The deterministic receipt is
`qa/BGK_UNIT_11_AUTHORITY_QA.json`.

## Semantic source identity

- Source project/API: German Wikiversity, namespace `Kurs`,
  `https://de.wikiversity.org/w/api.php`.
- Lecture: *Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung
  11*, page 109015, revision 1019976, timestamp `2025-08-09T13:36:06Z`,
  MediaWiki SHA-1 `dc9c24551d94791f407b85a6f32d01b16db66218`, oldid URL
  `https://de.wikiversity.org/w/index.php?oldid=1019976`.
- Worksheet: *Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/
  Arbeitsblatt 11*, page 110218, revision 612137, timestamp
  `2020-01-24T13:09:14Z`, MediaWiki SHA-1
  `0d36ef9ba0541058aa2bb8cc7bcfa015382e3106`, oldid URL
  `https://de.wikiversity.org/w/index.php?oldid=612137`.
- Complete recursive semantic closures contain 165/165 requested lecture
  transclusions and 104/104 requested worksheet transclusions, with zero
  missing pages. Exact API, XML, HTML, parse, expanded-TeX, transclusion, and
  solution witnesses are under `authority/wikiversity-bgk/unit-11/`.
- Terminal `/latex` witnesses are lecture page 112198 revision 807049 and
  worksheet page 117166 revision 807019. Their derived terminal TeX witnesses
  are `lecture-11-expanded.tex` (22,981 bytes, SHA-256
  `96a022fe9c9c7f174e51fb55668f179713d052eb0c37c6e24fbd39550e6c27e7`)
  and `worksheet-11-expanded.tex` (8,648 bytes, SHA-256
  `3361e7036c8432a1a14adcf8ac3fb859ddf999e3b5f44007caefa33e8e320a4b`).
  These are terminal-byte witnesses; no recursive wrapper-template rebuild is
  claimed.
- Stable manifest:
  `authority/wikiversity-bgk/unit-11/UNIT_AUTHORITY_MANIFEST.json`, 118,505
  bytes, SHA-256
  `c55c715d0a1bd3ef5b13ac96ccf38f9b5c261e87124c6da5ccc5984cb61deb09`.
  It declares 38 files; every declared byte count and SHA-256 was recomputed
  and matched. Two consecutive `--resume` replays reproduced this same
  manifest after the initial live-fetch state was converted to its stable
  resumable representation.

## Exercises and lawful solutions

`ORDERED_EXERCISE_MAP.json` is 8,176 bytes, SHA-256
`44c6b2f4a86976163360cf7d0b0b60e39334ec54336e8483249431039365c161`.
It contains exactly 19 worksheet exercises in source order. Exactly Exercises
11.9, 11.13, and 11.14 have public solution pages; the other 16 candidate
pages are explicitly missing.

- Solution 11.9: page 46303, revision 1106651, timestamp
  `2026-07-12T10:40:47Z`, MediaWiki SHA-1
  `de4c7d8f5839897ae9b847696318aa8d64677481`; XML 6,256 bytes, SHA-256
  `c1a8e3d35f3aed5ffe5e37f8f36bf009d1b17d0b4034d2ccbbe69bd6e82ace94`;
  HTML 20,058 bytes, SHA-256
  `3cc9ed5fb74ba0f1fae953a479aaecd48eaf8664b2cb15ea5e8aab17d4954b2e`.
- Solution 11.13: page 112468, revision 1089753, timestamp
  `2026-05-31T11:19:22Z`, MediaWiki SHA-1
  `c20228f9acca9fdea22e7c0c2f3b6c89f1905031`; XML 5,295 bytes, SHA-256
  `9a03466ce3c08e5afe63c17c7584c7fa863c2e1a3e208eba3bcf7b52d37ef10b`;
  HTML 14,077 bytes, SHA-256
  `95fe2bf8bacce3a9b38c34e509f8c1c67a1452d0ea47471a2d77df9ae19d8f26`.
- Solution 11.14: page 112464, revision 1089757, timestamp
  `2026-05-31T11:20:02Z`, MediaWiki SHA-1
  `a866b421baa8b504355e926d0dea7a39f6cbbe09`; XML 4,811 bytes, SHA-256
  `50e0903c021187f4476febca48565085083f3ed6215351084be9bdf7e963d0ce`;
  HTML 9,210 bytes, SHA-256
  `af692e48d0804abe49a6d40dcb4696c5a1197d26a36c71953e046be1878b5f96`.

The candidate query is 9,733 bytes, SHA-256
`18795e45391de20c07918171f5dadf47b6ea04fde24113964d3461eddfe801c4`.
The Indonesian edition must translate those three public solutions, preserve
their starred exercise markings, disclose all 16 negative candidates, and
invent no solution.

## Official PDF witnesses

- Lecture PDF `authority/artifacts/bgk-lecture-11-official.pdf`: 76,843 bytes,
  SHA-256 `011e4366b05a93c260db17ab966ab28464afd5cbb9e8df8158dcf25eaa4b40ff`;
  Commons upload SHA-1 `d7a1757c0486bba46ae3f5e2dcee18f94f9c0268`; seven pages at
  612 x 792 points.
- Worksheet PDF `authority/artifacts/bgk-worksheet-11-official.pdf`: 48,219
  bytes, SHA-256
  `83ef811e6047d4e23643881048dc614d58d7e8e328b55173a2e67fd09a65e6cd`;
  Commons upload SHA-1 `6882dd081f3fe441d544097ebc12628cb6aa5aee`; five pages at
  612 x 792 points.
- `pypdf` verifies all twelve page boxes and the final embedded rights pages,
  which name Holger Brenner alias Bocardodarapti and state `CC-by-sa 3.0`.

The canonical Wikimedia upload URLs, advertised byte counts, MediaWiki SHA-1
values, and admitted local SHA-256 values are bound in the authority manifest.
Both frozen PDF byte streams match those advertised identities. No
third-party mirror or reconstructed PDF is an authority surface.

## Media and component rights

The parse surfaces expose only the two official PDFs, so Unit 11 has zero
substantive reader-media positions. The exact component closure is:

- `authority/commons-imageinfo-bgk-unit-11.json`: 7,069 bytes, SHA-256
  `0342a732ab19231a0b3335949201f9e7b0d28953407f2d3704d1ce265912429e`.
- `authority/RIGHTS-bgk-unit-11.csv`: 1,051-byte header-only reader-media
  ledger, SHA-256
  `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d`.
- `authority/ASSET_CLOSURE-bgk-unit-11.json`: 6,152 bytes, SHA-256
  `ff47273310db6e03d868890097411fe8df8e330668a4e98d4124d0dfdf869448`,
  with zero reader positions, zero recovered assets, and zero broken source
  references.
- `source/id-ID/media-credits-bgk-unit-11.md`: 669 bytes, SHA-256
  `dd1c7bc3eea2d4d57ebcc4d9c4babea7e047c02232efd064960d73626cf3a52f`.

Current Commons description metadata labels the two PDF components CC BY-SA
4.0; each PDF's embedded course notice states CC-by-sa 3.0. Both are preserved
as component evidence. The semantic course and Indonesian derivative remain
bound to CC BY-SA 4.0 with attribution, share-alike, and non-endorsement. No
blanket relicensing claim is made. Two rights-resume replays reproduced the
closure hash above.

## Bounded translation boundary

Unit 11 covers irreducible spaces and closed subsets, generic points, Krull
dimension, noetherian spaces and schemes, irreducible-component
decompositions, reduced and integral schemes, injective restriction maps, and
function fields. Translation must preserve all 20 numbered lecture entities,
eleven proof bodies, all 19 exercises, the three exact public solutions, the
sixteen negative solution results, and every starred marker.

Three source surfaces require visible, meaning-preserving treatment:

1. Theorem 11.10 states uniqueness of the finite irreducible decomposition,
   while its proof supplies the necessary no-inclusion (irredundancy)
   convention only when comparing decompositions. The translated theorem must
   make that convention explicit and disclose its source location.
2. In Lemma 11.16, a section `f in Gamma(U,O_X)` is tested on a set called
   `X_f={P in X | f(P) != 0}` although `f` is only defined on `U`. The
   translation must use `U_f={P in U | f(P) != 0}` and disclose the symbol and
   domain correction.
3. Lemma 11.18 cites Exercise 10.14 for locality of reducedness, but frozen
   Worksheet 10 has only six exercises and frozen Exercise 11.18 is exactly
   the stalkwise-local reducedness result. The translation must cite Soal
   11.18 and visibly preserve the source's erroneous number.

The accompanying QA receipt verifies exact source identities, complete
transclusion closures, terminal TeX witnesses, ordered exercise and
positive/negative solution closure, official PDF byte identity and geometry,
zero reader media, separate component rights, the complete manifest,
deterministic replay, and `git_used=false` / `upstream_contacted=false`. Model
provenance is exactly `OpenAI Codex gpt-5.6-sol, Ultra.`

Next action: translate Unit 11 from these frozen witnesses in source order,
including all three public solutions and the three disclosed source
treatments; then run the per-unit translation gate before Unit 12 and the
cumulative BGK reader/backend/release milestone.
