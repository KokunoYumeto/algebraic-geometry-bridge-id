# BGK Unit 12 authority freeze

Status: admitted immutable source boundary for Unit 12 of Holger Brenner's
*Bündel, Garben und Kohomologie (Osnabrück 2019--2020)*. This file interprets
the complete machine-readable closure; it does not replace it.

## Exact official source identity

- Course root: German Wikiversity `Kurs:Bündel, Garben und Kohomologie
  (Osnabrück 2019-2020)`, frozen root revision 1052895.
- Lecture: page 109016, revision 1003742, timestamp
  `2025-06-08T15:40:27Z`, MediaWiki SHA-1
  `93e650abc2ff69aec101c168714ac078059b79de`, oldid URL
  `https://de.wikiversity.org/w/index.php?oldid=1003742`.
- Worksheet: page 110219, revision 660098, timestamp
  `2020-10-12T13:10:37Z`, MediaWiki SHA-1
  `ed53f8b78bd5729244e9d7576a281721387c234a`, oldid URL
  `https://de.wikiversity.org/w/index.php?oldid=660098`.
- Semantic LaTeX wrapper pages: lecture revision 807050 and worksheet
  revision 807020. Complete recursively expanded terminal TeX witnesses are
  `authority/wikiversity-bgk/unit-12/lecture-12-expanded.tex` (24,059 bytes,
  SHA-256
  `01f084e340c09049b25fe0e9d399a841d9ef422705ab2a0ac634c1011a3e6856`)
  and `authority/wikiversity-bgk/unit-12/worksheet-12-expanded.tex` (8,219
  bytes, SHA-256
  `d411c9610c0dc133391df2ca2e010a7e42b58cd00e0bc6704a3d129d95d56eaa`).
  The lecture closure captures all 138/138 transclusions and the worksheet
  closure all 104/104, with zero missing terminal pages.
- Complete authority manifest:
  `authority/wikiversity-bgk/unit-12/UNIT_AUTHORITY_MANIFEST.json`, 106,742
  bytes, 35 declared files, SHA-256
  `0e83f8718364e1d902dbe961cbf142cc7fb61e4ebfc7537f24488d508334e914`.
  Two consecutive `--resume` replays reproduced the identical byte count and
  hash after the initial live capture.

## Exercise and solution closure

`authority/wikiversity-bgk/unit-12/ORDERED_EXERCISE_MAP.json` is the controlling
ordered map: 7,612 bytes, SHA-256
`62678f3ece59348d362ed7bdf32726642957e6e977970fb276238ad2387e610a`.
It proves exactly 19 exercises in worksheet order. Public solution pages exist
only for Exercises 5 and 10; the other 17 candidates are explicit negative
results. Candidate evidence is
`authority/wikiversity-bgk/unit-12/worksheet-solution-candidates-api.json`,
5,214 bytes, SHA-256
`70dbb446f6644d217cb0174353440857d7f8a5ffb9ae87407d3183a14851f502`.

- Exercise 5 solution: page 125458, revision 1090081, timestamp
  `2026-05-31T12:13:13Z`, MediaWiki SHA-1
  `69678e5b8e9c6a32781db41971073d44112924b5`; XML 4,759 bytes / SHA-256
  `8454e0426944e6d14c5f339ce3b875751a04a1b4ca04aeae22ad7126adba336b`;
  HTML 11,030 bytes / SHA-256
  `b33965fd35360230a9361b0120bb0d17087296b7f68b12f6f78da30f674191ae`.
- Exercise 10 solution: page 96565, revision 1095409, timestamp
  `2026-06-14T18:37:09Z`, MediaWiki SHA-1
  `bdcc1f4516848ddd7123f5bcd61aec649513f946`; XML 4,193 bytes / SHA-256
  `6ad56024ad635141265df8ceafed0dd744ec511a2ea08e3edc91415b6513c527`;
  HTML 6,970 bytes / SHA-256
  `62cea581b91fc684fe2ddd1f2ba6197d4a7d87e4860a9dfa44e6546f05a16294`.

No other solution may be inferred or authored as a source solution.

## Official PDF and component-rights identity

- Lecture PDF: canonical Wikimedia upload, 95,101 bytes, seven Letter pages,
  upload SHA-1 `a71a8f643ee9b67423bc54e255feb21289a526d2`, local SHA-256
  `92000a36dadd4f0f9459276f40e4c927f414269cf441f60532571aa369baa5bd`.
- Worksheet PDF: canonical Wikimedia upload, 49,336 bytes, five Letter pages,
  upload SHA-1 `06f5289a54ca7355353b6a5bf715d597eaba1ccd`, local SHA-256
  `5b789ca531394c68352a85464ff7030f5d07ff70276a22e7202a72f15c5e85a8`.
- The two `images` returned by the semantic pages are these official PDF
  witnesses, not substantive reader media. Therefore Unit 12 has zero
  reader-media positions and no binary reader asset to recover.
- Raw Commons imageinfo, header-only component-rights ledger, Indonesian
  credits, and closure are respectively:
  `authority/commons-imageinfo-bgk-unit-12.json` (7,069 bytes, SHA-256
  `326e8da88b6466d5a711563abf97f343051e20659fcb0b77c8a7d205c0dc775a`),
  `authority/RIGHTS-bgk-unit-12.csv` (1,051 bytes, SHA-256
  `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d`),
  `source/id-ID/media-credits-bgk-unit-12.md` (669 bytes, SHA-256
  `6ec660d662ac191b18598205239fa9da286a6c73e2e9f1fa33eb689850db6f34`),
  and `authority/ASSET_CLOSURE-bgk-unit-12.json` (6,152 bytes, SHA-256
  `9ffae59f082f7a2fa4549c18bf0f04bcb2b7b58f6fe1d8ca3816b6af7aca149a`).
  Two rights replays were byte-identical.
- The semantic course surface is CC BY-SA 4.0. Each official PDF contains its
  own CC-by-sa 3.0 notice. The edition preserves component notices and makes no
  blanket relicensing claim.

## Scope and source findings

The lecture contains 17 numbered semantic entities: definitions of the
irrelevant ideal, projective spectrum/topology/structure sheaf, projective
space and projective schemes; six proved propositions or theorems; two
examples; and definitions/results on projective hypersurfaces and affine
charts. The worksheet contains 19 exercises.

Theorem 12.11 has the correct domain
`D_+(theta(A_+)B)` in its statement, but its proof prints that open set as
equal to all of `Proj(B)`. That equality is not valid without an additional
coverage hypothesis; the Indonesian proof must retain the stated open domain
and disclose the correction. The same proof later writes `D(f)` where the
projective basic open `D_+(f)` is meant. Lemma 12.17 reuses `d` both as the
last variable index and inside degree labels `d_j`; this is readable but must
not be silently allowed to create an index/degree ambiguity in translation.
Minor spelling errors do not change the mathematics.

This boundary was created without Git, upstream contact, credential access,
or publication. Exact provenance for derived work is
`OpenAI Codex gpt-5.6-sol, Ultra.`
