# BGK Unit 24 - terminal authority freeze

Status: PASS. Frozen official Brenner *Bündel, Garben und Kohomologie (Osnabrück 2019-2020)*; this is not classical Unit 24.

Lecture page 109028, revision 1003753, timestamp 2025-06-08T16:37:44Z, MediaWiki SHA-1 `e320bcba4562078adb0a963725102422a19ce046`. Worksheet page 110232, revision 991890, timestamp 2025-01-23T14:50:01Z, MediaWiki SHA-1 `267b9d5873c17927e9a9b7beb9f1813c9457b401`. Both match the frozen course index. All 140 lecture and 53 worksheet transclusions close without missing pages; all 29 manifest file records are rehashed.

Both official PDFs match bytes, SHA-256, upload SHA-1, and page counts (7 lecture, 3 worksheet). The combined course witness covers printed pages 209-215 (lecture 209-214; worksheet 214-215). PDF witnesses are not reader-media positions. There are zero substantive reader assets and zero rights-ledger asset rows.

Translation closure: 3 lecture sections; entities 24.1-24.11; 3 proofs; exercises 24.1-24.5; zero public source solutions; five explicit negative candidate pages. There are 26 semantic heading IDs plus one distinct media-credit ID. Pandoc parses all three semantic documents. This unit-local gate leaves global cross-unit collision validation to the owner's cumulative gate.

Metadata alone was rebound to terminal authority/PDF/component-rights evidence. Every raw post-YAML body remains byte-identical to the complete prior semantic audit; before/after body hashes and the full richer prior audit are retained in the translation QA. Definition 24.6's H^n versus Theorem 24.7's H_n notation and the source induced-map labels without inserted F remain unchanged.

Semantic text and translation: CC BY-SA 4.0. Current Commons PDF description metadata: CC BY-SA 4.0. Embedded PDF notice: CC-by-sa 3.0. Both component facts are preserved without blanket relicensing. Attribution, source-contributor credits, and non-endorsement remain intact. Exact provenance: OpenAI Codex gpt-5.6-sol, Ultra.

Replay: `python scripts/qa_bgk_unit_24_terminal.py`. This terminal record supersedes historical incomplete-capture/preflight observations without changing their historical record. No network, publication, cumulative build, or another unit is part of this replay.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-24/UNIT_AUTHORITY_MANIFEST.json` | 86,764 | `b938d6366fb91058f9e35b1b3b7c4ba255f5f53a7860f9f0dc2b905f732b263b` |
| `authority/artifacts/bgk-lecture-24-official.pdf` | 70,408 | `5f06a64aff74b064df8753ccdf2fe82358fd0f869f67a4df64082743d754a355` |
| `authority/artifacts/bgk-worksheet-24-official.pdf` | 33,575 | `38586fce4aaeb057584f01f781a3972fdd71648e8baacc7eaaf350869fce8981` |
| `authority/commons-imageinfo-bgk-unit-24.json` | 7,069 | `9b595f13f72a9416a587b97aa694b5655c538fa88ffbc69b54508da64c394f97` |
| `authority/RIGHTS-bgk-unit-24.csv` | 1,051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| `authority/ASSET_CLOSURE-bgk-unit-24.json` | 6,151 | `1583dbc371fb9c97b43346d27b50e1e733424d89c4972cc1e6171e5c258c019b` |
| `source/id-ID/bgk/lecture-24.md` | 16,169 | `b820a92e51cbb574bb1a24cfb6c952aa8a881da41fd07e614d402f8924b5da09` |
| `source/id-ID/bgk/worksheet-24.md` | 5,757 | `ae56c2bf34b4c568054806e0c22bc6ec391a57805420742b29f24f6c69c37816` |
| `source/id-ID/bgk/worksheet-24-solutions.md` | 3,023 | `9ae8b27f146fcf52209d3492d47e2eaf90f972464619cadbec5cf3578c218fba` |
| `source/id-ID/media-credits-bgk-unit-24.md` | 673 | `f3db5e0d70186a875db9c554930417bec4413b763f0cd4061f09a577288f440a` |
| `qa/BGK_UNIT_24_AUTHORITY_QA.json` | 4,150 | `4a3e565a117c3517b8222a09c685f0c2ab6536ab22bf51bca88f5dce8ca291ea` |
| `qa/BGK_UNIT_24_TRANSLATION_QA.json` | 25,167 | `4e9c6581364e163f66204418a15879eb2669541079ba4f7e1347d2d74ec4500f` |
