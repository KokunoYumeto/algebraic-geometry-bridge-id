# BGK Unit 9 authority freeze

Status: complete, bounded, and reproducible semantic/source authority for
Unit 9 of Holger Brenner's *Bündel, Garben und Kohomologie (Osnabrück
2019–2020)*. This freezes source identity and component surfaces; it is not a
translated reader or a publication. The deterministic receipt is
`qa/BGK_UNIT_09_AUTHORITY_QA.json`.

## Semantic source identity

- Source project/API: German Wikiversity, namespace `Kurs`,
  `https://de.wikiversity.org/w/api.php`.
- Lecture: *Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019–2020)/Vorlesung
  9*, page 109013, revision 793634, timestamp `2022-08-25T06:26:48Z`,
  MediaWiki SHA-1 `e8ee1bb24612aeb7a7b059301e772f069cfa487b`, oldid URL
  `https://de.wikiversity.org/w/index.php?oldid=793634`.
- Worksheet: *Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019–2020)/
  Arbeitsblatt 9*, page 110216, revision 612139, timestamp
  `2020-01-24T13:09:58Z`, MediaWiki SHA-1
  `a70fb42219bb50825083085945efaa6970121bb4`, oldid URL
  `https://de.wikiversity.org/w/index.php?oldid=612139`.
- Complete recursive semantic closures contain 121/121 requested lecture
  transclusions and 85/85 requested worksheet transclusions, with zero missing
  pages. Exact API, XML, HTML, parse, expanded-TeX, and transclusion witnesses
  are under `authority/wikiversity-bgk/unit-09/`.
- Terminal `/latex` witnesses are lecture page 110017 revision 807076 and
  worksheet page 117164 revision 807046. Their derived terminal TeX witnesses
  are `lecture-09-expanded.tex` (19,366 bytes, SHA-256
  `96e87e8b5a9d845a14e47d2b6c1941cf349cad0c35f417f3979d255a9214c656`)
  and `worksheet-09-expanded.tex` (6,676 bytes, SHA-256
  `6cf28466531ac280fb02918d082d502f3e052f64aa5077112ea28da64d4d1426`).
  These are terminal-byte witnesses; no recursive wrapper-template rebuild is
  claimed.
- Manifest:
  `authority/wikiversity-bgk/unit-09/UNIT_AUTHORITY_MANIFEST.json`, 91,244
  bytes, SHA-256
  `553255a52a560f0c4e14cf761409077d2b6788f2f8c9ace3e65b52743bfa3254`.
  It declares 29 files; every declared byte count and SHA-256 was recomputed
  and matched. Two consecutive resume replays reproduced the same manifest.

## Exercises and lawful solutions

`ORDERED_EXERCISE_MAP.json` is 4,765 bytes, SHA-256
`9d68f421350cc114427a681e7fc8c3b5701e535e0ba61f007b8fc654ebb38e3a`.
It contains exactly 13 worksheet exercises in source order. All 13 frozen
candidate solution pages are explicitly missing. The Indonesian edition must
therefore reproduce the 13 exercises and invent no solutions.

## Official PDF witnesses

- Lecture PDF `authority/artifacts/bgk-lecture-09-official.pdf`: 76,325 bytes,
  SHA-256 `83f58ee5ec71549c5fb5c2ccb7e119bd697ac3e3e04ca6f6c88f2ae0b379cc14`;
  Commons upload SHA-1 `357bf7d70354cb125db2c981cc5a4efd96dc571a`; 7 pages at
  612 × 792 points.
- Worksheet PDF `authority/artifacts/bgk-worksheet-09-official.pdf`: 43,753
  bytes, SHA-256
  `924a768074d08980319a8ca4d74d50a5716adaf6d35ea2dd74d6d45cf3438823`;
  Commons upload SHA-1 `4163c5ec2b0efddab2a80f1c2635a6e41ed36631`; 3 pages at
  612 × 792 points.
- pypdf verifies all 10 page boxes and the final embedded rights pages, which
  name Holger Brenner alias Bocardodarapti and state `CC-by-sa 3.0`.

The normal local route to `upload.wikimedia.org` returned HTTP 429 after the
semantic capture had completed. The two immutable files were then fetched
through Wikimedia's official cache endpoint `208.80.154.240` while retaining
the TLS hostname `upload.wikimedia.org`; both source byte counts and both
MediaWiki SHA-1 values matched before the files were admitted. No third-party
mirror or reconstructed PDF was used.

## Media and component rights

The parse surfaces expose only the two official PDFs, so Unit 9 has zero
substantive reader-media positions. The exact component closure is:

- `authority/commons-imageinfo-bgk-unit-09.json`: 7,059 bytes, SHA-256
  `d4aed8ee70c2a872958fd2ea21310d2f7a32082dc7f08626a608fe9ee727b5ad`.
- `authority/RIGHTS-bgk-unit-09.csv`: 1,051-byte header-only reader-media
  ledger, SHA-256
  `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d`.
- `authority/ASSET_CLOSURE-bgk-unit-09.json`: 6,144 bytes, SHA-256
  `08ba7a80ac7035fc32ac8fcf64031ccbe04c1787907d247c351978b6e57189ee`,
  with zero reader positions, zero recovered assets, and zero broken source
  references.
- `source/id-ID/media-credits-bgk-unit-09.md`: 666 bytes, SHA-256
  `50d2a6089f172973d982e9b8fbf29ee16bb0d228674d9e48de774e383bff8fcb`.

Current Commons description metadata labels the two PDF components CC BY-SA
4.0; each PDF's embedded course notice states CC-by-sa 3.0. Both are preserved
as component evidence. The semantic course and Indonesian derivative remain
bound to CC BY-SA 4.0 with attribution, share-alike, and non-endorsement. No
blanket relicensing claim is made. Two rights-resume replays reproduced the
closure hash above.

## Bounded translation boundary

Unit 9 develops affine schemes: the structure sheaf on a spectrum, sections
as locally representable fractions, stalks as localizations, principal open
subsets, global sections, and examples showing why sheafification matters.
Translation must preserve every definition, example, proposition, proof, all
13 exercises, and the explicit absence of public source solutions.

The accompanying QA receipt verifies exact source identities, complete
transclusion closures, terminal TeX witnesses, ordered exercise and negative
solution closure, official PDF byte identity and geometry, zero reader media,
separate component rights, the complete manifest, deterministic replay, and
`git_used=false` / `upstream_contacted=false`. Model provenance is exactly
`OpenAI Codex gpt-5.6-sol, Ultra.`

Next action: translate Unit 9 from these frozen witnesses in source order,
preserving mathematics, stable IDs, rights, and the no-invented-solutions
boundary; then run the per-unit translation gate before the next cumulative
BGK reader/backend/release milestone.
