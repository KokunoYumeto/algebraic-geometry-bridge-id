# BGK Unit 25 - terminal authority freeze

Status: PASS. This record closes Unit 25 of Holger Brenner's *Bündel, Garben und Kohomologie (Osnabrück 2019-2020)*, not classical Unit 25.

Lecture: page 109029, revision 1003754, timestamp 2025-06-08T16:38:19Z, MediaWiki SHA-1 `ca0f902e2615027938e7edf18cf1641135b671c2`. Worksheet: page 110234, revision 613127, timestamp 2020-01-27T15:28:07Z, MediaWiki SHA-1 `45f8aa55eae6ae2447eb9783f5329b25eeb50519`. Both roots agree with the frozen course index. The 141 lecture and 108 worksheet transclusions close without missing pages. All 33 manifest file records are rehashed and match. Both official PDF byte counts, SHA-256 values, upload SHA-1 values and embedded rights notices pass (7 lecture pages, 5 worksheet pages).

The translation contains 12 numbered lecture entities, 6 proof bodies, 13 ordered exercises, and the single public solution 25.1; the remaining 12 candidate results are explicitly negative. Solution page 125477/revision 1096264 retains contributor Arbota and source attribution `im Wesentlichen Tarek Emmrich`. No solution is invented. The 38 semantic heading IDs plus the media-credit ID are distinct. All 276 Pandoc math nodes remain present.

Only the three documents' YAML source-binding metadata changed. Their complete post-YAML bodies remain byte-identical to the completed semantic audit, as proved by before/after byte counts and SHA-256 in the translation QA. The complete earlier semantic/formula/visual audit is retained there, together with all eleven source-defect decisions and four visible source-error notes. The earlier missing-terminal-output observations are historical and superseded, not current limitations. This replay does not claim a new visual review.

Reader media: zero. The current semantic text/translation license is CC BY-SA 4.0. Current Commons metadata for both official PDFs records CC BY-SA 4.0, while their embedded notices state CC-by-sa 3.0; both component facts remain disclosed without blanket relicensing. Author/source relationships, public-solution contributor credits, non-endorsement, and exact provenance OpenAI Codex gpt-5.6-sol, Ultra. are preserved.

Replay: `python scripts/qa_bgk_unit_25_terminal.py`. This terminal freeze supersedes the earlier missing-tail preflight. No network, Git, build, publication, upstream contact, other-unit edit, or shared-control edit is part of this closure.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-25/UNIT_AUTHORITY_MANIFEST.json` | 109,722 | `f454cb2f8ada795015dcf78d4ad56a54107d9773705b7113a1ef1600b341e26d` |
| `authority/artifacts/bgk-lecture-25-official.pdf` | 85,771 | `f1de2ae26d338559fc894fdc3334bc62a5d1cf858ae5b96f66dc71b3b331c1af` |
| `authority/artifacts/bgk-worksheet-25-official.pdf` | 56,663 | `8909d39c3a3d0fe800a41f63aedcade07de8f558e2b9c6f053cf51cd724e0c40` |
| `authority/commons-imageinfo-bgk-unit-25.json` | 7,069 | `1837434057c81f93b851a37a83554082f0bd16385af66c27525fbf082ebbc0fc` |
| `authority/RIGHTS-bgk-unit-25.csv` | 1,051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| `authority/ASSET_CLOSURE-bgk-unit-25.json` | 6,153 | `b897e839fc6999e5c149e1bf065a634b96246b563860d46f0a16ddb82ae1c9d5` |
| `source/id-ID/bgk/lecture-25.md` | 19,599 | `b531d560298409ce33294c79fda589cb40ee7cbf47c6dd4f82a531d6d243bf51` |
| `source/id-ID/bgk/worksheet-25.md` | 10,712 | `5596b7710af91e3d6615acc1cfded81cb6f5624d1fd01f39fa5d84562386933f` |
| `source/id-ID/bgk/worksheet-25-solutions.md` | 4,388 | `8eaa4aaff283dc23a2e4bb7f3be87908e1c6f33a93849c968123224b644a9e7d` |
| `source/id-ID/media-credits-bgk-unit-25.md` | 1,523 | `c0367344876a648ab7141eb306e6a9a02f14c47b3b57a03012073940f4297037` |
| `qa/BGK_UNIT_25_AUTHORITY_QA.json` | 3,963 | `59df007bfbbdaf5a3c434eecfce371450c1eb921dffec50e8c24d2936bd51e15` |
| `qa/BGK_UNIT_25_TRANSLATION_QA.json` | 42,120 | `5d9ea4f59d5ed10c65912b509d4787391e9ddee017dcdab2f1d3ecfa4bd2cd71` |
| `scripts/qa_bgk_unit_25_terminal.py` | 15,671 | `4c80e83bb86fc2fc4ca550c86e5b53bd05894f664d2cbed8cc1559dff1a16af0` |
