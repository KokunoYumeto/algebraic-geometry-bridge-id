# BGK Unit 13 authority freeze

Status: **PASS_COMPLETE_SEMANTIC_AUTHORITY_PDF_RIGHTS_ZERO_MEDIA**.

This is the BGK 2019--2020 Unit 13 authority, not the similarly numbered
Algebraische-Kurven lane. One serialized `--resume` completed on 2026-08-31
after the external Wikimedia rate limit changed. No parallel capture ran.

| Evidence | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-13/UNIT_AUTHORITY_MANIFEST.json` | 130,087 | `792935b01daf0a2ee22decd78d3f9ccb8d95719c628cdd306b66405ea1427282` |
| `authority/artifacts/bgk-lecture-13-official.pdf` | 85,160 | `dcf6236638c6f34b253d7fd0fa8a9ec188ce9acef62dc1758f0dbfd7528809c0` |
| `authority/artifacts/bgk-worksheet-13-official.pdf` | 67,811 | `da5afab54c1ae5035074d5254b3d91a980c436609e83961705ec55701fe0cecb` |
| `authority/commons-imageinfo-bgk-unit-13.json` | 7,069 | `a8f1b15de0538ca12f5e64b7abce10ee23eb9608ee0a923dae8a0beb7366bfa3` |
| `authority/RIGHTS-bgk-unit-13.csv` | 1,051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| `authority/ASSET_CLOSURE-bgk-unit-13.json` | 6,152 | `3e2819ebda15bd726b605c2c449897ab34a9da8f26dbc9e7bafbff1da857456d` |
| `source/id-ID/media-credits-bgk-unit-13.md` | 673 | `a8d038e19cb09bb258cdc051cc639d6a3f10e98e3e355d30981733e288060aa0` |
| `qa/BGK_UNIT_13_AUTHORITY_QA.json` | 3,950 | `e07bff791852294265e7e0f3fe84cad4629b7af12a305cf69578874d8a2f84d1` |
| `qa/BGK_UNIT_13_TRANSLATION_QA.json` | 3,103 | `a5107d9dae0a53417e24f070eb8fd28aa4adfa455731856acb3529d54ad89d1d` |

The lecture PDF is seven pages and matches frozen upload SHA-1
`4174c9f24164d1b8a6eae9174330d09df3baabf4`; the worksheet PDF is five
pages and matches upload SHA-1
`746b331c8970bf1f16132de538067a88ec3a0d96`. All 33 manifest rows replay
with zero missing files, byte mismatches, or SHA-256 mismatches.

The semantic closure retains 170 lecture and 135 worksheet transclusions, 23
ordered exercises, zero public solutions, and 23 explicit negative solution
candidates. The PDFs are authority witnesses, not reader-media positions.
The zero-media closure records zero assets and preserves both embedded
component notices and current Commons metadata without a blanket relicensing
claim.

Canonical Indonesian files:

| Target | Bytes | SHA-256 |
|---|---:|---|
| `source/id-ID/bgk/lecture-13.md` | 19,362 | `d7e7c00a14ca8f373f0e24b241e68dc9a1f381a824e67f1c0815d415d4c43a54` |
| `source/id-ID/bgk/worksheet-13.md` | 13,146 | `a287f9218121190e8b2944f2e1596d4487f62035600b06798a3307e38c0ef5ee` |
| `source/id-ID/bgk/worksheet-13-solutions.md` | 1,959 | `b94a0f888c48ed2be1985f7a045cb1c41373bc68bf64d5ade289f3bd7d7c6872` |

There are 22 numbered lecture entities, six proof bodies, 23 exercises, zero
invented solutions, 59 unique target heading IDs, zero reader images, and no
remaining `PENDING_FINAL_CAPTURE_SHA256` sentinel. Exact provenance is
`OpenAI Codex gpt-5.6-sol, Ultra.`

This freeze records existing authority and QA only. It does not authorize a
translation rewrite, build, Git operation, publication, or upstream contact.
