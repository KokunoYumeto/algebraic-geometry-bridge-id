# BGK Unit 19 - terminal authority freeze

Status: PASS. Bound to the frozen official Brenner *Bündel, Garben und Kohomologie (Osnabrück 2019-2020)* course; the classical Unit 19 tree is excluded.

Lecture page `109023`, revision `793611`, timestamp `2022-08-25T06:23:18Z`, MediaWiki SHA-1 `4eb53f5c2f3154e392b0a8989bc69dca84449e0c`; worksheet page `110228`, revision `617377`, timestamp `2020-02-11T17:14:48Z`, MediaWiki SHA-1 `e8bfe61141c279e01d73db7311fbd7842378f7ee`. The manifest was frozen at `2026-08-31T13:48:48.582329+02:00`. All 163 lecture and 83 worksheet transclusions close without missing pages; all 33 declared authority records rehash without mismatch.

The 12 ordered exercises admit only public solution 19.10, with 11 explicit negative candidates and no invented solutions. The sole solution is page `116008`, revision `1094743`, MediaWiki SHA-1 `e3b3f8d7c95285e6d294f385eda15f3a5d27ec6c`. Both PDF witnesses match exact source bytes and upload SHA-1: lecture 100,644 bytes / `b4925ff55aa2f3c72a595abfc8bb93c95e5bb4ac` / 7 pages; worksheet 54,883 bytes / `1b67f5b59317b2e082f112250a2612d7a4e22ac8` / 5 pages.

Reader media: zero. Commons metadata is CC BY-SA 4.0 while both embedded PDF notices state CC-by-sa 3.0. Both provenance facts are preserved without blanket relicensing; the PDFs are authority witnesses, not reader-media positions. The semantic course text and translation remain CC BY-SA 4.0. Exact provenance: OpenAI Codex gpt-5.6-sol, Ultra. Author/contributor credits and non-endorsement are retained.

QA is deterministic PASS: 13 lecture entities, nine proof bodies, 12 ordered exercises, one public solution, 43 unique heading IDs including media credits, and Pandoc math-node counts 161/64/2. All three post-YAML bodies are byte-identical to the prior complete semantic audit. This closure changes only metadata and QA/control bindings. The prior formula audit, source anomalies, three semantic-versus-old-PDF differences, and historical corrections are preserved in the translation QA. No source anomaly was silently repaired or discarded, and no new mathematical edit was made.

Replay: `python scripts/qa_bgk_unit_19_terminal.py --verify`. This record supersedes earlier capture-tail absence observations without rewriting their historical evidence. No network, build, Git, publication, shared-ledger, queue, goal, cursor, or other-unit mutation is part of this closure.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-19/UNIT_AUTHORITY_MANIFEST.json` | 108,630 | `ffd4e79d12cd6fd63836cb6d7fd17e5dc6481f3befaeb50efeb9a47c4cc70512` |
| `authority/artifacts/bgk-lecture-19-official.pdf` | 100,644 | `656e979ceed28a4a9af768d91d4a0fdc53adcf65272e40edb153bc74c3b4ead7` |
| `authority/artifacts/bgk-worksheet-19-official.pdf` | 54,883 | `7b9a60924fac5d61d119a9a6156a7c22ce767a10a0dc645c4ff188a53c900283` |
| `authority/commons-imageinfo-bgk-unit-19.json` | 7,070 | `5f93abe4bbb12a8f2bbc3678b51b28d39ececc0bb71c494e8a1b1d51d15d0545` |
| `authority/RIGHTS-bgk-unit-19.csv` | 1,051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| `authority/ASSET_CLOSURE-bgk-unit-19.json` | 6,154 | `0adbc2e593bd9dab369022c73e8d4e69e988ce95bc57e7b1414147c8eb0e03fd` |
| `source/id-ID/bgk/lecture-19.md` | 19,377 | `1436b56e59c74cc2e78251ce255f8422e33e58973c8ed542b6f2753655e1e55b` |
| `source/id-ID/bgk/worksheet-19.md` | 8,736 | `cc87c5bb81ecac19d6938cd768d22b21b1d1210c3ee0d50ab905029a34e309a0` |
| `source/id-ID/bgk/worksheet-19-solutions.md` | 3,136 | `fd438e3ebd092c5c33a119ea2324eb789cb5ec65044bea56d967bcd04685005d` |
| `source/id-ID/media-credits-bgk-unit-19.md` | 673 | `28107d1f8bd51130fd01256467fc46c67911791711e619b9e46179b63c658841` |
| `qa/BGK_UNIT_19_AUTHORITY_QA.json` | 3,962 | `0faed949e887c0d4611f1d8d261c4320d72499163762e63095bff49326cd78fc` |
| `qa/BGK_UNIT_19_TRANSLATION_QA.json` | 21,153 | `b93e652b6561505dd592c04471949149ae2ce1b2aaebcf72177e8932e502bef6` |
