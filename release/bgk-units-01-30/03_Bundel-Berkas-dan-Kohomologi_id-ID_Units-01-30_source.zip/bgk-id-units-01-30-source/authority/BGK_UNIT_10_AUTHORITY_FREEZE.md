# BGK Unit 10 authority freeze

Status: complete, bounded, and reproducible semantic/source authority for
Unit 10 of Holger Brenner's *Bündel, Garben und Kohomologie (Osnabrück
2019-2020)*. This freezes source identity and component surfaces; it is not a
translated reader or a publication. The deterministic receipt is
`qa/BGK_UNIT_10_AUTHORITY_QA.json`.

## Semantic source identity

- Source project/API: German Wikiversity, namespace `Kurs`,
  `https://de.wikiversity.org/w/api.php`.
- Lecture: *Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung
  10*, page 109014, revision 1003733, timestamp `2025-06-08T15:32:21Z`,
  MediaWiki SHA-1 `4dfde713fd1b38ebf77c1be9a8717dbde34c76ba`, oldid URL
  `https://de.wikiversity.org/w/index.php?oldid=1003733`.
- Worksheet: *Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/
  Arbeitsblatt 10*, page 110217, revision 612138, timestamp
  `2020-01-24T13:09:39Z`, MediaWiki SHA-1
  `a4beef842f165681bee727e1e9c959365f09a28c`, oldid URL
  `https://de.wikiversity.org/w/index.php?oldid=612138`.
- Complete recursive semantic closures contain 146/146 requested lecture
  transclusions and 53/53 requested worksheet transclusions, with zero missing
  pages. Exact API, XML, HTML, parse, expanded-TeX, and transclusion witnesses
  are under `authority/wikiversity-bgk/unit-10/`.
- Terminal `/latex` witnesses are lecture page 112197 revision 807048 and
  worksheet page 117165 revision 807018. Their derived terminal TeX witnesses
  are `lecture-10-expanded.tex` (23,138 bytes, SHA-256
  `8b05be7634ca7c81f3aca9a8c7c3cad93637563d7341fb9987a29541043c9d6e`)
  and `worksheet-10-expanded.tex` (2,082 bytes, SHA-256
  `36959f4a8b6fa759c3d14b459fb21f4adcd613f4d66b663bb4fb6f54663cf703`).
  These are terminal-byte witnesses; no recursive wrapper-template rebuild is
  claimed.
- Manifest:
  `authority/wikiversity-bgk/unit-10/UNIT_AUTHORITY_MANIFEST.json`, 86,668
  bytes, SHA-256
  `a8b6384c316086dde5825b6c776289f93a1a2c4a4654bac57148f9e25a6f197f`.
  It declares 29 files; every declared byte count and SHA-256 was recomputed
  and matched. Two consecutive `--resume` replays reproduced the same manifest.

## Exercises and lawful solutions

`ORDERED_EXERCISE_MAP.json` is 2,969 bytes, SHA-256
`5af4a6aa6a975ec44339526cb40988e5c799f71f7c02eaada77f2fe22dd38ea2`.
It contains exactly six worksheet exercises in source order. All six frozen
candidate solution pages are explicitly missing. The Indonesian edition must
therefore reproduce the six exercises and invent no solutions.

## Official PDF witnesses

- Lecture PDF `authority/artifacts/bgk-lecture-10-official.pdf`: 86,498 bytes,
  SHA-256 `4f30cd25b1460fe216019e36529d80b3880b9ba7c7ee85ee6246f9454b51411a`;
  Commons upload SHA-1 `416f6218ed62449cd7c06d99ea93240ca888871d`; seven pages at
  612 x 792 points.
- Worksheet PDF `authority/artifacts/bgk-worksheet-10-official.pdf`: 31,609
  bytes, SHA-256
  `b8af98d8fac212b200909dff694cce7a7ea104b6dc083b3a01e1d60eb9686760`;
  Commons upload SHA-1 `bdece20657b21988f25639bff4a1ce4aa552d9b6`; three pages at
  612 x 792 points.
- `pypdf` verifies all ten page boxes and the final embedded rights pages,
  which name Holger Brenner alias Bocardodarapti and state `CC-by-sa 3.0`.

The canonical Wikimedia upload URLs, advertised byte counts, MediaWiki SHA-1
values, and admitted local SHA-256 values are bound in the authority manifest.
Both frozen PDF byte streams match those advertised identities. No
third-party mirror or reconstructed PDF is an authority surface.

## Media and component rights

The parse surfaces expose only the two official PDFs, so Unit 10 has zero
substantive reader-media positions. The exact component closure is:

- `authority/commons-imageinfo-bgk-unit-10.json`: 7,069 bytes, SHA-256
  `a9660d0c71ca4e031d4072b2eb8356a838de3485970e5235058ecd8e182d4331`.
- `authority/RIGHTS-bgk-unit-10.csv`: 1,051-byte header-only reader-media
  ledger, SHA-256
  `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d`.
- `authority/ASSET_CLOSURE-bgk-unit-10.json`: 6,151 bytes, SHA-256
  `9604b9c3f318194a61aeaab5519d164c9e8740b5c04db570b3d2657ac990da6b`,
  with zero reader positions, zero recovered assets, and zero broken source
  references.
- `source/id-ID/media-credits-bgk-unit-10.md`: 669 bytes, SHA-256
  `9bf0206eed102344d117836d2b711212af7ec99e317d88db7e7d3d145320bcf6`.

Current Commons description metadata labels the two PDF components CC BY-SA
4.0; each PDF's embedded course notice states CC-by-sa 3.0. Both are preserved
as component evidence. The semantic course and Indonesian derivative remain
bound to CC BY-SA 4.0 with attribution, share-alike, and non-endorsement. No
blanket relicensing claim is made. Two rights-resume replays reproduced the
closure hash above.

## Bounded translation boundary

Unit 10 introduces schemes and scheme morphisms. It covers affine
neighborhoods, open and quasiaffine subschemes, punctured spectra, gluing
examples for the affine and projective lines, the universal morphism from a
locally ringed space to an affine scheme, canonical morphisms to
`Spec(Z)`, affine-space morphisms defined by global functions, schemes and
morphisms over a base, finite-type morphisms, and open, closed, and general
immersions. Translation must preserve all 19 numbered lecture entities,
their proofs, every displayed diagram, all six exercises, and the explicit
absence of public source solutions.

The frozen semantic source has a visible index collision in Definition 10.16:
the cover of `Y` is indexed by `i`, the finite cover of
`phi^{-1}(V_i)` is then written with `I_j`, and the coordinate-ring map uses
`V_j`. The Indonesian edition must not silently propagate or silently repair
this. It must state the source wording and visibly normalize the dummy indices
to a consistent `j in J_i`, recording the treatment in
`00_control/CORRECTIONS.csv`.

The accompanying QA receipt verifies exact source identities, complete
transclusion closures, terminal TeX witnesses, ordered exercise and negative
solution closure, official PDF byte identity and geometry, zero reader media,
separate component rights, the complete manifest, deterministic replay, and
`git_used=false` / `upstream_contacted=false`. Model provenance is exactly
`OpenAI Codex gpt-5.6-sol, Ultra.`

Next action: translate Unit 10 from these frozen witnesses in source order,
preserving mathematics, stable IDs, rights, and the no-invented-solutions
boundary; then run the per-unit translation gate before continuing to Units
11-12 and the cumulative BGK reader/backend/release milestone.
