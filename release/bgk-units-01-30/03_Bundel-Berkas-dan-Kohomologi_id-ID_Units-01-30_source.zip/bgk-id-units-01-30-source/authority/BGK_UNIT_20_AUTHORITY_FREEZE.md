# BGK Unit 20 - terminal authority freeze

Status: PASS. Bound to the frozen official Brenner *Bündel, Garben und Kohomologie (Osnabrück 2019-2020)* course; not classical Unit 20.

Lecture page 109024, revision 1070035, timestamp `2026-02-06T08:44:37Z`, MediaWiki SHA-1 `69eee548900d7b7e00c3b3bd10e297a700800a89`; worksheet page 110229, revision 1069949, timestamp `2026-02-06T08:22:42Z`, MediaWiki SHA-1 `deebce0847dc537e97deb2cccbd5eb87000a92c1`. The frozen course index agrees. All 169 lecture and 111 worksheet transclusions close with zero missing pages, and all 32 terminal manifest file records replay exactly.

Both dedicated official PDF witnesses pass signature, source byte count, upload SHA-1, SHA-256, page count and embedded-rights-text checks: 96,088 bytes / 7 lecture pages / upload SHA-1 `21addd9a85777481565a4bb28602c5f64fb9d966`; 53,758 bytes / 5 worksheet pages / upload SHA-1 `a826ee89acd343a57ccd7102d7b5eadc9c2569b9`. The 265-page official course PDF remains the historical witness for printed pages 178-186; its previous complete visual audit is preserved, not newly claimed.

The translation retains 16 ordered lecture entities, eight proofs, all 13 ordered exercises, zero public solutions and all 13 explicitly negative candidate pages (with the recorded MediaWiki title normalization). No solution was invented. Fresh YAML/Pandoc parses reproduce 317 math nodes and 43 explicit unique Unit20 reader IDs with zero warnings, images, control characters or placeholders. Exact provenance: OpenAI Codex gpt-5.6-sol, Ultra.

Only the three source frontmatters changed. Their post-YAML bodies remain byte-identical to the complete semantic audit: lecture `68e1ef42291587af859649894987a49a64f4d8ff0c8fc745fa1023d77d970161`, worksheet `79951e6ef1c9763288705a4c97ca5eaf48733635917dd3003b71ddae925c076b`, solution-coverage statement `9aa6203f9693002837e75a93d1ff207c72cf6ee2a9853b31346f786c3639ab13`. The full earlier formula audit and all five source-anomaly findings remain in translation QA. The current map hash, manifest, official PDFs, rights ledger and asset-closure metadata replace obsolete capture-tail bindings; mathematical prose, formulas, exercises, IDs and negative-solution scope are unchanged.

Reader-media positions and local assets: zero. The header-only rights ledger has zero data rows. Both PDF witnesses are authority components, not reader-media positions. Semantic text and translation are CC BY-SA 4.0; current Commons PDF metadata is CC BY-SA 4.0 and embedded notices state CC-by-sa 3.0. Both facts, original credits and non-endorsement are preserved without blanket relicensing.

Replay: `python scripts/qa_bgk_unit_20_terminal.py` verifies the exact generated terminal artifacts without writes. `--emit-patch` emits only the bounded authority-QA, translation-QA and freeze patch for application. No network, Git, build, publication, shared ledger, other-unit source, queue, goal or cursor operation is performed. This terminal record supersedes earlier missing-tail observations without rewriting their historical artifacts.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-20/UNIT_AUTHORITY_MANIFEST.json` | 118,905 | `a59a4536a441cfdbcd579525119112156fcc5dc8041ba97d4834e18db55cd658` |
| `authority/artifacts/bgk-lecture-20-official.pdf` | 96,088 | `fae4d603a9f8f19f106c0e4e0c5960076c112796ec0d14dfb7f1e9e0c8c01cd9` |
| `authority/artifacts/bgk-worksheet-20-official.pdf` | 53,758 | `e477498aa6c1b82e4ae1ec37e9f2c814db79734f04583b0da77ca00cc2423daf` |
| `authority/commons-imageinfo-bgk-unit-20.json` | 7,069 | `1f7a9a669928fc49d59ded2a4c31f89d6ebad8ec4662d18339aa225103fa0f3e` |
| `authority/RIGHTS-bgk-unit-20.csv` | 1,051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| `authority/ASSET_CLOSURE-bgk-unit-20.json` | 6,152 | `2cdfc5e32e86b5f704f1f00f6d5690166967464fbe2c6474086e28e470463b40` |
| `source/id-ID/bgk/lecture-20.md` | 20,603 | `4d446afbc73f4a81ca638c2a6f5626934fa712d8c0bfdbd37b4b133769cf3383` |
| `source/id-ID/bgk/worksheet-20.md` | 11,113 | `6776d88036231d6342ca0e6528db12cc9c83fe02acad3244b289afc4b74f8fd4` |
| `source/id-ID/bgk/worksheet-20-solutions.md` | 1,790 | `a122771364d56ef111b88b22ff6bc46341db7ea92f0be7c2463dd44d60cc96e1` |
| `source/id-ID/media-credits-bgk-unit-20.md` | 673 | `2e6aac209d1c48d98326e17b676d1f48f5f7b799d9a804dcfcfe0cff506cf178` |
| `qa/BGK_UNIT_20_AUTHORITY_QA.json` | 4,504 | `3a3cca26ec400ba9523e337d11695a2e364c6efd821fd942f2356e894f1bd418` |
| `qa/BGK_UNIT_20_TRANSLATION_QA.json` | 36,785 | `cecdb8cd133eae3cac7bf4cdf88ea60b065be1eabc94388d1b817e48245e0032` |
| `scripts/qa_bgk_unit_20_terminal.py` | 28,619 | `1e15a48ec5faecc5fa36f0c43fafd853865c0cd8cb6cfc37656079b387a37830` |
