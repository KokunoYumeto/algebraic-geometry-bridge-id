# BGK Unit 21 - terminal authority freeze

Status: PASS. This freeze binds the official Brenner *Bündel, Garben und Kohomologie (Osnabrück 2019-2020)* authority and excludes classical Unit 21.

Lecture: page 109025, revision 793614, timestamp `2022-08-25T06:23:48Z`, MediaWiki SHA-1 `937e82c634f49d87e1555222366229d89f65aef0`. Worksheet: page 109894, revision 707217, timestamp `2021-10-07T06:20:57Z`, MediaWiki SHA-1 `30e9bf77922d6344a0429d26cb5c6a345a3ab994`.

All 35 terminal manifest records recompute exactly. All 114 lecture and 100 worksheet transclusions close with zero missing pages, with wikitext SHA-1 replay. The ordered map contains 13 exercises; public solutions are exactly 21.3, 21.9, and 21.10, with ten explicit negative candidates and no invented solutions. The two official unit PDFs each have five pages and match source byte count, upload SHA-1, and SHA-256. All ten pages were rendered and visually inspected on 2026-08-31, including the intentionally blank fourth pages and the embedded rights notices on page five.

Reader media is zero. Current Commons PDF metadata is CC BY-SA 4.0 while the embedded notices say CC-by-sa 3.0; both component facts remain preserved without blanket relicensing. Frozen Web entities remain the semantic authority. The historical course PDF is an older visual witness, including the disclosed Exercise 21.5 version difference.

Only source metadata was updated. The three Indonesian post-YAML bodies are byte-identical to the prior complete semantic audit: all prose, formulas, stable IDs, exercises, public solutions, and nine visible source-anomaly notes remain unchanged. The full previous audit is preserved in the terminal translation QA, including formula-by-formula parity, historical PDF visual findings, and all seven disclosed semantic boundaries. Current Pandoc parses pass with 128, 94, and 99 math nodes; 39 semantic heading IDs plus one media-credit ID are unique. Exact provenance: OpenAI Codex gpt-5.6-sol, Ultra.

Replay: `python scripts/qa_bgk_unit_21_terminal.py`. The script is offline/read-only unless its generated patch is explicitly applied. All deterministic gates pass before it emits any patch. No network, Git, Lean/Lake, reader build, publication, shared-control edit, or other-unit edit is part of this closure.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| `authority/wikiversity-bgk/unit-21/UNIT_AUTHORITY_MANIFEST.json` | 96,619 | `684637decc945c94137670f7c4238110b4a4c395287cf985b3f69adceedd9ef7` |
| `authority/wikiversity-bgk/unit-21/ORDERED_EXERCISE_MAP.json` | 6,940 | `69b9ecd0120626c3e4c8dc018862869b13316fa3e6c76edf5954807dcff6af65` |
| `authority/wikiversity-bgk/unit-21/worksheet-solution-candidates-api.json` | 8,038 | `19b8384f8a3e37828a2b5ae32f2e58809b7ac6169c6bff1b8f1649b4e4880782` |
| `authority/artifacts/bgk-lecture-21-official.pdf` | 60,765 | `31ddf1226d25837e8e79f15417008616f2d054337f06043feeea581b6d3ed606` |
| `authority/artifacts/bgk-worksheet-21-official.pdf` | 51,605 | `20491699d1583220c62fd69d54b9d4d14f4fc3fee492d3bed72afa1f2f849e1e` |
| `authority/commons-imageinfo-bgk-unit-21.json` | 7,069 | `53f67c1cb2ec680597f493506b42accca750a7344e742fde2438b26b62b496f0` |
| `authority/RIGHTS-bgk-unit-21.csv` | 1,051 | `87f9d56b1300a56ca68e4aa8f50e3d50ab622d7a4d05221089d49e1dba35981d` |
| `authority/ASSET_CLOSURE-bgk-unit-21.json` | 6,151 | `5fd26087ca516efbb8cbc6823c3622338bd9272eb7ab1452c87ba41c6e28afdd` |
| `source/id-ID/bgk/lecture-21.md` | 12,494 | `e0445540225e4b533fd3bbaa26d022ecc45812e4a129ed40ea9f647bb0d9c86a` |
| `source/id-ID/bgk/worksheet-21.md` | 11,900 | `3c3399a92733eac1d7f97133e2f90921f48060df6c07209cb22e3ed62b2b9dcb` |
| `source/id-ID/bgk/worksheet-21-solutions.md` | 9,935 | `5ac18ef8a5d361c137968e9a619d0c3035830ab00f37075d0912201ca69beae3` |
| `source/id-ID/media-credits-bgk-unit-21.md` | 673 | `07ef5ecaa38890028ebbc245b3511bfb3eb8a29b174c8802dd84a3492496d814` |
| `qa/BGK_UNIT_21_AUTHORITY_QA.json` | 4,919 | `dd6279cfdc7e82a6f6cea6fffe09fbcf32507777cec5805f70e99ac958ce11e5` |
| `qa/BGK_UNIT_21_TRANSLATION_QA.json` | 32,040 | `9f298ef27b6d8ab99718af77ae199b20a2d18ca33534a7e72f28a7e3cb26cd84` |
