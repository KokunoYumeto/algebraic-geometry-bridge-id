# BGK Units 13–30 additive glossary intake

Status: **PASS — bounded append-only intake complete**  
Date: 2026-08-31  
Provenance: **OpenAI Codex gpt-5.6-sol, Ultra.**

## Deliverables and contract

The companion ledger adds **502 per-unit records for 296 distinct German
source lemmas**. Its exact schema is:

`term_id,unit,source_language,source_term,target_language,preferred_target,accepted_variants,scope,status,rationale`

All records use integer `unit` 13–30, `source_language=de`,
`target_language=id-ID`, `scope=BGK`, and `status=admitted`.
The frozen IDs are **BGK-T13-30-0001 through BGK-T13-30-0502**.
Any subsequent additions must begin at 0503; do not renumber these records.
Repeated terms in distinct units are intentional evidence bindings. The
per-unit key `(unit,source_language,source_term,target_language,scope)` is
unique. One preferred target is used for each exact source lemma throughout
this sidecar.

Rows by unit: 13: 32; 14: 23; 15: 33; 16: 32; 17: 30; 18: 30; 19: 31; 20: 21; 21: 33; 22: 27; 23: 28; 24: 36; 25: 28; 26: 39; 27: 34; 28: 4; 29: 21; 30: 20.

| New artifact | Bytes | SHA-256 |
|---|---:|---|
| `00_control/BGK_UNITS_13_30_TERMINOLOGY.csv` | 98007 | `152690ecb4f0bf9ca704b083ca9e83e2c5618bff0c77e4938d48cfe49ddc2b10` |
| `source/id-ID/bgk/glossary-bgk-units-01-30.md` | 9134 | `918a90c8724122beec7fcee6dd237c445d57ebaeb7e050812b4c042d76bbc578` |

The reader root is `br-bgk-2019-glossary-01-30`; its four subordinate
headings use the same prefix. The glossary is a concise crosswalk, not an
exhaustive replacement for definitions or an extra translated source unit.

## Preservation and selection rules

- No lecture, worksheet, solution, media-credit file, shared central ledger,
  or existing Units 1–12 payload was edited by this intake.
- `00_control/TERMINOLOGY.csv` remains exactly **390 rows; 62342 bytes;
  SHA-256 0b66612398a771224b27d2dd691ff971d09793d5485f5d49673437996a201e56**.
- Exact existing BGK or whole-lane bindings were not duplicated. Existing
  Brenner-only rows can receive new BGK bindings without changing their IDs,
  preferred wording, or scope. Existing central duplicates were not merged
  or retired.
- German inflection is reduced to a source lemma, not assigned extra IDs:
  for example `globaler Schnitt` covers `globale Schnitte`.
  Genuine lexical source synonyms, such as `duale Garbe` and `Dualgarbe`,
  remain separately searchable.
- Ten initially considered unit associations lacked sufficient exact lexical
  evidence and were omitted before the IDs were frozen. The duplicate
  singular/plural global-section association was merged. There is no claim
  that every word in every unit has been exhaustively indexed.
- Unit 28 and Unit 29 have no files at the exact
  `BGK_UNIT_28_TERMINOLOGY_CORRECTIONS_PROPOSAL.md` and
  `BGK_UNIT_29_TERMINOLOGY_CORRECTIONS_PROPOSAL.md` paths. Their additions
  were checked directly against the frozen expanded TeX and current
  Indonesian lecture/worksheet. No nonexistent proposal is cited.
- The three integration audits are decision inputs, not current authority
  closure claims: some historical status/hash tables in them predate the
  later unit metadata closure. The source identities below are the intake
  snapshot, not a replacement for the owner's release receipts.

## Resolved terminology decisions

| Family | Intake decision |
|---|---|
| Sheafification | Keep existing preferred **berkasisasi**. Explain **pembentukan berkas** as its contextual synonym, not as a translation defect or a new central row. |
| Unit and rank | Existing **satuan**, **berkas satuan**, and **rank** remain the glossary preferences; **unit**, **berkas unit**, and **peringkat** are legitimate contextual aliases. A ring unit need not equal 1. |
| Restriction | Prefer **restriksi / pemetaan restriksi / homomorfisme restriksi**; accept the corresponding **pembatasan** forms. Explicitly separate restriction from boundedness. |
| Domains and quotients | Prefer **domain integral** and **gelanggang faktor**; accept **daerah integral**, **gelanggang hasil bagi**, and **gelanggang kelas sisa**. Fraction fields and quotient rings remain distinct. |
| Twists | Prefer **puntiran / terpuntir**; accept current **twist / terpilin**. Do not touch signs, degree shifts, duals, or the separate twisted-cubic name. |
| Smoothness | Prefer **mulus** and accept **halus** for geometric smoothness. Do not equate smoothness with regularity in arbitrary base settings; fine monomial grading has a separate sense of **halus**. |
| Flasque versus acyclic | Prefer **flasid**, accepting **flasque / flabby**. None is accepted as an alias for **asiklik**. |
| Covering | Prefer generic **penutup**, accepting **liputan**; preserve inherited exact **liputan afin standar**. Open covers and covering-space maps are different notions. |
| Projective and canonical | BGK retains **projektif**, with **proyektif** as a scoped spelling alias. **Kanonis / kanonik** name the same canonical object; anti- remains meaningful. |
| Homomorphisms and sections | Preserve sheaf/module/bundle object types, structured homomorphisms, global Hom versus sheaf Hom, stalk versus fiber, and section versus intersection. |
| Divisors | **Pembagi** and **divisor** are admitted contextual aliases. **Divisor nol** means the divisor of zeros of a function, not necessarily the zero divisor of the divisor group. |
| Ringed spaces | In the new glossary, prefer **ruang bergelanggang**: a topological space equipped with a sheaf of rings. **Ruang berdering** is explicitly labeled inherited reader wording, not recommended terminology. The old central row and canonical body were not rewritten. |
| Exact sequences | Both existing adjective orders are accepted when **eksak** is present. Missing exactness is not an acceptable synonym. |
| Notation | No terminology row authorizes changes to source operators, variables, indices, equality/isomorphism signs, hypotheses, or numbered references. |

These preferences settle this additive glossary; they do not create a
post-translation normalization obligation or a human-review release gate.
There is **no unresolved semantic issue in this bounded intake**. The
source's previously documented mathematical defects remain in their existing
edition notes; this terminology task neither repairs nor re-audits them.

## Input snapshot

### Integration audits

| Path | Bytes | SHA-256 |
|---|---:|---|
| `00_control/BGK_UNITS_13_20_TERMINOLOGY_INTEGRATION_AUDIT.md` | 8050 | `2d4fcff749a7c522c654634d47d598ae7581b773b7043c4a90712f6efed15ba0` |
| `00_control/BGK_UNITS_21_24_TERMINOLOGY_INTEGRATION_AUDIT.md` | 19248 | `ea49b0631379fc328ff7ebd56fc01676bacc1bd6c5fc807cf158455519fe4cfe` |
| `00_control/BGK_UNITS_25_27_TERMINOLOGY_INTEGRATION_AUDIT.md` | 18290 | `7827933a7905ac41274a07f818040beb23b4de09d1e0180827f2ff0762ad8db2` |

### Unit proposals

Every following row denotes the exact path
`00_control/BGK_UNIT_NN_TERMINOLOGY_CORRECTIONS_PROPOSAL.md`.

| NN | Bytes | SHA-256 |
|---|---:|---|
| 13 | 15328 | `dc3ef689dd55a18720ee21ab5d0ab18da9d052fad6b37f6fd75cdda8c4663c07` |
| 14 | 10857 | `9969c2753909295c4ec202fb54bb94c58fe4ade3ccadfa40848ef2cf83492477` |
| 15 | 13660 | `7f11e91348675e5f05cb4d5c81d0e80f5e1f3ae8ebeabaf7b54f2508892c063b` |
| 16 | 15402 | `f2c9fb93cc61409fc04feadbe131191155b2c17b8503c7fa7b73858d13b04a34` |
| 17 | 16489 | `7bdbd4eca0a2b077df4a4e0a4b46aad4e91b0cde5b63e8f1607a87e5a7736fa1` |
| 18 | 15930 | `3af1f060508750f76de6ba482833582d06f276692f64ee52ec67e6fcb91d9ca3` |
| 19 | 22516 | `08e03fc450c65dd0a7b8c10cb6ff9077d80dae60e36ac72be9ff34296d827424` |
| 20 | 20424 | `9d2c46a71563f12f8ab5698815adf14c0f7d3a81c81e8bf000e3ff71ba3d1285` |
| 21 | 20381 | `577c9c97ba74692693166d16907112bd166dd5334fd0ac27deb8a18caa3024fc` |
| 22 | 20881 | `83c4a19963900d070774c96574fa5ce047db8c2d9786ef04c095c0040d3a52d1` |
| 23 | 17129 | `1b880dd33af3ae68c0a56abec582053dc40dd4f642f3fa7e36bcb38cd6d4b45d` |
| 24 | 13598 | `37a901540d474a3cdceaa6b8fd12192d7d70540db70df1fd53a3692303af15d0` |
| 25 | 19527 | `47e16db7ad4220cdd480ab0625c83519fc38b828288c57c0fa9ecce5ccae3a50` |
| 26 | 21302 | `8fddc39bf47989a16de3d7c004f1866cee8995dd98816592027b624c65f8c0aa` |
| 27 | 23237 | `6441a3792a92d28ed17a191949f8c0a0f06c2fc0d4ecf11fd120578cb2843455` |
| 30 | 10881 | `c5bae09f440d7ee445fbdca6f2fd9c429dde725d012f825bf2d45237b62dc175` |

### Direct source check and Units 28–29

All 36 frozen expanded-TeX inputs at
`authority/wikiversity-bgk/unit-NN/lecture-NN-expanded.tex` and
`authority/wikiversity-bgk/unit-NN/worksheet-NN-expanded.tex`,
NN=13 through 30, were used for bounded lexical-evidence checks.
They total **638250 bytes**; their path/size/hash inventory digest is
`91897022fbff6fe33f7b3da5982d1b2cd84861bad96ce7ee6b41eff048b3a2ff`.
This digest is SHA-256 of UTF-8 lines
`relative_path<TAB>bytes<TAB>lowercase_sha256<LF>`, sorted by relative path
with `.NET StringComparer.Ordinal`, including the final LF.
The individual source files remain bound by their unit authority manifests.

| Direct Indonesian witness | Bytes | SHA-256 |
|---|---:|---|
| `source/id-ID/bgk/lecture-28.md` | 17529 | `2916de247572a587a6d4a04c6fe2955c076d5e6c40d03e1a9866643e4ee3ee06` |
| `source/id-ID/bgk/worksheet-28.md` | 9847 | `b946a386335585f0763bb4fe88eed8f7c60f211761ee18926d3598091dc36af4` |
| `source/id-ID/bgk/lecture-29.md` | 16941 | `35374bf83dfbe3a33567d8fa99acad12cca79968e629f13ad5ec156fd7af0b99` |
| `source/id-ID/bgk/worksheet-29.md` | 9571 | `9fc3540416b3665a9459bef784baca84a6f6d96d9a413c2740fdc7d15b17ad75` |

These four Indonesian witnesses total **53888 bytes**; the same inventory
digest method yields
`5e65a50fe8e7a672663bb49204102ace420534ebc4ea9be2dee51984aa508b16`.

## Validation and ownership handoff

Deterministic checks passed: exact CSV header/order; 502 parseable records;
sequential unique IDs; valid unit/language/scope/status values; required
nonempty source/preference/rationale fields; no per-unit duplicate keys;
consistent preferred target for each source lemma; no exact same-scope or
whole-lane central collision; five unique glossary heading IDs; exact
provenance twice in the reader; central-ledger byte identity unchanged.
The CSV contains data, not formulas. The spreadsheet package was unavailable
at its loader-provided path, so this plain backend CSV was authored with
`apply_patch` and validated with the native CSV parser; no workbook,
alternate dependency, package installation, or spreadsheet export was made.

Only the three new glossary/intake files are this subtask's durable writes.
No network operation, Git command, publication, reader build, or subagent
dispatch was performed. Reader layout and backend integration are the
canonical owner's next executable gates. This receipt does not claim those
later gates already passed.

Source author credit remains Holger Brenner. Original connective glossary,
rationales, and this intake text are **CC BY-SA 4.0**; source and media
component licenses and notices remain unchanged. Independent edition;
no endorsement by the author, Wikiversity, Wikimedia Foundation, or a source
institution is implied. **OpenAI Codex gpt-5.6-sol, Ultra.**
