# BGK Units 13–30 correction intake

Status: applied-treatment intake validated, 2026-08-31. Provenance: OpenAI Codex gpt-5.6-sol, Ultra.

This additive ledger records existing edition treatments; it makes no new mathematical corrections. It is not a new source freeze, fresh proof audit, publication gate, or replacement for the native unit QA. Only this intake and `BGK_UNITS_13_30_CORRECTIONS.csv` were written.

## Artifact and schema

- CSV: `00_control/BGK_UNITS_13_30_CORRECTIONS.csv`, **104556 bytes**, SHA-256 `7d1168d06454c9f1e71cd5116ba984d193507c9ff4e01a630456cfa51d71c57a`.
- Exact columns: `correction_id,unit,kind,scope,authority_identity,authority_observation,target_action,mathematical_effect,status`.
- 151 rows; unique sequential IDs `BGK-C13-30-0001` through `BGK-C13-30-0151`; integer units 13–30; every status is `applied`; all fields are nonempty.
- 14 `semantic_repair`, 67 `source_defect_disclosure`, 36 `notation_typesetting`, 34 `scope_license`.
- These are **not 151 repaired mathematical errors**. “Applied” means the documented treatment is present, including deliberate preservation/disclosure, source-version selection, grammar, and scope/rights notes.

The 151 rows comprise all 56 explicit “Catatan edisi” passages in the 54 current lecture/worksheet/solution files, 77 additional already-applied source/target treatments confirmed in exact unit-local proposals and current reader witnesses, and 18 deduplicated unit-level public-solution/rights scope notes. Unit 28 and 29 have no corresponding terminology-proposal file in this bounded input set; their visible notes bind directly to current reader/source identities and local translation QA.

## Intake and deduplication rules

1. Bounds are BGK Units 13–30 only. No classical-course, other-lane, unconsumed glossary recommendation, speculative repair, future action, or media-only ID edit is admitted.
2. One row represents one visible note or documented treatment cluster. A note that jointly discloses two related defects remains one row. The same warning on distinct source surfaces remains separate when its source entity or reader anchor differs.
3. Duplicate key `(unit,kind,scope,authority_identity)` is forbidden; zero duplicates were found. Shared unit solution/rights statements repeated across worksheet and solutions are collapsed into one row with both anchors.
4. Reader anchors are literal existing stable IDs. Container page IDs/revisions in `authority_identity` are explicitly labeled **container** identities; they are not falsely presented as revisions of transcluded entity pages. Exact entity titles, public-solution revisions, and official-PDF pages are recorded where present in the inspected notes/metadata/proposals.
5. Defects retained in the source text are never labeled repaired. Plain grammar, punctuation, typeface, or source-glyph preservation is `notation_typesetting`. In particular, the rank-one specialization after `r=1` and restoration of the TeX glyph `\\subset` do not assert newly proved mathematical restrictions.
6. Proposal disclosure is not misrepresented as an adjacent reader note. Only the 56 explicit reader passages carry the “visible note” scope marker. Existing terminology choices and optional recommendations are not counted as applied semantic repairs.

## Validation and write boundary

Native CSV parsing confirmed the exact nine-column schema, 151 rows, sequential IDs, nonempty fields, unit/status bounds, unique keys, and every cited reader anchor. An additional 79 focused current-text checks confirmed the 77 proposal-treatment records, including two multi-file witnesses. All 54 reader body hashes remained unchanged during intake; unit-finalizer metadata updates do not alter these body bindings.

The supplied spreadsheet runtime did not expose `@oai/artifact-tool`; this schema-only CSV was validated through PowerShell `Import-Csv`, not exported as an unsolicited styled workbook. No source, QA, proposal, media, shared ledger, build, backend, Git, network, or publication state was edited.

Existing `00_control/CORRECTIONS.csv` remains untouched; observed SHA-256 `dc11342b2a5c845078922ed15efbd3bab74863847ac4079358ce238e2bdb2e2e`. Backend integration must append this separate intake, not overwrite the legacy ledger.

## Current reader-body bindings

For each unit, remove only the opening YAML frontmatter through its closing `---` line; preserve the remaining text bytes as UTF-8 with existing newlines. Hash the three bodies in this order: lecture, worksheet, worksheet-solutions. Then SHA-256 the UTF-8 string of three lines `relative_path<TAB>body_sha256<LF>`, including the final LF. This body-set digest intentionally survives metadata-only finalization.

| Unit | Intake rows | Reader-body-set SHA-256 |
|---:|---:|---|
| 13 | 8 | `ce876e0856d2ae0ad9a55ffbd778012fd5f0bc42160d0cab348ba6278aeaae9e` |
| 14 | 11 | `56d2083fde5cc067a033eeb635f714d8de6aa2cfe26534409e09fb61fa1f34c8` |
| 15 | 9 | `dcc6f9f1dc80e0e92424694e6581adb48789f9637f0b273a6006a4560de7f67c` |
| 16 | 8 | `63424999d933f8149e7a7156de3e01b8501575a9f7659a14d42c24934323cea5` |
| 17 | 9 | `611546143e19fbcce25d54a95e2fa4584bfbdddfa134acadfbf92562794139d5` |
| 18 | 9 | `19d371e1e6c940dc0b8620e2117bbd1ee0069b97ce3acbd700743e2702a0f06a` |
| 19 | 10 | `0c421ea4e2e1db0e4ea068e2dfcfddb4b1f05cef82dbd8cc63291f9462ba139a` |
| 20 | 7 | `06b48244db92da32af77e79b156cbbb2a5a8409985255243f49e4b9b64e1ed4d` |
| 21 | 11 | `5b63e1fbd36effc229cfa28fd3adac6cd9f6649e80d6ffaaa1e7abc3f7ca0ace` |
| 22 | 11 | `6047cef2eec4b859b88d1b6d4673e80d32630f86c2504120899a2f40bd84368d` |
| 23 | 5 | `93fad97b41e459ce5a797777db93abb16796fc7f3006ac647f61d2e8a82b272e` |
| 24 | 5 | `9ef18ffcd48ffcf68b3da983f395e550f20363845f8c42fd177a5945ac1fab14` |
| 25 | 8 | `16e04424abbd0d990c43f16677d9f43688941fdade72bc77fcafbfb1b1a30cc5` |
| 26 | 11 | `8f862d92714bb784c45a344e8cacb5713e3fb95dff1d27924011265a3703dc95` |
| 27 | 11 | `9f3e6a0d02e4581565217f90f2b371eeab5b3254c8d538d343c0e984cf02409c` |
| 28 | 6 | `eb4b855f9170ee61ffb4166f66e64440284be2c0dc74bb588da22644f881850f` |
| 29 | 7 | `fb88d07407f926ef888d97848a9ef3155ff5c8767cfbb87253265c1d96f6deae` |
| 30 | 5 | `ab703dcad88491634d501689692e424cb9866dec4a1057c1345a2174e19b53b5` |

## Local proposal snapshot identities

Each path is `00_control/BGK_UNIT_NN_TERMINOLOGY_CORRECTIONS_PROPOSAL.md`. These are intake-time snapshots; later metadata/hash rebinding can change whole-file bytes without changing the documented treatment. Current reader bodies above are the content gate.

| Unit | Bytes | Proposal SHA-256 |
|---:|---:|---|
| 13 | 15328 | `dc3ef689dd55a18720ee21ab5d0ab18da9d052fad6b37f6fd75cdda8c4663c07` |
| 14 | 10857 | `9969c2753909295c4ec202fb54bb94c58fe4ade3ccadfa40848ef2cf83492477` |
| 15 | 13660 | `7f11e91348675e5f05cb4d5c81d0e80f5e1f3ae8ebeabaf7b54f2508892c063b` |
| 16 | 15402 | `f2c9fb93cc61409fc04feadbe131191155b2c17b8503c7fa7b73858d13b04a34` |
| 17 | 16489 | `7bdbd4eca0a2b077df4a4e0a4b46aad4e91b0cde5b63e8f1607a87e5a7736fa1` |
| 18 | 15930 | `3af1f060508750f76de6ba482833582d06f276692f64ee52ec67e6fcb91d9ca3` |
| 19 | 22516 | `08e03fc450c65dd0a7b8c10cb6ff9077d80dae60e36ac72be9ff34296d827424` |
| 20 | 20424 | `9d2c46a71563f12f8ab5698815adf14c0f7d3a81c81e8bf000e3ff71ba3d1285` |
| 21 | 20381 | `577c9c97ba74692693166d16907112bd166dd5334fd0ac27deb8a18caa3024fc` |
| 22 | 20881 | `83c4a19963900d070774c96574fa5ce047db8c2d9786ef04c095c0040d3a52d1` |
| 23 | 17129 | `1b880dd33af3ae68c0a56abec582053dc40dd4f642f3fa7e36bcb38cd6d4b45d` |
| 24 | 13598 | `37a901540d474a3cdceaa6b8fd12192d7d70540db70df1fd53a3692303af15d0` |
| 25 | 19527 | `47e16db7ad4220cdd480ab0625c83519fc38b828288c57c0fa9ecce5ccae3a50` |
| 26 | 21302 | `8fddc39bf47989a16de3d7c004f1866cee8995dd98816592027b624c65f8c0aa` |
| 27 | 23237 | `6441a3792a92d28ed17a191949f8c0a0f06c2fc0d4ecf11fd120578cb2843455` |
| 30 | 10881 | `c5bae09f440d7ee445fbdca6f2fd9c429dde725d012f825bf2d45237b62dc175` |

Next action: the owner may append the exact CSV to native/common-backend correction exports and run its deterministic gates. No source-body edits or fresh mathematical inferences are authorized by this intake.
