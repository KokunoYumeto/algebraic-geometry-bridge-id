#!/usr/bin/env python3
"""Exact, shared HTML/PDF serialization of frozen BGK math witnesses.

Only the allowlisted source spans are changed in generated staging files.
Canonical Markdown and the shared PDF header are never written here.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

FIXTURE = Path(__file__).with_name("bgk_reader_math_serialization_v1.json")
SCHEMA = "ag-bridge-bgk-reader-math-serialization-v1"
CD_PATTERN = re.compile(r"\\begin\{CD\}[\s\S]*?\\end\{CD\}")


def digest_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _label(text: str) -> str:
    value = text.strip()
    if value.startswith("{") and value.endswith("}"):
        return value[1:-1]
    return value


def _part(text: str, start: int, delimiter: str) -> tuple[str, int]:
    """Read one arrow label; arrow letters inside braces are not delimiters."""
    depth = 0
    for index in range(start, len(text)):
        char = text[index]
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth < 0:
                raise ValueError("unbalanced CD arrow label")
        elif char == delimiter and depth == 0:
            return _label(text[start:index]), index + 1
    raise ValueError("unterminated CD arrow label")


def _arrow(text: str, start: int = 0) -> tuple[dict[str, str], int]:
    if text[start:start + 2] == "@=":
        return {"direction": "equal", "above": "", "below": ""}, start + 2
    if text[start:start + 1] != "@" or start + 1 >= len(text):
        raise ValueError("missing CD arrow")
    marker = text[start + 1]
    if marker not in ">VA":
        raise ValueError(f"unsupported CD arrow marker {marker!r}")
    first, end = _part(text, start + 2, marker)
    second, end = _part(text, end, marker)
    if marker == ">":
        return {"direction": "right", "above": first, "below": second}, end
    return {
        "direction": "down" if marker == "V" else "up",
        "left": first,
        "right": second,
    }, end


def parse_cd(source: str) -> dict[str, object]:
    if not source.startswith(r"\begin{CD}") or not source.endswith(r"\end{CD}"):
        raise ValueError("not an exact CD environment")
    body = source[len(r"\begin{CD}"):-len(r"\end{CD}")]
    rows = [row.strip() for row in body.split(r"\\")]
    if len(rows) not in (3, 5) or any(not row for row in rows):
        raise ValueError("unsupported CD row topology")
    objects: list[list[str]] = []
    horizontal: list[dict[str, str]] = []
    vertical: list[list[dict[str, str]]] = []
    for index, row in enumerate(rows):
        if index % 2 == 0:
            split = row.find("@")
            if split <= 0:
                raise ValueError("CD object row lacks its horizontal relation")
            arrow, end = _arrow(row, split)
            if arrow["direction"] not in ("right", "equal"):
                raise ValueError("vertical arrow in a CD object row")
            nodes = [row[:split].strip(), row[end:].strip()]
            if not all(nodes) or any("@" in node for node in nodes):
                raise ValueError("unexpected CD object token")
            # Source line wrapping is whitespace, not a mathematical token.
            objects.append([re.sub(r"\s+", " ", node) for node in nodes])
            horizontal.append(arrow)
        else:
            arrows: list[dict[str, str]] = []
            rest = row
            for _ in range(2):
                rest = rest.lstrip()
                arrow, end = _arrow(rest)
                if arrow["direction"] not in ("up", "down"):
                    raise ValueError("horizontal arrow in a CD vertical row")
                arrows.append(arrow)
                rest = rest[end:]
            if rest.strip():
                raise ValueError("unconsumed CD vertical-row token")
            vertical.append(arrows)
    return {"objects": objects, "horizontal": horizontal, "vertical": vertical}


def render_cd(topology: dict[str, object]) -> str:
    """Keep node and vertical-arrow centres in the same array columns.

    Separate label columns preserve both left/right label attachment without
    shifting vertical arrows away from their source and target objects.
    """
    objects = topology["objects"]
    horizontal = topology["horizontal"]
    vertical = topology["vertical"]
    rows: list[str] = []
    for index, nodes in enumerate(objects):
        edge = horizontal[index]
        if edge["direction"] == "equal":
            relation = "="
        else:
            lower = "[" + edge["below"] + "]" if edge["below"] else ""
            relation = r"\xrightarrow" + lower + "{" + edge["above"] + "}"
        rows.append(" & ".join(("", nodes[0], "", relation, "", nodes[1], "")))
        if index < len(vertical):
            left, right = vertical[index]
            def label(value: str) -> str:
                return r"{\scriptstyle " + value + "}" if value else ""
            rows.append(" & ".join((
                label(left["left"]), "\\" + left["direction"] + "arrow",
                label(left["right"]), "", label(right["left"]),
                "\\" + right["direction"] + "arrow", label(right["right"]),
            )))
    return "\\begin{array}{rclcrcl}\n" + "\\\\\n".join(rows) + "\n\\end{array}"


def load_contract() -> dict[str, object]:
    contract = json.loads(FIXTURE.read_text(encoding="utf-8"))
    if contract["schema"] != SCHEMA:
        raise ValueError("math serialization schema")
    identities: set[tuple[str, str]] = set()
    for record in contract["records"]:
        identity = record["source"], record["input_sha256"]
        if identity in identities:
            raise ValueError("duplicate math serialization witness")
        identities.add(identity)
        if digest_text(record["input"]) != record["input_sha256"]:
            raise ValueError("math serialization input hash")
        if digest_text(record["output"]) != record["output_sha256"]:
            raise ValueError("math serialization output hash")
        if record["kind"] == "CD":
            if parse_cd(record["input"]) != record["topology"]:
                raise ValueError("CD source topology differs from exact witness")
            if render_cd(record["topology"]) != record["output"]:
                raise ValueError("CD output differs from exact witness")
        elif record["kind"] == "control-sequence-backslash":
            if record.get("through_only") != 30 or record["output"] != (
                record["input"].replace(")longrightarrow", r")\longrightarrow", 1)
            ):
                raise ValueError("control-sequence correction exceeds its exact scope")
            authority = record["authority"]
            payload = (FIXTURE.parent.parent / authority["path"]).read_bytes()
            span = b"".join(payload.splitlines(keepends=True)[
                authority["span_start_line"] - 1:authority["span_end_line"]
            ])
            if (
                len(payload) != authority["bytes"]
                or hashlib.sha256(payload).hexdigest() != authority["sha256"]
                or len(span) != authority["span_bytes"]
                or hashlib.sha256(span).hexdigest() != authority["span_sha256"]
                or span.decode("utf-8") != authority["span_text"]
            ):
                raise ValueError("control-sequence correction authority span changed")
    return contract


def serialize_reader_math(
    text: str, source_path: str, *, through: int | None = None
) -> tuple[str, list[dict[str, object]]]:
    """Return a staging-only transform and a complete exact-span receipt."""
    contract = load_contract()
    records = [
        row for row in contract["records"]
        if row["source"] == source_path
        and ("through_only" not in row or row["through_only"] == through)
    ]
    transformed = text
    receipts: list[dict[str, object]] = []
    for record in records:
        if text.count(record["input"]) != 1:
            raise ValueError(f"missing/duplicate frozen math span: {record['id']}")
        start = text.index(record["input"])
        identifiers = re.findall(r"\{#([^}]+)\}", text[:start])
        if not identifiers or identifiers[-1] != record["stable_id"]:
            raise ValueError(f"math span moved outside stable ID: {record['id']}")
        transformed = transformed.replace(record["input"], record["output"], 1)
        if record.get("staging_note"):
            anchor = record["output"] + "\n$$"
            if transformed.count(anchor) != 1:
                raise ValueError("edition note requires the exact display-math boundary")
            transformed = transformed.replace(
                anchor, anchor + "\n\n" + record["staging_note"], 1
            )
        receipts.append(dict(record))
    if CD_PATTERN.search(transformed) or r"\mathrel{\middle|}" in transformed:
        raise ValueError(f"unregistered unsupported math span in {source_path}")
    if re.findall(r"\{#[^}]+\}", transformed) != re.findall(r"\{#[^}]+\}", text):
        raise ValueError("math serialization changed stable IDs")
    return transformed, receipts
