#!/usr/bin/env python3
"""Build-free tests for the BGK media-fragment compatibility adapter."""

from __future__ import annotations

import json
from pathlib import Path
import sys
import tempfile
import unittest

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from build_bgk_reader import (
    MEDIA_FRAGMENT_COMPATIBILITY_SCHEMA,
    add_html_landmarks,
    apply_html_fragment_compatibility,
    validate_final_html_fragment_compatibility,
)


def fixture(through: int) -> str:
    toc: list[str] = []
    content: list[str] = ['<h1 id="reader-title">Judul pembaca</h1>']
    for unit in range(1, through + 1):
        suffix = f"{unit:02d}"
        legacy = f"agc-bgk-media-credits-unit-{suffix}"
        canonical = f"br-bgk-2019-media-credits-unit-{suffix}"
        identifier = legacy if unit <= 12 else canonical
        toc.append(
            f'<li><a href="#{identifier}" id="toc-{identifier}">'
            f"Kredit media BGK Unit {unit}</a></li>"
        )
        content.append(
            f'<h1 id="{identifier}">Kredit media BGK Unit {unit}</h1>'
        )
    return (
        "<!doctype html>\n<html><body>\n<nav><ul>\n"
        + "\n".join(toc)
        + "\n</ul></nav>\n"
        + "\n".join(content)
        + "\n</body></html>\n"
    )


class MediaFragmentCompatibilityTests(unittest.TestCase):
    def apply(self, text: str, through: int) -> tuple[str, dict[str, object]]:
        with tempfile.TemporaryDirectory(prefix="bgk-fragment-compat-test-") as temp:
            path = Path(temp) / "index.html"
            path.write_text(text, encoding="utf-8", newline="\n")
            receipt = apply_html_fragment_compatibility(path, through)
            return path.read_text(encoding="utf-8"), receipt

    def assert_rejected_without_write(self, text: str, through: int) -> None:
        with tempfile.TemporaryDirectory(prefix="bgk-fragment-compat-test-") as temp:
            path = Path(temp) / "index.html"
            path.write_text(text, encoding="utf-8", newline="\n")
            before = path.read_bytes()
            with self.assertRaises(RuntimeError):
                apply_html_fragment_compatibility(path, through)
            self.assertEqual(path.read_bytes(), before)

    def test_boundaries_and_receipt_mapping(self) -> None:
        for through in (1, 12, 13, 30):
            with self.subTest(through=through):
                result, receipt = self.apply(fixture(through), through)
                legacy_count = min(through, 12)
                self.assertEqual(
                    receipt["schema"], MEDIA_FRAGMENT_COMPATIBILITY_SCHEMA
                )
                self.assertEqual(receipt["canonical_heading_count"], through)
                self.assertEqual(receipt["legacy_alias_count"], legacy_count)
                self.assertEqual(receipt["toc_retarget_count"], legacy_count)
                self.assertEqual(
                    receipt["legacy_units"], list(range(1, legacy_count + 1))
                )
                self.assertEqual(
                    len(receipt["legacy_alias_mappings"]), legacy_count
                )
                for unit in range(1, through + 1):
                    suffix = f"{unit:02d}"
                    canonical = f"br-bgk-2019-media-credits-unit-{suffix}"
                    self.assertEqual(result.count(f'<h1 id="{canonical}">'), 1)
                    if unit <= 12:
                        legacy = f"agc-bgk-media-credits-unit-{suffix}"
                        alias = (
                            f'<span id="{legacy}" '
                            'class="fragment-alias fragment-alias--legacy" '
                            'aria-hidden="true"></span>'
                        )
                        self.assertEqual(result.count(alias), 1)
                        self.assertEqual(
                            result.count(
                                f'<a href="#{canonical}" id="toc-{legacy}">'
                            ),
                            1,
                        )
                    else:
                        self.assertNotIn(
                            f"agc-bgk-media-credits-unit-{suffix}", result
                        )
                        self.assertEqual(
                            result.count(
                                f'<a href="#{canonical}" id="toc-{canonical}">'
                            ),
                            1,
                        )

    def test_same_input_is_deterministic(self) -> None:
        first_html, first_receipt = self.apply(fixture(30), 30)
        second_html, second_receipt = self.apply(fixture(30), 30)
        self.assertEqual(first_html, second_html)
        self.assertEqual(
            json.dumps(first_receipt, sort_keys=True),
            json.dumps(second_receipt, sort_keys=True),
        )

    def test_final_post_landmark_dom_is_measured(self) -> None:
        with tempfile.TemporaryDirectory(prefix="bgk-fragment-compat-test-") as temp:
            path = Path(temp) / "index.html"
            path.write_text(fixture(30), encoding="utf-8", newline="\n")
            receipt = apply_html_fragment_compatibility(path, 30)
            add_html_landmarks(path)
            final = validate_final_html_fragment_compatibility(path, 30, receipt)
            measured = final["final_dom_validation"]
            self.assertEqual(measured["status"], "PASS")
            self.assertEqual(measured["total_id_count"], measured["unique_id_count"])
            self.assertEqual(measured["canonical_heading_count"], 30)
            self.assertEqual(measured["canonical_toc_destination_count"], 30)
            self.assertEqual(measured["legacy_alias_count"], 12)
            self.assertEqual(measured["legacy_toc_element_id_count"], 12)

    def test_landmark_insertion_rejects_single_quote_duplicate_id(self) -> None:
        with tempfile.TemporaryDirectory(prefix="bgk-fragment-compat-test-") as temp:
            path = Path(temp) / "index.html"
            text = fixture(1).replace(
                "<body>", "<body><div id='main-content'></div>"
            )
            path.write_text(text, encoding="utf-8", newline="\n")
            receipt = apply_html_fragment_compatibility(path, 1)
            before = path.read_bytes()
            with self.assertRaises(RuntimeError):
                add_html_landmarks(path)
            self.assertEqual(path.read_bytes(), before)
            self.assertNotIn("final_dom_validation", receipt)

    def test_already_transformed_state_is_rejected(self) -> None:
        transformed, _ = self.apply(fixture(12), 12)
        self.assert_rejected_without_write(transformed, 12)

    def test_missing_heading_is_rejected(self) -> None:
        text = fixture(12).replace(
            '<h1 id="agc-bgk-media-credits-unit-12">',
            '<h2 id="agc-bgk-media-credits-unit-12">',
        )
        self.assert_rejected_without_write(text, 12)

    def test_duplicate_id_is_rejected(self) -> None:
        text = fixture(1).replace(
            "</body>", '<span id="agc-bgk-media-credits-unit-01"></span></body>'
        )
        self.assert_rejected_without_write(text, 1)

    def test_mixed_toc_state_is_rejected(self) -> None:
        text = fixture(1).replace(
            'href="#agc-bgk-media-credits-unit-01"',
            'href="#br-bgk-2019-media-credits-unit-01"',
        )
        self.assert_rejected_without_write(text, 1)

    def test_unexpected_media_namespace_is_rejected(self) -> None:
        text = fixture(1).replace(
            "</body>", '<span id="br-bgk-media-credits-unit-01"></span></body>'
        )
        self.assert_rejected_without_write(text, 1)

    def test_cross_lineage_fragment_id_is_rejected(self) -> None:
        for identifier in (
            "br-ak-u01-media-001",
            "toc-br-ak-u01-media-001",
        ):
            with self.subTest(identifier=identifier):
                text = fixture(1).replace(
                    "</body>", f'<span id="{identifier}"></span></body>'
                )
                self.assert_rejected_without_write(text, 1)

    def test_cross_lineage_fragment_href_is_rejected(self) -> None:
        for target in (
            "br-ak-u01-media-001",
            "toc-br-ak-u01-media-001",
        ):
            with self.subTest(target=target):
                text = fixture(1).replace(
                    "</body>", f'<a href="#{target}">Silang</a></body>'
                )
                self.assert_rejected_without_write(text, 1)

    def test_script_or_iframe_surface_is_rejected(self) -> None:
        text = fixture(1).replace("</body>", "<script></script></body>")
        self.assert_rejected_without_write(text, 1)


if __name__ == "__main__":
    unittest.main()
