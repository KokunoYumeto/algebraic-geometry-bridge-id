#!/usr/bin/env python3
"""Capture one deterministic identity set after a cumulative BGK reader build."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def fact(path: Path) -> dict[str, object]:
    if not path.is_file() or path.is_symlink():
        raise RuntimeError(f"missing/non-regular file: {path}")
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }


def output_path(value: str) -> Path:
    path = (ROOT / value).resolve() if not Path(value).is_absolute() else Path(value).resolve()
    try:
        path.relative_to(ROOT)
    except ValueError as error:
        raise RuntimeError(f"output must remain inside the lane: {path}") from error
    return path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--through", required=True, type=int)
    parser.add_argument("--output", required=True)
    parser.add_argument("--replace", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    if not 1 <= args.through <= 30:
        parser.error("--through must be in 1..30")

    suffix = f"{args.through:02d}"
    pdf_name = (
        "bundel-berkas-dan-kohomologi-id-unit-01.pdf"
        if args.through == 1
        else f"bundel-berkas-dan-kohomologi-id-units-01-{suffix}.pdf"
    )
    build = ROOT / "build" / "reader-bgk-id"
    paths = [
        build / "BUILD_RECEIPT.json",
        build / "index.html",
        build / pdf_name,
        build / "pandoc-html.log",
        build / "pandoc-pdf.log",
    ]
    out = output_path(args.output)
    if args.dry_run:
        print(
            json.dumps(
                {
                    "status": "PASS_DRY_RUN",
                    "through_unit": args.through,
                    "output": out.relative_to(ROOT).as_posix(),
                    "inputs": [path.relative_to(ROOT).as_posix() for path in paths],
                },
                ensure_ascii=False,
                sort_keys=True,
            )
        )
        return 0

    receipt = json.loads(paths[0].read_text(encoding="utf-8"))
    if receipt.get("schema") != "ag-bridge-bgk-build-receipt-v1":
        raise RuntimeError("unexpected build receipt schema")
    if receipt.get("through_unit") != args.through:
        raise RuntimeError("build receipt scope does not match --through")
    if out.exists() and not args.replace:
        raise RuntimeError(f"output already exists; use --replace explicitly: {out}")
    out.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema": "ag-bridge-bgk-build-identity-v1",
        "through_unit": args.through,
        "artifacts": [fact(path) for path in paths],
    }
    temporary = out.with_name(out.name + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    temporary.replace(out)
    print(json.dumps({"status": "PASS", "receipt": fact(out)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
