"""Offline regressions for Zenodo redirects and complete draft discovery."""
import copy
import unittest
from unittest.mock import Mock

import publish_bgk_units_01_30_zenodo as publisher


TARGET_DRAFT = {
    "id": "22200001",
    "conceptrecid": str(publisher.CONCEPT_RECORD_ID),
    "submitted": False,
    "metadata": {"version": publisher.PREVIOUS_VERSION},
}
OTHER_DRAFT = {
    "id": 22200002,
    "conceptrecid": 22000000,
    "submitted": False,
    "metadata": {"version": "unrelated"},
}


def envelope(rows, *, total=None, next_link=None):
    links = {"self": "https://zenodo.org/api/deposit/depositions?status=draft"}
    if next_link is not None:
        links["next"] = next_link
    return {"hits": {"hits": rows, "total": len(rows) if total is None else total}, "links": links}


class RedirectTests(unittest.TestCase):
    def response(self, code, location=None):
        return Mock(status_code=code, headers={"Location": location} if location else {})

    def test_canonical_public_record_redirect(self):
        first = self.response(301, "https://zenodo.org/api/records/22164552")
        final = self.response(200)
        session = Mock()
        session.request.side_effect = [first, final]
        self.assertIs(publisher.request(session, "GET", "https://zenodo.org/api/records/22164552/versions/latest"), final)
        self.assertEqual(session.request.call_count, 2)
        first.close.assert_called_once()
        self.assertEqual(session.request.call_args.args[1], "https://zenodo.org/api/records/22164552")

    def test_cross_origin_redirect_rejected_before_follow(self):
        session = Mock()
        session.request.return_value = self.response(302, "https://example.org/collect")
        with self.assertRaisesRegex(RuntimeError, "Unsafe Zenodo"):
            publisher.request(session, "GET", "https://zenodo.org/api/records/1")
        self.assertEqual(session.request.call_count, 1)


class DraftListingTests(unittest.TestCase):
    def response(self, code, location=None):
        return Mock(status_code=code, headers={"Location": location} if location else {})

    def test_current_search_envelope_and_legacy_list_are_both_accepted(self):
        rows = [copy.deepcopy(OTHER_DRAFT), copy.deepcopy(TARGET_DRAFT)]
        self.assertEqual(publisher.draft_listing_rows(envelope(rows)), rows)
        self.assertEqual(publisher.draft_listing_rows(rows), rows)
        self.assertEqual(publisher.matching_concept_draft(rows), rows[1])

    def test_exact_elasticsearch_total_object_is_accepted(self):
        rows = [copy.deepcopy(TARGET_DRAFT)]
        payload = envelope(rows, total={"value": 1, "relation": "eq"})
        self.assertEqual(publisher.draft_listing_rows(payload), rows)

    def test_incomplete_or_paginated_envelope_is_rejected(self):
        rows = [copy.deepcopy(TARGET_DRAFT)]
        cases = (
            envelope(rows, total=2),
            envelope(rows, next_link="https://zenodo.org/api/deposit/depositions?page=2"),
            envelope([copy.deepcopy(OTHER_DRAFT) for _ in range(publisher.DRAFT_LOOKUP_SIZE)]),
        )
        for payload in cases:
            with self.subTest(payload=payload.get("links")), self.assertRaisesRegex(
                    RuntimeError, "incomplete|paginated"):
                publisher.draft_listing_rows(payload)

    def test_inexact_or_malformed_envelope_is_rejected(self):
        rows = [copy.deepcopy(TARGET_DRAFT)]
        cases = (
            None,
            {},
            {"hits": {"hits": rows, "total": 1}},
            {"hits": rows, "links": {}},
            envelope(rows, total=True),
            envelope(rows, total={"value": 1, "relation": "gte"}),
            envelope(rows, total={"value": 1, "relation": "eq", "extra": 0}),
        )
        for payload in cases:
            with self.subTest(payload=payload), self.assertRaises(RuntimeError):
                publisher.draft_listing_rows(payload)

    def test_each_row_requires_exact_identity_and_boolean_state(self):
        mutations = (
            {"id": None},
            {"id": True},
            {"id": "1.0"},
            {"conceptrecid": None},
            {"conceptrecid": "١٢٣"},
            {"submitted": None},
            {"submitted": 0},
        )
        for mutation in mutations:
            row = {**copy.deepcopy(TARGET_DRAFT), **mutation}
            with self.subTest(mutation=mutation), self.assertRaises(RuntimeError):
                publisher.draft_listing_rows(envelope([row]))

    def test_duplicate_record_or_concept_drafts_fail_closed(self):
        duplicate_id = [copy.deepcopy(TARGET_DRAFT),
                        {**copy.deepcopy(OTHER_DRAFT), "id": TARGET_DRAFT["id"]}]
        with self.assertRaisesRegex(RuntimeError, "duplicate record"):
            publisher.draft_listing_rows(envelope(duplicate_id))
        duplicate_concept = [copy.deepcopy(TARGET_DRAFT),
                             {**copy.deepcopy(TARGET_DRAFT), "id": 22200003}]
        parsed = publisher.draft_listing_rows(envelope(duplicate_concept))
        with self.assertRaisesRegex(RuntimeError, "Multiple drafts"):
            publisher.matching_concept_draft(parsed)

    def test_exact_unversioned_inherited_new_version_is_accepted_only_for_reservation(self):
        classical = {"classical.bin": {"bytes": 7, "sha256": "0" * 64}}
        new = {"new.bin": {"bytes": 9, "sha256": "1" * 64}}
        inherited = [
            {"filename": "classical.bin", "filesize": 7},
            *({"filename": name, "filesize": 1} for name in sorted(publisher.OLD_BGK_FILES)),
        ]
        draft = {
            "id": 22200004,
            "conceptrecid": str(publisher.CONCEPT_RECORD_ID),
            "submitted": False,
            "metadata": {"version": None, "prereserve_doi": {"doi": "10.5281/zenodo.22200004"}},
            "files": inherited,
        }
        with self.assertRaisesRegex(RuntimeError, "unreviewed version"):
            publisher.validate_draft(copy.deepcopy(draft), classical, new)
        inventory = publisher.validate_draft(
            copy.deepcopy(draft), classical, new, allow_unversioned_predecessor=True)
        self.assertEqual(set(inventory), {"classical.bin"} | publisher.OLD_BGK_FILES)

    def test_unversioned_draft_must_have_exact_inherited_inventory(self):
        classical = {"classical.bin": {"bytes": 7, "sha256": "0" * 64}}
        new = {"new.bin": {"bytes": 9, "sha256": "1" * 64}}
        draft = {
            "id": 22200005,
            "conceptrecid": str(publisher.CONCEPT_RECORD_ID),
            "submitted": False,
            "metadata": {"version": None, "prereserve_doi": {"doi": "10.5281/zenodo.22200005"}},
            "files": [
                {"filename": "classical.bin", "filesize": 7},
                *({"filename": name, "filesize": 1} for name in sorted(publisher.OLD_BGK_FILES)),
                {"filename": "new.bin", "filesize": 9},
            ],
        }
        with self.assertRaisesRegex(RuntimeError, "exact inherited predecessor"):
            publisher.validate_draft(
                draft, classical, new, allow_unversioned_predecessor=True)

    def test_mutation_is_never_redirected(self):
        session = Mock()
        session.request.return_value = self.response(307, "https://zenodo.org/api/deposit/depositions/2")
        with self.assertRaisesRegex(RuntimeError, "HTTP 307"):
            publisher.request(session, "POST", "https://zenodo.org/api/deposit/depositions/1/actions/publish")
        self.assertEqual(session.request.call_count, 1)

    def test_read_redirect_cycle_is_bounded(self):
        session = Mock()
        session.request.return_value = self.response(301, "/api/records/1")
        with self.assertRaisesRegex(RuntimeError, "bounded limit"):
            publisher.request(session, "GET", "https://zenodo.org/api/records/1")
        self.assertEqual(session.request.call_count, 4)

    def test_credential_query_redirect_is_rejected(self):
        session = Mock()
        # The forbidden query-key is the behavior under test.  Keep the dummy
        # value deliberately short so release secret-scanning does not need a
        # dangerous blanket exemption for this source fixture.
        session.request.return_value = self.response(302, "/api/records/1?access_token=x")
        with self.assertRaisesRegex(RuntimeError, "Unsafe Zenodo"):
            publisher.request(session, "GET", "https://zenodo.org/api/records/1")
        self.assertEqual(session.request.call_count, 1)


if __name__ == "__main__":
    unittest.main()
