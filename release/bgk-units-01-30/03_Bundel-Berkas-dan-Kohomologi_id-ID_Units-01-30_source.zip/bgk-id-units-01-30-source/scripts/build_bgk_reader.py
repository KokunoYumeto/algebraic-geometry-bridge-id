#!/usr/bin/env python3
"""Build the independent Indonesian BGK reader in its own output namespace."""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

from bgk_reader_math_serialization import (
    FIXTURE as MATH_SERIALIZATION_FIXTURE,
    SCHEMA as MATH_SERIALIZATION_SCHEMA,
    serialize_reader_math,
)


LANE = Path(__file__).resolve().parents[1]
SOURCE_ROOT = LANE / "source" / "id-ID"
SOURCE_DIR = SOURCE_ROOT / "bgk"
ASSET_DIR = LANE / "authority" / "assets"
BUILD_DIR = LANE / "build"
FINAL_DIR = BUILD_DIR / "reader-bgk-id"
CSS = SOURCE_ROOT / "reader.css"
PDF_HEADER = SOURCE_ROOT / "pdf-header.tex"
EXPECTED_PANDOC = "pandoc 3.9.0.2"
SOURCE_DATE_EPOCH = "1787875200"  # 2026-08-28T00:00:00Z
PDF_ID_PATTERN = re.compile(
    rb"/ID \[ <[0-9A-Fa-f]{32}> <[0-9A-Fa-f]{32}> \]"
)
MEDIA_FRAGMENT_COMPATIBILITY_SCHEMA = "ag-bridge-bgk-media-fragment-compat-v1"
LEGACY_MEDIA_FRAGMENT_UNITS = tuple(range(1, 13))
MEDIA_FRAGMENT_NAMESPACE_PREFIXES = (
    "agc-bgk-media-credits-unit-",
    "br-bgk-2019-media-credits-unit-",
    "br-bgk-media-credits-unit-",
    "agc-media-credits-unit-",
)
FORBIDDEN_CROSS_LINEAGE_FRAGMENT_PREFIXES = ("br-ak-",)
HTML_VOID_ELEMENTS = frozenset(
    {
        "area",
        "base",
        "br",
        "col",
        "embed",
        "hr",
        "img",
        "input",
        "link",
        "meta",
        "param",
        "source",
        "track",
        "wbr",
    }
)


class _HtmlFragmentInventory(HTMLParser):
    """Collect the small DOM surface needed by the fragment transform."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.elements: list[dict[str, object]] = []
        self.ids: list[str] = []
        self.hrefs: list[str] = []
        self.headings: list[dict[str, object]] = []
        self._active_h1: dict[str, object] | None = None
        self._h1_child_depth = 0

    @staticmethod
    def _attributes(attrs: list[tuple[str, str | None]]) -> dict[str, str | None]:
        names = [name.lower() for name, _ in attrs]
        if len(names) != len(set(names)):
            raise RuntimeError("HTML element contains a duplicate attribute")
        return {name.lower(): value for name, value in attrs}

    def _record_start(
        self,
        tag: str,
        attrs: list[tuple[str, str | None]],
        *,
        self_closing: bool,
    ) -> None:
        tag = tag.lower()
        attributes = self._attributes(attrs)
        element: dict[str, object] = {
            "tag": tag,
            "attrs": attributes,
            "parent_h1": None,
        }
        identifier = attributes.get("id")
        if isinstance(identifier, str):
            self.ids.append(identifier)
        href = attributes.get("href")
        if isinstance(href, str):
            self.hrefs.append(href)

        if tag == "h1":
            if self._active_h1 is not None:
                raise RuntimeError("HTML contains a nested h1")
            heading: dict[str, object] = {
                "id": identifier,
                "text_parts": [],
                "direct_children": [],
            }
            self.headings.append(heading)
            self._active_h1 = heading
            self._h1_child_depth = 0
            element["heading"] = heading
        elif self._active_h1 is not None:
            element["parent_h1"] = self._active_h1.get("id")
            if self._h1_child_depth == 0:
                direct_children = self._active_h1["direct_children"]
                assert isinstance(direct_children, list)
                direct_children.append(element)
            if not self_closing and tag not in HTML_VOID_ELEMENTS:
                self._h1_child_depth += 1
        self.elements.append(element)

    def handle_starttag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        self._record_start(tag, attrs, self_closing=False)

    def handle_startendtag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        self._record_start(tag, attrs, self_closing=True)

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if self._active_h1 is None:
            return
        if tag == "h1" and self._h1_child_depth == 0:
            self._active_h1 = None
        elif self._h1_child_depth > 0:
            self._h1_child_depth -= 1

    def handle_data(self, data: str) -> None:
        if self._active_h1 is not None:
            text_parts = self._active_h1["text_parts"]
            assert isinstance(text_parts, list)
            text_parts.append(data)

    def finish(self) -> None:
        self.close()
        if self._active_h1 is not None:
            raise RuntimeError("HTML contains an unclosed h1")


def _fragment_inventory(text: str) -> _HtmlFragmentInventory:
    inventory = _HtmlFragmentInventory()
    inventory.feed(text)
    inventory.finish()
    return inventory


def _element_matches(
    inventory: _HtmlFragmentInventory,
    tag: str,
    **attributes: str,
) -> list[dict[str, object]]:
    matches: list[dict[str, object]] = []
    for element in inventory.elements:
        attrs = element["attrs"]
        assert isinstance(attrs, dict)
        if element["tag"] == tag and all(
            attrs.get(key) == value for key, value in attributes.items()
        ):
            matches.append(element)
    return matches


def _is_media_fragment_identifier(value: str) -> bool:
    core = value[4:] if value.startswith("toc-") else value
    return core.startswith(MEDIA_FRAGMENT_NAMESPACE_PREFIXES)


def _is_forbidden_cross_lineage_fragment(value: str) -> bool:
    core = value[4:] if value.startswith("toc-") else value
    return core.startswith(FORBIDDEN_CROSS_LINEAGE_FRAGMENT_PREFIXES)


def _fragment_ids(unit: int) -> tuple[str, str, str, str]:
    suffix = f"{unit:02d}"
    legacy = f"agc-bgk-media-credits-unit-{suffix}"
    canonical = f"br-bgk-2019-media-credits-unit-{suffix}"
    return legacy, canonical, f"toc-{legacy}", f"toc-{canonical}"


def _require_unique_ids(inventory: _HtmlFragmentInventory, phase: str) -> None:
    duplicates = sorted(
        identifier
        for identifier, count in Counter(inventory.ids).items()
        if count != 1
    )
    if duplicates:
        raise RuntimeError(f"{phase} HTML contains duplicate IDs: {duplicates}")


def _expected_fragment_surface(
    through: int, *, transformed: bool
) -> tuple[set[str], set[str]]:
    identifiers: set[str] = set()
    targets: set[str] = set()
    for unit in range(1, through + 1):
        legacy, canonical, toc_legacy, toc_canonical = _fragment_ids(unit)
        if unit in LEGACY_MEDIA_FRAGMENT_UNITS:
            if transformed:
                identifiers.update((canonical, legacy, toc_legacy))
                targets.add(f"#{canonical}")
            else:
                identifiers.update((legacy, toc_legacy))
                targets.add(f"#{legacy}")
        else:
            identifiers.update((canonical, toc_canonical))
            targets.add(f"#{canonical}")
    return identifiers, targets


def _validate_fragment_namespace(
    inventory: _HtmlFragmentInventory,
    through: int,
    *,
    transformed: bool,
) -> None:
    phase = "post-transform" if transformed else "pre-transform"
    _require_unique_ids(inventory, phase)
    expected_ids, expected_targets = _expected_fragment_surface(
        through, transformed=transformed
    )
    observed_ids = {
        identifier
        for identifier in inventory.ids
        if _is_media_fragment_identifier(identifier)
    }
    cross_lineage_ids = sorted(
        identifier
        for identifier in inventory.ids
        if _is_forbidden_cross_lineage_fragment(identifier)
    )
    if cross_lineage_ids:
        raise RuntimeError(
            f"{phase} HTML contains cross-lineage fragment IDs: {cross_lineage_ids}"
        )
    if observed_ids != expected_ids:
        missing = sorted(expected_ids - observed_ids)
        unexpected = sorted(observed_ids - expected_ids)
        raise RuntimeError(
            f"{phase} media-fragment ID surface mismatch; "
            f"missing={missing}, unexpected={unexpected}"
        )
    observed_targets = {
        href
        for href in inventory.hrefs
        if href.startswith("#") and _is_media_fragment_identifier(href[1:])
    }
    unexpected_targets = sorted(observed_targets - expected_targets)
    if unexpected_targets:
        raise RuntimeError(
            f"{phase} HTML contains unexpected media-fragment href targets: "
            f"{unexpected_targets}"
        )
    cross_lineage_targets = sorted(
        href
        for href in inventory.hrefs
        if href.startswith("#")
        and _is_forbidden_cross_lineage_fragment(href[1:])
    )
    if cross_lineage_targets:
        raise RuntimeError(
            f"{phase} HTML contains cross-lineage fragment hrefs: "
            f"{cross_lineage_targets}"
        )

    alias_elements = []
    for element in inventory.elements:
        attrs = element["attrs"]
        assert isinstance(attrs, dict)
        classes = str(attrs.get("class") or "").split()
        if "fragment-alias" in classes:
            alias_elements.append(element)
    expected_aliases = (
        min(through, len(LEGACY_MEDIA_FRAGMENT_UNITS)) if transformed else 0
    )
    if len(alias_elements) != expected_aliases:
        raise RuntimeError(
            f"{phase} fragment-alias count is {len(alias_elements)}, "
            f"expected {expected_aliases}"
        )

    for unit in range(1, through + 1):
        legacy, canonical, toc_legacy, toc_canonical = _fragment_ids(unit)
        if transformed or unit not in LEGACY_MEDIA_FRAGMENT_UNITS:
            heading_id = canonical
            toc_id = (
                toc_legacy if unit in LEGACY_MEDIA_FRAGMENT_UNITS else toc_canonical
            )
            toc_target = f"#{canonical}"
        else:
            heading_id = legacy
            toc_id = toc_legacy
            toc_target = f"#{legacy}"
        if len(_element_matches(inventory, "h1", id=heading_id)) != 1:
            raise RuntimeError(f"{phase} requires exactly one h1#{heading_id}")
        if len(_element_matches(inventory, "a", id=toc_id, href=toc_target)) != 1:
            raise RuntimeError(
                f"{phase} requires exactly one a#{toc_id}[href='{toc_target}']"
            )

        if transformed and unit in LEGACY_MEDIA_FRAGMENT_UNITS:
            aliases = _element_matches(inventory, "span", id=legacy)
            if len(aliases) != 1:
                raise RuntimeError(f"{phase} requires exactly one span#{legacy}")
            alias = aliases[0]
            attrs = alias["attrs"]
            assert isinstance(attrs, dict)
            if (
                attrs.get("class") != "fragment-alias fragment-alias--legacy"
                or attrs.get("aria-hidden") != "true"
                or alias.get("parent_h1") != canonical
            ):
                raise RuntimeError(
                    f"{phase} legacy alias topology mismatch for Unit {unit}"
                )
            heading = _element_matches(inventory, "h1", id=canonical)[0]
            heading_record = heading.get("heading")
            assert isinstance(heading_record, dict)
            direct_children = heading_record["direct_children"]
            assert isinstance(direct_children, list)
            if not direct_children or direct_children[0] is not alias:
                raise RuntimeError(
                    f"{phase} legacy alias is not the first h1 child for Unit {unit}"
                )


def transform_html_fragment_compatibility(
    text: str, through: int
) -> tuple[str, dict[str, object]]:
    """Promote BGK media H1s while retaining published Units 01--12 fragments.

    The transform is deliberately limited to Pandoc's exact deterministic
    opening tags. It validates the complete namespace before and after the
    in-memory replacement, so malformed or partially transformed HTML is never
    written by :func:`apply_html_fragment_compatibility`.
    """

    if not 1 <= through <= 30:
        raise ValueError("through must be between 1 and 30")
    before = _fragment_inventory(text)
    _validate_fragment_namespace(before, through, transformed=False)
    if any(
        element["tag"] in {"script", "iframe"} for element in before.elements
    ):
        raise RuntimeError("pre-transform HTML contains a script or iframe surface")

    transformed = text
    mappings: list[dict[str, object]] = []
    legacy_units = [unit for unit in LEGACY_MEDIA_FRAGMENT_UNITS if unit <= through]
    for unit in legacy_units:
        legacy, canonical, toc_legacy, _ = _fragment_ids(unit)
        old_heading = f'<h1 id="{legacy}">'
        new_heading = (
            f'<h1 id="{canonical}"><span id="{legacy}" '
            'class="fragment-alias fragment-alias--legacy" '
            'aria-hidden="true"></span>'
        )
        old_toc = f'<a href="#{legacy}" id="{toc_legacy}">'
        new_toc = f'<a href="#{canonical}" id="{toc_legacy}">'
        if transformed.count(old_heading) != 1 or transformed.count(old_toc) != 1:
            raise RuntimeError(
                f"Pandoc opening-tag contract mismatch for legacy media Unit {unit}"
            )
        transformed = transformed.replace(old_heading, new_heading, 1)
        transformed = transformed.replace(old_toc, new_toc, 1)
        mappings.append(
            {
                "unit": unit,
                "legacy_fragment": legacy,
                "canonical_fragment": canonical,
                "toc_element_id": toc_legacy,
                "toc_target_before": f"#{legacy}",
                "toc_target_after": f"#{canonical}",
            }
        )

    after = _fragment_inventory(transformed)
    _validate_fragment_namespace(after, through, transformed=True)
    if any(
        element["tag"] in {"script", "iframe"} for element in after.elements
    ):
        raise RuntimeError("post-transform HTML contains a script or iframe surface")
    if len(after.headings) != len(before.headings):
        raise RuntimeError("HTML fragment transform changed the h1 count")
    before_text = ["".join(heading["text_parts"]) for heading in before.headings]
    after_text = ["".join(heading["text_parts"]) for heading in after.headings]
    if after_text != before_text:
        raise RuntimeError("HTML fragment transform changed h1 text content")
    expected_heading_ids = [
        (
            _fragment_ids(int(str(heading["id"])[-2:]))[1]
            if isinstance(heading.get("id"), str)
            and str(heading["id"]).startswith("agc-bgk-media-credits-unit-")
            else heading.get("id")
        )
        for heading in before.headings
    ]
    if [heading.get("id") for heading in after.headings] != expected_heading_ids:
        raise RuntimeError("HTML fragment transform changed an unrelated h1 ID")
    heading_text_sha256 = hashlib.sha256(
        json.dumps(after_text, ensure_ascii=False, separators=(",", ":")).encode(
            "utf-8"
        )
    ).hexdigest()

    receipt: dict[str, object] = {
        "schema": MEDIA_FRAGMENT_COMPATIBILITY_SCHEMA,
        "through_unit": through,
        "canonical_heading_pattern": "br-bgk-2019-media-credits-unit-NN",
        "canonical_heading_count": through,
        "legacy_alias_count": len(legacy_units),
        "toc_retarget_count": len(legacy_units),
        "legacy_units": legacy_units,
        "legacy_alias_mappings": mappings,
        "h1_count": len(after.headings),
        "h1_text_sha256": heading_text_sha256,
        "h1_text_parity": "PASS",
    }
    return transformed, receipt


def apply_html_fragment_compatibility(path: Path, through: int) -> dict[str, object]:
    """Validate and atomically replace one generated HTML file in place."""

    regular(path)
    original = path.read_text(encoding="utf-8")
    transformed, receipt = transform_html_fragment_compatibility(original, through)
    temporary = path.with_name(f".{path.name}.fragment-compat.tmp")
    if temporary.exists():
        raise RuntimeError(
            f"fragment compatibility temporary path already exists: {temporary}"
        )
    try:
        temporary.write_text(transformed, encoding="utf-8", newline="\n")
        if temporary.read_text(encoding="utf-8") != transformed:
            raise RuntimeError("fragment compatibility temporary-file replay mismatch")
        temporary.replace(path)
    finally:
        if temporary.exists():
            temporary.unlink()
    return receipt


def validate_final_html_fragment_compatibility(
    path: Path, through: int, receipt: dict[str, object]
) -> dict[str, object]:
    """Revalidate the final post-landmark HTML and bind measured DOM evidence."""

    regular(path)
    if (
        receipt.get("schema") != MEDIA_FRAGMENT_COMPATIBILITY_SCHEMA
        or receipt.get("through_unit") != through
    ):
        raise RuntimeError("fragment compatibility receipt scope mismatch")
    inventory = _fragment_inventory(path.read_text(encoding="utf-8"))
    _validate_fragment_namespace(inventory, through, transformed=True)
    script_count = sum(
        element["tag"] == "script" for element in inventory.elements
    )
    iframe_count = sum(
        element["tag"] == "iframe" for element in inventory.elements
    )
    if script_count or iframe_count:
        raise RuntimeError("final HTML contains a script or iframe surface")

    heading_text = [
        "".join(heading["text_parts"]) for heading in inventory.headings
    ]
    heading_text_sha256 = hashlib.sha256(
        json.dumps(heading_text, ensure_ascii=False, separators=(",", ":")).encode(
            "utf-8"
        )
    ).hexdigest()
    if (
        len(inventory.headings) != receipt.get("h1_count")
        or heading_text_sha256 != receipt.get("h1_text_sha256")
    ):
        raise RuntimeError("final HTML changed the validated h1 text surface")

    canonical_heading_count = 0
    canonical_toc_destination_count = 0
    legacy_alias_count = 0
    legacy_toc_element_id_count = 0
    for unit in range(1, through + 1):
        legacy, canonical, toc_legacy, toc_canonical = _fragment_ids(unit)
        canonical_heading_count += len(
            _element_matches(inventory, "h1", id=canonical)
        )
        toc_id = toc_legacy if unit in LEGACY_MEDIA_FRAGMENT_UNITS else toc_canonical
        canonical_toc_destination_count += len(
            _element_matches(inventory, "a", id=toc_id, href=f"#{canonical}")
        )
        if unit in LEGACY_MEDIA_FRAGMENT_UNITS:
            legacy_alias_count += len(
                _element_matches(inventory, "span", id=legacy)
            )
            legacy_toc_element_id_count += len(
                _element_matches(inventory, "a", id=toc_legacy)
            )

    final_receipt = dict(receipt)
    final_receipt["final_dom_validation"] = {
        "status": "PASS",
        "total_id_count": len(inventory.ids),
        "unique_id_count": len(set(inventory.ids)),
        "h1_count": len(inventory.headings),
        "h1_text_sha256": heading_text_sha256,
        "canonical_heading_count": canonical_heading_count,
        "canonical_toc_destination_count": canonical_toc_destination_count,
        "legacy_alias_count": legacy_alias_count,
        "legacy_toc_element_id_count": legacy_toc_element_id_count,
        "bare_or_classical_media_fragment_id_count": 0,
        "cross_lineage_fragment_id_count": 0,
        "script_count": script_count,
        "iframe_count": iframe_count,
    }
    return final_receipt


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def fact(path: Path) -> dict[str, object]:
    return {
        "path": path.relative_to(LANE).as_posix(),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }


def regular(path: Path) -> None:
    if not path.is_file() or path.is_symlink():
        raise RuntimeError(f"required regular file is missing or linked: {path}")


def add_html_landmarks(path: Path) -> None:
    """Wrap Pandoc's post-TOC reader content in one accessible main landmark."""

    text = path.read_text(encoding="utf-8")
    inventory = _fragment_inventory(text)
    if any(element["tag"] == "main" for element in inventory.elements) or (
        "main-content" in inventory.ids
    ):
        raise RuntimeError("HTML already contains a main landmark")
    body_match = re.search(r"<body(?:\s[^>]*)?>", text)
    if body_match is None:
        raise RuntimeError("Pandoc HTML lacks an opening body tag")
    if text.count("</nav>") != 1 or text.count("</body>") != 1:
        raise RuntimeError("Pandoc HTML has an unexpected nav/body structure")

    skip_link = (
        '\n<a class="skip-link" href="#main-content">Langsung ke isi utama</a>'
    )
    text = text[: body_match.end()] + skip_link + text[body_match.end() :]
    nav_end = text.index("</nav>") + len("</nav>")
    text = (
        text[:nav_end]
        + '\n<main id="main-content" tabindex="-1">'
        + text[nav_end:]
    )
    body_end = text.index("</body>")
    text = text[:body_end] + "</main>\n" + text[body_end:]
    path.write_text(text, encoding="utf-8", newline="\n")


def cumulative_inputs(
    through: int,
) -> tuple[tuple[Path, ...], dict[str, str]]:
    """Return every build-affecting frozen input through ``through``.

    Media closures are the authoritative unit-local index.  HTML keeps each
    selected asset (including animation); the PDF source substitutes only an
    explicitly frozen static fallback recorded by the closure.
    """

    inputs: list[Path] = [
        CSS,
        PDF_HEADER,
        LANE
        / "authority"
        / "wikiversity-bgk"
        / "course"
        / "COURSE_AUTHORITY_MANIFEST.json",
    ]
    pdf_replacements: dict[str, str] = {}
    if through == 30:
        # The complete volume carries its additive cross-unit terminology
        # intake without altering the immutable Units 1--12 ledger baseline.
        inputs.append(LANE / "00_control" / "BGK_UNITS_13_30_TERMINOLOGY.csv")
    fallback_keys = (
        "pdf_local_path",
        "pdf_fallback_local_path",
        "pdf_fallback_path",
        "pdf_static_fallback_path",
        "pdf_first_frame_path",
    )
    for unit in range(1, through + 1):
        closure_path = (
            LANE / "authority" / f"ASSET_CLOSURE-bgk-unit-{unit:02d}.json"
        )
        regular(closure_path)
        closure = json.loads(closure_path.read_text(encoding="utf-8"))
        if closure.get("unit") != unit:
            raise RuntimeError(
                f"media closure unit mismatch: expected {unit}, got {closure.get('unit')}"
            )
        manifest_rel = closure.get("authority_manifest", {}).get("path")
        rights_rel = closure.get("rights_file")
        if not isinstance(manifest_rel, str) or not isinstance(rights_rel, str):
            raise RuntimeError(f"incomplete authority/rights binding in {closure_path}")
        inputs.extend((LANE / manifest_rel, closure_path, LANE / rights_rel))
        for asset in closure.get("assets", []):
            local_rel = asset.get("local_path")
            if not isinstance(local_rel, str):
                raise RuntimeError(f"asset lacks local_path in {closure_path}")
            inputs.append(LANE / local_rel)
            fallback_rel = next(
                (
                    asset.get(key)
                    for key in fallback_keys
                    if isinstance(asset.get(key), str) and asset.get(key)
                ),
                None,
            )
            if fallback_rel is not None:
                inputs.append(LANE / fallback_rel)
                pdf_replacements[local_rel.replace("\\", "/")] = fallback_rel.replace(
                    "\\", "/"
                )

    # Preserve the first occurrence and make duplicate file references explicit
    # only once in the deterministic receipt.
    unique_inputs = tuple(dict.fromkeys(inputs))
    return unique_inputs, pdf_replacements


def normalize_pdf_id(path: Path) -> str:
    """Replace LuaTeX's random trailer ID with a content-derived stable ID.

    LuaTeX's generated PDF is otherwise byte-identical across replays.  The
    replacement is fixed-width, so it does not invalidate the cross-reference
    offsets.  Hashing the zeroed-ID representation avoids circularity.
    """

    payload = path.read_bytes()
    matches = tuple(PDF_ID_PATTERN.finditer(payload))
    if len(matches) != 1:
        raise RuntimeError(f"expected one PDF trailer ID, found {len(matches)}")
    zeroed = PDF_ID_PATTERN.sub(
        b"/ID [ <00000000000000000000000000000000> <00000000000000000000000000000000> ]",
        payload,
    )
    stable_id = hashlib.sha256(zeroed).hexdigest()[:32].encode("ascii")
    normalized = PDF_ID_PATTERN.sub(
        b"/ID [ <" + stable_id + b"> <" + stable_id + b"> ]",
        payload,
    )
    if len(normalized) != len(payload):
        raise RuntimeError("PDF trailer-ID normalization changed the byte length")
    path.write_bytes(normalized)
    return stable_id.decode("ascii")


def tool_line(executable: str, *args: str) -> str:
    process = subprocess.run(
        [executable, *args],
        cwd=LANE,
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    return process.stdout.splitlines()[0]


def run_logged(log: Path, executable: str, *args: str) -> None:
    environment = os.environ.copy()
    environment["SOURCE_DATE_EPOCH"] = SOURCE_DATE_EPOCH
    process = subprocess.run(
        [executable, *args],
        cwd=LANE,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    log.write_text(process.stdout, encoding="utf-8", newline="\n")
    if process.returncode:
        raise RuntimeError(f"build command failed ({process.returncode}); see {log}")


def scope(through: int) -> tuple[tuple[Path, ...], str, str, str]:
    if not 1 <= through <= 30:
        raise ValueError("--through must be between 1 and 30")
    frontmatter = (
        SOURCE_DIR / "frontmatter-bgk-units-01.md"
        if through == 1
        else SOURCE_DIR / f"frontmatter-bgk-units-01-{through:02d}.md"
    )
    paths: list[Path] = [frontmatter]
    if through == 30:
        paths.append(SOURCE_DIR / "glossary-bgk-units-01-30.md")
    for unit in range(1, through + 1):
        paths.extend(
            (
                SOURCE_DIR / f"lecture-{unit:02d}.md",
                SOURCE_DIR / f"worksheet-{unit:02d}.md",
                SOURCE_DIR / f"worksheet-{unit:02d}-solutions.md",
                SOURCE_ROOT / f"media-credits-bgk-unit-{unit:02d}.md",
            )
        )
    title = f"Bundel, Berkas, dan Kohomologi - Unit 1-{through}"
    if through == 1:
        title = "Bundel, Berkas, dan Kohomologi - Unit 1"
    subtitle = "Edisi Bahasa Indonesia independen"
    pdf_name = (
        "bundel-berkas-dan-kohomologi-id-unit-01.pdf"
        if through == 1
        else f"bundel-berkas-dan-kohomologi-id-units-01-{through:02d}.pdf"
    )
    return tuple(paths), title, subtitle, pdf_name


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--through", type=int, default=1)
    args = parser.parse_args()
    sources, title, subtitle, pdf_name = scope(args.through)
    fixed_inputs, pdf_asset_replacements = cumulative_inputs(args.through)
    for path in (*sources, *fixed_inputs):
        regular(path)

    pandoc = shutil.which("pandoc")
    lualatex = shutil.which("lualatex")
    if not pandoc or not lualatex:
        raise RuntimeError("pandoc and lualatex must both be available on PATH")
    pandoc_version = tool_line(pandoc, "--version")
    if pandoc_version != EXPECTED_PANDOC:
        raise RuntimeError(
            f"unexpected Pandoc version: {pandoc_version!r}; expected {EXPECTED_PANDOC!r}"
        )
    latex_version = tool_line(lualatex, "--version")

    BUILD_DIR.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix=".reader-bgk-id-stage-", dir=BUILD_DIR))
    try:
        html_path = stage / "index.html"
        pdf_path = stage / pdf_name
        serialized_texts: dict[Path, str] = {}
        html_sources: list[Path] = []
        math_serialization_records: list[dict[str, object]] = []
        for source in sources:
            original = source.read_text(encoding="utf-8")
            text, records = serialize_reader_math(
                original, source.relative_to(LANE).as_posix(), through=args.through
            )
            serialized_texts[source] = text
            math_serialization_records.extend(records)
            if records:
                staged_html = stage / f"html-{source.name}"
                staged_html.write_text(text, encoding="utf-8", newline="\n")
                html_sources.append(staged_html)
            else:
                # The historical Units 1--12 serialization is byte-preserved.
                html_sources.append(source)
        resource_path = os.pathsep.join(
            (str(stage), str(SOURCE_DIR), str(SOURCE_ROOT), str(ASSET_DIR), str(LANE))
        )
        common = [
            "--from=markdown+yaml_metadata_block+tex_math_dollars+fenced_divs+bracketed_spans",
            "--standalone",
            "--toc",
            "--metadata=lang:id-ID",
            f"--metadata=title:{title}",
            f"--metadata=subtitle:{subtitle}",
            "--metadata=author:Holger Brenner (karya sumber)",
            f"--resource-path={resource_path}",
            *(str(path) for path in html_sources),
        ]
        run_logged(
            stage / "pandoc-html.log",
            pandoc,
            *common,
            "--to=html5",
            "--mathml",
            "--embed-resources",
            f"--css={CSS}",
            f"--output={html_path}",
        )
        html_fragment_compatibility = apply_html_fragment_compatibility(
            html_path, args.through
        )
        add_html_landmarks(html_path)
        html_fragment_compatibility = validate_final_html_fragment_compatibility(
            html_path, args.through, html_fragment_compatibility
        )

        pdf_sources: list[Path] = []
        for source in sources:
            staged = stage / f"pdf-{source.name}"
            # Both backends receive exactly the same mathematical serialization.
            text = serialized_texts[source]
            text = text.replace("★", r"\sourceblackstar{}")
            text = text.replace("κ", r"$\kappa$")
            text = text.replace(r"\vcentcolon=", r":=")
            text = re.sub(
                # The opening delimiter must not itself be the closing backtick
                # of a preceding short code span (for example `PD`, followed
                # later by `{{PD-self}}`).
                r"(?<![\w}\]])`([^`\n]{40,})`",
                lambda match: r"\nolinkurl{" + match.group(1) + "}",
                text,
            )
            text = text.replace(
                "](authority/assets/bgk-tangent-bundle-500.png)",
                "](authority/assets/bgk-tangent-bundle-500.png){height=70%}",
            )
            for animated_path, fallback_path in pdf_asset_replacements.items():
                text = text.replace(animated_path, fallback_path)
            staged.write_text(text, encoding="utf-8", newline="\n")
            pdf_sources.append(staged)

        pdf_common = [
            "--from=markdown+yaml_metadata_block+tex_math_dollars+fenced_divs+bracketed_spans",
            "--standalone",
            "--toc",
            "--metadata=lang:id-ID",
            f"--metadata=title:{title}",
            f"--metadata=subtitle:{subtitle}",
            "--metadata=author:Holger Brenner (karya sumber)",
            f"--resource-path={resource_path}",
            f"--include-in-header={PDF_HEADER}",
            *(str(path) for path in pdf_sources),
        ]
        run_logged(
            stage / "pandoc-pdf.log",
            pandoc,
            *pdf_common,
            f"--pdf-engine={lualatex}",
            "--variable=papersize:a4",
            "--variable=geometry:margin=25mm",
            "--variable=colorlinks:true",
            f"--output={pdf_path}",
        )
        normalized_pdf_id = normalize_pdf_id(pdf_path)
        regular(html_path)
        regular(pdf_path)
        if html_path.stat().st_size < 10_000 or pdf_path.stat().st_size < 10_000:
            raise RuntimeError("BGK reader artifact is implausibly small")

        receipt = {
            "schema": "ag-bridge-bgk-build-receipt-v1",
            "built_utc": datetime.fromtimestamp(
                int(SOURCE_DATE_EPOCH), timezone.utc
            ).isoformat(),
            "source_date_epoch": SOURCE_DATE_EPOCH,
            "language": "id-ID",
            "volume": "Bündel, Garben und Kohomologie",
            "through_unit": args.through,
            "title": title,
            "pandoc": pandoc_version,
            "latex": latex_version,
            "normalized_pdf_trailer_id": normalized_pdf_id,
            "html_main_landmark": "main#main-content",
            "html_skip_link": "a.skip-link[href='#main-content']",
            "html_fragment_compatibility": html_fragment_compatibility,
            "inputs": [fact(path) for path in (*sources, *fixed_inputs)],
            "outputs": [
                {
                    "path": "build/reader-bgk-id/index.html",
                    "bytes": html_path.stat().st_size,
                    "sha256": sha256(html_path),
                },
                {
                    "path": f"build/reader-bgk-id/{pdf_name}",
                    "bytes": pdf_path.stat().st_size,
                    "sha256": sha256(pdf_path),
                },
            ],
        }
        if math_serialization_records:
            receipt["math_serialization"] = {
                "schema": MATH_SERIALIZATION_SCHEMA,
                "scope": "generated staging sources only; canonical source bytes unchanged",
                "shared_html_pdf_serialization": True,
                "diagram_count": sum(
                    row["kind"] == "CD" for row in math_serialization_records
                ),
                "set_separator_count": sum(
                    row["kind"] == "set-separator"
                    for row in math_serialization_records
                ),
                "control_sequence_backslash_correction_count": sum(
                    row["kind"] == "control-sequence-backslash"
                    for row in math_serialization_records
                ),
                "visible_staging_note_count": sum(
                    bool(row.get("staging_note"))
                    for row in math_serialization_records
                ),
                "renderer": fact(
                    LANE / "scripts" / "bgk_reader_math_serialization.py"
                ),
                "exact_input_output_contract": fact(MATH_SERIALIZATION_FIXTURE),
                "records": math_serialization_records,
            }
        (stage / "BUILD_RECEIPT.json").write_text(
            json.dumps(receipt, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
            newline="\n",
        )

        previous = BUILD_DIR / ".reader-bgk-id-previous"
        if previous.exists():
            shutil.rmtree(previous)
        if FINAL_DIR.exists():
            FINAL_DIR.replace(previous)
        stage.replace(FINAL_DIR)
        if previous.exists():
            shutil.rmtree(previous)
    except Exception as error:
        raise RuntimeError(f"{error}; failed stage retained at {stage}") from error

    print(FINAL_DIR)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1)
