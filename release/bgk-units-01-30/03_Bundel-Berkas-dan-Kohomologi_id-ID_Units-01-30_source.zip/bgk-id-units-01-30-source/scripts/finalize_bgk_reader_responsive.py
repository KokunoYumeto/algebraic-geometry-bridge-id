#!/usr/bin/env python3
"""Finalize immutable BGK responsive measurements after explicit screenshot review."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import struct
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODEL = "OpenAI Codex gpt-5.6-sol, Ultra."
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
IAB_ROUTE = "owner-operated-in-app-browser"
IAB_CAPTURE_POLICY = "iab-runtime-native-jpeg-v1"
JPEG_SOF_MARKERS = {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                    0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def lane_path(value: str) -> Path:
    raw = Path(value)
    path = raw.resolve() if raw.is_absolute() else (ROOT / raw).resolve()
    try:
        path.relative_to(ROOT)
    except ValueError as error:
        raise RuntimeError(f"path must remain inside the lane: {path}") from error
    return path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def fact(path: Path) -> dict[str, object]:
    require(path.is_file() and not path.is_symlink(), f"missing regular file: {path}")
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }


def replay(row: dict[str, object]) -> Path:
    path = lane_path(str(row["path"]))
    observed = fact(path)
    require(observed["bytes"] == row.get("bytes") and observed["sha256"] == row.get("sha256"), f"identity drift: {path}")
    return path


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as stream:
        header = stream.read(24)
    require(len(header) == 24 and header[:8] == PNG_SIGNATURE and header[12:16] == b"IHDR", f"invalid PNG: {path}")
    return struct.unpack(">II", header[16:24])


def jpeg_dimensions_data(data: bytes, label: str = "screenshot") -> tuple[int, int]:
    """Read actual JPEG SOF dimensions; do not decode, crop, or resample pixels."""
    require(len(data) >= 4 and data[:2] == b"\xff\xd8", f"invalid/truncated JPEG signature: {label}")
    offset = 2
    while offset < len(data):
        require(data[offset] == 0xFF, f"invalid JPEG marker: {label}")
        while offset < len(data) and data[offset] == 0xFF:
            offset += 1
        require(offset < len(data), f"truncated JPEG marker: {label}")
        marker = data[offset]
        offset += 1
        require(marker not in (0, 0xD8), f"invalid JPEG marker: {label}")
        require(marker not in (0xD9, 0xDA), f"missing JPEG SOF before image data: {label}")
        if marker == 0x01 or 0xD0 <= marker <= 0xD7:
            continue
        require(offset + 2 <= len(data), f"truncated JPEG segment: {label}")
        length = int.from_bytes(data[offset:offset + 2], "big")
        require(length >= 2 and offset + length <= len(data), f"invalid/truncated JPEG segment: {label}")
        if marker in JPEG_SOF_MARKERS:
            require(length >= 8, f"truncated JPEG SOF: {label}")
            height, width = struct.unpack(">HH", data[offset + 3:offset + 7])
            components = data[offset + 7]
            require(width > 0 and height > 0 and components > 0 and length == 8 + 3 * components,
                    f"invalid JPEG SOF dimensions/components: {label}")
            return width, height
        offset += length
    raise RuntimeError(f"missing JPEG SOF: {label}")


def jpeg_dimensions(path: Path) -> tuple[int, int]:
    return jpeg_dimensions_data(path.read_bytes(), str(path))


def validate_iab_surface(surface: dict, name: str) -> None:
    """Replay CSS geometry independently of the runtime's bounded JPEG raster."""
    expected = (1280, 720, 1265) if name == "desktop" else (390, 844, 375)
    viewport = surface.get("viewport", {})
    require(tuple(viewport.get(key) for key in ("innerWidth", "innerHeight", "clientWidth")) == expected,
            f"{name} IAB CSS viewport/client dimensions")
    require(surface.get("title") == "Bundel, Berkas, dan Kohomologi - Unit 1-30", f"{name} title drift")
    require(viewport.get("documentHorizontalOverflow") is False, f"{name} CSS overflow flag")
    for key in ("scrollWidth", "bodyScrollWidth"):
        value = viewport.get(key)
        require(type(value) is int and value >= 0, f"{name} CSS {key}")
    require(viewport["scrollWidth"] <= viewport["clientWidth"] + 1, f"{name} CSS document overflow")
    rect = surface.get("main", {})
    for key in ("left", "right", "width", "centeringDelta"):
        value = rect.get(key)
        require(type(value) in (int, float) and math.isfinite(value), f"{name} CSS main {key}")
    require(abs(rect["right"] - rect["left"] - rect["width"]) <= 0.03, f"{name} CSS main rectangle")
    delta = (rect["left"] + rect["right"]) / 2 - viewport["clientWidth"] / 2
    require(abs(delta - rect["centeringDelta"]) <= 0.02 and abs(rect["centeringDelta"]) <= 0.5,
            f"{name} CSS main centering")
    low, high = (960, 980) if name == "desktop" else (340, 345)
    require(low <= rect["width"] <= high, f"{name} CSS main width")
    counts = surface.get("counts", {})
    for key in ("main", "skipLinks", "missingAlt", "duplicateIds", "brokenAnchors", "unprotectedOutsideViewportNodes"):
        expected_count = 1 if key in ("main", "skipLinks") else 0
        require(type(counts.get(key)) is int and counts[key] == expected_count, f"{name} CSS/accessible closure: {key}")
    policy = surface.get("fragmentPolicy", {})
    require(policy.get("name") == "unencoded-ascii-id-v1" and policy.get("allSupported") is True
            and type(policy.get("unsupportedFragmentCount")) is int and policy["unsupportedFragmentCount"] == 0
            and policy.get("unsupportedFragments") == [], f"{name} ASCII fragment closure")


def verify_screenshot_evidence(measurement: dict) -> list[dict]:
    """Preserve legacy CDP PNG gates; admit exact native IAB JPEG evidence only."""
    iab = measurement.get("measurement_route") == IAB_ROUTE
    if iab:
        require(measurement.get("through_unit") == 30, "IAB native JPEG contract is scoped through Unit 30")
        contract = measurement.get("capture_contract", {})
        require(contract.get("policy") == IAB_CAPTURE_POLICY and contract.get("adapter_resampled") is False
                and contract.get("adapter_cropped") is False, "IAB native capture contract")
        require(measurement.get("checks", {}).get("internal_fragments_unencoded_ascii_ids") is True,
                "IAB ASCII fragment measurement check")
        validate_iab_surface(measurement["desktop"], "desktop")
        validate_iab_surface(measurement["mobile"], "mobile")
    screenshots = []
    for name, surface_key in (("desktop", "desktop"), ("mobile", "mobile"), ("deep", "deep_surface")):
        row = measurement[surface_key]["screenshot"]
        path = replay(row)
        if iab:
            expected = (1265, 712) if name == "desktop" else (375, 800)
            require(path.suffix.lower() in (".jpg", ".jpeg") and row.get("mediaType") == "image/jpeg",
                    f"{name} native JPEG media type/extension")
            dimensions = jpeg_dimensions(path)
            require(dimensions == expected, f"{name} native JPEG capture dimensions")
            require(row.get("dimensions") == dict(zip(("width", "height"), dimensions)),
                    f"{name} bound JPEG dimensions drift")
            viewport = measurement["desktop" if name == "desktop" else "mobile"]["viewport"]
            capture = row.get("capture", {})
            require(capture.get("kind") == "runtime-provided-bounded-capture"
                    and capture.get("adapterResampled") is False and capture.get("adapterCropped") is False,
                    f"{name} native capture binding")
            css_viewport = {"width": viewport["innerWidth"], "height": viewport["innerHeight"],
                            "clientWidth": viewport["clientWidth"]}
            require(capture.get("cssViewport") == css_viewport, f"{name} bound CSS viewport drift")
            screenshots.append({**fact(path), "mediaType": "image/jpeg", "dimensions": row["dimensions"],
                                "capture": capture})
        else:
            # Existing CDP receipts do not declare a route or mediaType. Their
            # required full-viewport PNG sizes and output facts stay unchanged.
            expected = (1280, 720) if name == "desktop" else (390, 844)
            require(png_dimensions(path) == expected, f"{name} screenshot dimensions")
            screenshots.append(fact(path))
    return screenshots


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--through", type=int, required=True)
    parser.add_argument("--measurement", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--reviewer-model", default=MODEL)
    parser.add_argument("--approve", action="store_true")
    parser.add_argument("--replace", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    if not 1 <= args.through <= 30:
        parser.error("--through must be in 1..30")
    measurement_path = lane_path(args.measurement)
    output = lane_path(args.output)
    require(measurement_path != output, "measurement and final receipt paths must differ")
    plan = {
        "status": "PASS_DRY_RUN",
        "through_unit": args.through,
        "measurement": measurement_path.relative_to(ROOT).as_posix(),
        "output": output.relative_to(ROOT).as_posix(),
        "reviewer_model": args.reviewer_model,
        "required_explicit_flag": "--approve",
    }
    if args.dry_run:
        print(json.dumps(plan, ensure_ascii=False, sort_keys=True))
        return 0

    require(args.approve, "explicit --approve is required after inspecting all bound screenshots")
    require(args.reviewer_model.strip(), "reviewer model must be non-empty")
    measurement = json.loads(measurement_path.read_text(encoding="utf-8"))
    require(measurement.get("schema") == "ag-bridge-bgk-responsive-measurement-v2", "measurement schema")
    require(measurement.get("through_unit") == args.through, "measurement scope")
    require(measurement.get("status") == "PASS_MEASURED_SCREENSHOTS_PENDING_REVIEW", "measurement status")
    checks = measurement.get("checks", {})
    required_checks = (
        "desktop_centered_and_page_filling",
        "mobile_reflow_without_document_overflow",
        "no_unprotected_content_outside_viewport",
        "skip_link_landmark_alt_id_and_anchor_closure",
        "deep_surface_captured",
    )
    require(all(checks.get(name) is True for name in required_checks), "measurement checks are incomplete")
    require(checks.get("screenshots_reviewed") is False, "measurement must remain immutable and unreviewed")

    screenshots = verify_screenshot_evidence(measurement)
    replay(measurement["html"])
    replay(measurement["reader_machine_qa"])
    replay(measurement["expectations"])

    payload = {
        "schema": "ag-bridge-bgk-responsive-reviewed-v1",
        "through_unit": args.through,
        "status": "PASS",
        "model_provenance": MODEL,
        "measurement_receipt": fact(measurement_path),
        "screenshots": screenshots,
        "review": {
            "decision": "PASS",
            "reviewer_model": args.reviewer_model,
            "invocation_contract": "The invoker inspected all three hash-bound screenshots before supplying --approve.",
            "checks": {
                "desktop_centering_and_page_fill_visually_confirmed": True,
                "mobile_reflow_and_local_overflow_visually_confirmed": True,
                "deep_terminal_surface_visually_confirmed": True,
                "visible_clipping_overlap_or_broken_glyph_observed": False,
            },
        },
    }
    if measurement.get("measurement_route") == IAB_ROUTE:
        payload["measurement_route"] = IAB_ROUTE
        payload["capture_contract"] = measurement["capture_contract"]
    if output.exists() and not args.replace:
        raise RuntimeError(f"output already exists; use --replace explicitly: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    temporary.replace(output)
    print(json.dumps({"status": "PASS", "receipt": fact(output)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
