"""Bounded regression: the contents page must never be a body transition."""
from types import SimpleNamespace

from qa_bgk_reader_general import locate_pdf_surfaces


class Reader:
    def __init__(self, entries):
        self.outline = entries

    def get_destination_page_number(self, entry):
        return entry.page - 1


def entry(title, page):
    return SimpleNamespace(title=title, page=page)


def main():
    rows = [{"unit": 1, "surface_markers": {"lecture": "Kuliah 1", "worksheet": "Lembar 1"}}]
    texts = ["Kuliah 1 Lembar 1", "Kuliah 1 badan", "Lembar 1 soal"]
    reader = Reader([entry("Kuliah 1", 2), [entry("Lembar 1", 3)]])
    assert locate_pdf_surfaces(reader, rows, texts) == [{"unit": 1, "lecture": 2, "worksheet": 3}]
    cases = [
        Reader([entry("Kuliah 1", 2)]),
        Reader([entry("Kuliah 1", 2), entry("Kuliah 1", 2), entry("Lembar 1", 3)]),
        Reader([entry("Kuliah 1", 3), entry("Lembar 1", 3)]),
        Reader([entry("Kuliah 1", 2), entry("Lembar 1", 0)]),
    ]
    for invalid in cases:
        try:
            locate_pdf_surfaces(invalid, rows, texts)
        except RuntimeError:
            pass
        else:
            raise AssertionError("invalid surface locator accepted")
    print("PASS: five PDF outline/TOC surface-location tests")


if __name__ == "__main__":
    main()
