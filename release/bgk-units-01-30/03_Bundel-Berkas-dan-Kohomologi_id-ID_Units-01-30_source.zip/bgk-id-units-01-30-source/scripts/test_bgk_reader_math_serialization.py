#!/usr/bin/env python3
"""Build-free exact topology/MathML tests for the nine BGK CD witnesses."""

from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import unittest
import xml.etree.ElementTree as ET

from bgk_reader_math_serialization import (
    digest_text,
    load_contract,
    parse_cd,
    render_cd,
    serialize_reader_math,
)
from build_bgk_reader import scope

ROOT = Path(__file__).resolve().parents[1]
MATH_NS = {"m": "http://www.w3.org/1998/Math/MathML"}


def pandoc(text: str, target: str) -> str:
    args = ["pandoc", "--from=markdown", "--to=" + target]
    if target == "html5":
        args.append("--mathml")
    result = subprocess.run(
        args, input="$$\n" + text + "\n$$\n", text=True,
        encoding="utf-8", stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        check=True, cwd=ROOT,
    )
    if result.stderr:
        raise AssertionError(result.stderr)
    return result.stdout


class MathSerializationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.records = load_contract()["records"]

    def test_all_eleven_exact_source_witnesses_and_nine_topologies(self) -> None:
        self.assertEqual(len(self.records), 11)
        self.assertEqual(sum(r["kind"] == "CD" for r in self.records), 9)
        for record in self.records:
            with self.subTest(record=record["id"]):
                text = (ROOT / record["source"]).read_text(encoding="utf-8")
                self.assertEqual(text.count(record["input"]), 1)
                self.assertEqual(digest_text(record["input"]), record["input_sha256"])
                self.assertEqual(digest_text(record["output"]), record["output_sha256"])
                if record["kind"] == "CD":
                    self.assertEqual(parse_cd(record["input"]), record["topology"])
                    self.assertEqual(render_cd(record["topology"]), record["output"])

    def test_exact_backend_serialization_and_real_mathml(self) -> None:
        for record in self.records:
            with self.subTest(record=record["id"]):
                output = record["output"]
                html = pandoc(output, "html5")
                latex = pandoc(output, "latex")
                self.assertNotIn(r"\begin{CD}", html + latex)
                self.assertNotIn(r"\middle", html + latex)
                self.assertIn(output, latex)
                match = re.search(r"<math\b[\s\S]*?</math>", html)
                self.assertIsNotNone(match)
                math = ET.fromstring(match.group())
                self.assertNotIn("merror", html)
                self.assertEqual(
                    math.find(".//m:annotation", MATH_NS).text.strip(), output
                )
                if record["kind"] != "CD":
                    self.assertIsNotNone(math.find(".//m:mo", MATH_NS))
                    continue
                table = math.find(".//m:mtable", MATH_NS)
                self.assertIsNotNone(table)
                rows = table.findall("m:mtr", MATH_NS)
                topology = record["topology"]
                self.assertEqual(len(rows), 2 * len(topology["objects"]) - 1)
                expected_arrows = Counter()
                for edge in topology["horizontal"]:
                    expected_arrows["→" if edge["direction"] == "right" else "="] += 1
                for pair in topology["vertical"]:
                    for edge in pair:
                        expected_arrows["↓" if edge["direction"] == "down" else "↑"] += 1
                relation_cells = [
                    row.findall("m:mtd", MATH_NS)[column]
                    for index, row in enumerate(rows)
                    for column in ((3,) if index % 2 == 0 else (1, 5))
                ]
                observed_arrows = Counter(
                    node.text for cell in relation_cells
                    for node in cell.findall(".//m:mo", MATH_NS)
                    if node.text in ("→", "↓", "↑", "=")
                )
                self.assertEqual(observed_arrows, expected_arrows)
                # Real MathML retains exact seven-column node/arrow/label
                # topology; no raw TeX fallback stands in for the diagram.
                for index, row in enumerate(rows):
                    cells = row.findall("m:mtd", MATH_NS)
                    self.assertEqual(len(cells), 7)
                    if index % 2:
                        for column, edge in zip((1, 5), topology["vertical"][index // 2]):
                            self.assertEqual(
                                "".join(cells[column].itertext()),
                                "↓" if edge["direction"] == "down" else "↑",
                            )
                            for label_column, side in ((column - 1, "left"), (column + 1, "right")):
                                self.assertEqual(
                                    "".join(cells[label_column].itertext()),
                                    self.math_text(edge[side]) if edge[side] else "",
                                )
                    else:
                        edge = topology["horizontal"][index // 2]
                        relation_text = "".join(cells[3].itertext())
                        if edge["direction"] == "right":
                            self.assertEqual(
                                relation_text.replace("→", ""),
                                self.math_text(edge["above"]) if edge["above"] else "",
                            )
                            if edge["above"]:
                                above = cells[3].find(".//m:mover", MATH_NS)
                                self.assertIsNotNone(above)
                                self.assertEqual("".join(above[-1].itertext()), self.math_text(edge["above"]))
                        # Compare each object cell against independently
                        # converted exact source-object MathML text.
                        for column, source_object in zip((1, 5), topology["objects"][index // 2]):
                            object_html = pandoc(source_object, "html5")
                            object_math = ET.fromstring(re.search(r"<math\b[\s\S]*?</math>", object_html).group())
                            semantics = object_math.find("m:semantics", MATH_NS)
                            object_text = "".join(
                                "".join(node.itertext()) for node in semantics
                                if not node.tag.endswith("annotation")
                            )
                            self.assertEqual("".join(cells[column].itertext()), object_text)

    def math_text(self, source: str) -> str:
        html = pandoc(source, "html5")
        math = ET.fromstring(re.search(r"<math\b[\s\S]*?</math>", html).group())
        semantics = math.find("m:semantics", MATH_NS)
        return "".join(
            "".join(node.itertext()) for node in semantics
            if not node.tag.endswith("annotation")
        )

    def test_transform_is_staging_only_and_id_preserving(self) -> None:
        paths = sorted({r["source"] for r in self.records})
        for relative in paths:
            path = ROOT / relative
            before = path.read_bytes()
            text = before.decode("utf-8")
            transformed, receipts = serialize_reader_math(text, relative, through=30)
            self.assertEqual(path.read_bytes(), before)
            self.assertEqual(re.findall(r"\{#[^}]+\}", text), re.findall(r"\{#[^}]+\}", transformed))
            # Reverse only the exact substituted spans and require every
            # outside byte, including all prose and IDs, to be unchanged.
            restored = transformed
            for record in reversed(receipts):
                if record.get("staging_note"):
                    restored = restored.replace(
                        record["output"] + "\n$$\n\n" + record["staging_note"],
                        record["output"] + "\n$$", 1,
                    )
                self.assertEqual(restored.count(record["output"]), 1)
                restored = restored.replace(record["output"], record["input"], 1)
            self.assertEqual(restored, text)

    def test_legacy_units_one_through_twelve_are_exact_noops(self) -> None:
        sources, _, _, _ = scope(12)
        for path in sources:
            before = path.read_bytes()
            text = before.decode("utf-8")
            transformed, records = serialize_reader_math(
                text, path.relative_to(ROOT).as_posix(), through=12
            )
            self.assertEqual(transformed, text)
            self.assertEqual(records, [])
            self.assertEqual(path.read_bytes(), before)

    def test_unregistered_or_changed_diagrams_fail_closed(self) -> None:
        with self.assertRaises(ValueError):
            serialize_reader_math(r"\begin{CD}A @>>> B\\@VVV @VVV\\C @>>> D\end{CD}", "unknown.md")
        first = self.records[0]
        text = (ROOT / first["source"]).read_text(encoding="utf-8")
        for broken in (text.replace(first["input"], first["input"].replace(r"\theta", r"\eta", 1)),
                       text.replace(first["stable_id"], "moved-id", 1),
                       text + "\n" + first["input"]):
            with self.assertRaises(ValueError):
                serialize_reader_math(broken, first["source"])

    def test_parser_consumes_every_arrow_label_and_direction(self) -> None:
        expected = self.records[6]["topology"]
        self.assertEqual([r["direction"] for r in expected["vertical"][0]], ["up", "up"])
        self.assertEqual([r["direction"] for r in expected["vertical"][1]], ["down", "down"])
        for source in (r"\begin{CD}A @<f<< B\\@VVV @VVV\\C @>>> D\end{CD}",
                       r"\begin{CD}A @>>> B\\@VVV @VVV junk\\C @>>> D\end{CD}"):
            with self.assertRaises(ValueError):
                parse_cd(source)

    def test_unit_nine_correction_is_through30_only_and_authority_backed(self) -> None:
        record = next(r for r in self.records if r["kind"] == "control-sequence-backslash")
        path = ROOT / record["source"]
        before = path.read_bytes()
        text = before.decode("utf-8")
        for through in (None, 9, 12, 29):
            unchanged, records = serialize_reader_math(text, record["source"], through=through)
            self.assertEqual(unchanged, text)
            self.assertEqual(records, [])
        transformed, records = serialize_reader_math(text, record["source"], through=30)
        self.assertEqual(len(records), 1)
        self.assertNotIn(record["input"], transformed)
        self.assertIn(record["output"] + "\n$$\n\n" + record["staging_note"], transformed)
        self.assertEqual(transformed.count(record["staging_note"]), 1)
        self.assertEqual(path.read_bytes(), before)
        self.assertEqual(hashlib.sha256(before).hexdigest(), "0f2963c7eeef74e95e2233c98637c138b494dae1e9909dd432b240295c418657")
        html = pandoc(record["output"], "html5")
        math = ET.fromstring(re.search(r"<math\b[\s\S]*?</math>", html).group())
        self.assertEqual(
            [node.text for node in math.findall(".//m:mo", MATH_NS) if node.text == "→"],
            ["→"],
        )
        self.assertNotIn("longrightarrow", "".join(
            "".join(node.itertext())
            for node in math.find("m:semantics", MATH_NS)
            if not node.tag.endswith("annotation")
        ))
        authority = record["authority"]
        payload = (ROOT / authority["path"]).read_bytes()
        span = b"".join(payload.splitlines(keepends=True)[1646:1654])
        self.assertEqual(len(span), 240)
        self.assertEqual(hashlib.sha256(span).hexdigest(), authority["span_sha256"])
        self.assertEqual(span.decode("utf-8"), authority["span_text"])
        self.assertIn(r"\maabbdisp", authority["span_text"])
        self.assertIn("not a new mathematical claim", record["classification"])


if __name__ == "__main__":
    unittest.main()
