#!/usr/bin/env python3
"""Create deterministic contact sheets for a parameterized BGK PDF raster set."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def fact(path: Path) -> dict[str, object]:
    require(path.is_file() and not path.is_symlink(), f"missing regular file: {path}")
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }


def lane_path(value: str) -> Path:
    raw = Path(value)
    path = raw.resolve() if raw.is_absolute() else (ROOT / raw).resolve()
    try:
        path.relative_to(ROOT)
    except ValueError as error:
        raise RuntimeError(f"path must remain inside the lane: {path}") from error
    return path


def ranges(page_count: int, batch_size: int) -> list[tuple[int, int]]:
    return [
        (start, min(start + batch_size - 1, page_count))
        for start in range(1, page_count + 1, batch_size)
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--through", type=int, required=True)
    parser.add_argument("--render-dir", required=True)
    parser.add_argument("--page-count", type=int, required=True)
    parser.add_argument("--output-dir")
    parser.add_argument("--manifest")
    parser.add_argument("--rows", type=int, default=5)
    parser.add_argument("--cols", type=int, default=5)
    parser.add_argument("--cell-width", type=int, default=228)
    parser.add_argument("--cell-height", type=int, default=342)
    parser.add_argument("--label-height", type=int, default=20)
    parser.add_argument("--replace", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    if not 1 <= args.through <= 30:
        parser.error("--through must be in 1..30")
    for name in ("page_count", "rows", "cols", "cell_width", "cell_height", "label_height"):
        if getattr(args, name) <= 0:
            parser.error(f"--{name.replace('_', '-')} must be positive")

    render = lane_path(args.render_dir)
    output_dir = lane_path(args.output_dir) if args.output_dir else render
    manifest = lane_path(
        args.manifest
        or str(output_dir / f"BGK_UNITS_01_{args.through:02d}_CONTACT_SHEETS.json")
    )
    page_digits = max(3, len(str(args.page_count)))
    batch_size = args.rows * args.cols
    contact_ranges = ranges(args.page_count, batch_size)
    contact_names = [
        f"contact-{start:0{page_digits}d}-{end:0{page_digits}d}.png"
        for start, end in contact_ranges
    ]
    plan = {
        "status": "PASS_DRY_RUN",
        "through_unit": args.through,
        "render_dir": render.relative_to(ROOT).as_posix(),
        "output_dir": output_dir.relative_to(ROOT).as_posix(),
        "page_count": args.page_count,
        "page_digits": page_digits,
        "contact_ranges": [list(row) for row in contact_ranges],
        "contact_names": contact_names,
        "manifest": manifest.relative_to(ROOT).as_posix(),
    }
    if args.dry_run:
        print(json.dumps(plan, ensure_ascii=False, sort_keys=True))
        return 0

    from PIL import Image, ImageDraw, ImageFont, __version__ as pillow_version

    expected_names = [f"page-{number:0{page_digits}d}.png" for number in range(1, args.page_count + 1)]
    pages = sorted(render.glob("page-*.png"))
    require([path.name for path in pages] == expected_names, "page raster sequence is not exact and contiguous")
    output_dir.mkdir(parents=True, exist_ok=True)
    targets = [output_dir / name for name in contact_names]
    if not args.replace:
        require(not any(path.exists() for path in targets), "a contact sheet already exists; use --replace")
        require(not manifest.exists(), "manifest already exists; use --replace")
    font = ImageFont.load_default()
    contact_rows: list[dict[str, object]] = []
    raster_set = hashlib.sha256()
    for page in pages:
        row = fact(page)
        raster_set.update(
            f"{row['path']}\0{row['bytes']}\0{row['sha256']}\n".encode("utf-8")
        )

    for index, (start, end) in enumerate(contact_ranges):
        target = targets[index]
        batch = pages[start - 1 : end]
        sheet = Image.new("RGB", (args.cols * args.cell_width, args.rows * args.cell_height), "white")
        draw = ImageDraw.Draw(sheet)
        for offset, path in enumerate(batch):
            number = start + offset
            with Image.open(path) as opened:
                page = opened.convert("RGB")
                page.thumbnail(
                    (args.cell_width - 8, args.cell_height - args.label_height - 8),
                    Image.Resampling.LANCZOS,
                )
                col = offset % args.cols
                row = offset // args.cols
                x = col * args.cell_width + (args.cell_width - page.width) // 2
                y = (
                    row * args.cell_height
                    + args.label_height
                    + (args.cell_height - args.label_height - page.height) // 2
                )
                sheet.paste(page, (x, y))
                draw.rectangle(
                    (x - 1, y - 1, x + page.width, y + page.height),
                    outline="#777777",
                    width=1,
                )
                draw.text(
                    (col * args.cell_width + 6, row * args.cell_height + 4),
                    f"Page {number}",
                    fill="black",
                    font=font,
                )
        temporary = target.with_name(target.name + ".tmp.png")
        sheet.save(temporary, optimize=True)
        temporary.replace(target)
        row = fact(target)
        row["pages"] = [start, end]
        contact_rows.append(row)

    payload = {
        "schema": "ag-bridge-bgk-contact-sheet-manifest-v1",
        "through_unit": args.through,
        "status": "PASS",
        "page_count": args.page_count,
        "page_name_digits": page_digits,
        "page_raster_set_sha256": raster_set.hexdigest(),
        "layout": {
            "rows": args.rows,
            "cols": args.cols,
            "cell_width": args.cell_width,
            "cell_height": args.cell_height,
            "label_height": args.label_height,
        },
        "pillow": pillow_version,
        "contact_sheets": contact_rows,
    }
    manifest.parent.mkdir(parents=True, exist_ok=True)
    temporary = manifest.with_name(manifest.name + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    temporary.replace(manifest)
    print(json.dumps({"status": "PASS", "manifest": fact(manifest)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
