#!/usr/bin/env python3
"""Build-free contract tests for the generalized BGK reader QA tools."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
PYTHON_TOOLS = (
    "snapshot_bgk_reader_build.py",
    "qa_bgk_reader_general.py",
    "make_bgk_reader_contact_sheets.py",
    "finalize_bgk_reader_responsive.py",
    "write_bgk_reader_visual_receipt.py",
    "test_bgk_reader_tooling.py",
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def run(command: list[str], expected: int = 0) -> subprocess.CompletedProcess[str]:
    process = subprocess.run(
        command,
        cwd=ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    require(
        process.returncode == expected,
        f"command exit {process.returncode}, expected {expected}: {command}\n{process.stderr}",
    )
    return process


def stable_json(command: list[str]) -> dict[str, object]:
    first = run(command).stdout.strip()
    second = run(command).stdout.strip()
    require(first == second, f"dry-run output is not stable: {command}")
    payload = json.loads(first)
    require(payload.get("status") == "PASS_DRY_RUN", f"dry-run status: {command}")
    return payload


def main() -> int:
    tests: list[str] = []
    for name in PYTHON_TOOLS:
        path = SCRIPTS / name
        require(path.is_file() and not path.is_symlink(), f"missing Python tool: {path}")
        if name != "test_bgk_reader_tooling.py":
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
            help_result = run([sys.executable, str(path), "--help"])
            require("usage:" in help_result.stdout.lower(), f"missing deterministic help: {name}")
            tests.append(f"help:{name}")
        tests.append(f"syntax:{name}")

    manifest_path = SCRIPTS / "bgk_reader_expectations_v1.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    require(manifest.get("schema") == "ag-bridge-bgk-reader-expectations-v1", "manifest schema")
    units = manifest.get("units")
    require([row["unit"] for row in units] == list(range(1, 31)), "manifest units")
    require(sum(row["exercise_count"] for row in units) == 495, "manifest exercise total")
    require(sum(len(row["public_solution_ids"]) for row in units) == 25, "manifest public total")
    require(sum(row["negative_public_solution_count"] for row in units) == 470, "manifest negative total")
    require(
        all(len(row["public_solution_ids"]) + row["negative_public_solution_count"] == row["exercise_count"] for row in units),
        "manifest per-unit closure",
    )
    tests.append("expectations:30-units-495=25+470")

    sentinels = [
        ROOT / "tmp" / "bgk-tooling-dry-snapshot.json",
        ROOT / "tmp" / "bgk-tooling-dry-contact.json",
        ROOT / "tmp" / "bgk-tooling-dry-responsive.json",
        ROOT / "tmp" / "bgk-tooling-dry-visual.json",
    ]
    require(not any(path.exists() for path in sentinels), "a dry-run sentinel already exists")

    stable_json(
        [sys.executable, str(SCRIPTS / "qa_bgk_reader_general.py"), "--through", "30", "--dry-run"]
    )
    tests.append("dry-run:machine-unit30")
    stable_json(
        [
            sys.executable,
            str(SCRIPTS / "snapshot_bgk_reader_build.py"),
            "--through", "30",
            "--output", "tmp/bgk-tooling-dry-snapshot.json",
            "--dry-run",
        ]
    )
    tests.append("dry-run:snapshot-unit30")
    contact = stable_json(
        [
            sys.executable,
            str(SCRIPTS / "make_bgk_reader_contact_sheets.py"),
            "--through", "30",
            "--render-dir", "tmp/bgk-tooling-nonexistent-render",
            "--output-dir", "tmp/bgk-tooling-nonexistent-contacts",
            "--page-count", "26",
            "--manifest", "tmp/bgk-tooling-dry-contact.json",
            "--dry-run",
        ]
    )
    require(contact["contact_ranges"] == [[1, 25], [26, 26]], "contact dry-run ranges")
    tests.append("dry-run:contacts-26-pages")
    stable_json(
        [
            sys.executable,
            str(SCRIPTS / "finalize_bgk_reader_responsive.py"),
            "--through", "30",
            "--measurement", "tmp/bgk-tooling-nonexistent-measured.json",
            "--output", "tmp/bgk-tooling-dry-responsive.json",
            "--dry-run",
        ]
    )
    tests.append("dry-run:responsive-finalizer")
    stable_json(
        [
            sys.executable,
            str(SCRIPTS / "write_bgk_reader_visual_receipt.py"),
            "--through", "30",
            "--pdf", "tmp/bgk-tooling-nonexistent.pdf",
            "--render-dir", "tmp/bgk-tooling-nonexistent-render",
            "--page-count", "500",
            "--build-receipt", "tmp/bgk-tooling-nonexistent-build.json",
            "--machine-qa", "tmp/bgk-tooling-nonexistent-machine.json",
            "--responsive-qa", "tmp/bgk-tooling-nonexistent-responsive.json",
            "--contact-manifest", "tmp/bgk-tooling-nonexistent-contacts.json",
            "--output", "tmp/bgk-tooling-dry-visual.json",
            "--full-size-pages", "1,500",
            "--transition-pages", "1,250,500",
            "--dry-run",
        ]
    )
    tests.append("dry-run:visual-500-pages")

    node = shutil.which("node")
    require(node is not None, "Node is required for responsive-tool validation")
    run([node, "--check", str(SCRIPTS / "measure_bgk_reader_responsive.mjs")])
    node_help = run([node, str(SCRIPTS / "measure_bgk_reader_responsive.mjs"), "--help"])
    require("usage:" in node_help.stdout.lower(), "missing responsive help")
    tests.append("help:responsive")
    responsive = stable_json(
        [node, str(SCRIPTS / "measure_bgk_reader_responsive.mjs"), "--through", "30", "--dry-run"]
    )
    require(responsive["deep_anchor"] == "br-bgk-2019-w30-ex05", "responsive terminal anchor")
    tests.append("syntax+dry-run:responsive-unit30")

    invalid = run(
        [sys.executable, str(SCRIPTS / "qa_bgk_reader_general.py"), "--through", "31", "--dry-run"],
        expected=2,
    )
    require("1..30" in invalid.stderr, "machine invalid-scope diagnostic")
    tests.append("negative:machine-through31")
    invalid_contact = run(
        [
            sys.executable,
            str(SCRIPTS / "make_bgk_reader_contact_sheets.py"),
            "--through", "30",
            "--render-dir", "tmp/none",
            "--page-count", "0",
            "--dry-run",
        ],
        expected=2,
    )
    require("positive" in invalid_contact.stderr, "contact invalid-page diagnostic")
    tests.append("negative:contact-pagecount0")

    require(not any(path.exists() for path in sentinels), "dry-run created an output sentinel")
    require((SCRIPTS / "BGK_READER_QA_COMMAND_CONTRACT.md").is_file(), "command contract missing")
    tests.append("no-writes+command-contract")
    print(json.dumps({"status": "PASS", "tests": tests, "count": len(tests)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
