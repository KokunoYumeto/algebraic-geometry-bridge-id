#!/usr/bin/env python3
"""Publish complete BGK Units 1--30 in the existing classical/BGK Zenodo concept.

No mode creates a concept or changes an already-public record's files/access.
Only --reserve/--publish read credentials. --dry-run and --local-preflight are
strictly offline; --verify-public performs anonymous readback, not publication.
The actual pinned predecessor is the verified Units 1--6 record, not an
unproved Units 1--12 public release. An unreviewed newer version fails closed.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote, urljoin, urlparse

import requests


ROOT = Path(__file__).resolve().parents[1]
RELEASE = ROOT / "release/bgk-units-01-30"
TOKEN_FILE = Path.home() / "Documents/Obsidian notes/New zenodo token.md"
RESERVATION = ROOT / "qa/BGK_UNITS_01_30_ZENODO_RESERVATION.json"
PUBLICATION_RECEIPT = ROOT / "qa/BGK_UNITS_01_30_ZENODO_PUBLICATION.json"
MIGRATION_RECEIPT = ROOT / "backend/bgk-common-backend-v1/MIGRATION_RECEIPT_UNITS_01_30.json"
MIGRATION_SCHEMA = ROOT / "backend/common-backend-v1-contract/upstream/backend-migration-receipt-v1.v0.42.0.schema.json"
MIGRATION_SCHEMA_SHA256 = "0147b14972dd562805b3b5f76fac453a9f32a6d298827d3f588316d4a8f5ffe0"
BASE = "https://zenodo.org"
CONCEPT_DOI = "10.5281/zenodo.22059686"
CONCEPT_RECORD_ID = 22059686
PREVIOUS_RECORD_ID = 22164552
PREVIOUS_VERSION = "ak-unit-30+bgk-unit-06"
PREVIOUS_RECEIPT = ROOT / "qa/BGK_UNITS_01_06_ZENODO_PUBLICATION.json"
PREVIOUS_RECEIPT_SHA256 = "a97ac072e4d2f433fbec802c6c1ce4b13ba1a7cd449b275066ca2edee86ce4f1"
CLASSICAL_RECEIPT = ROOT / "qa/UNIT_30_ZENODO_PUBLICATION.json"
CLASSICAL_RECEIPT_SHA256 = "dcd2c4574081a4462627b5775480b27de4d5959e76442bc7d409979480e4bcea"
VERSION = "ak-unit-30+bgk-unit-30"
TITLE = ("Kurva Aljabar (Unit 1–30, lengkap) + Bundel, Berkas, dan Kohomologi "
         "(Unit 1–30, lengkap) — Edisi Bahasa Indonesia")
MODEL_ID = "OpenAI Codex gpt-5.6-sol, Ultra"
MODEL = MODEL_ID + "."
ORGANIZATION_HUB = "https://github.com/KokunoYumeto/program-matematika-indonesia"
MIGRATION_PUBLIC_NAME = "10_BGK_MIGRATION_RECEIPT_UNITS_01_30.json"
OLD_BGK_FILES = {
    "01_Bundel-Berkas-dan-Kohomologi_id-ID_Units-01-06.pdf",
    "02_Bundel-Berkas-dan-Kohomologi_id-ID_Units-01-06.html",
    "03_Bundel-Berkas-dan-Kohomologi_id-ID_Units-01-06_source.zip",
    "04_Bundel-Berkas-dan-Kohomologi_id-ID_Units-01-06_native-backend.zip",
    "05_LICENSE_AND_COMPONENT_RIGHTS.md", "06_README.md", "07_RELEASE_MANIFEST.json",
    "08_SHA256SUMS.txt", "09_RELEASE_CANDIDATE_QA.json", "10_BGK_MIGRATION_RECEIPT.json",
}
DRAFT_LOOKUP_SIZE = 100


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def fact(path: Path) -> dict:
    require(path.is_file() and not path.is_symlink(), f"Missing/nonregular local file: {path.name}")
    return {"bytes": path.stat().st_size, "sha256": sha256_path(path)}


def load(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    require(isinstance(value, dict), f"Expected JSON object: {path.name}")
    return value


def write_receipt(path: Path, value: dict) -> None:
    payload = (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")
    require(not path.is_symlink(), "Unsafe receipt target")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    require(not temporary.exists(), "Unresolved receipt staging file exists")
    with temporary.open("xb") as stream:
        stream.write(payload)
    require(temporary.read_bytes() == payload, "Receipt staging readback mismatch")
    temporary.replace(path)
    require(path.read_bytes() == payload, "Receipt readback mismatch")


def packager():
    # Import without creating __pycache__; importing never builds or packages.
    sys.dont_write_bytecode = True
    path = ROOT / "scripts/package_bgk_units_01_30_release.py"
    spec = importlib.util.spec_from_file_location("bgk_unit30_release_contract", path)
    require(spec is not None and spec.loader is not None, "Cannot load release contract")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def receipt_files(path: Path, digest: str, count: int) -> tuple[dict, dict]:
    require(sha256_path(path) == digest, f"Frozen predecessor receipt drifted: {path.name}")
    receipt = load(path)
    require(receipt.get("status") == "PASS", "Predecessor receipt not PASS")
    readback = receipt.get("anonymous_public_byte_readback", {})
    require(readback.get("credential_used") is False and readback.get("all_size_and_sha256_matches") is True,
            "Predecessor lacks anonymous exact-byte proof")
    rows = readback.get("files", [])
    require(len(rows) == count and len({row["name"] for row in rows}) == count and
            all(row.get("public_readback") is True and
                row.get("credential_used", readback["credential_used"]) is False for row in rows),
            "Predecessor file set/readback incomplete")
    return receipt, {row["name"]: {"bytes": int(row["bytes"]), "sha256": row["sha256"]} for row in rows}


def predecessor_facts() -> tuple[dict, dict]:
    classical_receipt, classical = receipt_files(CLASSICAL_RECEIPT, CLASSICAL_RECEIPT_SHA256, 8)
    previous_receipt, previous = receipt_files(PREVIOUS_RECEIPT, PREVIOUS_RECEIPT_SHA256, 18)
    identity = previous_receipt["record"]
    require(identity.get("id") == PREVIOUS_RECORD_ID and identity.get("version") == PREVIOUS_VERSION and
            identity.get("concept_doi") == CONCEPT_DOI, "Pinned public predecessor identity mismatch")
    require(classical_receipt["record"].get("concept_doi") == CONCEPT_DOI,
            "Classical receipt belongs to another concept")
    require(set(previous) == set(classical) | OLD_BGK_FILES and not set(classical) & OLD_BGK_FILES,
            "Predecessor inventory must be classical-eight plus BGK-ten")
    require(all(previous[name] == classical[name] for name in classical), "Classical inherited bytes drifted")
    return classical, {name: previous[name] for name in OLD_BGK_FILES}


def release_contract() -> tuple[dict, dict, dict]:
    package = packager()
    require(RELEASE.is_dir() and not RELEASE.is_symlink(), "Unit30 release directory is absent")
    require({path.name for path in RELEASE.iterdir()} == set(package.FILES), "Unexpected release inventory")
    # Rebuild in memory twice and compare every candidate byte, including QA.
    # This reuses the exact strict Unit30 reader/backend/rights gates, not a
    # copied declaration that could continue passing after source changes.
    first, second = package.build_once(), package.build_once()
    require(first == second, "Current packaging replay is not deterministic")
    require(all((RELEASE / name).read_bytes() == value for name, value in first.items()),
            "Packaged candidate no longer matches the live verified boundary")
    manifest = load(RELEASE / package.MANIFEST_NAME)
    qa = load(RELEASE / package.QA_NAME)
    require(manifest.get("status") == "complete_bgk_course_original_bridge_pending" and
            manifest.get("included_units") == list(range(1, 31)) and
            manifest.get("remaining_unit_count") == 0 and manifest.get("full_d100_lane_complete") is False and
            qa.get("status") == "PASS" and qa.get("through_unit") == 30,
            "Wrong complete-course/original-bridge scope")
    facts = {name: fact(RELEASE / name) for name in package.FILES}
    return manifest, qa, facts


def metadata(manifest: dict) -> dict:
    reader, backend = manifest["reader"], manifest["backend"]
    pages, records = int(reader["pdf_pages"]), int(backend["native_records"])
    require(pages > 0 and records > 0 and reader["exercises"] == 495 and
            reader["public_source_solutions"] == 25 and reader["documented_absent_source_solutions"] == 470,
            "Metadata counts do not match the exact course")
    course = load(ROOT / "authority/wikiversity-bgk/course/COURSE_AUTHORITY_MANIFEST.json")
    source_url = course["course_root"]["oldid_url"]
    require(source_url == "https://de.wikiversity.org/w/index.php?oldid=1052895", "Course root identity drifted")
    value = {
        "title": TITLE, "upload_type": "publication", "publication_type": "book",
        "description": (
            "<p><strong>Edisi Bahasa Indonesia (id-ID) dari dua kursus Holger Brenner.</strong> "
            "<em>Kurva Aljabar</em> tetap lengkap: 30 unit, 504 halaman PDF, 693 soal, dan seluruh "
            "122 solusi publik yang dibekukan. Versi ini melengkapi <em>Bundel, Berkas, dan "
            "Kohomologi</em> menjadi seluruh 30 kuliah dan 30 lembar kerja: "
            f"{pages} halaman PDF A4, HTML mandiri responsif dengan MathML, 495 soal, dan seluruh "
            "25 solusi publik pada revisi sumber. Sebanyak 470 solusi lain memang tidak tersedia "
            "dalam sumber dan tidak diciptakan.</p>"
            "<p>Kedua kursus sumber telah lengkap. Materi penghubung orisinal tentang skema/kohomologi "
            "serta modul penguasaan dan tugas akhir masih belum selesai; rilis ini tidak menyatakan "
            "seluruh jalur D100 selesai. Delapan berkas volume klasik dipertahankan tanpa perubahan. "
            "Checkpoint BGK sebelumnya diganti hanya pada versi baru ini; semua versi publik "
            "terdahulu tetap dapat diakses. PDF menjadi berkas pembaca utama, diikuti HTML, sumber "
            f"ringkas yang dapat dilanjutkan, backend asli {records:,} rekaman, adapter tervalidasi, "
            "lisensi/hak komponen, manifest, checksum, dan bukti QA.</p>"
            "<p>Teks kursus dan terjemahan berlisensi CC BY-SA 4.0; media mempertahankan atribusi "
            "dan lisensi per komponen. Tidak ada klaim satu lisensi untuk seluruh paket campuran. "
            f"Edisi independen disiapkan atas instruksi pengguna dengan {MODEL} Bukan terbitan resmi "
            "atau dukungan dari penulis, Universitas Osnabrück, Wikiversity, Wikimedia Foundation, "
            "atau OpenAI.</p>"
            "<p><strong>English identification:</strong> complete Indonesian editions of both "
            "30-unit Brenner source courses, <em>Algebraische Kurven</em> and <em>Bündel, Garben und "
            "Kohomologie</em>. The original connective bridge/mastery/capstone remains pending. "
            "Independent, non-endorsed derivative; CC BY-SA 4.0 course text and translation with "
            "component-specific media rights preserved.</p>"
        ),
        "creators": [{"name": "Brenner, Holger"}],
        "contributors": [{"name": "TTP", "type": "Other", "affiliation": ORGANIZATION_HUB},
                         {"name": MODEL_ID, "type": "Other"}],
        "access_right": "open", "license": "other-open", "language": "ind", "version": VERSION,
        "keywords": ["geometri aljabar", "algebraic geometry", "Bahasa Indonesia", "id-ID",
                     "kurva aljabar", "berkas", "kohomologi", "open textbook"],
        "related_identifiers": [
            {"identifier": "https://de.wikiversity.org/wiki/Kurs:Algebraische_Kurven_(Osnabr%C3%BCck_2025-2026)",
             "relation": "isDerivedFrom", "resource_type": "publication-book"},
            {"identifier": "https://de.wikiversity.org/wiki/Kurs:Algebraische_Kurven_(Osnabr%C3%BCck_2012)",
             "relation": "isDerivedFrom", "resource_type": "publication-book"},
            {"identifier": source_url, "relation": "isDerivedFrom", "resource_type": "publication-book"},
        ],
    }
    require(json.dumps(value, ensure_ascii=False).count("TTP") == 1 and
            "TTP" not in value["title"] and "TTP" not in value["description"] and MODEL in value["description"],
            "Organization/provenance metadata convention violated")
    return value


def safe_url(url: str) -> str:
    parsed = urlparse(url)
    require(parsed.scheme == "https" and parsed.netloc == "zenodo.org" and not parsed.username and
            not parsed.password and "access_token" not in parsed.query, "Unsafe Zenodo request URL")
    return url


def request(session: requests.Session, method: str, url: str, **kwargs) -> requests.Response:
    # Do not expose HTTP response bodies or signed/credential-bearing URLs.
    # Zenodo's public versions/latest endpoint legitimately redirects to its
    # canonical record. Follow at most three same-origin read-only redirects;
    # never redirect or automatically retry a mutation/upload.
    current = safe_url(url)
    for hop in range(4):
        response = session.request(method, current, timeout=(30, 240), allow_redirects=False, **kwargs)
        if response.status_code in (301, 302, 303, 307, 308) and method in ("GET", "HEAD"):
            location = response.headers.get("Location")
            response.close()
            require(bool(location) and hop < 3, "Zenodo read redirect absent or bounded limit reached")
            current = safe_url(urljoin(current, location))
            continue
        require(200 <= response.status_code < 300, f"Zenodo {method} failed: HTTP {response.status_code}")
        return response
    raise RuntimeError("Zenodo read redirect limit reached")


def anonymous_json(url: str) -> dict:
    with requests.Session() as session:
        session.trust_env = False
        result = request(session, "GET", url).json()
    require(isinstance(result, dict), "Zenodo public response is not an object")
    return result


def authenticated_session() -> requests.Session:
    candidates = set()
    for line in TOKEN_FILE.read_text(encoding="utf-8-sig").splitlines():
        value = line.strip().strip("`'\"")
        if ":" in value and "token" in value.casefold():
            value = value.split(":", 1)[1].strip().strip("`'\"")
        if re.fullmatch(r"[A-Za-z0-9._-]{32,}", value):
            candidates.add(value)
    require(len(candidates) == 1, "Designated credential file does not contain one unambiguous token")
    session = requests.Session()
    session.trust_env = False
    session.headers["Authorization"] = "Bearer " + candidates.pop()
    return session


def _positive_record_id(value: object, label: str) -> int:
    """Return one canonical positive Zenodo record id, rejecting coercions."""
    require(not isinstance(value, bool) and
            (isinstance(value, int) or (isinstance(value, str) and value.isascii() and value.isdigit())),
            f"Draft lookup {label} is not a positive integer id")
    result = int(value)
    require(result > 0, f"Draft lookup {label} is not a positive integer id")
    return result


def draft_listing_rows(payload: object) -> list[dict]:
    """Parse a complete legacy list or current Invenio search envelope.

    The current Zenodo deposit search response is an object whose records are
    in ``hits.hits`` and whose exact result count is ``hits.total``.  Retain
    support for the legacy bare-list response, but never treat a malformed or
    paginated envelope as an empty result: doing so could create a duplicate
    version draft.
    """
    if isinstance(payload, list):
        rows, total = payload, len(payload)
    else:
        require(isinstance(payload, dict), "Draft lookup is neither a list nor a search envelope")
        hits = payload.get("hits")
        links = payload.get("links")
        require(isinstance(hits, dict) and isinstance(links, dict),
                "Draft lookup search envelope lacks hits/links objects")
        rows = hits.get("hits")
        total_value = hits.get("total")
        require(isinstance(rows, list), "Draft lookup search envelope lacks hits.hits list")
        if isinstance(total_value, dict):
            require(set(total_value) == {"value", "relation"} and total_value.get("relation") == "eq",
                    "Draft lookup total is not an exact count")
            total_value = total_value.get("value")
        require(isinstance(total_value, int) and not isinstance(total_value, bool) and total_value >= 0,
                "Draft lookup total is not a nonnegative exact integer")
        total = total_value
        require(links.get("next") in (None, ""), "Draft lookup is paginated; do not create a duplicate")
    require(total == len(rows) and total < DRAFT_LOOKUP_SIZE,
            "Draft lookup incomplete; do not create a duplicate")
    normalized: list[dict] = []
    ids: set[int] = set()
    for index, row in enumerate(rows):
        require(isinstance(row, dict), f"Draft lookup row {index} is not an object")
        record_id = _positive_record_id(row.get("id"), f"row {index} id")
        _positive_record_id(row.get("conceptrecid"), f"row {index} conceptrecid")
        require(isinstance(row.get("submitted"), bool),
                f"Draft lookup row {index} lacks a boolean submitted state")
        require(record_id not in ids, "Draft lookup contains duplicate record ids")
        ids.add(record_id)
        normalized.append(row)
    return normalized


def matching_concept_draft(rows: list[dict]) -> dict | None:
    matches = [row for row in rows if row["submitted"] is False and
               _positive_record_id(row["conceptrecid"], "conceptrecid") == CONCEPT_RECORD_ID]
    require(len(matches) <= 1, "Multiple drafts in this concept; preserve them without mutation")
    return matches[0] if matches else None


def latest_public() -> tuple[dict, str]:
    record = anonymous_json(f"{BASE}/api/records/{PREVIOUS_RECORD_ID}/versions/latest")
    require(record.get("conceptdoi") == CONCEPT_DOI, "Public concept DOI mismatch")
    md = record.get("metadata", {})
    require(md.get("access_right") == "open", "Public record is not open")
    if md.get("version") == VERSION:
        require(md.get("title") == TITLE, "Target-version title mismatch")
        return record, "target_public"
    require(int(record.get("id", 0)) == PREVIOUS_RECORD_ID and md.get("version") == PREVIOUS_VERSION,
            "An unreviewed version is latest; preserve it and rebind the verified predecessor explicitly")
    return record, "predecessor_public"


def public_inventory(record: dict, expected: dict) -> dict:
    rows = record.get("files", [])
    inventory = {row["key"]: row for row in rows}
    require(len(rows) == len(inventory) and set(inventory) == set(expected), "Public file inventory mismatch")
    for name, row in inventory.items():
        require(int(row.get("size", -1)) == expected[name]["bytes"], f"Public size mismatch: {name}")
    return inventory


def verify_public(record_id: int, expected: dict) -> tuple[dict, list[dict]]:
    record = None
    for attempt in range(3):
        candidate = anonymous_json(f"{BASE}/api/records/{record_id}")
        if {row.get("key") for row in candidate.get("files", [])} == set(expected):
            record = candidate
            break
        if attempt < 2:
            time.sleep(2)
    require(record is not None, "Published inventory not visible after three bounded reads")
    require(record.get("conceptdoi") == CONCEPT_DOI and record["metadata"].get("version") == VERSION and
            record["metadata"].get("title") == TITLE and record["metadata"].get("access_right") == "open",
            "Public identity/access does not match the target")
    rows = public_inventory(record, expected)
    verified = []
    with requests.Session() as session:
        session.trust_env = False
        for name in sorted(expected):
            with request(session, "GET", rows[name]["links"]["self"], stream=True) as response:
                digest, size = hashlib.sha256(), 0
                for chunk in response.iter_content(1024 * 1024):
                    if chunk:
                        size += len(chunk)
                        digest.update(chunk)
            actual = {"bytes": size, "sha256": digest.hexdigest()}
            require(actual == expected[name], f"Anonymous byte/hash mismatch: {name}")
            verified.append({"name": name, **actual, "public_readback": True, "credential_used": False})
    return record, verified


def descriptor(draft: dict, state: str, facts: dict) -> dict:
    md = draft.get("metadata", {})
    doi = (md.get("prereserve_doi") or {}).get("doi") or md.get("doi")
    require(isinstance(doi, str) and doi.startswith("10.5281/zenodo."), "No exact reserved DOI")
    return {"schema": "ag-bridge-bgk-zenodo-reservation-v2", "status": "PASS", "state": state,
            "record_id": int(draft["id"]), "record_url": f"{BASE}/records/{int(draft['id'])}",
            "doi": doi, "concept_doi": CONCEPT_DOI, "previous_record_id": PREVIOUS_RECORD_ID,
            "previous_version": PREVIOUS_VERSION, "previous_receipt_sha256": PREVIOUS_RECEIPT_SHA256,
            "title": TITLE, "version": VERSION, "release_files": facts,
            "classical_files_preserved": sorted(predecessor_facts()[0]),
            "target_files_planned": sorted(facts) + [MIGRATION_PUBLIC_NAME],
            "original_bridge_mastery_capstone": "pending", "credentials_recorded": False}


def validate_draft(draft: dict, classical: dict, new: dict, *,
                   allow_unversioned_predecessor: bool = False) -> dict:
    require(draft.get("submitted") is False and int(draft.get("conceptrecid", 0)) == CONCEPT_RECORD_ID,
            "Refusing mutation outside the unsubmitted draft of the exact concept")
    metadata_value = draft.get("metadata", {})
    version = metadata_value.get("version")
    unversioned_predecessor = allow_unversioned_predecessor and version is None
    require(version in (PREVIOUS_VERSION, VERSION) or unversioned_predecessor,
            "Existing draft has an unreviewed version; preserve it without mutation")
    if unversioned_predecessor:
        require(isinstance(metadata_value.get("prereserve_doi"), dict),
                "Unversioned inherited draft has no reserved DOI")
    rows = draft.get("files", [])
    inventory = {row.get("filename") or row.get("key"): row for row in rows}
    allowed = set(classical) | OLD_BGK_FILES | set(new) | {MIGRATION_PUBLIC_NAME}
    require(len(rows) == len(inventory) and set(classical).issubset(inventory) and set(inventory).issubset(allowed),
            "Unrecognized draft files or absent classical baseline; no deletion permitted")
    if unversioned_predecessor:
        require(set(inventory) == set(classical) | OLD_BGK_FILES,
                "Unversioned draft is not the exact inherited predecessor inventory")
    for name in classical:
        require(int(inventory[name].get("filesize", -1)) == classical[name]["bytes"],
                f"Inherited classical size mismatch: {name}")
    return inventory


def reserve() -> dict:
    classical, old = predecessor_facts()
    manifest, _, new = release_contract()
    latest, state = latest_public()
    if state == "target_public":
        value = descriptor(latest, "already_public", new)
        write_receipt(RESERVATION, value)
        return value
    public_inventory(latest, {**classical, **old})
    with authenticated_session() as session:
        draft = None
        if RESERVATION.is_file():
            prior = load(RESERVATION)
            require(prior.get("concept_doi") == CONCEPT_DOI and prior.get("version") == VERSION and
                    prior.get("previous_record_id") == PREVIOUS_RECORD_ID, "Reservation belongs to another release")
            draft = request(session, "GET", f"{BASE}/api/deposit/depositions/{int(prior['record_id'])}").json()
        else:
            payload = request(session, "GET", f"{BASE}/api/deposit/depositions",
                              params={"status": "draft", "sort": "mostrecent",
                                      "q": f"conceptrecid:{CONCEPT_RECORD_ID}",
                                      "size": DRAFT_LOOKUP_SIZE}).json()
            summary = matching_concept_draft(draft_listing_rows(payload))
            if summary is None:
                response = request(session, "POST", f"{BASE}/api/deposit/depositions/{PREVIOUS_RECORD_ID}/actions/newversion").json()
                draft_url = response.get("links", {}).get("latest_draft")
                require(bool(draft_url), "New-version response has no latest_draft")
                draft = request(session, "GET", draft_url).json()
            else:
                draft = request(session, "GET",
                                f"{BASE}/api/deposit/depositions/{_positive_record_id(summary.get('id'), 'matched id')}").json()
        validate_draft(draft, classical, new, allow_unversioned_predecessor=True)
        draft = request(session, "PUT", draft["links"]["self"], json={"metadata": metadata(manifest)}).json()
        validate_draft(draft, classical, new)
        value = descriptor(draft, "reserved_draft", new)
        write_receipt(RESERVATION, value)
        return value


def migration_fact(reservation: dict, new: dict) -> dict:
    from jsonschema import Draft202012Validator, FormatChecker

    require(sha256_path(MIGRATION_SCHEMA) == MIGRATION_SCHEMA_SHA256, "Frozen migration schema drifted")
    receipt = load(MIGRATION_RECEIPT)
    Draft202012Validator(load(MIGRATION_SCHEMA), format_checker=FormatChecker()).validate(receipt)
    package = packager()
    package.reject_secrets({MIGRATION_RECEIPT.name: MIGRATION_RECEIPT.read_bytes()})
    source, coverage = receipt["source"], receipt["coverage"]
    require(source.get("through_unit") == coverage.get("through_unit") == 30 and
            package.bind(source["manifest"]) == ROOT / "backend/bgk-units-01-30/MANIFEST.json" and
            package.bind(source["records_jsonl"]) == ROOT / "backend/bgk-units-01-30/records.jsonl",
            "Migration does not bind the current Unit30 native backend")
    validation = receipt["validation"]
    require(validation.get("result") == "pass" and validation.get("deterministic_double_replay") is True and
            validation.get("lossless_native_reverse") is True and
            validation.get("native_reverse_sha256") == source["records_jsonl"]["sha256"] and
            receipt["transformation"].get("model_provenance") == MODEL and
            receipt.get("credentials_recorded") is False, "Migration final validation/provenance gate")
    package.bind(validation["terminology_qa_receipt"])
    artifacts = receipt["public_artifacts"]
    require(len(artifacts) == 1 and artifacts[0].get("repository") == "Zenodo" and
            artifacts[0].get("concept_doi") == CONCEPT_DOI and artifacts[0].get("doi") == reservation["doi"] and
            artifacts[0].get("publication_uri") == reservation["record_url"], "Migration reserved public identity")
    files = artifacts[0].get("files", [])
    require(len(files) == len(new) and {Path(row["path"]).name for row in files} == set(new),
            "Migration must bind exactly the nine current candidate files")
    for row in files:
        path = package.bind(row)
        require(path.parent == RELEASE and fact(path) == new[path.name], "Migration release file binding")
    return fact(MIGRATION_RECEIPT)


def publication_receipt(record: dict, verified: list[dict], manifest: dict) -> dict:
    md = record["metadata"]
    expected_metadata = metadata(manifest)
    require(md.get("creators") and md["creators"][0].get("name") == "Brenner, Holger", "Author credit changed")
    contributors = md.get("contributors", [])
    require(sum(row.get("name") == "TTP" and row.get("affiliation") == ORGANIZATION_HUB for row in contributors) == 1 and
            sum(row.get("name") == MODEL_ID for row in contributors) == 1 and
            "TTP" not in md["title"] and "TTP" not in md["description"] and MODEL in md["description"],
            "Public provenance/organization metadata mismatch")
    require(md["description"] == expected_metadata["description"], "Public scope/rights description differs")
    return {"schema": "ag-bridge-bgk-zenodo-publication-receipt-v2", "status": "PASS",
            "record": {"id": int(record["id"]), "url": f"{BASE}/records/{record['id']}",
                       "api_url": f"{BASE}/api/records/{record['id']}", "doi": md["doi"],
                       "concept_doi": CONCEPT_DOI, "previous_record_id": PREVIOUS_RECORD_ID,
                       "title": md["title"], "version": md["version"],
                       "publication_date": md["publication_date"], "published_timestamp": record.get("created")},
            "coverage": {"classical_units_complete": 30, "bgk_units_complete": 30, "bgk_units_total": 30,
                         "bgk_units_remaining": 0, "original_bridge_mastery_capstone": "pending",
                         "full_d100_lane_complete": False, **manifest["reader"],
                         "native_backend_records": manifest["backend"]["native_records"],
                         "classical_files_preserved": 8, "target_bgk_files": 10,
                         "prior_public_record_remains_accessible": True},
            "anonymous_public_byte_readback": {"verified_at": datetime.now(timezone.utc).isoformat(),
                "credential_used": False, "files_expected": 18, "files_verified": len(verified),
                "all_size_and_sha256_matches": True, "files": verified},
            "previous_receipt_sha256": PREVIOUS_RECEIPT_SHA256,
            "model_provenance": MODEL, "credentials_recorded": False}


def publish(verify_only: bool = False) -> dict:
    classical, old = predecessor_facts()
    manifest, _, new = release_contract()
    require(RESERVATION.is_file(), "Reserve the exact target version before generating its migration receipt")
    reservation = load(RESERVATION)
    require(reservation.get("concept_doi") == CONCEPT_DOI and reservation.get("version") == VERSION and
            reservation.get("previous_record_id") == PREVIOUS_RECORD_ID and
            reservation.get("release_files") == new, "Reservation identity/candidate hashes drifted")
    migration = migration_fact(reservation, new)
    expected = {**classical, **new, MIGRATION_PUBLIC_NAME: migration}
    require(len(expected) == 18 and sum(row["bytes"] for row in new.values()) + migration["bytes"] <= 500_000_000,
            "Final inventory collision/payload cap")
    latest, state = latest_public()
    if state == "target_public":
        record, verified = verify_public(int(latest["id"]), expected)
        write_receipt(PUBLICATION_RECEIPT, publication_receipt(record, verified, manifest))
        return {"status": "PASS", "action": "verified_existing_units_01_30", "record_id": int(record["id"]),
                "doi": record["metadata"]["doi"], "files_verified": len(verified)}
    require(not verify_only, "Unit30 is not the public latest version; anonymous verification made no mutation")
    public_inventory(latest, {**classical, **old})
    paths = {name: RELEASE / name for name in new}
    paths[MIGRATION_PUBLIC_NAME] = MIGRATION_RECEIPT
    with authenticated_session() as session:
        draft_id = int(reservation["record_id"])
        draft = request(session, "GET", f"{BASE}/api/deposit/depositions/{draft_id}").json()
        if draft.get("submitted") is True:
            # A prior publish may have succeeded despite an interrupted response.
            # Never create another draft or repeat the publish action here.
            require(int(draft.get("conceptrecid", 0)) == CONCEPT_RECORD_ID, "Submitted draft concept mismatch")
            published_id = int(draft.get("record_id") or draft["id"])
        else:
            inventory = validate_draft(draft, classical, {**new, MIGRATION_PUBLIC_NAME: migration})
            require(descriptor(draft, "reserved_draft", new)["doi"] == reservation["doi"], "Reserved DOI drifted")
            # Only exact superseded/new BGK names in this unsubmitted draft are
            # replaceable. Classical files and prior public records are untouched.
            for name, row in inventory.items():
                if name not in classical:
                    request(session, "DELETE", f"{BASE}/api/deposit/depositions/{draft_id}/files/{row['id']}")
            draft = request(session, "PUT", draft["links"]["self"], json={"metadata": metadata(manifest)}).json()
            bucket = draft["links"]["bucket"].rstrip("/")
            for name in sorted(paths):
                with paths[name].open("rb") as stream:
                    request(session, "PUT", f"{bucket}/{quote(name, safe='')}", data=stream)
            refreshed = request(session, "GET", draft["links"]["self"]).json()
            inventory = validate_draft(refreshed, classical, {**new, MIGRATION_PUBLIC_NAME: migration})
            require(set(inventory) == set(expected), "Pre-publication inventory differs")
            previous_rows = {row["key"]: row for row in latest["files"]}
            for name, row in inventory.items():
                require(int(row.get("filesize", -1)) == expected[name]["bytes"], f"Uploaded size mismatch: {name}")
                if name in classical:
                    require(str(row.get("checksum", "")).removeprefix("md5:") ==
                            str(previous_rows[name].get("checksum", "")).removeprefix("md5:"),
                            "Inherited classical checksum drifted")
                else:
                    expected_md5 = hashlib.md5(paths[name].read_bytes()).hexdigest()
                    require(str(row.get("checksum", "")).removeprefix("md5:") == expected_md5,
                            f"Uploaded checksum mismatch: {name}")
            published = request(session, "POST", refreshed["links"]["publish"]).json()
            published_id = int(published.get("record_id") or published["id"])
    record, verified = verify_public(published_id, expected)
    require(record["metadata"]["doi"] == reservation["doi"], "Published DOI differs from reserved migration identity")
    write_receipt(PUBLICATION_RECEIPT, publication_receipt(record, verified, manifest))
    return {"status": "PASS", "action": "published_and_anonymously_verified_units_01_30",
            "record_id": published_id, "doi": record["metadata"]["doi"], "files_verified": len(verified)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--dry-run", action="store_true", help="Offline plan only; no gate PASS claim")
    modes.add_argument("--local-preflight", action="store_true", help="Offline exact candidate/predecessor gates")
    modes.add_argument("--reserve", action="store_true", help="Reserve/reuse one new version in existing concept")
    modes.add_argument("--publish", action="store_true", help="Publish exact files and anonymously read all back")
    modes.add_argument("--verify-public", action="store_true", help="Anonymous readback only; writes sanitized receipt")
    args = parser.parse_args()
    if args.dry_run:
        result = {"status": "PLAN_ONLY", "concept_doi": CONCEPT_DOI, "previous_record_id": PREVIOUS_RECORD_ID,
                  "previous_version": PREVIOUS_VERSION, "target_version": VERSION, "network": False,
                  "credentials": False, "writes": False, "release_directory": RELEASE.relative_to(ROOT).as_posix(),
                  "migration_receipt": MIGRATION_RECEIPT.relative_to(ROOT).as_posix()}
    elif args.local_preflight:
        classical, old = predecessor_facts()
        manifest, _, new = release_contract()
        metadata(manifest)
        result = {"status": "PASS", "mode": "offline_no_credentials_no_writes", "concept_doi": CONCEPT_DOI,
                  "classical_files_preserved": len(classical), "superseded_bgk_files": len(old),
                  "new_release_files": len(new), "target_version": VERSION,
                  "migration_receipt": "required_after_reservation", "full_d100_lane_complete": False}
    elif args.reserve:
        result = reserve()
    else:
        result = publish(verify_only=args.verify_public)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
