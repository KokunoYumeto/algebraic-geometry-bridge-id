# BGK cumulative reader deterministic command contract

This contract governs a cumulative Unit 1–30 reader run. Run it only after `frontmatter-bgk-units-01-30.md` and every Unit 1–30 authority manifest, rights file, and asset closure are frozen. It does not authorize publication and does not alter the historical Unit 1–12 scripts or receipts.

## 0. Build-free tooling validation

```powershell
$laneRoot = (Resolve-Path -LiteralPath '.').Path
if ((Split-Path -Leaf $laneRoot) -ne 'algebraic-geometry-bridge-id') { throw 'Run this contract from the lane root.' }
python scripts\test_bgk_reader_tooling.py
python scripts\qa_bgk_reader_general.py --through 30 --dry-run
node scripts\measure_bgk_reader_responsive.mjs --through 30 --dry-run
```

Every dry-run is read-only, performs no build/network/CDP action, and emits one stable JSON plan.

## 1. Two separately preserved build identities

```powershell
python scripts\build_bgk_reader.py --through 30
python scripts\snapshot_bgk_reader_build.py --through 30 --output qa\BGK_UNITS_01_30_BUILD_REPLAY_A.json

python scripts\build_bgk_reader.py --through 30
python scripts\snapshot_bgk_reader_build.py --through 30 --output qa\BGK_UNITS_01_30_BUILD_REPLAY_B.json

$pdfPath = Join-Path $laneRoot 'build\reader-bgk-id\bundel-berkas-dan-kohomologi-id-units-01-30.pdf'
$pageCount = [int](python -c "from pypdf import PdfReader; print(len(PdfReader(r'$pdfPath', strict=True).pages))")

python scripts\qa_bgk_reader_general.py `
  --through 30 `
  --replay-a qa\BGK_UNITS_01_30_BUILD_REPLAY_A.json `
  --replay-b qa\BGK_UNITS_01_30_BUILD_REPLAY_B.json `
  --expected-pages $pageCount `
  --output qa\BGK_UNITS_01_30_READER_QA.json
```

The machine QA refuses a final PASS unless both identity snapshots are byte-identical, match the live build, all thirty finalized translation receipts are exact `PASS`, and the frozen expectations close all 495 exercises as 25 public plus 470 negative solutions.

## 2. Completed in-app Browser measurement and review contract

The actual Unit 1–30 run used the owner-operated in-app Browser at `http://127.0.0.1:18765/index.html`, through the Browser skill's Node REPL `js` tool, not a separately launched CDP browser. Its immutable measurement is `qa/BGK_UNITS_01_30_RESPONSIVE_MEASURED.json`; its approved, separately written final receipt is `qa/BGK_UNITS_01_30_RESPONSIVE_QA.json`, status `PASS`. All three bound captures have already been inspected by the invoking Codex. The measurement deliberately retains `PASS_MEASURED_SCREENSHOTS_PENDING_REVIEW`; that historical measurement status does not override the completed final review.

This is the recorded API/command contract, not an instruction to repeat completed work. Do not launch a browser or server, recapture, rerender, rebuild, or replace a receipt merely to follow this document. Sections 1 and 3 describe the already completed production operations; reuse their verified artifacts for the current closure.

For a separately requested future app-browser measurement, first read the Browser skill. Initialize `setupBrowserRuntime()` from the skill's absolute `scripts/browser-client.mjs` path only once; select the explicitly requested in-app Browser with `agent.browsers.get("iab")` and immediately read its full documentation with `nodeRepl.write(await iab.documentation());`. Reuse existing browser/tab bindings when available. Only the Node REPL `js` tool controls this browser; use its documented tab APIs, not an external browser automation server or a standalone browser launch.

The exact import-only adapter is `scripts/bgk_reader_iab_responsive_receipt.mjs`. With the Node REPL working directory set to the lane, its public receipt API is:

```javascript
const { pathToFileURL } = await import("node:url");
const { resolve } = await import("node:path");
const { expression, writeResponsiveReceipt } = await import(
  pathToFileURL(resolve("scripts/bgk_reader_iab_responsive_receipt.mjs")).href
);

// desktop/mobile: complete observed results of the exported read-only expression.
// observedTabId/deepAnchorPresent: actual observations from the connected tab.
// The three native JPEG captures must already exist; this call takes no captures.
const result = writeResponsiveReceipt({
  through: 30,
  desktop,
  mobile,
  screenshotPaths: {
    desktop: "qa/bgk-units-01-30-responsive-desktop.jpg",
    mobile: "qa/bgk-units-01-30-responsive-mobile.jpg",
    deep: "qa/bgk-units-01-30-responsive-deep-unit-30.jpg",
  },
  targetUrl: "http://127.0.0.1:18765/index.html",
  browserIdentity: { kind: "in-app-browser", tabId: observedTabId },
  deepAnchor: "br-bgk-2019-w30-ex05",
  deepAnchorPresent,
  machineQaPath: "qa/BGK_UNITS_01_30_READER_QA.json",
  outputPath: "qa/BGK_UNITS_01_30_RESPONSIVE_MEASURED.json",
});
nodeRepl.write(result);
```

Evaluate the exported `expression` read-only at desktop CSS 1280×720 and mobile CSS 390×844, retaining both complete returned objects. Independently observe `Boolean(document.getElementById("br-bgk-2019-w30-ex05"))`; navigate to that deep surface using the supported Browser API and preserve its native capture. The archived run records in-app tab ID `1`; a future run must supply its own observed ID rather than copy that value. The adapter validates and binds already observed data and files; it does not operate the browser, capture, crop, resample, or visually approve images, and refuses an existing output without explicit `replace: true`.

The actual captures retain native JPEG bytes and `.jpg` names. Raster size and CSS size are different observations, not an inferred rescale:

| Exact capture | Native raster | Measured CSS viewport | CSS client width |
|---|---|---|---|
| `qa/bgk-units-01-30-responsive-desktop.jpg` | 1265×712 | 1280×720 | 1265 |
| `qa/bgk-units-01-30-responsive-mobile.jpg` | 375×800 | 390×844 | 375 |
| `qa/bgk-units-01-30-responsive-deep-unit-30.jpg` | 375×800 | 390×844 | 375 |

After the invoking Codex inspected those exact three hash-bound images, this separate explicit finalizer created the final `PASS` receipt without mutating the measurement (already completed; do not rerun it for this documentation update):

```powershell
python scripts\finalize_bgk_reader_responsive.py `
  --through 30 `
  --measurement qa\BGK_UNITS_01_30_RESPONSIVE_MEASURED.json `
  --output qa\BGK_UNITS_01_30_RESPONSIVE_QA.json `
  --reviewer-model 'OpenAI Codex gpt-5.6-sol, Ultra.' `
  --approve

```

`--approve` records that the invoking model completed the explicit visual inspection. It is not a request for user confirmation or a human-dependent hold.

The historical `scripts/measure_bgk_reader_responsive.mjs` standalone CDP CLI remains an external reproducibility option with `--through`, `--reader-url`, `--cdp-endpoint`, `--machine-qa`, `--output-measured`, and `--screenshot-dir`. It is not the active app-agent route, and its `.png` capture convention must not be substituted for the actual `.jpg` evidence above. Do not start it during this closure. The `$browserExe --version` command in section 5 applies only to that external route after resolving its executable; the active route records the observed in-app `browser_identity` in its measurement receipt rather than inventing a standalone executable identity.

## 3. Exact 110-DPI raster/contact-sheet contract

```powershell
$renderDir = Join-Path $laneRoot 'qa\render-bgk-units-01-30'
New-Item -ItemType Directory -Path $renderDir -Force | Out-Null

pdftoppm -png -r 110 $pdfPath (Join-Path $renderDir 'page')

python scripts\make_bgk_reader_contact_sheets.py `
  --through 30 `
  --render-dir qa\render-bgk-units-01-30 `
  --page-count $pageCount `
  --manifest qa\render-bgk-units-01-30\BGK_UNITS_01_30_CONTACT_SHEETS.json
```

The contact tool rejects missing, duplicate, noncanonical, or extra `page-NNN.png` files and emits exact page/contact hashes.

## 4. Explicit visual receipt

The machine receipt's `surface_pages` are the actual body PDF-outline destinations for every lecture, worksheet, solution section, and media-credit section, not textual matches in the table of contents. Derive the complete required transition-page union from those frozen page numbers, then add the first and final page for full-size review:

```powershell
$machine = Get-Content -LiteralPath (Join-Path $laneRoot 'qa\BGK_UNITS_01_30_READER_QA.json') -Raw | ConvertFrom-Json
$transitionPages = (($machine.surface_pages | ForEach-Object { $_.lecture; $_.worksheet; $_.solutions; $_.media_credits }) | Sort-Object -Unique) -join ','
$fullSizePages = ((@(1, $pageCount) + ($transitionPages -split ',' | ForEach-Object { [int]$_ })) | Sort-Object -Unique) -join ','
```

Four independent Codex reviewers have inspected all 380 PDF pages via all 16 contact sheets, plus 122 distinct full-size pages including all 76 actual body-surface pages and pages 1 and 380. Their disjoint evidence packets are passed through optional, repeated `--review-packet PATH` arguments below. The invoking Codex reviewed their results and personally inspected page 1, contact sheet 201–225, and all three separately bound browser captures; this is not a claim that the invoker personally viewed every PDF page.

The writer replays each packet's exact PDF, contact-manifest, reader-QA, contact-image, and full-size page-image byte/hash bindings. It rejects non-PASS evidence, defects, coverage overlaps or gaps, missing contacts, and missing required full-size/transition pages. It independently derives the complete body-surface union from `surface_pages`, so a shorter CLI list cannot weaken that requirement. The final receipt binds the packet-file facts and attributes inspection to the delegated Codex reviewers. The invoking Codex supplies `--approve` only after reviewing those results:

```powershell
python scripts\write_bgk_reader_visual_receipt.py `
  --through 30 `
  --pdf build\reader-bgk-id\bundel-berkas-dan-kohomologi-id-units-01-30.pdf `
  --render-dir qa\render-bgk-units-01-30 `
  --page-count $pageCount `
  --build-receipt build\reader-bgk-id\BUILD_RECEIPT.json `
  --machine-qa qa\BGK_UNITS_01_30_READER_QA.json `
  --responsive-qa qa\BGK_UNITS_01_30_RESPONSIVE_QA.json `
  --contact-manifest qa\render-bgk-units-01-30\BGK_UNITS_01_30_CONTACT_SHEETS.json `
  --full-size-pages $fullSizePages `
  --transition-pages $transitionPages `
  --review-packet qa\BGK_UNITS_01_30_VISUAL_PACKET_001_100.json `
  --review-packet qa\BGK_UNITS_01_30_VISUAL_PACKET_101_200.json `
  --review-packet qa\BGK_UNITS_01_30_VISUAL_PACKET_201_300.json `
  --review-packet qa\BGK_UNITS_01_30_VISUAL_PACKET_301_380.json `
  --output qa\BGK_UNITS_01_30_VISUAL_QA.json `
  --reviewer-model 'OpenAI Codex gpt-5.6-sol, Ultra.' `
  --approve
```

Without `--review-packet`, legacy behavior is unchanged: the invoker must personally inspect every contact sheet and all listed full-size pages before `--approve`. Do not use that no-packet attribution for this delegated run, and do not regenerate existing rasters or rebuild the reader to satisfy documentation wording.

## 5. Tool identity evidence

Before the two builds, record sanitized output from these exact commands in the release evidence:

```powershell
python --version
pandoc --version
lualatex --version
node --version
pdftoppm -v
& $browserExe --version
```

The builder itself enforces `pandoc 3.9.0.2`, fixes `SOURCE_DATE_EPOCH=1787875200`, and normalizes the PDF trailer ID. The release evidence must additionally bind LuaHBTeX/MiKTeX, Python packages (`beautifulsoup4`, `pypdf`, Pillow), Node, browser, Poppler, and every new QA script/configuration hash.
