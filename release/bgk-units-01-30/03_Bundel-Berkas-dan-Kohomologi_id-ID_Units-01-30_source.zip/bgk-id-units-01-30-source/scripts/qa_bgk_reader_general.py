#!/usr/bin/env python3
"""Deterministic cumulative BGK reader QA for any frozen boundary through Unit 30."""

from __future__ import annotations

import argparse
import collections
import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_EXPECTATIONS = ROOT / "scripts" / "bgk_reader_expectations_v1.json"
MODEL = "OpenAI Codex gpt-5.6-sol, Ultra."


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def fact(path: Path) -> dict[str, object]:
    require(path.is_file() and not path.is_symlink(), f"missing regular file: {path}")
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }


def lane_path(value: str | Path) -> Path:
    raw = Path(value)
    path = raw.resolve() if raw.is_absolute() else (ROOT / raw).resolve()
    try:
        path.relative_to(ROOT)
    except ValueError as error:
        raise RuntimeError(f"path must remain inside the lane: {path}") from error
    return path


def title_for(through: int) -> str:
    if through == 1:
        return "Bundel, Berkas, dan Kohomologi - Unit 1"
    return f"Bundel, Berkas, dan Kohomologi - Unit 1-{through}"


def pdf_name_for(through: int) -> str:
    if through == 1:
        return "bundel-berkas-dan-kohomologi-id-unit-01.pdf"
    return f"bundel-berkas-dan-kohomologi-id-units-01-{through:02d}.pdf"


def load_expectations(path: Path, through: int) -> tuple[dict[str, object], list[dict[str, object]]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    require(data.get("schema") == "ag-bridge-bgk-reader-expectations-v1", "expectations schema")
    require(data.get("language") == "id-ID", "expectations language")
    units = data.get("units")
    require(isinstance(units, list), "expectations units must be a list")
    require([row.get("unit") for row in units] == list(range(1, 31)), "expectations unit sequence")
    for row in units:
        unit = int(row["unit"])
        count = int(row["exercise_count"])
        public = row.get("public_solution_ids")
        negative = int(row["negative_public_solution_count"])
        require(isinstance(public, list) and len(set(public)) == len(public), f"Unit {unit} public list")
        require(
            all(re.fullmatch(rf"{unit}\.([1-9]|[1-9][0-9]*)", str(item)) for item in public),
            f"Unit {unit} public ID format",
        )
        require(all(int(str(item).split(".")[1]) <= count for item in public), f"Unit {unit} public range")
        require(len(public) + negative == count, f"Unit {unit} solution closure")
    totals = data.get("totals", {})
    require(sum(int(row["exercise_count"]) for row in units) == totals.get("exercise_count"), "exercise total")
    require(sum(len(row["public_solution_ids"]) for row in units) == totals.get("public_solution_count"), "public total")
    require(
        sum(int(row["negative_public_solution_count"]) for row in units)
        == totals.get("negative_public_solution_count"),
        "negative total",
    )
    return data, units[:through]


def source_inventory(units: list[dict[str, object]]) -> tuple[list[dict[str, object]], list[str], list[str]]:
    rows: list[dict[str, object]] = []
    exercise_anchors: list[str] = []
    solution_anchors: list[str] = []
    for expected in units:
        unit = int(expected["unit"])
        suffix = f"{unit:02d}"
        worksheet = ROOT / "source" / "id-ID" / "bgk" / f"worksheet-{suffix}.md"
        solutions = ROOT / "source" / "id-ID" / "bgk" / f"worksheet-{suffix}-solutions.md"
        lecture = ROOT / "source" / "id-ID" / "bgk" / f"lecture-{suffix}.md"
        credits = ROOT / "source" / "id-ID" / f"media-credits-bgk-unit-{suffix}.md"
        for path in (lecture, worksheet, solutions, credits):
            require(path.is_file() and not path.is_symlink(), f"Unit {unit} source missing: {path}")
        surface_markers: dict[str, str] = {}
        for name, path in (
            ("lecture", lecture),
            ("worksheet", worksheet),
            ("solutions", solutions),
            ("media_credits", credits),
        ):
            heading = re.search(r"^# (.*?)\s+\{#[^}]+\}\s*$", path.read_text(encoding="utf-8"), re.M)
            require(heading is not None, f"Unit {unit} {name} H1 marker")
            surface_markers[name] = heading.group(1)
        worksheet_text = worksheet.read_text(encoding="utf-8")
        solution_text = solutions.read_text(encoding="utf-8")
        exercise_matches = re.findall(
            rf"^#{{2,3}} Soal {unit}\.(\d+).*?\{{#([^\s}}]+)\}}\s*$",
            worksheet_text,
            re.M,
        )
        numbers = [int(number) for number, _ in exercise_matches]
        expected_count = int(expected["exercise_count"])
        require(numbers == list(range(1, expected_count + 1)), f"Unit {unit} exercise sequence")
        observed_exercise_ids = [f"{unit}.{number}" for number in numbers]
        expected_exercise_ids = [f"{unit}.{number}" for number in range(1, expected_count + 1)]
        require(observed_exercise_ids == expected_exercise_ids, f"Unit {unit} exercise IDs")
        public_matches = re.findall(
            r"^## Solusi (?:sumber untuk )?Soal ([0-9]+\.[0-9]+).*?\{#([^\s}]+)\}\s*$",
            solution_text,
            re.M,
        )
        observed_public = [identifier for identifier, _ in public_matches]
        require(observed_public == expected["public_solution_ids"], f"Unit {unit} public solutions")
        negative_match = re.search(r"^negative_public_solution_count: (\d+)$", solution_text, re.M)
        observed_negative = (
            int(negative_match.group(1))
            if negative_match is not None
            else expected_count - len(observed_public)
        )
        require(
            observed_negative == int(expected["negative_public_solution_count"]),
            f"Unit {unit} negative solution count",
        )
        exercise_anchors.extend(anchor for _, anchor in exercise_matches)
        solution_anchors.extend(anchor for _, anchor in public_matches)
        rows.append(
            {
                "unit": unit,
                "exercise_count": expected_count,
                "exercise_ids": expected_exercise_ids,
                "public_solution_ids": observed_public,
                "negative_public_solution_count": observed_negative,
                "negative_count_source": "frontmatter" if negative_match else "audited complement",
                "surface_markers": surface_markers,
                "sources": [fact(path) for path in (lecture, worksheet, solutions, credits)],
            }
        )
    return rows, exercise_anchors, solution_anchors


def replay_fact(row: dict[str, object]) -> None:
    path = lane_path(str(row["path"]))
    require(
        path.is_file()
        and path.stat().st_size == row.get("bytes")
        and sha256(path) == row.get("sha256"),
        f"identity mismatch: {path}",
    )


def load_build_identity(path: Path, through: int) -> dict[str, object]:
    data = json.loads(path.read_text(encoding="utf-8"))
    require(data.get("schema") == "ag-bridge-bgk-build-identity-v1", f"identity schema: {path}")
    require(data.get("through_unit") == through, f"identity scope: {path}")
    artifacts = data.get("artifacts")
    require(isinstance(artifacts, list) and len(artifacts) == 5, f"identity artifact set: {path}")
    for row in artifacts:
        replay_fact(row)
    return data


def locate_pdf_surfaces(reader, inventory: list[dict[str, object]], page_texts: list[str]) -> list[dict[str, object]]:
    """Use actual PDF outline destinations, never the earlier TOC occurrences."""
    destinations: dict[str, list[int]] = {}

    def collect(entries) -> None:
        for entry in entries:
            if isinstance(entry, list):
                collect(entry)
                continue
            title = re.sub(r"\s+", " ", str(entry.title)).strip()
            page = reader.get_destination_page_number(entry) + 1
            require(1 <= page <= len(page_texts), f"PDF outline destination out of range: {title}")
            destinations.setdefault(title, []).append(page)

    collect(reader.outline)
    result = []
    previous_page = 0
    for row in inventory:
        located = {}
        for name, marker in row["surface_markers"].items():
            title = re.sub(r"\s+", " ", marker).strip()
            matches = destinations.get(title, [])
            require(len(matches) == 1, f"Unit {row['unit']} PDF outline surface not unique: {marker}")
            page = matches[0]
            page_text = page_texts[page - 1]
            # LuaLaTeX may split e.g. Parameter as Para- meter. This is a
            # text-extraction comparison only, not a PDF/source mutation.
            dehyphenated = re.sub(r"(?<=\w)-\s+(?=\w)", "", page_text)
            # Kerning can also yield "T arik" in PDF extraction. The outline
            # title remains an exact match; remove only extracted whitespace
            # for this additional on-page presence check.
            compact_title = re.sub(r"\s+", "", title)
            compact_page = re.sub(r"\s+", "", dehyphenated)
            require(title in page_text or title in dehyphenated or compact_title in compact_page,
                    f"Unit {row['unit']} PDF destination does not contain surface: {marker}")
            require(page >= previous_page, f"Unit {row['unit']} PDF surface order regressed")
            previous_page = page
            located[name] = page
        result.append({"unit": row["unit"], **located})
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--through", type=int, required=True)
    parser.add_argument("--expectations", default=str(DEFAULT_EXPECTATIONS.relative_to(ROOT)))
    parser.add_argument("--build-dir", default="build/reader-bgk-id")
    parser.add_argument("--replay-a")
    parser.add_argument("--replay-b")
    parser.add_argument("--expected-pages", type=int)
    parser.add_argument("--output")
    parser.add_argument("--replace", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    if not 1 <= args.through <= 30:
        parser.error("--through must be in 1..30")

    expectations_path = lane_path(args.expectations)
    expectations, expected_units = load_expectations(expectations_path, args.through)
    inventory, exercise_anchors, solution_anchors = source_inventory(expected_units)
    translation_qas: list[Path] = []
    translation_statuses: list[str] = []
    for unit in range(1, args.through + 1):
        path = ROOT / "qa" / f"BGK_UNIT_{unit:02d}_TRANSLATION_QA.json"
        require(path.is_file() and not path.is_symlink(), f"Unit {unit} translation QA missing")
        data = json.loads(path.read_text(encoding="utf-8"))
        require(data.get("unit") == unit, f"Unit {unit} translation QA scope")
        translation_qas.append(path)
        translation_statuses.append(str(data.get("status")))

    output = lane_path(
        args.output or f"qa/BGK_UNITS_01_{args.through:02d}_READER_QA.json"
    )
    plan = {
        "status": "PASS_DRY_RUN",
        "through_unit": args.through,
        "expectations": fact(expectations_path),
        "source_units_validated": len(inventory),
        "exercise_count": sum(row["exercise_count"] for row in inventory),
        "public_solution_count": sum(len(row["public_solution_ids"]) for row in inventory),
        "negative_public_solution_count": sum(row["negative_public_solution_count"] for row in inventory),
        "translation_qa_files_validated": len(translation_qas),
        "expected_build": {
            "directory": lane_path(args.build_dir).relative_to(ROOT).as_posix(),
            "html": "index.html",
            "pdf": pdf_name_for(args.through),
            "title": title_for(args.through),
        },
        "output": output.relative_to(ROOT).as_posix(),
    }
    if args.dry_run:
        print(json.dumps(plan, ensure_ascii=False, sort_keys=True))
        return 0

    require(args.replay_a and args.replay_b, "--replay-a and --replay-b are required")
    require(args.expected_pages and args.expected_pages > 0, "positive --expected-pages is required")
    require(all(status == "PASS" for status in translation_statuses), "all translation QA statuses must be PASS")

    complete_source_receipt = None
    if args.through == 30:
        source_qa_path = ROOT / "qa/BGK_UNITS_01_30_SOURCE_CLOSURE_QA.json"
        source_qa = json.loads(source_qa_path.read_text(encoding="utf-8"))
        require(source_qa.get("status") == "PASS" and source_qa.get("through_unit") == 30,
                "complete Unit30 source closure is not PASS")
        require(source_qa.get("source_unit_count") == 30 and source_qa.get("translation_file_count") == 90,
                "complete source closure scope")
        require((source_qa.get("exercise_count"), source_qa.get("public_solution_count"),
                 source_qa.get("negative_solution_count")) == (495, 25, 470),
                "complete source closure exercise/solution topology")
        for unit_row in source_qa["units"]:
            for binding in unit_row["artifacts"].values():
                replay_fact(binding)
            for binding in unit_row["translation_files"]:
                replay_fact(binding)
        complete_source_receipt = fact(source_qa_path)

    build = lane_path(args.build_dir)
    html_path = build / "index.html"
    pdf_path = build / pdf_name_for(args.through)
    receipt_path = build / "BUILD_RECEIPT.json"
    html_log = build / "pandoc-html.log"
    pdf_log = build / "pandoc-pdf.log"
    for path in (html_path, pdf_path, receipt_path, html_log, pdf_log):
        require(path.is_file() and not path.is_symlink(), f"reader artifact missing: {path}")
    require(html_log.stat().st_size == 0 and pdf_log.stat().st_size == 0, "Pandoc logs are not empty")

    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    require(receipt.get("schema") == "ag-bridge-bgk-build-receipt-v1", "build receipt schema")
    require(receipt.get("through_unit") == args.through, "build receipt scope")
    require(receipt.get("language") == "id-ID", "build receipt language")
    require(receipt.get("title") == title_for(args.through), "build title")
    require(receipt.get("pandoc") == "pandoc 3.9.0.2", "Pandoc identity")
    require(
        receipt.get("html_main_landmark") == "main#main-content"
        and receipt.get("html_skip_link") == "a.skip-link[href='#main-content']",
        "accessibility binding",
    )
    for row in receipt.get("inputs", []):
        replay_fact(row)
    for row in receipt.get("outputs", []):
        replay_fact(row)

    replay_a_path = lane_path(args.replay_a)
    replay_b_path = lane_path(args.replay_b)
    replay_a = load_build_identity(replay_a_path, args.through)
    replay_b = load_build_identity(replay_b_path, args.through)
    require(replay_a["artifacts"] == replay_b["artifacts"], "build replay identities differ")

    from bs4 import BeautifulSoup
    from pypdf import PdfReader

    html = html_path.read_text(encoding="utf-8")
    soup = BeautifulSoup(html, "html.parser")
    require(soup.html is not None and soup.html.get("lang") == "id-ID", "HTML language")
    require(soup.title and soup.title.get_text(strip=True) == title_for(args.through), "HTML title")
    require(len(soup.select("meta[name='viewport']")) == 1, "HTML viewport")
    require(
        soup.select_one("main#main-content") is not None
        and soup.select_one("a.skip-link[href='#main-content']") is not None,
        "HTML landmarks",
    )
    require(
        not re.search(
            r"(?:url\(\s*['\"]?https?://|@import\s+['\"]?https?://|src=['\"]https?://)",
            html,
            re.I,
        ),
        "external HTML dependency",
    )
    identifiers = [str(node.get("id")) for node in soup.find_all(id=True)]
    identifier_set = set(identifiers)
    duplicates = [key for key, count in collections.Counter(identifiers).items() if count > 1]
    require(not duplicates, f"duplicate HTML IDs: {duplicates[:5]}")
    broken = sorted(
        {
            str(link.get("href"))[1:]
            for link in soup.select("a[href^='#']")
            if str(link.get("href")) != "#" and str(link.get("href"))[1:] not in identifier_set
        }
    )
    require(not broken, f"broken internal anchors: {broken[:5]}")
    require(all(anchor in identifier_set for anchor in exercise_anchors), "exercise anchor closure")
    require(all(anchor in identifier_set for anchor in solution_anchors), "solution anchor closure")
    if args.through == 30:
        require("br-bgk-2019-glossary-01-30" in identifier_set,
                "complete reader additive terminology crosswalk absent")
    require("OpenAI Codex gpt-5.6-sol, Ultra." in html, "HTML provenance")
    require(len(soup.find_all("math")) > 0, "HTML lacks MathML")
    require(
        not soup.select("span.math, div.math") and "Could not convert TeX math" not in html,
        "raw TeX fallback",
    )

    visible = re.sub(r"\s+", " ", soup.get_text(" ", strip=True))
    for row in inventory:
        for marker in row["surface_markers"].values():
            require(marker in visible, f"Unit {row['unit']} HTML surface absent: {marker}")
    terminal = expectations.get("terminal_surface", {})
    if terminal.get("unit") == args.through:
        for marker in terminal.get("markers", []):
            require(marker in visible, f"terminal HTML surface absent: {marker}")

    reader = PdfReader(str(pdf_path), strict=True)
    require(len(reader.pages) == args.expected_pages, "PDF page-count drift")
    boxes = {
        (round(float(page.mediabox.width), 2), round(float(page.mediabox.height), 2))
        for page in reader.pages
    }
    require(boxes == {(595.28, 841.89)}, f"PDF page boxes: {boxes}")
    require(str(reader.metadata.title) == title_for(args.through), "PDF title metadata")
    require(str(reader.metadata.author) == "Holger Brenner (karya sumber)", "PDF author metadata")
    page_texts = [re.sub(r"\s+", " ", page.extract_text() or " ") for page in reader.pages]
    pdf_text = "\n".join(page_texts)
    surface_pages = locate_pdf_surfaces(reader, inventory, page_texts)
    if terminal.get("unit") == args.through:
        for marker in terminal.get("markers", []):
            require(marker in pdf_text, f"terminal PDF surface absent: {marker}")
    require(MODEL in pdf_text, "PDF provenance")

    payload = {
        "schema": "ag-bridge-bgk-cumulative-reader-qa-v2",
        "through_unit": args.through,
        "language": "id-ID",
        "status": "PASS",
        "model_provenance": MODEL,
        "expectations": fact(expectations_path),
        "build_receipt": fact(receipt_path),
        "deterministic_build_replays": [fact(replay_a_path), fact(replay_b_path)],
        "build_logs": [fact(html_log), fact(pdf_log)],
        "outputs": [fact(html_path), fact(pdf_path)],
        "pdf_pages": len(reader.pages),
        "pdf_page_boxes": [[595.28, 841.89]],
        "html_ids": len(identifiers),
        "html_duplicate_ids": 0,
        "html_broken_internal_anchors": 0,
        "mathml_nodes": len(soup.find_all("math")),
        "exercise_counts": {str(row["unit"]): row["exercise_count"] for row in inventory},
        "total_exercises": sum(row["exercise_count"] for row in inventory),
        "public_solutions": [item for row in inventory for item in row["public_solution_ids"]],
        "negative_solution_checks": sum(row["negative_public_solution_count"] for row in inventory),
        "surface_pages": surface_pages,
        "surface_page_locator": "unique PDF outline destinations, verified against visible page text; TOC matches excluded",
        "translation_qas": [fact(path) for path in translation_qas],
        "complete_source_closure_qa": complete_source_receipt,
        "checks": [
            "independently frozen exercise/public/negative solution expectations",
            "two separately recorded byte-identical build identities",
            "build input/output replay and zero-byte Pandoc logs",
            "self-contained accessible MathML HTML with closed unique anchors",
            "strict A4 PDF parse, metadata, provenance, pagination, and terminal surfaces",
        ],
    }
    if output.exists() and not args.replace:
        raise RuntimeError(f"output already exists; use --replace explicitly: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    temporary.replace(output)
    print(json.dumps({"status": "PASS", "receipt": fact(output)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
