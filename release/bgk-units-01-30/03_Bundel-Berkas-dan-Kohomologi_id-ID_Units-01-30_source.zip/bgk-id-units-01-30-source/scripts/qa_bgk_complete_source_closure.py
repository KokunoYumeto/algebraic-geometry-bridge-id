#!/usr/bin/env python3
"""Finite, read-only-source gate for all thirty BGK unit closures."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

import qa_bgk_reader_general as reader_gate

ROOT = Path(__file__).resolve().parents[1]
MODEL = "OpenAI Codex gpt-5.6-sol, Ultra."


def fact(path: Path) -> dict:
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def current_facts(value, trail=()):
    if isinstance(value, dict):
        if all(k in value for k in ("path", "bytes", "sha256")):
            yield value
        for key, child in value.items():
            if any(word in key.lower() for word in ("historical", "previous", "preserved", "before", "pre_repair", "pre_capture")):
                continue
            yield from current_facts(child, trail + (key,))
    elif isinstance(value, list):
        for child in value:
            yield from current_facts(child, trail)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="qa/BGK_UNITS_01_30_SOURCE_CLOSURE_QA.json")
    parser.add_argument("--refresh-frontmatter-facts", action="store_true")
    args = parser.parse_args()
    errors = []
    rows = []
    expected, expected_units = reader_gate.load_expectations(ROOT / "scripts/bgk_reader_expectations_v1.json", 30)
    inventory, _, _ = reader_gate.source_inventory(expected_units)
    for unit in range(1, 31):
        label = f"{unit:02d}"
        unit_dir = ROOT / f"authority/wikiversity-bgk/unit-{label}"
        paths = {
            "manifest": unit_dir / "UNIT_AUTHORITY_MANIFEST.json",
            "authority_qa": ROOT / f"qa/BGK_UNIT_{label}_AUTHORITY_QA.json",
            "translation_qa": ROOT / f"qa/BGK_UNIT_{label}_TRANSLATION_QA.json",
            "closure": ROOT / f"authority/ASSET_CLOSURE-bgk-unit-{label}.json",
            "rights": ROOT / f"authority/RIGHTS-bgk-unit-{label}.csv",
        }
        missing = [str(p.relative_to(ROOT)) for p in paths.values() if not p.is_file() or p.is_symlink()]
        if missing:
            errors.append({"unit": unit, "missing": missing})
            continue
        manifest, aq, tq, closure = (json.loads(paths[k].read_text(encoding="utf-8")) for k in ("manifest", "authority_qa", "translation_qa", "closure"))
        unit_errors = []
        if manifest.get("unit_number") != unit or aq.get("unit") != unit or tq.get("unit") != unit:
            unit_errors.append("unit_identity")
        if not str(aq.get("status", "")).startswith("PASS") or tq.get("status") != "PASS":
            unit_errors.append({"qa_status": [aq.get("status"), tq.get("status")]})
        if unit >= 13 and tq.get("model_provenance") != MODEL:
            unit_errors.append("translation_model_provenance")
        for rec in manifest["files"]:
            target = unit_dir / rec["file"]
            if not target.is_file():
                unit_errors.append({"missing_manifest_file": rec["file"]})
                continue
            got = fact(target)
            if (got["bytes"], got["sha256"]) != (rec["bytes"], rec["sha256"]):
                unit_errors.append({"manifest_file_identity": rec["file"]})
        for rec in manifest["official_pdf_witnesses"]:
            target = ROOT / rec["local_path"]
            got = fact(target)
            if (got["bytes"], got["sha256"]) != (rec["source_bytes"], rec["local_sha256"]) or hashlib.sha1(target.read_bytes()).hexdigest() != rec["mediawiki_sha1"]:
                unit_errors.append({"official_pdf_identity": rec["kind"]})
        for name in ("lecture", "worksheet"):
            cl = manifest[f"{name}_transclusion_closure"]
            if cl["captured_page_count"] != cl["requested_template_count"] or cl["missing_page_count"]:
                unit_errors.append({"transclusion_closure": name})
        authority_binding = closure["authority_manifest"]
        if any(authority_binding.get(k) != fact(paths["manifest"])[k] for k in ("path", "bytes", "sha256")):
            unit_errors.append("asset_closure_manifest_binding")
        target_paths = [ROOT / f"source/id-ID/bgk/{name}" for name in (f"lecture-{label}.md", f"worksheet-{label}.md", f"worksheet-{label}-solutions.md")]
        target_rows = [fact(p) for p in target_paths]
        qa_source_facts = list(current_facts(tq))
        for got, path in zip(target_rows, target_paths):
            matches = [r for r in qa_source_facts if r["path"].replace("\\", "/") == got["path"]]
            if not matches or not any(r["bytes"] == got["bytes"] and r["sha256"] == got["sha256"] for r in matches):
                unit_errors.append({"translation_qa_target_binding": got["path"]})
            text = path.read_text(encoding="utf-8")
            # Published solution-boundary files use source_scope_complete:
            # this means all frozen public solutions/negative results are
            # represented, not that invented solutions were supplied.
            complete = re.search(r"(?m)^translation_status: (?:complete|source_scope_complete|complete_semantic_authority_bound)\s*$", text)
            if not complete or MODEL not in text or "CC BY-SA 4.0" not in text:
                unit_errors.append({"source_metadata": got["path"]})
            if re.search(r"\b(?:TODO|TBD|PLACEHOLDER|LOREM IPSUM)\b", text, re.I):
                unit_errors.append({"placeholder": got["path"]})
        if unit_errors:
            errors.append({"unit": unit, "errors": unit_errors})
        rows.append({"unit": unit, "status": "PASS" if not unit_errors else "FAIL", "manifest_file_count": len(manifest["files"]), "artifacts": {k: fact(p) for k, p in paths.items()}, "translation_files": target_rows, "reader_media_positions": closure["reader_media_positions"]})
    result = {
        "schema": "ag-bridge-bgk-complete-source-closure-v1",
        "status": "PASS" if not errors and len(rows) == 30 else "FAIL",
        "through_unit": 30, "model_provenance": MODEL,
        "source_unit_count": len(rows), "translation_file_count": sum(len(r["translation_files"]) for r in rows),
        "exercise_count": sum(r["exercise_count"] for r in inventory),
        "public_solution_count": sum(len(r["public_solution_ids"]) for r in inventory),
        "negative_solution_count": sum(r["negative_public_solution_count"] for r in inventory),
        "units": rows, "errors": errors,
        "boundary": "Terminal source/translation closure only. Cumulative reader, backend, and publication have separate gates.",
    }
    output = ROOT / args.output
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    if result["status"] == "PASS" and args.refresh_frontmatter_facts:
        path = ROOT / "00_control/BGK_UNITS_01_30_FRONTMATTER_FACTS.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        for row in data["units"]:
            for key, old in row["evidence"].items():
                row["evidence"][key] = fact(ROOT / old["path"])
            row["evidence"]["authority_qa"] = fact(ROOT / f"qa/BGK_UNIT_{row['unit']:02d}_AUTHORITY_QA.json")
            row["evidence"]["translation_qa"] = fact(ROOT / f"qa/BGK_UNIT_{row['unit']:02d}_TRANSLATION_QA.json")
        data["claim_boundary"] = {
            "purpose": "source-derived facts for complete Units 1-30 reader",
            "translation_completeness_claim": "All 90 canonical lecture, worksheet and solution-coverage files complete; all 30 source/translation closures PASS.",
            "formal_authority_closure_claim": "PASS",
            "source_closure_receipt": fact(output),
            "note": "Cumulative reader/build/backend/publication PASS is asserted only by their separate final receipts.",
        }
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"status": result["status"], "units": len(rows), "receipt": fact(output), "errors": errors}, ensure_ascii=False))
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
