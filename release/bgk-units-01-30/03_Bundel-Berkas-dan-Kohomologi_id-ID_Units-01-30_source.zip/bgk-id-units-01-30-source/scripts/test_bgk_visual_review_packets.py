#!/usr/bin/env python3
"""Small build-free positive/negative cases for delegated visual packets."""

from __future__ import annotations

import contextlib
import copy
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import write_bgk_reader_visual_receipt as writer


class ReviewPacketTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix="bgk-visual-packet-test-")
        self.root = Path(self.temp.name)
        self.root_patch = patch.object(writer, "ROOT", self.root)
        self.root_patch.start()

        def make(name: str, data: bytes) -> dict[str, object]:
            path = self.root / name
            path.write_bytes(data)
            return writer.fact(path)

        self.pdf = make("pdf-identity.bin", b"fixed PDF identity test bytes")
        self.contact_manifest = make("contacts.json", b'{"test":"contacts"}')
        self.machine = make("machine.json", b'{"test":"machine"}')
        self.pages = [
            {**make(f"page-{n:03d}.bin", f"page-{n}".encode()), "page": n}
            for n in range(1, 5)
        ]
        self.contacts = [
            {**make("contact-1.bin", b"contact-1"), "pages": [1, 2]},
            {**make("contact-2.bin", b"contact-2"), "pages": [3, 4]},
        ]
        self.packets = []
        for index, (first, last) in enumerate(((1, 2), (3, 4))):
            original_schema = index == 0
            contacts = copy.deepcopy([self.contacts[index]])
            pages = copy.deepcopy(self.pages[first - 1:last])
            for row in contacts:
                row.update(
                    {"visually_viewed": True, "status": "PASS"}
                    if original_schema else {"viewed": "original image"}
                )
            for row in pages:
                row.update(
                    {"visually_viewed_full_size": True, "status": "PASS"}
                    if original_schema else {"viewed": "original image at native size"}
                )
            self.packets.append({
                "schema": (
                    "ag-bridge-bgk-visual-review-packet-v1" if original_schema
                    else "ag-bridge-bgk-cumulative-visual-packet-v1"
                ),
                "status": "PASS",
                "model_provenance": writer.MODEL,
                "pdf": {**self.pdf, "pages": 4},
                "contact_manifest": self.contact_manifest,
                "reader_qa": self.machine,
                "covered_pages": list(range(first, last + 1)),
                "full_size_pages": list(range(first, last + 1)),
                "required_surface_pages": [last],
                ("viewed_contact_facts" if original_schema else "viewed_contacts"): contacts,
                "viewed_page_facts": pages,
                "checks": {"inspection": "PASS"},
                "findings": [],
                "defect_count": 0,
            })

    def tearDown(self) -> None:
        self.root_patch.stop()
        self.temp.cleanup()

    def validate(self, packets=None, **overrides):
        packets = self.packets if packets is None else packets
        paths = []
        for index, packet in enumerate(packets):
            path = self.root / f"packet-{index}.json"
            path.write_text(json.dumps(packet), encoding="utf-8")
            paths.append(path)
        options = {
            "pdf_fact": self.pdf,
            "contact_manifest_fact": self.contact_manifest,
            "machine_fact": self.machine,
            "page_count": 4,
            "page_rows": self.pages,
            "contact_rows": self.contacts,
            "required_full_size_pages": [1, 4],
            "required_transition_pages": [2, 3],
        }
        options.update(overrides)
        return writer.validate_review_packets(paths, **options)

    def test_both_real_packet_schemas_form_exact_union_without_final_write(self):
        before = set(self.root.iterdir())
        result = self.validate()
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["covered_pages"], [1, 2, 3, 4])
        self.assertEqual(result["full_size_pages"], [1, 2, 3, 4])
        self.assertEqual(len(result["packet_facts"]), 2)
        self.assertEqual(result["contact_sheets"], [[1, 2], [3, 4]])
        # Only explicit test packet fixtures were created, never a final receipt.
        self.assertEqual(
            {path.name for path in set(self.root.iterdir()) - before},
            {"packet-0.json", "packet-1.json"},
        )

    def test_overlap_and_gap_rejected(self):
        with self.assertRaisesRegex(RuntimeError, "overlapping"):
            self.validate([self.packets[0], self.packets[0]])
        with self.assertRaisesRegex(RuntimeError, "gaps"):
            self.validate([self.packets[0]])

    def test_arriving_packet_original_detail_and_boolean_check_variants(self):
        packets = copy.deepcopy(self.packets)
        packet = packets[0]
        packet["pdf"]["page_count"] = packet["pdf"].pop("pages")
        packet["checks"] = {"inspection": True}
        packet["required_full_size_pages"] = packet.pop("required_surface_pages")
        for key in ("viewed_contact_facts", "viewed_page_facts"):
            for row in packet[key]:
                row.pop("visually_viewed", None)
                row.pop("visually_viewed_full_size", None)
                row.update({"viewed": True, "view_detail": "original"})
        self.assertEqual(self.validate(packets)["status"], "PASS")
        for mutation in ("failed_check", "conflicting_page_count", "thumbnail"):
            with self.subTest(mutation=mutation):
                changed = copy.deepcopy(packets)
                if mutation == "failed_check":
                    changed[0]["checks"]["inspection"] = False
                elif mutation == "conflicting_page_count":
                    changed[0]["pdf"]["pages"] = 3
                else:
                    changed[0]["viewed_page_facts"][0]["view_detail"] = "thumbnail"
                with self.assertRaises(RuntimeError):
                    self.validate(changed)

    def test_nonpass_defects_and_wrong_provenance_rejected(self):
        for field, value in (("status", "PENDING"), ("defect_count", 1),
                             ("model_provenance", "unknown reviewer")):
            with self.subTest(field=field):
                packets = copy.deepcopy(self.packets)
                packets[0][field] = value
                with self.assertRaises(RuntimeError):
                    self.validate(packets)

    def test_exact_pdf_manifest_and_page_hash_bindings_required(self):
        for field in ("pdf", "contact_manifest", "reader_qa"):
            with self.subTest(field=field):
                packets = copy.deepcopy(self.packets)
                packets[0][field]["sha256"] = "0" * 64
                with self.assertRaisesRegex(RuntimeError, "binding"):
                    self.validate(packets)
        packets = copy.deepcopy(self.packets)
        packets[0]["viewed_page_facts"][0]["sha256"] = "0" * 64
        with self.assertRaisesRegex(RuntimeError, "page identity"):
            self.validate(packets)

    def test_contact_drift_and_incomplete_full_size_fact_list_rejected(self):
        packets = copy.deepcopy(self.packets)
        packets[0]["viewed_contact_facts"][0]["pages"] = [1, 1]
        with self.assertRaisesRegex(RuntimeError, "page-range drift"):
            self.validate(packets)
        packets = copy.deepcopy(self.packets)
        packets[0]["viewed_page_facts"].pop()
        with self.assertRaisesRegex(RuntimeError, "full-size facts"):
            self.validate(packets)

    def test_missing_required_transition_and_first_last_page_rejected(self):
        for missing in (1, 3, 4):
            with self.subTest(missing=missing):
                packets = copy.deepcopy(self.packets)
                packet = packets[0 if missing <= 2 else 1]
                packet["full_size_pages"].remove(missing)
                packet["viewed_page_facts"] = [r for r in packet["viewed_page_facts"] if r["page"] != missing]
                packet.pop("required_surface_pages")
                with self.assertRaisesRegex(RuntimeError, "required full-size/transition"):
                    self.validate(packets)

    def test_explicit_view_evidence_is_required(self):
        packets = copy.deepcopy(self.packets)
        packets[0]["viewed_contact_facts"][0]["visually_viewed"] = False
        with self.assertRaisesRegex(RuntimeError, "visual-view evidence"):
            self.validate(packets)
        packets = copy.deepcopy(self.packets)
        packets[1]["viewed_page_facts"][0]["viewed"] = "not inspected"
        with self.assertRaisesRegex(RuntimeError, "full-size visual-view"):
            self.validate(packets)

    def test_machine_transition_pages_are_derived_not_trusted_from_cli(self):
        machine = {"surface_pages": [
            {"unit": 1, "lecture": 1, "worksheet": 2, "solutions": 3, "media_credits": 4},
        ]}
        self.assertEqual(writer.required_surface_pages(machine, 1), [1, 2, 3, 4])
        with self.assertRaisesRegex(RuntimeError, "surface-page inventory"):
            writer.required_surface_pages(machine, 2)

    def test_legacy_and_repeated_packet_dry_run_do_not_write(self):
        base = [
            "visual-writer", "--through", "1", "--pdf", "missing.pdf",
            "--render-dir", "missing-render", "--page-count", "4",
            "--build-receipt", "missing-build.json", "--machine-qa", "missing-machine.json",
            "--responsive-qa", "missing-responsive.json", "--contact-manifest", "missing-contacts.json",
            "--output", "must-not-exist.json", "--dry-run",
        ]
        for extra in ([], ["--review-packet", "a.json", "--review-packet", "b.json"]):
            with self.subTest(extra=extra):
                stream = io.StringIO()
                with patch("sys.argv", base + extra), contextlib.redirect_stdout(stream):
                    self.assertEqual(writer.main(), 0)
                payload = json.loads(stream.getvalue())
                self.assertEqual(payload["required_explicit_flag"], "--approve")
                self.assertEqual("review_packets" in payload, bool(extra))
                if extra:
                    self.assertEqual(payload["review_packets"], ["a.json", "b.json"])
                self.assertFalse((self.root / "must-not-exist.json").exists())


if __name__ == "__main__":
    unittest.main()
