#!/usr/bin/env python3
"""Package the exact, fully verified BGK Units 1--30 reader boundary.

--dry-run is a read-only plan; --verify-only replays all existing bindings
without writing. Only --build writes the nine deterministic release files.
This is a complete BGK volume, not completion of the original bridge/capstone.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import re
import zipfile
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "release/bgk-units-01-30"
UNITS = tuple(range(1, 31))
MODEL = "OpenAI Codex gpt-5.6-sol, Ultra."
TITLE = "Bundel, Berkas, dan Kohomologi - Unit 1-30, Bahasa Indonesia"
ZIP_TIME = (2026, 8, 31, 0, 0, 0)
MAX_RELEASE_BYTES = 500_000_000
PDF_NAME = "01_Bundel-Berkas-dan-Kohomologi_id-ID_Units-01-30.pdf"
HTML_NAME = "02_Bundel-Berkas-dan-Kohomologi_id-ID_Units-01-30.html"
SOURCE_ZIP_NAME = "03_Bundel-Berkas-dan-Kohomologi_id-ID_Units-01-30_source.zip"
BACKEND_ZIP_NAME = "04_Bundel-Berkas-dan-Kohomologi_id-ID_Units-01-30_native-backend.zip"
LICENSE_NAME = "05_LICENSE_AND_COMPONENT_RIGHTS.md"
README_NAME = "06_README.md"
MANIFEST_NAME = "07_RELEASE_MANIFEST.json"
CHECKSUMS_NAME = "08_SHA256SUMS.txt"
QA_NAME = "09_RELEASE_CANDIDATE_QA.json"
FILES = (PDF_NAME, HTML_NAME, SOURCE_ZIP_NAME, BACKEND_ZIP_NAME, LICENSE_NAME,
         README_NAME, MANIFEST_NAME, CHECKSUMS_NAME, QA_NAME)
PDF = ROOT / "build/reader-bgk-id/bundel-berkas-dan-kohomologi-id-units-01-30.pdf"
HTML = ROOT / "build/reader-bgk-id/index.html"
BUILD = ROOT / "build/reader-bgk-id/BUILD_RECEIPT.json"
BACKEND = ROOT / "backend/bgk-units-01-30"
EXPECTATIONS = ROOT / "scripts/bgk_reader_expectations_v1.json"
GATES = {
    "reader_qa": ROOT / "qa/BGK_UNITS_01_30_READER_QA.json",
    "visual_qa": ROOT / "qa/BGK_UNITS_01_30_VISUAL_QA.json",
    "responsive_qa": ROOT / "qa/BGK_UNITS_01_30_RESPONSIVE_QA.json",
    "backend_qa": ROOT / "qa/BGK_UNITS_01_30_BACKEND_QA.json",
    "common_adapter_qa": ROOT / "qa/BGK_UNITS_01_30_COMMON_ADAPTER_PREFLIGHT_QA.json",
}
SCRIPTS = (
    "build_bgk_reader.py", "snapshot_bgk_reader_build.py", "qa_bgk_reader_general.py",
    "make_bgk_reader_contact_sheets.py", "measure_bgk_reader_responsive.mjs",
    "finalize_bgk_reader_responsive.py", "write_bgk_reader_visual_receipt.py",
    "test_bgk_reader_tooling.py", "test_bgk_media_fragment_compatibility.py",
    "bgk_reader_expectations_v1.json", "BGK_READER_QA_COMMAND_CONTRACT.md",
    "qa_bgk_complete_source_closure.py", "test_bgk_pdf_surface_locations.py",
    "bgk_reader_math_serialization.py", "bgk_reader_math_serialization_v1.json",
    "test_bgk_reader_math_serialization.py", "bgk_reader_iab_responsive_receipt.mjs",
    "test_bgk_reader_iab_responsive_receipt.mjs",
    "test_bgk_visual_review_packets.py", "test_bgk_zenodo_read_redirects.py",
    "package_bgk_units_01_30_release.py", "publish_bgk_units_01_30_zenodo.py",
)
BACKEND_SCRIPTS = (
    "export_backend_bgk_units_01_30.py", "qa_backend_bgk_units_01_30.py",
    "test_bgk_complete30_baseline_replay.py",
    "generate_common_backend_v1_receipts.py", "qa_common_backend_bgk_units_01_30.py",
)
LEGACY_TRANSLATION_QA_PINS = {
    1: "c1b815046172ebe42c07d3e1780c1ea4ccc9b510bb5da5430f90c1445fc9612a",
    2: "285b29c9b4d9ebd938b1106f5b84e2fd6ad3509edbad79f66ebe10d29b42ffee",
    3: "8bde479b506421bddcdab21c9c0e3fb1c2027fc27d029dce87258cb29e30e6f0",
    4: "f06586dbb166c7d305fbf29c77bd5831d4f119057296789a0ee9c0f1871b5817",
    5: "95735e6853026cd7c6a4eea0ccd9d53dfdd22d25cea017ae3297cc9c35668f68",
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def rel(path: Path) -> str:
    return path.resolve().relative_to(ROOT).as_posix()


def local(value: str) -> Path:
    require(isinstance(value, str) and bool(value) and "\\" not in value,
            "Expected a nonempty POSIX lane-relative path")
    candidate = Path(value)
    require(not candidate.is_absolute() and not candidate.drive and
            all(part not in (".", "..") for part in candidate.parts), "Unsafe binding path")
    path = ROOT / candidate
    path.resolve().relative_to(ROOT)
    require(not any(p.is_symlink() for p in (path, *path.parents) if p != ROOT.parent),
            f"Symlink in binding: {value}")
    return path


def data(path: Path) -> bytes:
    require(path.is_file() and not path.is_symlink(), f"Missing regular file: {rel(path)}")
    return path.read_bytes()


def sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def fact(path: Path, payload: bytes | None = None) -> dict[str, Any]:
    value = data(path) if payload is None else payload
    return {"path": rel(path), "bytes": len(value), "sha256": sha256(value)}


def bind(row: dict[str, Any]) -> Path:
    require(isinstance(row, dict), "Missing artifact binding")
    path = local(row.get("path", ""))
    require(fact(path) == {key: row.get(key) for key in ("path", "bytes", "sha256")},
            f"Artifact drifted: {rel(path)}")
    return path


def load(path: Path) -> dict[str, Any]:
    value = json.loads(data(path))
    require(isinstance(value, dict), f"Expected object: {rel(path)}")
    return value


def canonical(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def verify_boundary() -> dict[str, Any]:
    build = load(BUILD)
    receipts = {name: load(path) for name, path in GATES.items()}
    for name, value in receipts.items():
        require(value.get("status") == "PASS" and value.get("model_provenance") == MODEL,
                f"Final PASS/model gate absent: {name}")
        if name != "common_adapter_qa":
            require(value.get("through_unit") == 30, f"Wrong boundary: {name}")
    require(build.get("through_unit") == 30 and build.get("language") == "id-ID" and
            build.get("schema") == "ag-bridge-bgk-build-receipt-v1", "Build boundary drifted")
    require(build.get("inputs") and build.get("outputs"), "Build has no input/output closure")
    for row in build["inputs"] + build["outputs"]:
        bind(row)
    serialization = build.get("math_serialization", {})
    require(serialization.get("shared_html_pdf_serialization") is True and
            serialization.get("diagram_count") == 9 and
            serialization.get("set_separator_count") == 1 and
            serialization.get("control_sequence_backslash_correction_count") == 1,
            "Complete reader math serialization closure is absent")
    bind(serialization["renderer"])
    bind(serialization["exact_input_output_contract"])
    for row in serialization["records"]:
        if row.get("authority"):
            bind(row["authority"])
    require({rel(PDF), rel(HTML)}.issubset({row["path"] for row in build["outputs"]}),
            "Build does not bind the current PDF/HTML")
    reader = receipts["reader_qa"]
    require(bind(reader["build_receipt"]) == BUILD and bind(reader["expectations"]) == EXPECTATIONS,
            "Reader QA binds another build/expectation")
    require({row["path"] for row in reader["outputs"]} == {rel(PDF), rel(HTML)}, "Reader output set")
    for row in reader["outputs"] + reader["build_logs"] + reader["translation_qas"]:
        bind(row)
    expected = load(EXPECTATIONS)
    require(expected["scope"] == {"first_unit": 1, "last_unit": 30} and
            expected["totals"] == {"exercise_count": 495, "public_solution_count": 25,
                                    "negative_public_solution_count": 470}, "Frozen corpus totals drifted")
    require(reader["total_exercises"] == 495 and len(reader["public_solutions"]) == 25 and
            reader["negative_solution_checks"] == 470 and int(reader["pdf_pages"]) > 0,
            "Reader coverage mismatch")
    require(reader["exercise_counts"] == {str(row["unit"]): row["exercise_count"] for row in expected["units"]}
            and reader["public_solutions"] == [s for row in expected["units"] for s in row["public_solution_ids"]],
            "Reader per-unit exercise/solution identity mismatch")
    require({row["unit"] for row in reader["surface_pages"]} == set(UNITS), "Missing reader unit surfaces")
    replays = [load(bind(row)) for row in reader["deterministic_build_replays"]]
    require(len(replays) == 2 and replays[0] == replays[1] and
            replays[0].get("through_unit") == 30, "Two exact build replays absent")
    for row in replays[0]["artifacts"]:
        bind(row)
    require(reader["html_duplicate_ids"] == reader["html_broken_internal_anchors"] == 0 and
            reader["mathml_nodes"] > 0, "HTML closure gate")
    translations = {rel(ROOT / f"qa/BGK_UNIT_{u:02d}_TRANSLATION_QA.json") for u in UNITS}
    require({row["path"] for row in reader["translation_qas"]} == translations, "Translation QA set incomplete")
    for unit in UNITS:
        authority = load(ROOT / f"qa/BGK_UNIT_{unit:02d}_AUTHORITY_QA.json")
        translation = load(ROOT / f"qa/BGK_UNIT_{unit:02d}_TRANSLATION_QA.json")
        authority_status = str(authority.get("status"))
        require(authority.get("unit") == unit and
                re.fullmatch(r"PASS(?:_[A-Z0-9_]+)?", authority_status) is not None and
                not any(marker in authority_status for marker in
                        ("PENDING", "INCOMPLETE", "PREFLIGHT", "DRY_RUN", "STAGED", "WAITING")),
                f"Unit {unit} authority not final PASS")
        require(translation.get("unit") == unit and translation.get("status") == "PASS" and
                translation.get("schema") == "ag-bridge-bgk-unit-translation-qa-v1" and
                translation.get("language") == "id-ID", f"Unit {unit} translation not final PASS")
        if unit in LEGACY_TRANSLATION_QA_PINS:
            # Units 1--5 predate the model_provenance field. Preserve those
            # immutable accepted receipts rather than rewriting history; all
            # current reader/backend/release surfaces carry the exact model.
            require(translation.get("model_provenance") is None and
                    sha256(data(ROOT / f"qa/BGK_UNIT_{unit:02d}_TRANSLATION_QA.json")) ==
                    LEGACY_TRANSLATION_QA_PINS[unit],
                    f"Unit {unit} legacy translation receipt identity drifted")
        else:
            require(translation.get("model_provenance") == MODEL,
                    f"Unit {unit} translation provenance mismatch")

    responsive = receipts["responsive_qa"]
    measurement = load(bind(responsive["measurement_receipt"]))
    require(measurement.get("through_unit") == 30 and
            measurement.get("status") == "PASS_MEASURED_SCREENSHOTS_PENDING_REVIEW",
            "Responsive measurement identity")
    require(bind(measurement["html"]) == HTML and bind(measurement["reader_machine_qa"]) == GATES["reader_qa"],
            "Responsive measurement binds other reader")
    for key in ("desktop_centered_and_page_filling", "mobile_reflow_without_document_overflow",
                "no_unprotected_content_outside_viewport", "skip_link_landmark_alt_id_and_anchor_closure",
                "deep_surface_captured"):
        require(measurement["checks"].get(key) is True, f"Responsive measurement: {key}")
    review = responsive["review"]
    require(review.get("decision") == "PASS" and review.get("reviewer_model") == MODEL and
            review["checks"].get("visible_clipping_overlap_or_broken_glyph_observed") is False,
            "Responsive visible defect/review gate")
    require(len(responsive["screenshots"]) == 3, "Responsive screenshot set")
    for row in responsive["screenshots"]:
        bind(row)
    visual = receipts["visual_qa"]
    require(bind(visual["pdf"]) == PDF and visual["pdf"]["pages_rendered"] == reader["pdf_pages"] and
            visual["defect_counts"]["total"] == 0 and visual["review"]["decision"] == "PASS" and
            visual["review"]["reviewer_model"] == MODEL, "Visual closure gate")
    for name, path in (("bound_build_receipt", BUILD), ("bound_machine_qa", GATES["reader_qa"]),
                       ("bound_responsive_qa", GATES["responsive_qa"])):
        require(bind(visual[name]) == path, f"Visual binding: {name}")
    bind(visual["bound_contact_manifest"])
    require(len(visual["page_rasters"]) == reader["pdf_pages"], "Visual raster page closure")
    for row in visual["page_rasters"] + visual["contact_sheets"]:
        bind(row)

    manifest = load(BACKEND / "MANIFEST.json")
    require(manifest.get("through_unit") == 30 and manifest.get("model_provenance") == MODEL and
            manifest.get("exercise_count") == 495 and manifest.get("public_solution_count") == 25 and
            int(manifest.get("record_count", 0)) > 0, "Native backend scope")
    for row in manifest["files"] + manifest["source_bindings"]:
        bind(row)
    native = receipts["backend_qa"]
    require(bind(native["backend"]["manifest"]) == BACKEND / "MANIFEST.json" and
            bind(native["backend"]["records"]) == BACKEND / "records.jsonl" and
            native["backend"]["record_count"] == manifest["record_count"], "Native QA binding")
    require(native["deterministic_replay"].get("runs") == 2 and
            native["deterministic_replay"].get("all_in_memory_output_bytes_identical") is True and
            native["deterministic_replay"].get("manifest_object_identical") is True, "Native replay gate")
    for row in native["final_qa_evidence"] + native["backend"]["files"]:
        bind(row)
    common = receipts["common_adapter_qa"]
    require(common.get("scope") == "BGK Units 1--30 cumulative native backend" and
            bind(common["native_backend"]["manifest"]) == BACKEND / "MANIFEST.json" and
            bind(common["native_backend"]["records_file"]) == BACKEND / "records.jsonl" and
            bind(common["native_backend"]["native_qa"]) == GATES["backend_qa"], "Common adapter exact scope")
    projection = common["common_projection"]
    require(projection.get("native_records") == manifest["record_count"] and
            projection.get("lossless_reverse_sha256") == fact(BACKEND / "records.jsonl")["sha256"] and
            projection.get("double_preflight_stdout_identical") is True, "Common lossless replay gate")
    for row in common["contract"] + common["final_qa_evidence"]:
        bind(row)
    for row in (native["driver"], native["exporter"], common["preflight_driver"],
                common["exporter"], common["adapter"]):
        bind(row)
    return {"build": build, "reader": reader, "native_manifest": manifest, "receipts": receipts}


def source_inventory(boundary: dict[str, Any]) -> dict[str, bytes]:
    # Use every actual build input, not an assumed assets-directory spelling.
    paths = {bind(row) for row in boundary["build"]["inputs"]}
    paths.update({BUILD, *GATES.values(), ROOT / "00_control/TERMINOLOGY.csv", ROOT / "00_control/CORRECTIONS.csv"})
    paths.add(bind(boundary["reader"]["complete_source_closure_qa"]))
    serialization = boundary["build"]["math_serialization"]
    paths.update((bind(serialization["renderer"]), bind(serialization["exact_input_output_contract"])))
    paths.update(bind(row["authority"]) for row in serialization["records"] if row.get("authority"))
    paths.update(ROOT / "scripts" / name for name in SCRIPTS)
    # Additive terminology/correction intake must not overwrite the immutable
    # Units 1--12 ledgers. Include the separate current files when admitted.
    for name in (
        "source/id-ID/bgk/glossary-bgk-units-01-30.md",
        "00_control/BGK_UNITS_13_30_TERMINOLOGY.csv",
        "00_control/BGK_UNITS_13_30_GLOSSARY_INTAKE.md",
        "00_control/BGK_UNITS_13_30_CORRECTIONS.csv",
        "00_control/BGK_UNITS_13_30_CORRECTIONS_INTAKE.md",
    ):
        path = local(name)
        if path.exists():
            paths.add(path)
    for unit in UNITS:
        s = f"{unit:02d}"
        paths.update({
            ROOT / f"authority/wikiversity-bgk/unit-{s}/ORDERED_EXERCISE_MAP.json",
            ROOT / f"authority/BGK_UNIT_{s}_AUTHORITY_FREEZE.md",
            ROOT / f"qa/BGK_UNIT_{s}_AUTHORITY_QA.json", ROOT / f"qa/BGK_UNIT_{s}_TRANSLATION_QA.json",
        })
    result = {rel(path): data(path) for path in sorted(paths)}
    result["REPRODUCE_READER.md"] = (
        "# Reader reproduction and provenance boundary\n\n"
        "Extract the source ZIP into a directory and run `python scripts/build_bgk_reader.py --through 30` "
        "from its root. All build-affecting source/manifest/rights/media inputs are included, at their exact "
        "lane-relative paths. Follow scripts/BGK_READER_QA_COMMAND_CONTRACT.md with the recorded tool versions "
        "to reproduce and verify the reader. The public PDF/HTML are separately supplied; copy them into their "
        "build/reader-bgk-id paths when replaying published bindings without rebuilding.\n\n"
        "This compact reader/source package is not a dump of raw MediaWiki/XML/API captures or official PDFs. "
        "Their exact identities/URLs/revisions remain in the authority manifests. Full independent source-" 
        "authority and append-only backend re-export requires those frozen witnesses and the manifest-bound "
        "immutable Units 1-12/native/classical collision baselines. They are not falsely claimed to be "
        "bundled here. The complete current native backend is supplied as a separate resumable archive.\n"
    ).encode("utf-8")
    return result


def backend_inventory(boundary: dict[str, Any]) -> dict[str, bytes]:
    paths = {bind(row) for row in boundary["native_manifest"]["files"]}
    require(all(path.parent == BACKEND for path in paths), "Backend manifest escapes its directory")
    paths.add(BACKEND / "MANIFEST.json")
    paths.update(ROOT / "scripts" / name for name in BACKEND_SCRIPTS)
    paths.update(bind(row) for row in boundary["receipts"]["common_adapter_qa"]["contract"])
    paths.update((GATES["backend_qa"], GATES["common_adapter_qa"]))
    return {rel(path): data(path) for path in sorted(paths)}


def license_text() -> str:
    rows = []
    for unit in UNITS:
        path = ROOT / f"authority/RIGHTS-bgk-unit-{unit:02d}.csv"
        for item in csv.DictReader(io.StringIO(data(path).decode("utf-8-sig"))):
            rows.append(f"- Unit {unit}, {item['resource_title']}: {item.get('artist', '')}; "
                        f"{item.get('license_short', '')}; {item.get('description_url', '')}.")
    return """# License and component rights

Holger Brenner is the author of *Bündel, Garben und Kohomologie (Osnabrück
2019-2020)* on German Wikiversity. The frozen semantic text and this independent
Indonesian translation/re-typesetting are CC BY-SA 4.0:
https://creativecommons.org/licenses/by-sa/4.0/. Attribute Holger Brenner,
indicate the 2026 translation and typesetting changes, retain the license link,
and satisfy ShareAlike. Backend text adaptations follow the same terms.

This is not an official edition or an endorsement by the author, University of
Osnabrück, Wikiversity, Wikimedia Foundation, OpenAI, or another upstream party.

Official PDF witnesses are identified but not included in this compact package.
Their visible notices and current Commons metadata are separate rights surfaces;
the per-unit frozen manifests preserve both without a blanket relicensing claim.
Some official PDFs visibly retain CC BY-SA 3.0 notices while Commons records
CC BY-SA 4.0. No blanket package license overrides component rights.

## Reader media

The exact per-unit rights CSVs, asset closures, and translated media credits are
included. Their original notices, attribution, and selected-license evidence
remain controlling. Static PDF companions preserve the animated HTML originals.
Unit 8 retains its explicit missing-source-media disclosure.

""" + "\n".join(rows) + """

## Repository-authored code

Build/export/QA/packaging code is MIT unless a file states otherwise; MIT does
not relicense course/translated text, backend content, witnesses, or media.

Copyright (c) 2026 Indonesian-edition contributors

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions: The above copyright notice and this
permission notice shall be included in all copies or substantial portions of
the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""


def archive(entries: dict[str, bytes], prefix: str) -> tuple[bytes, dict[str, Any]]:
    rows = [{"path": name, "bytes": len(value), "sha256": sha256(value)} for name, value in sorted(entries.items())]
    wrapped = {f"{prefix}/{name}": value for name, value in entries.items()}
    wrapped[f"{prefix}/INVENTORY.json"] = canonical({"schema": "ag-bridge-compact-archive-v1", "files": rows})
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name, value in sorted(wrapped.items()):
            require(not name.startswith("/") and ".." not in Path(name).parts, "Unsafe ZIP entry")
            info = zipfile.ZipInfo(name, ZIP_TIME)
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            zipped.writestr(info, value, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    payload = stream.getvalue()
    with zipfile.ZipFile(io.BytesIO(payload)) as zipped:
        require(zipped.testzip() is None and set(zipped.namelist()) == set(wrapped), "ZIP CRC/inventory failure")
        require(all(zipped.read(name) == value for name, value in wrapped.items()), "ZIP entry mismatch")
    return payload, {"entry_count": len(wrapped), "uncompressed_bytes": sum(map(len, wrapped.values())),
                     "content_fingerprint": sha256(canonical(rows))}


SECRET_PATTERNS = {
    "private_key": re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "github_token": re.compile(rb"(?:gh[pousr]_|github_pat_)[A-Za-z0-9_]{20,}"),
    "bearer": re.compile(rb"(?i)authorization\s*:\s*bearer\s+[A-Za-z0-9._~-]{20,}"),
    "assigned_secret": re.compile(rb"(?i)(?:access[_-]?token|api[_-]?key|password)\s*[:=]\s*[\"']?[A-Za-z0-9._~-]{16,}"),
}


def reject_secrets(entries: dict[str, bytes]) -> None:
    suffixes = {".css", ".csv", ".html", ".json", ".jsonl", ".md", ".mjs", ".py", ".tex", ".txt"}
    personal_name = Path.home().name.encode("utf-8")
    for name, value in entries.items():
        if Path(name).suffix.lower() in suffixes:
            for label, pattern in SECRET_PATTERNS.items():
                require(not pattern.search(value), f"Credential-like pattern ({label}) in {name}")
            if len(personal_name) >= 3:
                require(not re.search(rb"(?i)(?<![A-Za-z])" + re.escape(personal_name) + rb"(?![A-Za-z])", value),
                        f"Personal user identifier in candidate text: {name}")


def build_once() -> dict[str, bytes]:
    boundary = verify_boundary()
    sources = source_inventory(boundary)
    backend = backend_inventory(boundary)
    license_bytes = license_text().encode("utf-8")
    sources["LICENSE_AND_COMPONENT_RIGHTS.md"] = license_bytes
    backend["LICENSE_AND_COMPONENT_RIGHTS.md"] = license_bytes
    reject_secrets(sources)
    reject_secrets(backend)
    source_zip, source_evidence = archive(sources, "bgk-id-units-01-30-source")
    backend_zip, backend_evidence = archive(backend, "bgk-id-units-01-30-native-backend")
    pages = boundary["reader"]["pdf_pages"]
    records = boundary["native_manifest"]["record_count"]
    readme = f"""# {TITLE}

Complete Indonesian (`id-ID`) BGK course: all 30 lectures, 30 worksheets,
495 exercises, and all 25 frozen public source solutions. The remaining 470
solutions are absent in the source; the reader discloses that absence and does
not invent them. Start with `{PDF_NAME}` ({pages} A4 pages), or use the
self-contained responsive/accessible MathML HTML `{HTML_NAME}`.

The separate classical *Kurva Aljabar* volume is already complete and remains
unchanged in the existing Zenodo lineage. Both source courses are complete;
the finite original connective schemes/cohomology bridge and mastery/capstone
are still pending. This release does not claim the entire D100 lane is complete.

The source ZIP contains every reader-build input, compact authority/rights
manifests, and QA evidence. The native-backend ZIP has {records:,} records and
an additive lossless common-backend adapter. Consult REPRODUCE_READER.md inside
the source ZIP for the exact included/external reproduction boundaries.
Raw API/XML dumps, official witness PDFs, caches, and duplicate renders are
not uploaded. `{LICENSE_NAME}` preserves CC BY-SA 4.0 text/translation terms
and the exact per-component media rights; it is not a blanket package license.

Source: Holger Brenner, *Bündel, Garben und Kohomologie (Osnabrück 2019-2020)*,
German Wikiversity. Provenance: {MODEL} Independent, non-endorsed edition.
""".encode("utf-8")
    payload = {PDF_NAME: data(PDF), HTML_NAME: data(HTML), SOURCE_ZIP_NAME: source_zip,
               BACKEND_ZIP_NAME: backend_zip, LICENSE_NAME: license_bytes, README_NAME: readme}
    reject_secrets(payload)
    require(all(b"TTP" not in payload[name] and b"Translation and Transcription Project" not in payload[name]
                for name in (LICENSE_NAME, README_NAME)), "Umbrella label in visible release prose")
    gate_facts = {name: fact(path) for name, path in GATES.items()}
    manifest = canonical({
        "schema": "ag-bridge-bgk-release-manifest-v2", "title": TITLE, "language": "id-ID",
        "status": "complete_bgk_course_original_bridge_pending", "source_course_units": 30,
        "included_units": list(UNITS), "included_unit_count": 30, "remaining_unit_count": 0,
        "full_d100_lane_complete": False, "original_bridge_mastery_capstone": "pending",
        "reader": {"primary_file": PDF_NAME, "html_file": HTML_NAME, "pdf_pages": pages,
                   "exercises": 495, "public_source_solutions": 25, "documented_absent_source_solutions": 470},
        "backend": {"native_records": records, "native_archive": BACKEND_ZIP_NAME,
                    "common_backend_preflight": "PASS", "final_migration_receipt": "separate reserved-DOI-bound asset"},
        "license": "CC BY-SA 4.0 course text/translation; component media rights preserved",
        "model_provenance": MODEL, "exact_gate_hashes": gate_facts,
        "build_receipt": fact(BUILD), "native_manifest": fact(BACKEND / "MANIFEST.json"),
        "source_archive": source_evidence, "backend_archive": backend_evidence,
        "files": [{"path": name, "bytes": len(value), "sha256": sha256(value)} for name, value in sorted(payload.items())],
    })
    checksums = "".join(f"{sha256(value)}  {name}\n" for name, value in sorted({**payload, MANIFEST_NAME: manifest}.items())).encode("ascii")
    qa = canonical({
        "schema": "ag-bridge-bgk-release-candidate-qa-v2", "status": "PASS", "through_unit": 30,
        "model_provenance": MODEL, "scope_truth": {"bgk_units_complete": 30, "bgk_units_total": 30,
          "bgk_units_remaining": 0, "original_bridge_mastery_capstone": "pending", "full_d100_lane_complete": False},
        "reader_first": {"lexicographically_first_file": PDF_NAME, "pdf_pages": pages},
        "exact_gate_hashes": gate_facts, "source_archive": source_evidence, "backend_archive": backend_evidence,
        "deterministic_double_replay_required_by_writer": True,
        "manifest": {"path": MANIFEST_NAME, "bytes": len(manifest), "sha256": sha256(manifest)},
        "checksums": {"path": CHECKSUMS_NAME, "bytes": len(checksums), "sha256": sha256(checksums)},
        "checks": {"all_thirty_unit_authority_translation_gates": True,
          "exact_reader_machine_visual_responsive_backend_common_gates": True,
          "reader_build_inputs_included": True, "zip_crc_inventory_entry_bytes": True,
          "per_component_licenses_preserved": True, "credential_pattern_hits": 0,
          "raw_authority_dumps_included": False, "official_pdf_witnesses_included": False},
    })
    result = {**payload, MANIFEST_NAME: manifest, CHECKSUMS_NAME: checksums, QA_NAME: qa}
    require(set(result) == set(FILES) and sorted(result)[0] == PDF_NAME, "Final file set")
    require(sum(map(len, result.values())) <= MAX_RELEASE_BYTES, "Reader-first payload exceeds 500 MB cap")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--dry-run", action="store_true", help="Read-only plan; does not claim gates pass")
    modes.add_argument("--verify-only", action="store_true", help="Replay existing exact gates without writing")
    modes.add_argument("--build", action="store_true", help="Double replay, then write exact release files")
    args = parser.parse_args()
    if args.dry_run:
        print(canonical({"status": "PLAN_ONLY", "through_unit": 30, "output": rel(OUT),
                         "required_gates": {name: rel(path) for name, path in GATES.items()},
                         "files": FILES, "network": False, "credentials": False, "writes": False}).decode())
        return
    if args.verify_only:
        boundary = verify_boundary()
        print(canonical({"status": "PASS", "through_unit": 30, "writes": False,
                         "pdf_pages": boundary["reader"]["pdf_pages"],
                         "native_records": boundary["native_manifest"]["record_count"]}).decode())
        return
    first, second = build_once(), build_once()
    require(first == second, "Deterministic packaging replay produced different bytes")
    if OUT.exists():
        require(OUT.is_dir() and not OUT.is_symlink(), "Unsafe release output directory")
        require(not {p.name for p in OUT.iterdir()} - set(FILES), "Unexpected file in candidate directory")
    OUT.mkdir(parents=True, exist_ok=True)
    for name, value in sorted(first.items()):
        path = OUT / name
        require(not path.is_symlink(), f"Unsafe release target: {name}")
        temporary = path.with_name(path.name + ".tmp")
        require(not temporary.exists(), f"Unresolved prior staging file: {temporary.name}")
        with temporary.open("xb") as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
        require(data(temporary) == value, f"Staging bytes mismatch: {name}")
        temporary.replace(path)
    require(all(data(OUT / name) == value for name, value in first.items()), "Final release readback mismatch")
    print(canonical({"status": "PASS", "directory": rel(OUT), "deterministic_double_replay": True,
                     "file_count": len(first), "total_bytes": sum(map(len, first.values())),
                     "files": [fact(OUT / name) for name in sorted(first)]}).decode())


if __name__ == "__main__":
    main()
