#!/usr/bin/env node
/**
 * In-app Browser measurement adapter. Import-only: no browser, CDP, network,
 * build, capture, resizing, source edit, or visual approval is performed here.
 *
 * Owner usage (after observing both viewports and saving three native JPEGs):
 *   const { expression, writeResponsiveReceipt } =
 *     await import("./scripts/bgk_reader_iab_responsive_receipt.mjs");
 *   // Evaluate expression read-only in the owner's connected Browser at
 *   // desktop 1280x720 and mobile 390x844; retain both complete returned objects.
 *   // Independently observe Boolean(document.getElementById(deepAnchor)).
 *   // Owner scrolls to that anchor and captures the deep mobile screenshot.
 *   const result = writeResponsiveReceipt({
 *     through: 30, desktop, mobile,
 *     screenshotPaths: { desktop: "qa/desktop.jpg", mobile: "qa/mobile.jpg",
 *                        deep: "qa/deep.jpg" },
 *     targetUrl: "http://127.0.0.1:18765/index.html",
 *     browserIdentity: { kind: "in-app-browser", tabId: "OWNER_OBSERVED_TAB_ID" },
 *     deepAnchor: "br-bgk-2019-w30-ex05", deepAnchorPresent: true,
 *     // outputPath: "qa/BGK_UNITS_01_30_RESPONSIVE_MEASURED.json",
 *     // replace: true, // only when the caller explicitly requests replacement
 *   });
 *   console.log(result);
 *
 * targetUrl/browserIdentity/deepAnchorPresent are owner observations, not
 * invented by this adapter. The measurement remains pending screenshot review.
 * The exported expression is an explicitly bound sandbox adaptation of the
 * original collector: window dimensions are qualified and URI decoding is
 * replaced only for unencoded ASCII ID fragments. Unsupported fragments are
 * retained in fragmentPolicy and fail receipt validation, never guessed.
 * Native IAB captures are 1265x712 desktop and 375x800 mobile/deep, distinct
 * from measured CSS viewports 1280x720/client1265 and 390x844/client375.
 * The adapter binds these runtime-provided bounded captures unchanged; it
 * never resamples, crops, or claims that raster and CSS dimensions coincide.
 */
import { createHash, randomUUID } from "node:crypto";
import {
  existsSync, linkSync, lstatSync, readFileSync, realpathSync,
  renameSync, unlinkSync, writeFileSync,
} from "node:fs";
import { dirname, extname, isAbsolute, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const SELF = fileURLToPath(import.meta.url);
const ROOT = resolve(dirname(SELF), "..");
const ROOT_REAL = realpathSync(ROOT);
const PROVENANCE = "OpenAI Codex gpt-5.6-sol, Ultra.";
const EXPECTED_TITLE = "Bundel, Berkas, dan Kohomologi - Unit 1-30";
const PNG_SIGNATURE = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
const FRAGMENT_POLICY = "unencoded-ascii-id-v1";
const IAB_CAPTURE_POLICY = "iab-runtime-native-jpeg-v1";
const JPEG_SOF_MARKERS = new Set([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7,
  0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf]);

const ORIGINAL_ANCHOR_CHECK = String.raw`  const brokenAnchors = anchors.map((anchor) => decodeURIComponent(anchor.hash.slice(1)))
    .filter((id) => id && !document.getElementById(id));`;
const IAB_ANCHOR_CHECK = String.raw`  const fragments = anchors.map((anchor) => anchor.hash.slice(1));
  const unsupportedFragments = fragments.filter((id) => /[^A-Za-z0-9_.:-]/.test(id));
  const brokenAnchors = fragments.filter((id) => !/[^A-Za-z0-9_.:-]/.test(id))
    .filter((id) => id && !document.getElementById(id));`;
const ORIGINAL_VIEWPORT = "    viewport: {innerWidth, innerHeight, clientWidth: de.clientWidth, scrollWidth: de.scrollWidth,";
const IAB_VIEWPORT = "    viewport: {innerWidth: window.innerWidth, innerHeight: window.innerHeight, clientWidth: de.clientWidth, scrollWidth: de.scrollWidth,";
const ORIGINAL_RETURN = "    title: document.title,";
const IAB_RETURN = String.raw`    title: document.title,
    fragmentPolicy: {name: 'unencoded-ascii-id-v1', allSupported: unsupportedFragments.length === 0,
      unsupportedFragmentCount: unsupportedFragments.length, unsupportedFragments},`;

function require(condition, message) {
  if (!condition) throw new Error(message);
}

/** Pure, narrowly specified adaptation; all other collector bytes must agree. */
export function adaptCollectorExpression(original) {
  require(typeof original === "string", "original DOM expression must be a string");
  let adapted = original;
  for (const [before, after] of [
    [ORIGINAL_ANCHOR_CHECK, IAB_ANCHOR_CHECK],
    [ORIGINAL_VIEWPORT, IAB_VIEWPORT],
    [ORIGINAL_RETURN, IAB_RETURN],
  ]) {
    require(adapted.split(before).length === 2, "original DOM expression lacks one exact adaptation site");
    adapted = adapted.replace(before, after);
  }
  return adapted;
}

function inside(root, path) {
  const rel = relative(root, path);
  return rel !== "" && rel !== ".." && !rel.startsWith(".." + "/")
    && !rel.startsWith(".." + "\\") && !isAbsolute(rel);
}

function lanePath(value, { output = false } = {}) {
  require(typeof value === "string" && value.trim() !== "", "path must be a nonempty string");
  const path = resolve(ROOT, value);
  require(inside(ROOT, path), "path must remain strictly inside the lane: " + path);
  if (existsSync(path)) {
    const stat = lstatSync(path);
    require(stat.isFile() && !stat.isSymbolicLink(), "input/output must be a regular non-symlink file: " + path);
    require(inside(ROOT_REAL, realpathSync(path)), "resolved path escapes the lane: " + path);
  } else {
    require(output, "missing input file: " + path);
    require(inside(ROOT_REAL, realpathSync(dirname(path))), "output parent escapes the lane: " + path);
  }
  if (output) {
    require(inside(resolve(ROOT, "qa"), path) && extname(path) === ".json",
      "measurement output must be a JSON file under the lane qa directory");
  }
  return path;
}

function hash(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

function boundFile(path) {
  const bytes = readFileSync(path);
  return {
    data: bytes,
    fact: { path: relative(ROOT, path).replaceAll("\\", "/"), bytes: bytes.length, sha256: hash(bytes) },
  };
}

function jsonClone(value, name) {
  require(value !== undefined, name + " is required");
  const serialized = JSON.stringify(value, (_key, current) => {
    require(!["undefined", "function", "symbol", "bigint"].includes(typeof current),
      name + " must be complete JSON data");
    if (typeof current === "number") require(Number.isFinite(current), name + " contains a non-finite number");
    return current;
  });
  require(typeof serialized === "string", name + " is not JSON data");
  return JSON.parse(serialized);
}

function object(value, name) {
  require(value !== null && typeof value === "object" && !Array.isArray(value), name + " must be an object");
}

function finite(value, name) {
  require(typeof value === "number" && Number.isFinite(value), name + " must be a finite number");
}

function count(value, name) {
  require(Number.isSafeInteger(value) && value >= 0, name + " must be a nonnegative integer");
}

/** Dimension validation only; visual/pixel-content review remains with owner. */
export function pngDimensions(data, label = "screenshot") {
  require(Buffer.isBuffer(data) || data instanceof Uint8Array, label + " must supply PNG bytes");
  const bytes = Buffer.from(data);
  require(bytes.length >= 33 && bytes.subarray(0, 8).equals(PNG_SIGNATURE)
    && bytes.readUInt32BE(8) === 13 && bytes.toString("ascii", 12, 16) === "IHDR",
  label + " has an invalid/truncated PNG header");
  const width = bytes.readUInt32BE(16);
  const height = bytes.readUInt32BE(20);
  require(width > 0 && height > 0, label + " has invalid PNG dimensions");
  return { width, height };
}

/** SOF dimension validation only; owner still reviews the actual image. */
export function jpegDimensions(data, label = "screenshot") {
  require(Buffer.isBuffer(data) || data instanceof Uint8Array, label + " must supply JPEG bytes");
  const bytes = Buffer.from(data);
  require(bytes.length >= 4 && bytes[0] === 0xff && bytes[1] === 0xd8,
    label + " has an invalid/truncated JPEG signature");
  let offset = 2;
  while (offset < bytes.length) {
    require(bytes[offset] === 0xff, label + " has an invalid JPEG marker");
    while (offset < bytes.length && bytes[offset] === 0xff) offset += 1;
    require(offset < bytes.length, label + " has a truncated JPEG marker");
    const marker = bytes[offset++];
    require(marker !== 0 && marker !== 0xd8, label + " has an invalid JPEG marker");
    require(marker !== 0xd9 && marker !== 0xda, label + " lacks JPEG SOF dimensions before image data");
    if (marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) continue;
    require(offset + 2 <= bytes.length, label + " has a truncated JPEG segment");
    const length = bytes.readUInt16BE(offset);
    require(length >= 2 && offset + length <= bytes.length, label + " has an invalid/truncated JPEG segment");
    if (JPEG_SOF_MARKERS.has(marker)) {
      require(length >= 8, label + " has a truncated JPEG SOF");
      const height = bytes.readUInt16BE(offset + 3);
      const width = bytes.readUInt16BE(offset + 5);
      const components = bytes[offset + 7];
      require(width > 0 && height > 0 && components > 0 && length === 8 + 3 * components,
        label + " has invalid JPEG SOF dimensions/components");
      return { width, height };
    }
    offset += length;
  }
  throw new Error(label + " lacks JPEG SOF dimensions");
}

/** Bind the observed IAB raster contract independently of CSS geometry. */
export function validateIabCapture(data, name, surface) {
  require(["desktop", "mobile", "deep"].includes(name), "unknown IAB capture role");
  object(surface, name + " CSS surface");
  object(surface.viewport, name + " CSS viewport");
  const desktop = name === "desktop";
  const expected = desktop
    ? { width: 1265, height: 712, cssWidth: 1280, cssHeight: 720, clientWidth: 1265 }
    : { width: 375, height: 800, cssWidth: 390, cssHeight: 844, clientWidth: 375 };
  const dimensions = jpegDimensions(data, name);
  require(dimensions.width === expected.width && dimensions.height === expected.height,
    name + " native JPEG capture dimensions");
  const v = surface.viewport;
  require(v.innerWidth === expected.cssWidth && v.innerHeight === expected.cssHeight
    && v.clientWidth === expected.clientWidth, name + " IAB CSS viewport/client dimensions");
  return {
    mediaType: "image/jpeg",
    dimensions,
    capture: {
      kind: "runtime-provided-bounded-capture",
      cssViewport: { width: v.innerWidth, height: v.innerHeight, clientWidth: v.clientWidth },
      adapterResampled: false,
      adapterCropped: false,
    },
  };
}

function validateSurface(raw, name, width, height) {
  const surface = jsonClone(raw, name);
  object(surface, name);
  require(surface.title === EXPECTED_TITLE, name + " title drift");
  if ("name" in surface) require(surface.name === name, name + " name drift");
  if ("width" in surface) require(surface.width === width, name + " requested width drift");
  if ("height" in surface) require(surface.height === height, name + " requested height drift");
  object(surface.viewport, name + ".viewport");
  const v = surface.viewport;
  for (const key of ["innerWidth", "innerHeight", "clientWidth", "scrollWidth", "bodyScrollWidth"]) {
    count(v[key], name + ".viewport." + key);
  }
  require(v.innerWidth === width && v.innerHeight === height, name + " observed viewport dimensions");
  require(v.clientWidth > 0 && v.clientWidth <= width, name + " client width");
  require(v.documentHorizontalOverflow === false && v.scrollWidth <= v.clientWidth + 1,
    name + " document overflow");
  object(surface.main, name + ".main");
  const main = surface.main;
  for (const key of ["left", "right", "width", "centeringDelta"]) finite(main[key], name + ".main." + key);
  require(main.width > 0 && Math.abs(main.right - main.left - main.width) <= 0.03,
    name + " inconsistent main rectangle");
  const delta = (main.left + main.right) / 2 - v.clientWidth / 2;
  require(Math.abs(delta - main.centeringDelta) <= 0.02 && Math.abs(main.centeringDelta) <= 0.5,
    name + " main not centered");
  const [minWidth, maxWidth] = name === "desktop" ? [960, 980] : [340, 345];
  require(main.width >= minWidth && main.width <= maxWidth, name + " main-width contract");
  object(surface.counts, name + ".counts");
  const c = surface.counts;
  for (const key of ["main", "skipLinks", "mathml", "images", "missingAlt", "ids",
    "duplicateIds", "anchors", "brokenAnchors", "headings", "outsideViewportNodes",
    "unprotectedOutsideViewportNodes", "localHorizontalScrollNodes"]) count(c[key], name + ".counts." + key);
  require(c.main === 1 && c.skipLinks === 1, name + " landmark closure");
  require(c.missingAlt === 0 && c.duplicateIds === 0 && c.brokenAnchors === 0,
    name + " accessibility/anchor closure");
  object(surface.fragmentPolicy, name + ".fragmentPolicy");
  const fragmentPolicy = surface.fragmentPolicy;
  require(fragmentPolicy.name === FRAGMENT_POLICY, name + " fragment policy mismatch");
  count(fragmentPolicy.unsupportedFragmentCount, name + ".fragmentPolicy.unsupportedFragmentCount");
  require(Array.isArray(fragmentPolicy.unsupportedFragments)
    && fragmentPolicy.unsupportedFragments.length === fragmentPolicy.unsupportedFragmentCount,
  name + " incomplete unsupported-fragment details");
  require(fragmentPolicy.allSupported === true && fragmentPolicy.unsupportedFragmentCount === 0,
    name + " unsupported fragment: only unencoded ASCII ID characters are admitted");
  require(c.unprotectedOutsideViewportNodes === 0, name + " unprotected clipping");
  require(Array.isArray(surface.outsideViewportNodes)
    && surface.outsideViewportNodes.length === Math.min(50, c.outsideViewportNodes),
  name + " incomplete outside-viewport details");
  require(Array.isArray(surface.localHorizontalScrollNodes)
    && surface.localHorizontalScrollNodes.length === Math.min(50, c.localHorizontalScrollNodes),
  name + " incomplete local-scroll details");
  for (const row of surface.outsideViewportNodes) {
    object(row, name + ".outsideViewportNodes row");
    require(row.protectedByLocalScroll === true, name + " unprotected clipping in details");
    for (const key of ["left", "right", "width"]) finite(row[key], name + ".outsideViewportNodes." + key);
  }
  for (const row of surface.localHorizontalScrollNodes) {
    object(row, name + ".localHorizontalScrollNodes row");
    count(row.clientWidth, name + ".localScroll.clientWidth");
    count(row.scrollWidth, name + ".localScroll.scrollWidth");
    require(row.scrollWidth > row.clientWidth + 1, name + " inconsistent local-scroll details");
  }
  // Preserve every actual measurement field. Only role/dimension fields are
  // added after checking any caller-supplied values. No result is summarized.
  return { ...surface, name, width, height };
}

/** Pure geometry/accessibility validation; does not read/write any file. */
export function validateResponsiveMeasurements({ through = 30, desktop, mobile }) {
  require(through === 30, "this owner adapter is scoped exactly through Unit 30");
  return {
    desktop: validateSurface(desktop, "desktop", 1280, 720),
    mobile: validateSurface(mobile, "mobile", 390, 844),
  };
}

function checkedTarget(value) {
  require(typeof value === "string" && value.trim() === value && value.length > 0, "exact targetUrl is required");
  const url = new URL(value);
  require(["http:", "https:"].includes(url.protocol), "reader target must be an HTTP(S) URL");
  require(["127.0.0.1", "localhost", "[::1]"].includes(url.hostname), "reader target must be loopback");
  require(!url.username && !url.password, "reader target must not contain credentials");
  return value; // Preserve the exact owner-observed URL, including any fragment.
}

function checkedBrowser(value) {
  const identity = jsonClone(value, "browserIdentity");
  if (typeof identity === "string") require(identity.trim().length > 0, "browserIdentity is empty");
  else {
    object(identity, "browserIdentity");
    require(Object.keys(identity).length > 0, "browserIdentity is empty");
  }
  return identity;
}

/**
 * Validate owner measurements + local bound evidence, then write only the v2
 * unreviewed measurement receipt. Existing screenshots are always read-only.
 */
export function writeResponsiveReceipt(options) {
  object(options, "options");
  const through = options.through ?? 30;
  require(through === 30, "this owner adapter is scoped exactly through Unit 30");
  const replace = options.replace ?? false;
  require(typeof replace === "boolean", "replace must be an explicit boolean");
  const outputPath = lanePath(options.outputPath || "qa/BGK_UNITS_01_30_RESPONSIVE_MEASURED.json", { output: true });
  require(replace || !existsSync(outputPath), "measured receipt already exists; pass replace:true explicitly");

  const surfaces = validateResponsiveMeasurements({ through, desktop: options.desktop, mobile: options.mobile });
  const target = checkedTarget(options.targetUrl);
  const browserIdentity = checkedBrowser(options.browserIdentity);
  const htmlPath = lanePath(options.htmlPath || "build/reader-bgk-id/index.html");
  const machinePath = lanePath(options.machineQaPath || "qa/BGK_UNITS_01_30_READER_QA.json");
  const expectationsPath = lanePath(options.expectationsPath || "scripts/bgk_reader_expectations_v1.json");
  const html = boundFile(htmlPath);
  const machine = boundFile(machinePath);
  const expectationsFile = boundFile(expectationsPath);
  const qa = JSON.parse(machine.data.toString("utf8"));
  const expectations = JSON.parse(expectationsFile.data.toString("utf8"));
  require(qa.status === "PASS" && qa.through_unit === through, "machine QA is not final PASS for Unit 30");
  require(Array.isArray(qa.outputs), "machine QA outputs are absent");
  const machineHtml = qa.outputs.find((row) => row.path === html.fact.path);
  require(machineHtml && machineHtml.bytes === html.fact.bytes && machineHtml.sha256 === html.fact.sha256,
    "machine QA HTML binding drift");
  require(expectations.schema === "ag-bridge-bgk-reader-expectations-v1", "expectations schema");
  require(Array.isArray(expectations.units) && expectations.units.some((unit) => unit.unit === 30),
    "expectations lack Unit 30");
  require(expectations.terminal_surface?.unit === 30
    && typeof expectations.terminal_surface.deep_anchor === "string", "Unit 30 terminal expectation missing");
  const deepAnchor = options.deepAnchor ?? expectations.terminal_surface.deep_anchor;
  require(deepAnchor === expectations.terminal_surface.deep_anchor, "deep anchor differs from frozen expectation");
  require(options.deepAnchorPresent === true, "owner must supply actual positive deep-anchor observation");

  object(options.screenshotPaths, "screenshotPaths");
  const screenshotPaths = Object.fromEntries(["desktop", "mobile", "deep"].map((name) => {
    const path = lanePath(options.screenshotPaths[name]);
    require([".jpg", ".jpeg"].includes(extname(path).toLowerCase()),
      name + " IAB screenshot must retain its native JPEG bytes with a .jpg/.jpeg extension");
    return [name, path];
  }));
  require(new Set(Object.values(screenshotPaths).map((path) => path.toLowerCase())).size === 3,
    "three distinct existing screenshot paths are required");
  const screenshots = {};
  for (const name of ["desktop", "mobile", "deep"]) {
    const file = boundFile(screenshotPaths[name]);
    const capture = validateIabCapture(file.data, name, name === "desktop" ? surfaces.desktop : surfaces.mobile);
    screenshots[name] = { ...file.fact, ...capture };
  }

  const referencePath = lanePath("scripts/measure_bgk_reader_responsive.mjs");
  const reference = boundFile(referencePath);
  const referenceMatch = reference.data.toString("utf8").match(/const expression = String\.raw\x60([\s\S]*?)\x60;\s*\n\s*async function measure/);
  require(referenceMatch && adaptCollectorExpression(referenceMatch[1]) === expression,
    "exported DOM expression differs beyond the documented sandbox adaptation");
  const inputPaths = [htmlPath, machinePath, expectationsPath, referencePath, SELF, ...Object.values(screenshotPaths)];
  require(!inputPaths.some((path) => path.toLowerCase() === outputPath.toLowerCase()), "output must not replace any input");
  const receipt = {
    schema: "ag-bridge-bgk-responsive-measurement-v2",
    through_unit: through,
    status: "PASS_MEASURED_SCREENSHOTS_PENDING_REVIEW",
    model_provenance: PROVENANCE,
    target,
    measurement_route: "owner-operated-in-app-browser",
    capture_contract: {
      policy: IAB_CAPTURE_POLICY,
      description: "Runtime-provided native JPEG bounded captures: desktop1265x712; mobile/deep375x800. Separately measured CSS viewports: desktop1280x720/client1265; mobile390x844/client375. Capture and CSS dimensions are different observations; the adapter performs no crop or resampling and makes no raster-to-CSS rescale claim.",
      adapter_resampled: false,
      adapter_cropped: false,
    },
    browser_identity: browserIdentity,
    collector: boundFile(SELF).fact,
    dom_expression: {
      sha256: hash(Buffer.from(expression, "utf8")),
      expression,
      source: reference.fact,
      original_expression_sha256: hash(Buffer.from(referenceMatch[1], "utf8")),
      adaptation: {
        policy: FRAGMENT_POLICY,
        description: "Explicit window dimensions; URI-decoding equivalent only for unencoded ASCII ID fragments containing exclusively A-Z, a-z, 0-9, underscore, period, colon, and hyphen (empty fragment allowed). Percent-encoded, non-ASCII, or other fragments are recorded without truncation and fail closed.",
        unchanged_remainder_verified: true,
      },
    },
    expectations: expectationsFile.fact,
    html: html.fact,
    reader_machine_qa: machine.fact,
    desktop: { ...surfaces.desktop, screenshot: screenshots.desktop },
    mobile: { ...surfaces.mobile, screenshot: screenshots.mobile },
    deep_surface: { anchor: deepAnchor, anchor_observed: true, screenshot: screenshots.deep },
    checks: {
      desktop_centered_and_page_filling: true,
      mobile_reflow_without_document_overflow: true,
      no_unprotected_content_outside_viewport: true,
      skip_link_landmark_alt_id_and_anchor_closure: true,
      internal_fragments_unencoded_ascii_ids: true,
      deep_surface_captured: true,
      screenshots_reviewed: false,
    },
  };
  const bytes = JSON.stringify(receipt, null, 2) + "\n";
  const temporary = outputPath + ".tmp-" + randomUUID();
  writeFileSync(temporary, bytes, { flag: "wx", encoding: "utf8" });
  try {
    if (replace) renameSync(temporary, outputPath);
    else {
      // Atomic no-clobber creation; unlike rename, linking fails if another
      // owner operation creates outputPath after the initial existence check.
      linkSync(temporary, outputPath);
      unlinkSync(temporary);
    }
  } catch (error) {
    if (existsSync(temporary)) unlinkSync(temporary);
    throw error;
  }
  return { status: receipt.status, receipt: boundFile(outputPath).fact };
}

// Read-only collector with only the three documented sandbox adaptations.
export const expression = String.raw`(() => {
  const de = document.documentElement;
  const body = document.body;
  const main = document.querySelector('main');
  const mainRect = main.getBoundingClientRect();
  const ids = [...document.querySelectorAll('[id]')].map((node) => node.id);
  const duplicateIds = ids.filter((value, index) => ids.indexOf(value) !== index);
  const anchors = [...document.querySelectorAll('a[href^="#"]')];
  const fragments = anchors.map((anchor) => anchor.hash.slice(1));
  const unsupportedFragments = fragments.filter((id) => /[^A-Za-z0-9_.:-]/.test(id));
  const brokenAnchors = fragments.filter((id) => !/[^A-Za-z0-9_.:-]/.test(id))
    .filter((id) => id && !document.getElementById(id));
  const overflowNodes = [...document.body.querySelectorAll('*')]
    .filter((node) => !node.matches('.skip-link'))
    .map((node) => {
      const rect = node.getBoundingClientRect();
      return {
        tag: node.tagName.toLowerCase(), id: node.id || null,
        classes: typeof node.className === 'string' ? node.className : '',
        left: Number(rect.left.toFixed(2)), right: Number(rect.right.toFixed(2)),
        width: Number(rect.width.toFixed(2)),
        protectedByLocalScroll: Boolean(node.closest('math[display="block"], pre, table, div.column')),
      };
    }).filter((row) => row.width > 0 && (row.left < -0.5 || row.right > de.clientWidth + 0.5));
  const localScrollNodes = [...document.querySelectorAll('math[display="block"], pre, table, div.column')]
    .filter((node) => node.scrollWidth > node.clientWidth + 1)
    .map((node) => ({tag: node.tagName.toLowerCase(), id: node.id || null,
      clientWidth: node.clientWidth, scrollWidth: node.scrollWidth}));
  return {
    title: document.title,
    fragmentPolicy: {name: 'unencoded-ascii-id-v1', allSupported: unsupportedFragments.length === 0,
      unsupportedFragmentCount: unsupportedFragments.length, unsupportedFragments},
    viewport: {innerWidth: window.innerWidth, innerHeight: window.innerHeight, clientWidth: de.clientWidth, scrollWidth: de.scrollWidth,
      bodyScrollWidth: body.scrollWidth, documentHorizontalOverflow: de.scrollWidth > de.clientWidth + 1},
    main: {left: Number(mainRect.left.toFixed(2)), right: Number(mainRect.right.toFixed(2)),
      width: Number(mainRect.width.toFixed(2)),
      centeringDelta: Number((((mainRect.left + mainRect.right) / 2) - de.clientWidth / 2).toFixed(2))},
    counts: {main: document.querySelectorAll('main').length,
      skipLinks: document.querySelectorAll('.skip-link').length,
      mathml: document.querySelectorAll('math').length,
      images: document.querySelectorAll('img').length,
      missingAlt: document.querySelectorAll('img:not([alt])').length,
      ids: ids.length, duplicateIds: [...new Set(duplicateIds)].length,
      anchors: anchors.length, brokenAnchors: [...new Set(brokenAnchors)].length,
      headings: document.querySelectorAll('h1,h2,h3,h4,h5,h6').length,
      outsideViewportNodes: overflowNodes.length,
      unprotectedOutsideViewportNodes: overflowNodes.filter((row) => !row.protectedByLocalScroll).length,
      localHorizontalScrollNodes: localScrollNodes.length},
    outsideViewportNodes: overflowNodes.slice(0, 50),
    localHorizontalScrollNodes: localScrollNodes.slice(0, 50),
  };
})()`;
