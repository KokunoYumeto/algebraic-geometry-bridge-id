import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { runInNewContext } from "node:vm";
import {
  adaptCollectorExpression, expression, jpegDimensions, pngDimensions,
  validateIabCapture, validateResponsiveMeasurements, writeResponsiveReceipt,
} from "./bgk_reader_iab_responsive_receipt.mjs";

const HERE = dirname(fileURLToPath(import.meta.url));

function sample(name) {
  const desktop = name === "desktop";
  const width = desktop ? 1280 : 390;
  const height = desktop ? 720 : 844;
  const mainWidth = desktop ? 968 : 343;
  return {
    title: "Bundel, Berkas, dan Kohomologi - Unit 1-30",
    fragmentPolicy: { name: "unencoded-ascii-id-v1", allSupported: true,
      unsupportedFragmentCount: 0, unsupportedFragments: [] },
    viewport: { innerWidth: width, innerHeight: height, clientWidth: width,
      scrollWidth: width, bodyScrollWidth: width, documentHorizontalOverflow: false },
    main: { left: (width - mainWidth) / 2, right: (width + mainWidth) / 2,
      width: mainWidth, centeringDelta: 0 },
    counts: { main: 1, skipLinks: 1, mathml: 20, images: 2, missingAlt: 0,
      ids: 30, duplicateIds: 0, anchors: 10, brokenAnchors: 0, headings: 15,
      outsideViewportNodes: 0, unprotectedOutsideViewportNodes: 0,
      localHorizontalScrollNodes: 0 },
    outsideViewportNodes: [], localHorizontalScrollNodes: [],
  };
}

function data() { return { through: 30, desktop: sample("desktop"), mobile: sample("mobile") }; }

test("DOM expression has only the specified ASCII-equivalent sandbox adaptations", () => {
  const original = readFileSync(resolve(HERE, "measure_bgk_reader_responsive.mjs"), "utf8");
  const match = original.match(/const expression = String\.raw\x60([\s\S]*?)\x60;\s*\n\s*async function measure/);
  assert.ok(match);
  assert.notEqual(expression, match[1]);
  assert.equal(expression, adaptCollectorExpression(match[1]));
  assert.doesNotMatch(expression, /decodeURIComponent/);
  assert.match(expression, /innerWidth: window\.innerWidth, innerHeight: window\.innerHeight/);
  assert.doesNotMatch(expression, /scrollTo|scrollIntoView|\.click\(|\.reload\(/);
  assert.throws(() => adaptCollectorExpression(match[1].replace("title: document.title,", "title: 'changed',")), /exact adaptation site/);
  assert.throws(() => adaptCollectorExpression(match[1] + "\n    title: document.title,"), /exact adaptation site/);
});

// A deliberately tiny synthetic DOM, never an actual browser. URI decoding and
// bare viewport globals are absent, matching the owner's evaluator constraint.
function evaluateFixture(fragments, existingIds = [], name = "desktop") {
  const fixture = sample(name);
  const main = { getBoundingClientRect: () => fixture.main };
  const anchors = fragments.map((hash) => ({ hash }));
  const idNodes = existingIds.map((id) => ({ id }));
  const selectors = {
    main: [main], ".skip-link": [{}], math: Array.from({ length: 20 }, () => ({})),
    img: [{}, {}], "img:not([alt])": [], "[id]": idNodes,
    'a[href^="#"]': anchors,
    "h1,h2,h3,h4,h5,h6": Array.from({ length: 15 }, () => ({})),
    'math[display="block"], pre, table, div.column': [],
  };
  const document = {
    title: fixture.title,
    documentElement: { clientWidth: fixture.viewport.clientWidth, scrollWidth: fixture.viewport.scrollWidth },
    body: { scrollWidth: fixture.viewport.bodyScrollWidth, querySelectorAll: () => [] },
    querySelector: (selector) => selectors[selector]?.[0] ?? null,
    querySelectorAll: (selector) => selectors[selector] ?? [],
    getElementById: (id) => idNodes.find((node) => node.id === id) ?? null,
  };
  return runInNewContext(expression, {
    document,
    window: { innerWidth: fixture.viewport.innerWidth, innerHeight: fixture.viewport.innerHeight },
    decodeURIComponent: undefined,
  }, { timeout: 1000 });
}

test("expression evaluates ASCII anchors without decoding or bare viewport globals", () => {
  const desktop = evaluateFixture(["#br-bgk-2019-w30-ex05", "#id_1:part.2", "#"],
    ["br-bgk-2019-w30-ex05", "id_1:part.2"]);
  const mobile = evaluateFixture(["#ok"], ["ok"], "mobile");
  const result = validateResponsiveMeasurements({ desktop, mobile });
  assert.equal(result.desktop.viewport.innerWidth, 1280);
  assert.equal(result.mobile.viewport.innerHeight, 844);
  assert.equal(result.desktop.counts.brokenAnchors, 0);
  assert.equal(result.desktop.fragmentPolicy.allSupported, true);
});

test("expression still detects missing supported ASCII anchors", () => {
  const desktop = evaluateFixture(["#missing"]);
  assert.equal(desktop.counts.brokenAnchors, 1);
  assert.throws(() => validateResponsiveMeasurements({ ...data(), desktop }), /accessibility\/anchor closure/);
});

for (const fragment of ["#term%2D1", "#termé", "#term space", "#term/part", "#term\n"]) {
  test("unsupported fragment is recorded and rejected: " + JSON.stringify(fragment), () => {
    const desktop = evaluateFixture([fragment], [fragment.slice(1)]);
    assert.equal(desktop.fragmentPolicy.allSupported, false);
    assert.equal(desktop.fragmentPolicy.unsupportedFragmentCount, 1);
    assert.equal(desktop.fragmentPolicy.unsupportedFragments[0], fragment.slice(1));
    assert.throws(() => validateResponsiveMeasurements({ ...data(), desktop }), /unsupported fragment/);
  });
}

test("unsupported fragment evidence is never truncated by overflow's 50-row policy", () => {
  const desktop = evaluateFixture(Array.from({ length: 61 }, (_, i) => "#term%20" + i));
  assert.equal(desktop.fragmentPolicy.unsupportedFragmentCount, 61);
  assert.equal(desktop.fragmentPolicy.unsupportedFragments.length, 61);
  assert.throws(() => validateResponsiveMeasurements({ ...data(), desktop }), /unsupported fragment/);
});

test("complete actual-shape data passes without mutation or detail truncation", () => {
  const input = data();
  input.mobile.ownerExtraObservation = { source: "synthetic unit-test fixture", values: [1, 2, 3] };
  const original = structuredClone(input);
  const result = validateResponsiveMeasurements(input);
  assert.deepEqual(input, original);
  assert.deepEqual(result.mobile.ownerExtraObservation, original.mobile.ownerExtraObservation);
  assert.equal(result.desktop.width, 1280);
  assert.equal(result.desktop.height, 720);
  assert.equal(result.mobile.width, 390);
  assert.equal(result.mobile.height, 844);
});

const rejectionCases = [
  ["title", (x) => { x.desktop.title = "wrong"; }, /title drift/],
  ["viewport width", (x) => { x.mobile.viewport.innerWidth = 400; }, /viewport dimensions/],
  ["viewport height", (x) => { x.desktop.viewport.innerHeight = 900; }, /viewport dimensions/],
  ["declared overflow", (x) => { x.mobile.viewport.documentHorizontalOverflow = true; }, /document overflow/],
  ["numeric overflow", (x) => { x.mobile.viewport.scrollWidth = 400; }, /document overflow/],
  ["centering", (x) => { x.mobile.main.left += 2; x.mobile.main.right += 2; x.mobile.main.centeringDelta = 2; }, /not centered/],
  ["fabricated centering", (x) => { x.mobile.main.left += 2; x.mobile.main.right += 2; }, /not centered/],
  ["desktop width", (x) => { x.desktop.main = { left: 190, right: 1090, width: 900, centeringDelta: 0 }; }, /main-width contract/],
  ["mobile width", (x) => { x.mobile.main = { left: 30, right: 360, width: 330, centeringDelta: 0 }; }, /main-width contract/],
  ["main count", (x) => { x.desktop.counts.main = 2; }, /landmark closure/],
  ["skip link", (x) => { x.mobile.counts.skipLinks = 0; }, /landmark closure/],
  ["alt text", (x) => { x.mobile.counts.missingAlt = 1; }, /accessibility/],
  ["duplicate ID", (x) => { x.desktop.counts.duplicateIds = 1; }, /accessibility/],
  ["broken anchor", (x) => { x.desktop.counts.brokenAnchors = 1; }, /accessibility/],
  ["missing fragment policy", (x) => { delete x.desktop.fragmentPolicy; }, /fragmentPolicy must be an object/],
  ["fragment policy drift", (x) => { x.desktop.fragmentPolicy.name = "anything-goes"; }, /fragment policy mismatch/],
  ["missing fragment count", (x) => { delete x.desktop.fragmentPolicy.unsupportedFragmentCount; }, /nonnegative integer/],
  ["incomplete fragment details", (x) => { x.desktop.fragmentPolicy.unsupportedFragmentCount = 1; }, /incomplete unsupported-fragment/],
  ["unsupported fragment flag", (x) => { x.desktop.fragmentPolicy.allSupported = false; }, /unsupported fragment/],
  ["clipping", (x) => { x.mobile.counts.unprotectedOutsideViewportNodes = 1; }, /unprotected clipping/],
  ["missing actual count", (x) => { delete x.mobile.counts.mathml; }, /nonnegative integer/],
  ["nonfinite measurement", (x) => { x.mobile.main.width = NaN; }, /non-finite number/],
  ["unknown non-JSON field", (x) => { x.desktop.extra = undefined; }, /complete JSON data/],
  ["incomplete overflow details", (x) => { x.mobile.counts.outsideViewportNodes = 1; }, /incomplete outside/],
];
for (const [name, mutate, pattern] of rejectionCases) {
  test("rejects " + name, () => { const value = data(); mutate(value); assert.throws(() => validateResponsiveMeasurements(value), pattern); });
}

test("only existing 50-row overflow-detail policy is accepted", () => {
  const value = data();
  value.mobile.counts.outsideViewportNodes = 62;
  value.mobile.outsideViewportNodes = Array.from({ length: 50 }, () => ({
    tag: "mi", id: null, classes: "", left: 370, right: 415, width: 45, protectedByLocalScroll: true,
  }));
  const result = validateResponsiveMeasurements(value);
  assert.equal(result.mobile.counts.outsideViewportNodes, 62);
  assert.equal(result.mobile.outsideViewportNodes.length, 50);
  value.mobile.outsideViewportNodes[0].protectedByLocalScroll = false;
  assert.throws(() => validateResponsiveMeasurements(value), /unprotected clipping in details/);
});

test("PNG dimensions are checked from IHDR bytes without a browser", () => {
  // Header fixture only: this test asserts dimensions, never image-content QA.
  const bytes = Buffer.alloc(33);
  Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]).copy(bytes);
  bytes.writeUInt32BE(13, 8); bytes.write("IHDR", 12, "ascii");
  bytes.writeUInt32BE(1280, 16); bytes.writeUInt32BE(720, 20);
  assert.deepEqual(pngDimensions(bytes), { width: 1280, height: 720 });
  assert.throws(() => pngDimensions(bytes.subarray(0, 24)), /invalid\/truncated PNG/);
  bytes[0] = 0;
  assert.throws(() => pngDimensions(bytes), /invalid\/truncated PNG/);
});

// Synthetic SOF header only, not a captured or visually approved image.
function jpegFixture(width, height, marker = 0xc0) {
  const bytes = Buffer.from([0xff, 0xd8, 0xff, marker, 0, 17, 8,
    0, 0, 0, 0, 3, 1, 0x11, 0, 2, 0x11, 0, 3, 0x11, 0]);
  bytes.writeUInt16BE(height, 7);
  bytes.writeUInt16BE(width, 9);
  return Buffer.concat([bytes.subarray(0, 2), Buffer.from([0xff, 0xe0, 0, 4, 0x41, 0x42]),
    bytes.subarray(2), Buffer.from([0xff, 0xd9])]);
}

function iabSurface(name) {
  const surface = sample(name);
  const client = name === "desktop" ? 1265 : 375;
  surface.viewport.clientWidth = client;
  surface.viewport.scrollWidth = client;
  surface.viewport.bodyScrollWidth = client;
  surface.main.left = (client - surface.main.width) / 2;
  surface.main.right = (client + surface.main.width) / 2;
  return surface;
}

test("JPEG SOF dimensions are read through APP segments for baseline and progressive JPEG", () => {
  assert.deepEqual(jpegDimensions(jpegFixture(1265, 712)), { width: 1265, height: 712 });
  assert.deepEqual(jpegDimensions(jpegFixture(375, 800, 0xc2)), { width: 375, height: 800 });
  assert.throws(() => jpegDimensions(jpegFixture(375, 0)), /invalid JPEG SOF/);
  assert.throws(() => jpegDimensions(jpegFixture(375, 800).subarray(0, 18)), /truncated JPEG/);
  assert.throws(() => jpegDimensions(Buffer.from([0xff, 0xd8, 0xff, 0xda])), /lacks JPEG SOF/);
  assert.throws(() => jpegDimensions(Buffer.from("not JPEG")), /JPEG signature/);
});

test("IAB JPEG evidence binds native dimensions separately from measured CSS", () => {
  const desktop = iabSurface("desktop"), mobile = iabSurface("mobile");
  validateResponsiveMeasurements({ desktop, mobile });
  const input = jpegFixture(1265, 712), before = Buffer.from(input);
  const metadata = validateIabCapture(input, "desktop", desktop);
  assert.deepEqual(input, before);
  assert.equal(metadata.mediaType, "image/jpeg");
  assert.deepEqual(metadata.dimensions, { width: 1265, height: 712 });
  assert.deepEqual(metadata.capture.cssViewport, { width: 1280, height: 720, clientWidth: 1265 });
  assert.equal(metadata.capture.adapterResampled, false);
  assert.equal(metadata.capture.adapterCropped, false);
  for (const name of ["mobile", "deep"]) {
    const capture = validateIabCapture(jpegFixture(375, 800), name, mobile);
    assert.deepEqual(capture.dimensions, { width: 375, height: 800 });
    assert.deepEqual(capture.capture.cssViewport, { width: 390, height: 844, clientWidth: 375 });
  }
});

test("IAB does not silently reinterpret raster dimensions as CSS or accept rescaled captures", () => {
  assert.throws(() => validateIabCapture(jpegFixture(1280, 720), "desktop", iabSurface("desktop")), /native JPEG capture dimensions/);
  assert.throws(() => validateIabCapture(jpegFixture(390, 844), "mobile", iabSurface("mobile")), /native JPEG capture dimensions/);
  assert.throws(() => validateIabCapture(jpegFixture(1265, 712), "desktop", sample("desktop")), /CSS viewport\/client dimensions/);
  const wrong = iabSurface("mobile");
  wrong.viewport.innerHeight = 800;
  assert.throws(() => validateIabCapture(jpegFixture(375, 800), "deep", wrong), /CSS viewport\/client dimensions/);
});

test("only Unit30 is accepted", () => {
  assert.throws(() => validateResponsiveMeasurements({ ...data(), through: 29 }), /exactly through Unit 30/);
});

test("writer refuses existing QA path without explicit replacement and does not alter it", () => {
  const existing = resolve(HERE, "../qa/BGK_UNIT_30_TRANSLATION_QA.json");
  const before = readFileSync(existing);
  assert.throws(() => writeResponsiveReceipt({ outputPath: existing }), /already exists/);
  assert.deepEqual(readFileSync(existing), before);
});

test("writer refuses paths outside the lane before any write", () => {
  assert.throws(() => writeResponsiveReceipt({ outputPath: "../OUTSIDE-IAB-TEST.json" }), /inside the lane/);
  assert.throws(() => writeResponsiveReceipt({ outputPath: "source/NOT-A-RECEIPT.json" }), /qa directory/);
});

test("replace requires an explicit boolean", () => {
  assert.throws(() => writeResponsiveReceipt({ replace: "true" }), /explicit boolean/);
});

test("writer does not accept a remote reader target", () => {
  assert.throws(() => writeResponsiveReceipt({ ...data(),
    outputPath: "qa/IAB-TEST-NEVER-WRITTEN.json", targetUrl: "https://example.invalid/reader.html",
    browserIdentity: "synthetic fixture",
  }), /loopback/);
});

test("module contains no network, browser-launch, or final-approval implementation", () => {
  const source = readFileSync(resolve(HERE, "bgk_reader_iab_responsive_receipt.mjs"), "utf8");
  assert.doesNotMatch(source, /\bfetch\s*\(|new\s+WebSocket|node:child_process|node:(?:https?|net)|Page\.captureScreenshot/);
  assert.match(source, /screenshots_reviewed: false/);
  assert.match(source, /PASS_MEASURED_SCREENSHOTS_PENDING_REVIEW/);
  assert.match(source, /original_expression_sha256:/);
  assert.match(source, /unchanged_remainder_verified: true/);
  assert.match(source, /\n      expression,/);
});
