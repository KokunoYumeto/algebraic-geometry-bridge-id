#!/usr/bin/env node
/* Deterministic CDP measurements for any cumulative BGK HTML boundary. */

import { createHash } from "node:crypto";
import { mkdirSync, readFileSync, renameSync, statSync, writeFileSync } from "node:fs";
import { dirname, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const PROVENANCE = "OpenAI Codex gpt-5.6-sol, Ultra.";

function parseArgs(argv) {
  const values = new Map();
  const flags = new Set();
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (token === "--dry-run" || token === "--replace" || token === "--help") {
      flags.add(token);
      continue;
    }
    if (!token.startsWith("--") || index + 1 >= argv.length) {
      throw new Error(`invalid argument sequence near ${token}`);
    }
    if (values.has(token)) throw new Error(`duplicate argument ${token}`);
    values.set(token, argv[++index]);
  }
  return { values, flags };
}

function lanePath(value) {
  const path = resolve(ROOT, value);
  const rel = relative(ROOT, path).replaceAll("\\", "/");
  if (rel === ".." || rel.startsWith("../") || rel.startsWith("..\\")) {
    throw new Error(`path must remain inside the lane: ${path}`);
  }
  return path;
}

function sha256(path) {
  return createHash("sha256").update(readFileSync(path)).digest("hex");
}

function fact(path) {
  return {
    path: relative(ROOT, path).replaceAll("\\", "/"),
    bytes: statSync(path).size,
    sha256: sha256(path),
  };
}

function require(condition, message) {
  if (!condition) throw new Error(message);
}

function titleFor(through) {
  return through === 1
    ? "Bundel, Berkas, dan Kohomologi - Unit 1"
    : `Bundel, Berkas, dan Kohomologi - Unit 1-${through}`;
}

const { values, flags } = parseArgs(process.argv.slice(2));
if (flags.has("--help")) {
  console.log(`usage: measure_bgk_reader_responsive.mjs --through N [options]

Options:
  --expectations PATH    frozen exercise/solution manifest
  --html PATH            cumulative reader HTML
  --machine-qa PATH      final machine-QA receipt
  --reader-url URL       loopback reader URL
  --cdp-endpoint URL     loopback CDP endpoint
  --screenshot-dir PATH  screenshot output directory
  --output-measured PATH immutable measurement receipt
  --deep-anchor ID       terminal surface anchor
  --timeout-ms N         CDP event timeout
  --settle-ms N          post-load settle interval
  --replace              explicitly replace prior measured outputs
  --dry-run              print a stable plan without network or writes
  --help                 show this help`);
  process.exit(0);
}
const through = Number(values.get("--through"));
require(Number.isInteger(through) && through >= 1 && through <= 30, "--through must be in 1..30");
const expectationsPath = lanePath(values.get("--expectations") || "scripts/bgk_reader_expectations_v1.json");
const expectations = JSON.parse(readFileSync(expectationsPath, "utf8"));
require(expectations.schema === "ag-bridge-bgk-reader-expectations-v1", "expectations schema");
const unit = expectations.units.find((row) => row.unit === through);
require(unit, `expectations lack Unit ${through}`);
const defaultAnchor = expectations.terminal_surface?.unit === through
  ? expectations.terminal_surface.deep_anchor
  : `br-bgk-2019-w${String(through).padStart(2, "0")}-ex${String(unit.exercise_count).padStart(2, "0")}`;
const deepAnchor = values.get("--deep-anchor") || defaultAnchor;
require(deepAnchor.length > 0, "deep anchor is empty");

const endpoint = values.get("--cdp-endpoint") || "http://127.0.0.1:9229";
const expectedUrl = values.get("--reader-url") || "http://127.0.0.1:18765/index.html";
const htmlPath = lanePath(values.get("--html") || "build/reader-bgk-id/index.html");
const machinePath = lanePath(
  values.get("--machine-qa") || `qa/BGK_UNITS_01_${String(through).padStart(2, "0")}_READER_QA.json`,
);
const screenshotDir = lanePath(values.get("--screenshot-dir") || "qa");
const outputPath = lanePath(
  values.get("--output-measured")
    || `qa/BGK_UNITS_01_${String(through).padStart(2, "0")}_RESPONSIVE_MEASURED.json`,
);
const timeoutMs = Number(values.get("--timeout-ms") || "10000");
const settleMs = Number(values.get("--settle-ms") || "500");
require(Number.isInteger(timeoutMs) && timeoutMs > 0, "invalid timeout");
require(Number.isInteger(settleMs) && settleMs >= 0, "invalid settle delay");
const suffix = String(through).padStart(2, "0");
const screenshotPaths = {
  desktop: resolve(screenshotDir, `bgk-units-01-${suffix}-responsive-desktop.png`),
  mobile: resolve(screenshotDir, `bgk-units-01-${suffix}-responsive-mobile.png`),
  deep: resolve(screenshotDir, `bgk-units-01-${suffix}-responsive-deep-unit-${suffix}.png`),
};

const plan = {
  status: "PASS_DRY_RUN",
  through_unit: through,
  endpoint,
  reader_url: expectedUrl,
  html: relative(ROOT, htmlPath).replaceAll("\\", "/"),
  machine_qa: relative(ROOT, machinePath).replaceAll("\\", "/"),
  expectations: fact(expectationsPath),
  deep_anchor: deepAnchor,
  screenshots: Object.fromEntries(
    Object.entries(screenshotPaths).map(([key, path]) => [key, relative(ROOT, path).replaceAll("\\", "/")]),
  ),
  output_measured: relative(ROOT, outputPath).replaceAll("\\", "/"),
};
if (flags.has("--dry-run")) {
  console.log(JSON.stringify(plan));
  process.exit(0);
}

require(typeof fetch === "function", "Node runtime lacks global fetch");
require(typeof WebSocket === "function", "Node runtime lacks global WebSocket");
const machine = JSON.parse(readFileSync(machinePath, "utf8"));
require(machine.status === "PASS" && machine.through_unit === through, "machine QA is not final PASS for this scope");
const html = fact(htmlPath);
const machineHtml = machine.outputs.find((row) => row.path === html.path);
require(machineHtml && machineHtml.bytes === html.bytes && machineHtml.sha256 === html.sha256, "machine QA HTML binding drift");
if (!flags.has("--replace")) {
  require(!Object.values(screenshotPaths).some((path) => {
    try { statSync(path); return true; } catch { return false; }
  }), "responsive screenshot already exists; use --replace");
  try { statSync(outputPath); throw new Error("measured receipt already exists; use --replace"); } catch (error) {
    if (!String(error.message).includes("ENOENT") && String(error.message).includes("already exists")) throw error;
  }
}
mkdirSync(screenshotDir, { recursive: true });
mkdirSync(dirname(outputPath), { recursive: true });

const tabs = await (await fetch(`${endpoint}/json/list`)).json();
const target = tabs.find((tab) => tab.type === "page" && tab.url.startsWith(expectedUrl));
if (!target?.webSocketDebuggerUrl) throw new Error(`No CDP page target for ${expectedUrl}`);
const socket = new WebSocket(target.webSocketDebuggerUrl);
const pending = new Map();
const eventWaiters = new Map();
let sequence = 0;

socket.addEventListener("message", (event) => {
  const message = JSON.parse(event.data);
  if (message.id && pending.has(message.id)) {
    const { resolve: done, reject } = pending.get(message.id);
    pending.delete(message.id);
    if (message.error) reject(new Error(JSON.stringify(message.error)));
    else done(message.result);
    return;
  }
  const waiters = eventWaiters.get(message.method) || [];
  eventWaiters.delete(message.method);
  for (const done of waiters) done(message.params || {});
});
await new Promise((done, reject) => {
  socket.addEventListener("open", done, { once: true });
  socket.addEventListener("error", reject, { once: true });
});

function call(method, params = {}) {
  const id = ++sequence;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((done, reject) => pending.set(id, { resolve: done, reject }));
}

function waitEvent(method) {
  return new Promise((done, reject) => {
    const timer = setTimeout(() => reject(new Error(`Timed out waiting for ${method}`)), timeoutMs);
    const wrapped = (value) => { clearTimeout(timer); done(value); };
    const waiters = eventWaiters.get(method) || [];
    waiters.push(wrapped);
    eventWaiters.set(method, waiters);
  });
}

const expression = String.raw`(() => {
  const de = document.documentElement;
  const body = document.body;
  const main = document.querySelector('main');
  const mainRect = main.getBoundingClientRect();
  const ids = [...document.querySelectorAll('[id]')].map((node) => node.id);
  const duplicateIds = ids.filter((value, index) => ids.indexOf(value) !== index);
  const anchors = [...document.querySelectorAll('a[href^="#"]')];
  const brokenAnchors = anchors.map((anchor) => decodeURIComponent(anchor.hash.slice(1)))
    .filter((id) => id && !document.getElementById(id));
  const overflowNodes = [...document.body.querySelectorAll('*')]
    .filter((node) => !node.matches('.skip-link'))
    .map((node) => {
      const rect = node.getBoundingClientRect();
      return {
        tag: node.tagName.toLowerCase(), id: node.id || null,
        classes: typeof node.className === 'string' ? node.className : '',
        left: Number(rect.left.toFixed(2)), right: Number(rect.right.toFixed(2)),
        width: Number(rect.width.toFixed(2)),
        protectedByLocalScroll: Boolean(node.closest('math[display="block"], pre, table, div.column')),
      };
    }).filter((row) => row.width > 0 && (row.left < -0.5 || row.right > de.clientWidth + 0.5));
  const localScrollNodes = [...document.querySelectorAll('math[display="block"], pre, table, div.column')]
    .filter((node) => node.scrollWidth > node.clientWidth + 1)
    .map((node) => ({tag: node.tagName.toLowerCase(), id: node.id || null,
      clientWidth: node.clientWidth, scrollWidth: node.scrollWidth}));
  return {
    title: document.title,
    viewport: {innerWidth, innerHeight, clientWidth: de.clientWidth, scrollWidth: de.scrollWidth,
      bodyScrollWidth: body.scrollWidth, documentHorizontalOverflow: de.scrollWidth > de.clientWidth + 1},
    main: {left: Number(mainRect.left.toFixed(2)), right: Number(mainRect.right.toFixed(2)),
      width: Number(mainRect.width.toFixed(2)),
      centeringDelta: Number((((mainRect.left + mainRect.right) / 2) - de.clientWidth / 2).toFixed(2))},
    counts: {main: document.querySelectorAll('main').length,
      skipLinks: document.querySelectorAll('.skip-link').length,
      mathml: document.querySelectorAll('math').length,
      images: document.querySelectorAll('img').length,
      missingAlt: document.querySelectorAll('img:not([alt])').length,
      ids: ids.length, duplicateIds: [...new Set(duplicateIds)].length,
      anchors: anchors.length, brokenAnchors: [...new Set(brokenAnchors)].length,
      headings: document.querySelectorAll('h1,h2,h3,h4,h5,h6').length,
      outsideViewportNodes: overflowNodes.length,
      unprotectedOutsideViewportNodes: overflowNodes.filter((row) => !row.protectedByLocalScroll).length,
      localHorizontalScrollNodes: localScrollNodes.length},
    outsideViewportNodes: overflowNodes.slice(0, 50),
    localHorizontalScrollNodes: localScrollNodes.slice(0, 50),
  };
})()`;

async function measure(name, width, height) {
  await call("Emulation.setDeviceMetricsOverride", { width, height, deviceScaleFactor: 1, mobile: false, screenWidth: width, screenHeight: height });
  const loaded = waitEvent("Page.loadEventFired");
  await call("Page.reload", { ignoreCache: true });
  await loaded;
  await new Promise((done) => setTimeout(done, settleMs));
  await call("Runtime.evaluate", { expression: "window.scrollTo(0, 0); true", returnByValue: true });
  const evaluated = await call("Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true });
  if (evaluated.exceptionDetails) throw new Error(JSON.stringify(evaluated.exceptionDetails));
  const screenshot = await call("Page.captureScreenshot", { format: "png", fromSurface: true, captureBeyondViewport: false });
  writeFileSync(screenshotPaths[name], Buffer.from(screenshot.data, "base64"));
  return { name, width, height, screenshot: fact(screenshotPaths[name]), ...evaluated.result.value };
}

await call("Page.enable");
await call("Runtime.enable");
const desktop = await measure("desktop", 1280, 720);
const mobile = await measure("mobile", 390, 844);
const deepResult = await call("Runtime.evaluate", { expression: `Boolean(document.getElementById(${JSON.stringify(deepAnchor)}))`, returnByValue: true });
require(deepResult.result.value === true, `missing deep anchor ${deepAnchor}`);
await call("Runtime.evaluate", { expression: `document.getElementById(${JSON.stringify(deepAnchor)}).scrollIntoView({block:'start'}); true`, returnByValue: true });
await new Promise((done) => setTimeout(done, Math.min(settleMs, 500)));
const deepScreenshot = await call("Page.captureScreenshot", { format: "png", fromSurface: true, captureBeyondViewport: false });
writeFileSync(screenshotPaths.deep, Buffer.from(deepScreenshot.data, "base64"));
socket.close();

for (const surface of [desktop, mobile]) {
  require(surface.title === titleFor(through), `${surface.name} title drift`);
  require(!surface.viewport.documentHorizontalOverflow, `${surface.name} document overflow`);
  require(Math.abs(surface.main.centeringDelta) <= 0.5, `${surface.name} main not centered`);
  require(surface.counts.main === 1 && surface.counts.skipLinks === 1, `${surface.name} landmark closure`);
  require(surface.counts.missingAlt === 0 && surface.counts.duplicateIds === 0 && surface.counts.brokenAnchors === 0, `${surface.name} accessibility/anchor closure`);
  require(surface.counts.unprotectedOutsideViewportNodes === 0, `${surface.name} unprotected clipping`);
}
require(desktop.main.width >= 960 && desktop.main.width <= 980, "desktop main-width contract");
require(mobile.main.width >= 340 && mobile.main.width <= 345, "mobile main-width contract");

const receipt = {
  schema: "ag-bridge-bgk-responsive-measurement-v2",
  through_unit: through,
  status: "PASS_MEASURED_SCREENSHOTS_PENDING_REVIEW",
  model_provenance: PROVENANCE,
  target: expectedUrl,
  endpoint,
  expectations: fact(expectationsPath),
  html,
  reader_machine_qa: fact(machinePath),
  desktop,
  mobile,
  deep_surface: { anchor: deepAnchor, screenshot: fact(screenshotPaths.deep) },
  checks: {
    desktop_centered_and_page_filling: true,
    mobile_reflow_without_document_overflow: true,
    no_unprotected_content_outside_viewport: true,
    skip_link_landmark_alt_id_and_anchor_closure: true,
    deep_surface_captured: true,
    screenshots_reviewed: false,
  },
};
const temporary = `${outputPath}.tmp`;
writeFileSync(temporary, JSON.stringify(receipt, null, 2) + "\n");
renameSync(temporary, outputPath);
console.log(JSON.stringify({ status: receipt.status, receipt: fact(outputPath) }));
