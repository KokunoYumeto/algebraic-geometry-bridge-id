#!/usr/bin/env python3
"""Bind deterministic raster closure and explicit visual review for a BGK reader."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODEL = "OpenAI Codex gpt-5.6-sol, Ultra."
REVIEW_PACKET_SCHEMAS = frozenset({
    "ag-bridge-bgk-visual-review-packet-v1",
    "ag-bridge-bgk-cumulative-visual-packet-v1",
})


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def lane_path(value: str) -> Path:
    raw = Path(value)
    path = raw.resolve() if raw.is_absolute() else (ROOT / raw).resolve()
    try:
        path.relative_to(ROOT)
    except ValueError as error:
        raise RuntimeError(f"path must remain inside the lane: {path}") from error
    return path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def fact(path: Path) -> dict[str, object]:
    require(path.is_file() and not path.is_symlink(), f"missing regular file: {path}")
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }


def parse_pages(value: str, page_count: int, label: str) -> list[int]:
    try:
        pages = [int(item) for item in value.split(",") if item.strip()]
    except ValueError as error:
        raise RuntimeError(f"invalid {label} page list") from error
    require(pages and len(set(pages)) == len(pages), f"{label} pages must be non-empty and unique")
    require(all(1 <= page <= page_count for page in pages), f"{label} page outside PDF")
    return pages


def replay(row: dict[str, object]) -> Path:
    path = lane_path(str(row["path"]))
    observed = fact(path)
    require(observed["bytes"] == row.get("bytes") and observed["sha256"] == row.get("sha256"), f"identity drift: {path}")
    return path


def _identity(row: dict[str, object]) -> dict[str, object]:
    return {key: row.get(key) for key in ("path", "bytes", "sha256")}


def _packet_pages(value: object, page_count: int, label: str) -> list[int]:
    require(isinstance(value, list) and bool(value), f"{label} missing")
    require(
        all(type(page) is int and 1 <= page <= page_count for page in value),
        f"{label} contains an invalid PDF page",
    )
    require(value == sorted(set(value)), f"{label} must be sorted and unique")
    return value


def required_surface_pages(machine: dict[str, object], through: int) -> list[int]:
    rows = machine.get("surface_pages")
    require(isinstance(rows, list) and len(rows) == through, "machine surface-page inventory")
    require([row.get("unit") for row in rows] == list(range(1, through + 1)), "machine surface units")
    values = [
        row.get(role) for row in rows
        for role in ("lecture", "worksheet", "solutions", "media_credits")
    ]
    require(all(type(page) is int for page in values), "machine surface page is not an integer")
    return sorted(set(values))


def validate_review_packets(
    paths: list[Path],
    *,
    pdf_fact: dict[str, object],
    contact_manifest_fact: dict[str, object],
    machine_fact: dict[str, object],
    page_count: int,
    page_rows: list[dict[str, object]],
    contact_rows: list[dict[str, object]],
    required_full_size_pages: list[int],
    required_transition_pages: list[int],
) -> dict[str, object]:
    """Replay an exhaustive disjoint union of independently viewed packets.

    This validates evidence and coverage, not the truth of a fresh visual
    inspection. The original reviewers' signed model/provenance and findings
    remain bound in their immutable packet files.
    """
    require(paths and len(paths) == len(set(paths)), "review packets must be unique")
    expected_pages = {row["page"]: row for row in page_rows}
    expected_contacts = {row["path"]: row for row in contact_rows}
    require(len(expected_pages) == page_count, "packet validator page inventory")
    require(len(expected_contacts) == len(contact_rows), "duplicate contact inventory")
    covered_union: set[int] = set()
    full_size_union: set[int] = set()
    viewed_contact_paths: set[str] = set()
    packet_facts: list[dict[str, object]] = []
    summaries: list[dict[str, object]] = []
    for path in paths:
        packet_fact = fact(path)
        data = path.read_bytes()
        require(hashlib.sha256(data).hexdigest() == packet_fact["sha256"], "packet changed during read")
        packet = json.loads(data)
        require(packet.get("schema") in REVIEW_PACKET_SCHEMAS, "unsupported visual packet schema")
        require(packet.get("status") == "PASS", "review packet is not PASS")
        require(packet.get("model_provenance") == MODEL, "review packet Codex model provenance")
        require(packet.get("defect_count") == 0 and packet.get("findings", []) == [], "review packet has defects/findings")
        checks = packet.get("checks")
        require(isinstance(checks, dict) and checks and all(value == "PASS" or value is True for value in checks.values()), "review packet checks are not all PASS")
        for key, expected in (
            ("pdf", pdf_fact), ("contact_manifest", contact_manifest_fact),
            ("reader_qa", machine_fact),
        ):
            row = packet.get(key)
            require(isinstance(row, dict) and _identity(row) == _identity(expected), f"review packet {key} binding")
            replay(row)
        count_keys = [key for key in ("pages", "page_count") if key in packet["pdf"]]
        require(count_keys and all(type(packet["pdf"][key]) is int and packet["pdf"][key] == page_count for key in count_keys), "review packet PDF page count")
        covered = _packet_pages(packet.get("covered_pages"), page_count, "packet covered_pages")
        full_size = _packet_pages(packet.get("full_size_pages"), page_count, "packet full_size_pages")
        require(set(full_size) <= set(covered), "full-size page outside packet coverage")
        require(not covered_union.intersection(covered), "overlapping review packet coverage")
        if "full_size_page_count" in packet:
            require(packet["full_size_page_count"] == len(full_size), "packet full-size count drift")
        for key in ("required_surface_pages", "required_full_size_pages"):
            if key in packet:
                required = _packet_pages(packet[key], page_count, f"packet {key}")
                require(set(required) <= set(full_size), "packet required surface not inspected full-size")

        contact_keys = [key for key in ("viewed_contact_facts", "viewed_contacts") if key in packet]
        require(len(contact_keys) == 1, "packet must have one unambiguous viewed-contact inventory")
        contacts = packet[contact_keys[0]]
        require(isinstance(contacts, list) and contacts, "packet viewed contacts missing")
        contact_coverage: list[int] = []
        for row in contacts:
            expected = expected_contacts.get(row.get("path"))
            require(expected is not None and _identity(row) == _identity(expected), "packet contact identity")
            require(row.get("pages") == expected["pages"], "packet contact page-range drift")
            require(row.get("status", "PASS") == "PASS", "packet contact is not PASS")
            require(
                row.get("visually_viewed") is True or row.get("viewed") == "original image"
                or (row.get("viewed") is True and row.get("view_detail") == "original"),
                "packet contact lacks explicit visual-view evidence",
            )
            require(row["path"] not in viewed_contact_paths, "overlapping packet contact")
            replay(row)
            viewed_contact_paths.add(row["path"])
            start, end = row["pages"]
            contact_coverage.extend(range(start, end + 1))
        require(sorted(contact_coverage) == covered, "packet contact coverage differs from covered_pages")

        viewed_pages = packet.get("viewed_page_facts")
        require(isinstance(viewed_pages, list), "packet full-size page facts missing")
        observed_full_size: list[int] = []
        for row in viewed_pages:
            number = row.get("page")
            require(type(number) is int, "packet page number is not an integer")
            expected = expected_pages.get(number)
            require(expected is not None and _identity(row) == _identity(expected), "packet page identity")
            require(row.get("status", "PASS") == "PASS", "packet page is not PASS")
            require(
                row.get("visually_viewed_full_size") is True
                or row.get("viewed") == "original image at native size"
                or (row.get("viewed") is True and row.get("view_detail") == "original"),
                "packet page lacks explicit full-size visual-view evidence",
            )
            replay(row)
            observed_full_size.append(number)
        require(sorted(observed_full_size) == full_size, "packet full-size facts differ from full_size_pages")
        covered_union.update(covered)
        full_size_union.update(full_size)
        packet_facts.append(packet_fact)
        summaries.append({
            "packet": packet_fact["path"],
            "schema": packet["schema"],
            "reviewer_model": packet["model_provenance"],
            "covered_pages": covered,
            "full_size_pages": full_size,
            "contact_sheets": [row["pages"] for row in contacts],
            "status": "PASS",
        })
    require(covered_union == set(range(1, page_count + 1)), "review packet coverage has gaps")
    require(viewed_contact_paths == set(expected_contacts), "review packets do not cover every contact sheet")
    required = set(required_full_size_pages) | set(required_transition_pages) | {1, page_count}
    require(required <= full_size_union, f"required full-size/transition pages missing: {sorted(required - full_size_union)}")
    return {
        "status": "PASS",
        "packet_facts": packet_facts,
        "packet_reviews": summaries,
        "covered_pages": sorted(covered_union),
        "full_size_pages": sorted(full_size_union),
        "transition_pages": sorted(set(required_transition_pages)),
        "contact_sheets": [row["pages"] for row in contact_rows],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--through", type=int, required=True)
    parser.add_argument("--pdf", required=True)
    parser.add_argument("--render-dir", required=True)
    parser.add_argument("--page-count", type=int, required=True)
    parser.add_argument("--build-receipt", required=True)
    parser.add_argument("--machine-qa", required=True)
    parser.add_argument("--responsive-qa", required=True)
    parser.add_argument("--contact-manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--full-size-pages", default="1")
    parser.add_argument("--transition-pages", default="1")
    parser.add_argument("--render-dpi", type=int, default=110)
    parser.add_argument("--width-px", type=int, default=910)
    parser.add_argument("--height-px", type=int, default=1287)
    parser.add_argument("--blank-gray-threshold", type=int, default=248)
    parser.add_argument("--minimum-ink-fraction", type=float, default=0.001)
    parser.add_argument("--reviewer-model", default=MODEL)
    parser.add_argument("--review-packet", action="append", default=[], metavar="PATH")
    parser.add_argument("--approve", action="store_true")
    parser.add_argument("--replace", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    if not 1 <= args.through <= 30:
        parser.error("--through must be in 1..30")
    if args.page_count <= 0 or args.render_dpi <= 0 or args.width_px <= 0 or args.height_px <= 0:
        parser.error("page count, DPI, width, and height must be positive")
    if not 1 <= args.blank_gray_threshold <= 255:
        parser.error("--blank-gray-threshold must be in 1..255")
    if not 0 < args.minimum_ink_fraction < 1:
        parser.error("--minimum-ink-fraction must be in (0,1)")

    pdf = lane_path(args.pdf)
    render = lane_path(args.render_dir)
    build_receipt = lane_path(args.build_receipt)
    machine_path = lane_path(args.machine_qa)
    responsive_path = lane_path(args.responsive_qa)
    contact_path = lane_path(args.contact_manifest)
    output = lane_path(args.output)
    review_packet_paths = [lane_path(value) for value in args.review_packet]
    full_size_pages = parse_pages(args.full_size_pages, args.page_count, "full-size")
    transition_pages = parse_pages(args.transition_pages, args.page_count, "transition")
    page_digits = max(3, len(str(args.page_count)))
    plan = {
        "status": "PASS_DRY_RUN",
        "through_unit": args.through,
        "pdf": pdf.relative_to(ROOT).as_posix(),
        "render_dir": render.relative_to(ROOT).as_posix(),
        "page_count": args.page_count,
        "page_digits": page_digits,
        "full_size_pages": full_size_pages,
        "transition_pages": transition_pages,
        "bindings": [
            path.relative_to(ROOT).as_posix()
            for path in (build_receipt, machine_path, responsive_path, contact_path)
        ],
        "output": output.relative_to(ROOT).as_posix(),
        "required_explicit_flag": "--approve",
    }
    if review_packet_paths:
        plan["review_packets"] = [path.relative_to(ROOT).as_posix() for path in review_packet_paths]
        plan["review_mode"] = "delegated Codex inspection; --approve follows invoker review of packet results"
    if args.dry_run:
        print(json.dumps(plan, ensure_ascii=False, sort_keys=True))
        return 0

    require(args.approve, "explicit --approve is required after visual inspection")
    require(args.reviewer_model.strip(), "reviewer model must be non-empty")
    from PIL import Image, __version__ as pillow_version
    from pypdf import PdfReader

    build_data = json.loads(build_receipt.read_text(encoding="utf-8"))
    machine = json.loads(machine_path.read_text(encoding="utf-8"))
    responsive = json.loads(responsive_path.read_text(encoding="utf-8"))
    contacts = json.loads(contact_path.read_text(encoding="utf-8"))
    require(build_data.get("through_unit") == args.through, "build receipt scope")
    require(machine.get("status") == "PASS" and machine.get("through_unit") == args.through, "machine QA scope/status")
    require(responsive.get("status") == "PASS" and responsive.get("through_unit") == args.through, "responsive QA scope/status")
    require(contacts.get("status") == "PASS" and contacts.get("through_unit") == args.through, "contact manifest scope/status")
    require(contacts.get("page_count") == args.page_count, "contact page count")

    pdf_fact = fact(pdf)
    build_pdf = next((row for row in build_data.get("outputs", []) if row.get("path") == pdf_fact["path"]), None)
    machine_pdf = next((row for row in machine.get("outputs", []) if row.get("path") == pdf_fact["path"]), None)
    require(build_pdf == pdf_fact and machine_pdf == pdf_fact, "PDF is not identically bound upstream")
    reader = PdfReader(str(pdf), strict=True)
    require(len(reader.pages) == args.page_count, "PDF page-count drift")
    boxes = {
        (round(float(page.mediabox.width), 2), round(float(page.mediabox.height), 2))
        for page in reader.pages
    }
    require(boxes == {(595.28, 841.89)}, f"PDF page boxes: {boxes}")

    expected_names = [f"page-{number:0{page_digits}d}.png" for number in range(1, args.page_count + 1)]
    pages = sorted(render.glob("page-*.png"))
    require([path.name for path in pages] == expected_names, "page raster sequence is not exact and contiguous")
    page_rows: list[dict[str, object]] = []
    raster_set = hashlib.sha256()
    for number, path in enumerate(pages, start=1):
        row = fact(path)
        raster_set.update(f"{row['path']}\0{row['bytes']}\0{row['sha256']}\n".encode("utf-8"))
        with Image.open(path) as image:
            require(image.size == (args.width_px, args.height_px), f"raster dimensions on page {number}")
            gray = image.convert("L")
            histogram = gray.histogram()
            visible_fraction = sum(histogram[: args.blank_gray_threshold]) / (gray.width * gray.height)
        require(visible_fraction > args.minimum_ink_fraction, f"apparently blank page: {number}")
        row.update(
            {
                "page": number,
                "width_px": args.width_px,
                "height_px": args.height_px,
                "visible_ink_fraction": round(visible_fraction, 8),
                "gray_threshold": args.blank_gray_threshold,
            }
        )
        page_rows.append(row)
    require(raster_set.hexdigest() == contacts.get("page_raster_set_sha256"), "contact manifest raster-set drift")

    contact_rows = contacts.get("contact_sheets")
    require(isinstance(contact_rows, list) and contact_rows, "contact-sheet inventory missing")
    covered: list[int] = []
    for row in contact_rows:
        replay(row)
        start, end = row["pages"]
        covered.extend(range(int(start), int(end) + 1))
    require(covered == list(range(1, args.page_count + 1)), "contact-sheet coverage is not exact")

    packet_review = None
    if review_packet_paths:
        packet_review = validate_review_packets(
            review_packet_paths,
            pdf_fact=pdf_fact,
            contact_manifest_fact=fact(contact_path),
            machine_fact=fact(machine_path),
            page_count=args.page_count,
            page_rows=page_rows,
            contact_rows=contact_rows,
            required_full_size_pages=full_size_pages,
            required_transition_pages=sorted(
                set(transition_pages) | set(required_surface_pages(machine, args.through))
            ),
        )

    payload = {
        "schema": "ag-bridge-bgk-visual-qa-v2",
        "through_unit": args.through,
        "status": "PASS",
        "model_provenance": MODEL,
        "pdf": {
            **pdf_fact,
            "pages_rendered": args.page_count,
            "paper": "A4",
            "render_dpi": args.render_dpi,
            "page_pixel_dimensions": {"width": args.width_px, "height": args.height_px},
        },
        "pillow": pillow_version,
        "bound_build_receipt": fact(build_receipt),
        "bound_machine_qa": fact(machine_path),
        "bound_responsive_qa": fact(responsive_path),
        "bound_contact_manifest": fact(contact_path),
        "page_rasters": page_rows,
        "contact_sheets": contact_rows,
        "review": {
            "decision": "PASS",
            "reviewer_model": args.reviewer_model,
            "invocation_contract": "The invoker reviewed every contact sheet and the listed full-size pages before supplying --approve.",
            "contact_sheets_reviewed_in_full": [row["pages"] for row in contact_rows],
            "full_size_pages_reviewed": full_size_pages,
            "transition_pages_reviewed": transition_pages,
            "checks": {
                "all_pages_present_and_legible": "PASS",
                "unit_transitions_and_terminal_surface": "PASS",
                "headings_paragraphs_math_and_notes_not_clipped": "PASS",
                "figures_and_captions_visible": "PASS",
                "no_overlap_or_broken_glyphs_observed": "PASS",
            },
        },
        "defect_counts": {
            "visible_clipping": 0,
            "visible_overlap": 0,
            "visible_broken_glyph": 0,
            "visible_broken_equation": 0,
            "unintended_blank_page": 0,
            "total": 0,
        },
    }
    if packet_review is not None:
        payload["bound_review_packets"] = packet_review["packet_facts"]
        payload["review"].update({
            "inspection_mode": "delegated_codex_review_packets",
            "invocation_contract": (
                "Independent Codex reviewers inspected every contact sheet and "
                "the full-size pages recorded in the bound review packets. "
                "The invoking Codex reviewed those results before supplying "
                "--approve; this does not claim that the invoker personally "
                "viewed every PDF page. Browser inspection is separately bound "
                "by the responsive QA receipt."
            ),
            "contact_sheets_reviewed_in_full": packet_review["contact_sheets"],
            "full_size_pages_reviewed": packet_review["full_size_pages"],
            "transition_pages_reviewed": packet_review["transition_pages"],
            "pages_reviewed_via_contacts": packet_review["covered_pages"],
            "delegated_packet_reviews": packet_review["packet_reviews"],
        })
    if output.exists() and not args.replace:
        raise RuntimeError(f"output already exists; use --replace explicitly: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    temporary.replace(output)
    print(json.dumps({"status": "PASS", "receipt": fact(output)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
