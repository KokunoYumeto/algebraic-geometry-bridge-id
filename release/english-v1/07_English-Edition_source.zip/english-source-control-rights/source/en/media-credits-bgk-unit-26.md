# Media credits for BGK Unit 26 {#br-bgk-2019-media-credits-unit-26}

Course source: **Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)**, Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Vorlesung 26 and Kurs:Bündel, Garben und Kohomologie (Osnabrück 2019-2020)/Arbeitsblatt 26.

This unit has no substantive reader media positions, so there are no component captions or alternative texts to add. The two official PDF files appearing in the parsed output are frozen solely as authority witnesses; their identities, attributions, licences, revisions, sizes, and hashes are recorded in the asset closure, not as reader media.
