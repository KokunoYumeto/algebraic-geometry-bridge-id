"""Freeze a verifiable English release-input binding without publishing it.

This tool consumes only the already-complete English HTML/PDF/backend outputs
and their named source-bound QA receipts.  It writes six compact release QA
binders and one exact packager configuration.  The candidate packager remains
the only tool that creates a release directory or release artifacts.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import socket
import sys
import threading
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Iterator

from playwright.sync_api import sync_playwright

import package_release_en as package
import reader_common_en as common


ROOT = Path(__file__).resolve().parents[2]
MODEL = "OpenAI Codex gpt-5.6-sol, Ultra."
RELEASE_ID = "en-v1.0.0"
HTML_BUILD = "build/english/html-en-v6"
STANDALONE_BUILD = "build/english/standalone-en-v1.0.0"
PDF_RECEIPT = "build/english/pdf/DOUBLE_BUILD_all.json"
INTEGRATION = "qa/english/TRANSLATION_INTEGRATION_QA.json"
MACHINE = "qa/english/reader-qa-en-v1/MACHINE_QA.json"
RESPONSIVE = "qa/english/reader-qa-en-v1/RESPONSIVE_QA.json"
VISUAL = "qa/english/reader-qa-en-v1/VISUAL_QA.json"
METADATA = "00_control/english/RELEASE_METADATA_EN.json"
METADATA_REVIEW = "qa/english/RELEASE_METADATA_REVIEW.json"
README = "00_control/english/RELEASE_README_EN.md"
OUTPUT_DIRECTORY = "qa/english/release-bindings-en-v1.0.0-r2"
CONFIG_PATH = "00_control/english/RELEASE_BINDINGS_EN_V2.json"
BACKEND_ROOT = "backend/english/release-en-v1.0.0"
BOOKS = ("ak", "bgk", "companion")


class BindingError(RuntimeError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise BindingError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def safe(relative: str) -> Path:
    path = (ROOT / relative).resolve()
    require(path.is_relative_to(ROOT.resolve()) and path.is_file(), f"Missing regular input: {relative}")
    return path


def fact(relative: str) -> dict[str, Any]:
    data = safe(relative).read_bytes()
    return {"path": relative, "bytes": len(data), "sha256": sha(data)}


def relative_fact(path: Path) -> dict[str, Any]:
    relative = path.resolve().relative_to(ROOT.resolve()).as_posix()
    return fact(relative)


def embedded_facts(value: Any) -> Iterator[dict[str, Any]]:
    if isinstance(value, dict):
        if {"path", "bytes", "sha256"}.issubset(value):
            if isinstance(value["path"], str) and type(value["bytes"]) is int and isinstance(value["sha256"], str):
                yield {key: value[key] for key in ("path", "bytes", "sha256")}
        for child in value.values():
            yield from embedded_facts(child)
    elif isinstance(value, list):
        for child in value:
            yield from embedded_facts(child)


def load_receipt(relative: str, schema: str) -> tuple[dict[str, Any], dict[str, Any]]:
    data = safe(relative).read_bytes()
    document = json.loads(data)
    require(document.get("schema") == schema and document.get("status") == "PASS",
            f"QA receipt is not a PASS {schema}: {relative}")
    language = document.get("language")
    require(language in (None, "en"), f"QA receipt language drifted: {relative}")
    return document, {"path": relative, "bytes": len(data), "sha256": sha(data)}


def contains_fact(document: dict[str, Any], target: dict[str, Any], *aliases: str) -> bool:
    accepted = {target["path"], *aliases}
    return any(row["path"] in accepted and row["bytes"] == target["bytes"] and row["sha256"] == target["sha256"]
               for row in embedded_facts(document))


def require_receipt_binding(document: dict[str, Any], target: dict[str, Any], *aliases: str) -> None:
    require(contains_fact(document, target, *aliases),
            "Receipt lacks exact bound target: " + target["path"])


def archive_fact(relative: str, archive_path: str) -> dict[str, Any]:
    result = fact(relative)
    result["archive_path"] = archive_path
    return result


def chrome_path() -> Path:
    candidates = (
        Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
        Path(r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"),
        Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
        Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
    )
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    raise BindingError("No installed Chromium-family executable is available for standalone QA")


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, format: str, *args: object) -> None:
        return


def observe_standalone() -> dict[str, Any]:
    root = (ROOT / STANDALONE_BUILD).resolve()
    handler = partial(QuietHandler, directory=str(root))
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    worker = threading.Thread(target=server.serve_forever, daemon=True)
    worker.start()
    port = int(server.server_address[1])
    executable = chrome_path()
    records: list[dict[str, Any]] = []
    try:
        with sync_playwright() as runtime:
            browser = runtime.chromium.launch(headless=True, executable_path=str(executable))
            try:
                for name, width, height in (("desktop", 1440, 1000), ("tablet", 768, 1024), ("mobile", 390, 844)):
                    for book in ("ak", "bgk"):
                        context = browser.new_context(viewport={"width": width, "height": height}, device_scale_factor=1)
                        page = context.new_page()
                        console_errors: list[str] = []
                        external_requests: list[str] = []
                        page.on("console", lambda message: console_errors.append(message.text)
                                if message.type == "error" else None)
                        page.on("request", lambda request: external_requests.append(request.url)
                                if not request.url.startswith((f"http://127.0.0.1:{port}/", "data:")) else None)
                        response = page.goto(f"http://127.0.0.1:{port}/{book}.html", wait_until="load", timeout=120_000)
                        require(response is not None and response.status == 200, f"Standalone browser load failed: {book}/{name}")
                        page.evaluate("document.fonts ? document.fonts.ready : Promise.resolve()")
                        page.wait_for_timeout(200)
                        observation = page.evaluate("""() => ({
                            docWidth: document.documentElement.scrollWidth,
                            clientWidth: document.documentElement.clientWidth,
                            imageCount: document.images.length,
                            badImages: [...document.images].filter(x => !x.complete || x.naturalWidth <= 0).length,
                            mathmlCount: document.querySelectorAll('math').length,
                            tableCount: document.querySelectorAll('table').length,
                            scriptCount: document.querySelectorAll('script').length,
                            localAnchorCount: [...document.querySelectorAll('a[href]')].filter(a => {
                                const h = a.getAttribute('href'); return h && !h.startsWith('#') && !/^[a-z][a-z0-9+.-]*:/i.test(h);
                            }).length,
                            bodyTextLength: (document.body.innerText || '').length
                        })""")
                        require(observation["docWidth"] <= observation["clientWidth"] + 1,
                                f"Standalone horizontal overflow: {book}/{name}")
                        require(observation["badImages"] == 0 and observation["mathmlCount"] > 0 and
                                observation["scriptCount"] == 0 and
                                observation["localAnchorCount"] == 0 and observation["bodyTextLength"] > 1000,
                                f"Standalone semantic/layout check failed: {book}/{name}")
                        require(not console_errors and not external_requests,
                                f"Standalone browser emitted errors or external dependencies: {book}/{name}")
                        records.append({"book": book, "viewport": {"name": name, "width": width, "height": height},
                                        "response_status": response.status, **observation})
                        context.close()
            finally:
                browser.close()
    finally:
        server.shutdown()
        server.server_close()
        worker.join(timeout=5)
    require(len(records) == 6, "Standalone observation coverage is incomplete")
    return {"observer": {"engine": "chromium-local", "headless": True, "executable": relative_fact(executable) if executable.is_relative_to(ROOT) else {"name": executable.name, "sha256": sha(executable.read_bytes()), "bytes": executable.stat().st_size}},
            "records": records, "checks": {"all_six_book_viewport_observations": True,
                                                "no_horizontal_overflow": True,
                                                "no_console_or_external_resource_errors": True,
                                                "images_mathml_table_layout_and_text_observed": True}}


def html_inputs() -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
    receipt = json.loads(safe(HTML_BUILD + "/build-receipt.json").read_bytes())
    require(receipt.get("schema") == "english-html-reader-build-v1" and receipt.get("status") == "PASS" and
            receipt.get("provenance") == MODEL, "English HTML build receipt is not the expected PASS boundary")
    rows = receipt.get("files")
    require(isinstance(rows, list) and len(rows) == 468, "English HTML inventory count drifted")
    result: list[dict[str, Any]] = []
    by_archive: dict[str, dict[str, Any]] = {}
    for row in rows:
        require(isinstance(row, dict) and set(row) == {"path", "bytes", "sha256"}, "Malformed HTML file fact")
        archive = row["path"]
        relative = HTML_BUILD + "/" + archive
        live = fact(relative)
        require(live["bytes"] == row["bytes"] and live["sha256"] == row["sha256"],
                "HTML receipt/file drift: " + archive)
        item = {**live, "archive_path": archive}
        result.append(item)
        by_archive[archive] = item
    require(len(by_archive) == len(result) and set(package.HTML_ENTRY_POINTS).issubset(by_archive),
            "HTML output lacks required entry points")
    return result, by_archive


def standalone_inputs() -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    receipt_relative = STANDALONE_BUILD + "/BUILD_RECEIPT.json"
    receipt = json.loads(safe(receipt_relative).read_bytes())
    require(receipt.get("schema") == "d100-en-standalone-html-build-v1" and receipt.get("status") == "PASS" and
            receipt.get("language") == "en" and receipt.get("model_provenance") == MODEL,
            "Standalone reader build is not the expected PASS boundary")
    outputs = receipt.get("outputs")
    require(isinstance(outputs, list) and len(outputs) == 2, "Standalone receipt lacks exactly two readers")
    result = {}
    for entry in outputs:
        live = fact(entry["path"])
        require(live == entry, "Standalone reader output drifted")
        name = Path(entry["path"]).name
        book = name.removesuffix(".html")
        require(book in {"ak", "bgk"} and book not in result, "Standalone reader name drifted")
        result[book] = live
    require(set(result) == {"ak", "bgk"}, "Standalone course closure drifted")
    return fact(receipt_relative), result


def backend_inputs(integration_fact: dict[str, Any]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    selected_by_lane: dict[str, dict[str, dict[str, Any]]] = {}
    for lane in ("classical", "bgk", "original"):
        prefix = BACKEND_ROOT + "/" + lane
        manifest_relative = prefix + "/MANIFEST.json"
        manifest = json.loads(safe(manifest_relative).read_bytes())
        require(manifest.get("schema") == "ag-bridge-english-backend-adapter-manifest-v1" and
                manifest.get("status") == "translated_final_frozen_adapter_checks_pass" and
                manifest.get("language") == "en" and manifest.get("model_provenance") == MODEL,
                "Final backend manifest drifted: " + lane)
        require(manifest.get("translation_integration_qa") == integration_fact,
                "Final backend lacks current integration QA binding: " + lane)
        rows = manifest.get("files")
        require(isinstance(rows, list) and rows, "Final backend lacks a file inventory: " + lane)
        names = {row["path"] for row in rows}
        require({"common.dataset.json", "record.schema.json", "records.jsonl"}.issubset(names),
                "Final backend lacks required surfaces: " + lane)
        selected_by_lane[lane] = {}
        for name in ("records.jsonl", "record.schema.json"):
            row = next(candidate for candidate in rows if candidate["path"] == name)
            relative = prefix + "/" + name
            live = fact(relative)
            require(live["bytes"] == row["bytes"] and live["sha256"] == row["sha256"],
                    "Final backend artifact drift: " + relative)
            selected_by_lane[lane][name] = live
            result.append({**live, "archive_path": lane + "/" + name})
        manifest_fact = fact(manifest_relative)
        selected_by_lane[lane]["MANIFEST.json"] = manifest_fact
        result.append({**manifest_fact, "archive_path": lane + "/MANIFEST.json"})
    index_relative = BACKEND_ROOT + "/index/common.dataset.json"
    index_manifest_relative = BACKEND_ROOT + "/index/MANIFEST.json"
    index = json.loads(safe(index_relative).read_bytes())
    index_manifest = json.loads(safe(index_manifest_relative).read_bytes())
    require(index.get("schema") == "d100-en-native-backend-index-v1" and index.get("status") == "PASS" and
            index.get("language") == "en" and index.get("model_provenance") == MODEL and
            index_manifest.get("schema") == "d100-en-compact-native-backend-manifest-v1" and
            index_manifest.get("status") == "PASS" and index_manifest.get("model_provenance") == MODEL,
            "Compact backend index is not the expected PASS boundary")
    indexed_lanes = {row.get("lane"): row for row in index.get("lanes", [])}
    for lane, selected in selected_by_lane.items():
        row = indexed_lanes.get(lane)
        require(isinstance(row, dict) and row.get("manifest") == selected["MANIFEST.json"] and
                row.get("record_schema") == selected["record.schema.json"] and
                row.get("records") == selected["records.jsonl"],
                "Compact backend index drifted: " + lane)
    for relative, archive in ((index_manifest_relative, "index/MANIFEST.json"),
                              (index_relative, "index/common.dataset.json")):
        result.append({**fact(relative), "archive_path": archive})
    archive_names = [row["archive_path"] for row in result]
    require(len(archive_names) == len(set(archive_names)), "Backend archive names collide")
    return sorted(result, key=lambda row: row["archive_path"])


def make_wrapper(schema: str, sources: list[dict[str, Any]], bindings: list[dict[str, Any]], checks: dict[str, Any]) -> bytes:
    return canonical({"schema": schema, "status": "PASS", "language": "en", "model_provenance": MODEL,
                      "source_receipts": sources, "bindings": bindings, "checks": checks})


def output_names(metadata: dict[str, Any]) -> list[str]:
    rows = metadata.get("reader_first_release_files")
    require(isinstance(rows, list) and len(rows) == 13, "Release metadata does not declare 13 files")
    names = [row.get("name") for row in rows]
    require(all(isinstance(name, str) for name in names), "Release metadata name drifted")
    return names


def freeze() -> dict[str, Any]:
    metadata = json.loads(safe(METADATA).read_bytes())
    require(metadata.get("schema") == "ag-bridge-english-release-metadata-contract-v1" and
            metadata.get("status") == "metadata_preparation_complete", "Release metadata is not current")
    names = output_names(metadata)
    release = metadata["work"]
    require(release.get("version") == RELEASE_ID and metadata.get("model_provenance", {}).get("exact_statement") == MODEL,
            "Release metadata version/provenance drifted")
    _, integration_fact = load_receipt(INTEGRATION, "d100-en-translation-integration-qa-v1")
    integration_doc = json.loads(safe(INTEGRATION).read_bytes())
    source_facts = [fact(path.relative_to(ROOT).as_posix())
                    for book in BOOKS for path in common.book_sources(book)]
    require(len(source_facts) == 274 and integration_doc.get("facts", {}).get("current_sources") == source_facts,
            "Integration receipt no longer binds exact English source closure")
    html_files, html_by_archive = html_inputs()
    standalone_receipt, standalone = standalone_inputs()
    machine_doc, machine_fact = load_receipt(MACHINE, "english-reader-machine-qa-v1")
    responsive_doc, responsive_fact = load_receipt(RESPONSIVE, "english-reader-responsive-qa-v1")
    visual_doc, visual_fact = load_receipt(VISUAL, "english-reader-visual-qa-v1")
    for item in html_files:
        require_receipt_binding(machine_doc, item, item["archive_path"])
    pdf_doc = json.loads(safe(PDF_RECEIPT).read_bytes())
    require(pdf_doc.get("schema") == "d100-en-pdf-double-build-v1" and pdf_doc.get("language") == "en" and
            pdf_doc.get("integration_qa") == integration_fact, "PDF double build receipt drifted")
    reader_rows: list[dict[str, Any]] = []
    reader_facts: list[dict[str, Any]] = []
    for book, name in zip(BOOKS, (names[0], names[2], names[4])):
        row = next((candidate for candidate in pdf_doc.get("books", []) if candidate.get("book") == book), None)
        require(isinstance(row, dict) and row.get("identical_pdf_bytes") is True and
                isinstance(row.get("a"), dict) and isinstance(row.get("b"), dict) and
                row["a"].get("bytes") == row["b"].get("bytes") and
                row["a"].get("sha256") == row["b"].get("sha256"),
                "PDF replay identity drifted: " + book)
        output = row["a"]
        require(fact(output["path"]) == output, "PDF artifact drifted: " + book)
        reader_rows.append({"book": book, "input": output, "output_name": name, "page_count": row["page_count"]})
        reader_facts.append(output)
        require_receipt_binding(machine_doc, output)
        single_pdf_receipt = fact("build/english/pdf/DOUBLE_BUILD_" + book + ".json")
        require_receipt_binding(visual_doc, single_pdf_receipt)
        single_pdf_document = json.loads(safe(single_pdf_receipt["path"]).read_bytes())
        single_book = next((candidate for candidate in single_pdf_document.get("books", [])
                            if candidate.get("book") == book), None)
        require(isinstance(single_book, dict) and single_book.get("a") == output and
                single_book.get("identical_pdf_bytes") is True,
                "Visual QA's bound PDF replay receipt drifted: " + book)
    backend_files = backend_inputs(integration_fact)
    browser_observation = observe_standalone()
    for item in standalone.values():
        require(Path(item["path"]).is_file(), "Standalone artifact vanished during observation")

    wrapper_specs = {
        "INTEGRATION_QA_BINDING.json": make_wrapper(
            "d100-en-release-integration-qa-binding-v1", [integration_fact], source_facts,
            {"full_274_source_closure_receipt_passed": True}),
        "HTML_QA_BINDING.json": make_wrapper(
            "d100-en-release-html-qa-binding-v1", [machine_fact, standalone_receipt],
            [*[{key: value for key, value in row.items() if key != "archive_path"} for row in html_files], *standalone.values()],
            {"full_offline_html_machine_qa_passed": True, "standalone_packager_validator_passed": True}),
        "PDF_QA_BINDING.json": make_wrapper(
            "d100-en-release-pdf-qa-binding-v1", [machine_fact, fact(PDF_RECEIPT)], reader_facts,
            {"three_pdf_double_replays_passed": True, "machine_pdf_diagnostics_passed": True}),
        "BACKEND_QA_BINDING.json": make_wrapper(
            "d100-en-release-backend-qa-binding-v1", [integration_fact],
            [{key: value for key, value in row.items() if key != "archive_path"} for row in backend_files],
            {"three_final_native_backend_manifests_passed": True, "current_integration_qa_bound": True,
             "all_manifest_artifacts_re_read": True}),
        "VISUAL_QA_BINDING.json": make_wrapper(
            "d100-en-release-visual-qa-binding-v1", [visual_fact], reader_facts,
            {"full_pdf_page_render_and_visual_qa_passed": True}),
        "RESPONSIVE_QA_BINDING.json": make_wrapper(
            "d100-en-release-responsive-qa-binding-v1", [responsive_fact, standalone_receipt],
            [*[{key: value for key, value in html_by_archive[name].items() if key != "archive_path"}
               for name in package.HTML_ENTRY_POINTS], *standalone.values()],
            {"full_offline_package_responsive_qa_passed": True, "standalone_headless_observation": browser_observation}),
    }
    output = ROOT / OUTPUT_DIRECTORY
    config_file = ROOT / CONFIG_PATH
    require(not output.exists() and not config_file.exists(), "Release bindings already exist; refusing overwrite")
    output.parent.mkdir(parents=True, exist_ok=True)
    from tempfile import TemporaryDirectory
    with TemporaryDirectory(prefix=".release-bindings-", dir=output.parent) as temporary:
        stage = Path(temporary)
        for name, data in wrapper_specs.items():
            path = stage / name
            path.write_bytes(data)
            require(path.read_bytes() == data, "Release QA binder write/readback mismatch: " + name)
        stage.rename(output)
    wrapper_facts = {name: fact(OUTPUT_DIRECTORY + "/" + name) for name in wrapper_specs}
    control_paths = ["00_control/english/RELEASE_README_EN.md", "00_control/english/TRANSLATION_PROGRESS.json"]
    control = [fact(path) for path in control_paths]
    rights_paths = sorted(package.expected_component_rights_paths()) + [metadata["licensing"]["original_companion_rights"]["path"]]
    rights = [fact(path) for path in rights_paths]
    reproducibility_paths = [
        "scripts/english/package_release_en.py", "scripts/english/prepare_release_bindings_en.py",
        "scripts/english/build_standalone_html_en.py", "scripts/english/build_html_en.py",
        "scripts/english/build_pdf_en.py", "scripts/english/verify_readers_en.py",
        "scripts/english/export_backend_en.py", "scripts/english/prepare_backend_inputs_en.py",
        "scripts/english/build_compact_backend_index_en.py", "scripts/english/reader_common_en.py",
    ]
    config = {
        "schema": package.CONFIG_SCHEMA,
        "release": {"id": RELEASE_ID, "title": release["title"], "language": "en", "model_provenance": MODEL},
        "release_metadata": {"input": fact(METADATA), "review": fact(METADATA_REVIEW)},
        "output_directory": "release/english/" + RELEASE_ID,
        "readers": reader_rows,
        "offline_html": {"output_name": names[5], "archive_prefix": "english-offline-html",
                         "entry_points": list(package.HTML_ENTRY_POINTS),
                         "promoted_readers": [
                             {"book": "ak", "input": standalone["ak"], "output_name": names[1]},
                             {"book": "bgk", "input": standalone["bgk"], "output_name": names[3]},
                         ], "files": html_files},
        "source_bundle": {"output_name": names[6], "archive_prefix": "english-source-control-rights",
                          "reader_sources": source_facts, "control": control, "rights": rights,
                          "reproducibility": [fact(path) for path in reproducibility_paths]},
        "backend_bundle": {"output_name": names[7], "archive_prefix": "english-backend", "files": backend_files},
        "license_and_component_rights": {"input": fact("LICENSE.md"), "output_name": names[8]},
        "readme": {"input": fact(README), "output_name": names[9]},
        "output_names": {"manifest": names[10], "checksums": names[11], "candidate_qa": names[12]},
        "receipts": {
            "integration_qa": {"input": wrapper_facts["INTEGRATION_QA_BINDING.json"],
                               "schema": "d100-en-release-integration-qa-binding-v1", "status": "PASS"},
            "html_qa": {"input": wrapper_facts["HTML_QA_BINDING.json"],
                        "schema": "d100-en-release-html-qa-binding-v1", "status": "PASS"},
            "pdf_qa": {"input": wrapper_facts["PDF_QA_BINDING.json"],
                       "schema": "d100-en-release-pdf-qa-binding-v1", "status": "PASS"},
            "backend_qa": {"input": wrapper_facts["BACKEND_QA_BINDING.json"],
                           "schema": "d100-en-release-backend-qa-binding-v1", "status": "PASS"},
            "visual_qa": {"input": wrapper_facts["VISUAL_QA_BINDING.json"],
                          "schema": "d100-en-release-visual-qa-binding-v1", "status": "PASS"},
            "responsive_qa": {"input": wrapper_facts["RESPONSIVE_QA_BINDING.json"],
                              "schema": "d100-en-release-responsive-qa-binding-v1", "status": "PASS"},
        },
    }
    config_data = canonical(config)
    with config_file.open("xb") as stream:
        stream.write(config_data)
    require(config_file.read_bytes() == config_data, "Release binding configuration readback mismatch")
    package.prepare(config_file, ROOT)
    return {"status": "PASS", "binding_config": fact(CONFIG_PATH),
            "qa_binders": [wrapper_facts[name] for name in sorted(wrapper_facts)],
            "standalone_browser_observation": browser_observation["checks"],
            "reader_count": len(reader_rows), "html_file_count": len(html_files),
            "backend_file_count": len(backend_files)}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true", help="Freeze a new release-binding boundary")
    args = parser.parse_args(argv)
    try:
        require(args.write, "Use --write to create the fresh, immutable binding boundary")
        print(json.dumps(freeze(), ensure_ascii=False, indent=2))
        return 0
    except (BindingError, OSError, UnicodeError, json.JSONDecodeError) as exc:
        print("English release binding preparation failed: " + str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
