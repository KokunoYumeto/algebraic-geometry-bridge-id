#!/usr/bin/env python3
"""Build a hash-bound, deterministic English release candidate.

The packager deliberately contains no mutable build hashes.  A caller supplies a
JSON binding document whose every input is a repository-relative
``path/bytes/sha256`` fact.  Verification and two complete in-memory renders
finish before ``--build`` creates one previously absent child of
``release/english``.  The tool never invokes a renderer, TeX, Git, a model, the
network, or a publication API.

Binding schema (``d100-en-release-bindings-v1``), abbreviated::

    {
      "release": {"id": "en-v1.0.0", "title": "...", "language": "en",
                  "model_provenance": "..."},
      "release_metadata": {"input": FACT, "review": FACT},
      "output_directory": "release/english/<id>",
      "readers": [
        {"book": "ak", "input": FACT, "output_name": "01_....pdf",
         "page_count": 1},
        ... bgk and companion ...
      ],
      "offline_html": {"output_name": "06_....zip", "archive_prefix": "...",
                       "entry_points": ["index.html", "ak.html", "bgk.html",
                                        "companion.html"],
                       "promoted_readers": [
                         {"book": "ak", "input": FACT,
                          "output_name": "02_....html"},
                         {"book": "bgk", "input": FACT,
                          "output_name": "04_....html"}],
                       "files": [ARCHIVE_FACT, ...]},
      "source_bundle": {"output_name": "07_....zip", "archive_prefix": "...",
                        "reader_sources": [FACT x 274], "control": [FACT, ...],
                        "rights": [FACT, ...], "reproducibility": [FACT, ...]},
      "backend_bundle": {"output_name": "08_....zip", "archive_prefix": "...",
                         "files": [ARCHIVE_FACT, ...]},
      "license_and_component_rights": {"input": FACT, "output_name": "09_....md"},
      "readme": {"input": FACT, "output_name": "10_README.md"},
      "output_names": {"manifest": "11_RELEASE_MANIFEST.json",
                       "checksums": "12_SHA256SUMS.txt",
                       "candidate_qa": "13_RELEASE_CANDIDATE_QA.json"},
      "receipts": {ROLE: {"input": FACT, "schema": "...", "status": "PASS"}, ...}
    }

``FACT`` contains exactly ``path``, ``bytes`` and ``sha256``.  An
``ARCHIVE_FACT`` adds ``archive_path`` and may add ``receipt_path`` when a build
receipt uses a path spelling different from both the live path and archive
path.  Required receipt roles are integration, HTML, PDF, backend, visual and
responsive QA.
"""

from __future__ import annotations

import argparse
import hashlib
from html.parser import HTMLParser
import io
import json
import os
from pathlib import Path, PurePosixPath
import posixpath
import re
import sys
from typing import Any, Iterator
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET
import zipfile


ROOT = Path(__file__).resolve().parents[2]
CONFIG_SCHEMA = "d100-en-release-bindings-v1"
ARCHIVE_SCHEMA = "d100-en-deterministic-archive-inventory-v1"
MANIFEST_SCHEMA = "d100-en-release-manifest-v1"
QA_SCHEMA = "d100-en-release-candidate-qa-v1"
MAX_RELEASE_BYTES = 500_000_000  # strict decimal 500 MB boundary
ZIP_TIME = (2026, 9, 4, 0, 0, 0)
ZIP_MODE = 0o100644
BOOKS = ("ak", "bgk", "companion")
HTML_ENTRY_POINTS = ("index.html", "ak.html", "bgk.html", "companion.html")
RECEIPT_ROLES = (
    "integration_qa",
    "html_qa",
    "pdf_qa",
    "backend_qa",
    "visual_qa",
    "responsive_qa",
)
REQUIRED_BACKEND_BASENAMES = {
    "MANIFEST.json",
    "common.dataset.json",
    "record.schema.json",
    "records.jsonl",
}
WINDOWS_RESERVED = {
    "con", "prn", "aux", "nul", *(f"com{n}" for n in range(1, 10)),
    *(f"lpt{n}" for n in range(1, 10)),
}
FORBIDDEN_TITLE = re.compile(
    r"(?i)(?:\b(?:TODO|TBD|FIXME|PLACEHOLDER|TTP)\b|"
    r"Translation\s+and\s+Transcription\s+Project)"
)
SECRET_NAME = re.compile(
    r"(?i)^(?:\.env(?:\..*)?|\.netrc|id_(?:rsa|dsa|ecdsa|ed25519)(?:\..*)?|"
    r"credentials?(?:\..*)?|secrets?(?:\..*)?|tokens?(?:\..*)?|"
    r"passwords?(?:\..*)?|cookies?(?:\..*)?|sessions?(?:\..*)?)$"
)
SECRET_PATTERNS = {
    "private key": re.compile(rb"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----"),
    "GitHub token": re.compile(rb"(?:gh[pousr]_|github_pat_)[A-Za-z0-9_]{20,}"),
    "AWS access key": re.compile(rb"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"),
    "bearer token": re.compile(
        rb"(?i)authorization\s*:\s*bearer\s+[A-Za-z0-9._~+/=-]{20,}"
    ),
    "assigned credential": re.compile(
        rb"(?i)(?:access[_-]?token|api[_-]?key|client[_-]?secret|password)"
        rb"\s*[:=]\s*[\"']?[A-Za-z0-9._~+/=-]{16,}"
    ),
    "Zenodo token": re.compile(
        rb"(?i)\bzenodo(?:[_-]?(?:access|api))?[_-]?token\b"
        rb"\s*[:=]\s*[\"']?[A-Za-z0-9._~+/=-]{32,}"
    ),
}
PROFILE_PATTERN = re.compile(
    rb"(?i)(?:[A-Z]:[\\/]+(?:Users|Documents and Settings)[\\/]+"
    rb"[^\\/\s\"']+|/(?:home|Users)/[^/\s\"']+)"
)


class PackageError(RuntimeError):
    """A closed release gate."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise PackageError(message)


def canonical(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def expected_reader_source_paths() -> list[str]:
    """The exact source order shared with ``reader_common_en.py`` (274 files)."""
    classical_credit_units = (1, *range(2, 10), *range(11, 31))
    mastery_units = (2, 3, 4, 5, 6, 7, 9, 10, 12, 13, 14, 15, 23, 24, 25, 26, 27)
    result = ["source/en/frontmatter-units-01-30.md"]
    result += [
        f"source/en/{stem}-{unit:02d}{suffix}.md"
        for unit in range(1, 31)
        for stem, suffix in (("lecture", ""), ("worksheet", ""), ("worksheet", "-solutions"))
    ]
    result += [
        "source/en/media-credits.md" if unit == 1
        else f"source/en/media-credits-unit-{unit:02d}.md"
        for unit in classical_credit_units
    ]
    result += [
        "source/en/bgk/frontmatter-bgk-units-01-30.md",
        "source/en/bgk/glossary-bgk-units-01-30.md",
    ]
    result += [
        f"source/en/bgk/{stem}-{unit:02d}{suffix}.md"
        for unit in range(1, 31)
        for stem, suffix in (("lecture", ""), ("worksheet", ""), ("worksheet", "-solutions"))
    ]
    result += [f"source/en/media-credits-bgk-unit-{unit:02d}.md" for unit in range(1, 31)]
    companion = ["frontmatter.md", "seam-varieties-to-schemes.md"]
    companion += [f"mastery-bgk-{unit:02d}.md" for unit in mastery_units]
    companion += [f"integrative-{unit:02d}.md" for unit in range(1, 13)]
    companion += ["stacks-navigation-capstone.md"]
    result += [f"source/en/bridge/{name}" for name in companion]
    require(len(result) == len(set(result)) == 274, "Internal English source closure is not 274 unique files")
    return result


def expected_component_rights_paths() -> set[str]:
    return {
        "authority/RIGHTS.csv",
        *(f"authority/RIGHTS-unit-{unit:02d}.csv" for unit in range(2, 31)),
        *(f"authority/RIGHTS-bgk-unit-{unit:02d}.csv" for unit in range(1, 31)),
    }


def normal_relative(value: Any, *, label: str) -> str:
    require(isinstance(value, str) and bool(value), f"{label} must be a nonempty POSIX relative path")
    require("\\" not in value and "\x00" not in value, f"Unsafe path spelling in {label}: {value!r}")
    path = PurePosixPath(value)
    require(not path.is_absolute() and value == path.as_posix(), f"Non-canonical path in {label}: {value!r}")
    require(all(part not in ("", ".", "..") for part in path.parts), f"Traversal in {label}: {value!r}")
    for part in path.parts:
        require(":" not in part and not part.endswith((" ", ".")), f"Non-portable path in {label}: {value!r}")
        stem = part.split(".", 1)[0].casefold()
        require(stem not in WINDOWS_RESERVED, f"Reserved path in {label}: {value!r}")
        require(not any(ord(char) < 32 or ord(char) == 127 for char in part),
                f"Control character in {label}: {value!r}")
    return path.as_posix()


def output_leaf(value: Any, suffix: str, *, label: str) -> str:
    name = normal_relative(value, label=label)
    require(len(PurePosixPath(name).parts) == 1, f"{label} must be a single filename")
    require(name.lower().endswith(suffix.lower()), f"Unexpected suffix in {label}: {name}")
    return name


def path_is_link_or_reparse(path: Path) -> bool:
    try:
        status = path.lstat()
    except FileNotFoundError:
        return False
    attributes = getattr(status, "st_file_attributes", 0)
    return path.is_symlink() or bool(attributes & 0x400)  # FILE_ATTRIBUTE_REPARSE_POINT


def safe_regular(root: Path, relative: str) -> Path:
    relative = normal_relative(relative, label="input path")
    root = root.resolve(strict=True)
    require(root.is_dir() and not path_is_link_or_reparse(root), "Repository root is not a real directory")
    path = root.joinpath(*PurePosixPath(relative).parts)
    try:
        path.resolve(strict=False).relative_to(root)
    except ValueError as exc:
        raise PackageError(f"Input escapes repository: {relative}") from exc
    current = root
    for part in PurePosixPath(relative).parts:
        current /= part
        if current.exists() or current.is_symlink():
            require(not path_is_link_or_reparse(current), f"Link/reparse input is forbidden: {relative}")
    require(path.is_file(), f"Missing regular input: {relative}")
    return path


def live_fact(root: Path, relative: str) -> dict[str, Any]:
    path = safe_regular(root, relative)
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            size += len(chunk)
            digest.update(chunk)
    return {"path": relative, "bytes": size, "sha256": digest.hexdigest()}


def validate_fact_shape(value: Any, *, label: str) -> dict[str, Any]:
    require(isinstance(value, dict) and set(value) == {"path", "bytes", "sha256"},
            f"{label} must contain exactly path/bytes/sha256")
    path = normal_relative(value["path"], label=f"{label} path")
    require(type(value["bytes"]) is int and 0 <= value["bytes"] < MAX_RELEASE_BYTES,
            f"Invalid byte count in {label}")
    require(isinstance(value["sha256"], str) and
            re.fullmatch(r"[0-9a-f]{64}", value["sha256"]) is not None,
            f"Invalid SHA-256 in {label}")
    return {"path": path, "bytes": value["bytes"], "sha256": value["sha256"]}


def reject_secret_name(name: str) -> None:
    for part in PurePosixPath(name).parts:
        require(SECRET_NAME.fullmatch(part) is None, f"Secret/profile filename is forbidden: {name}")
        require(Path(part).suffix.casefold() not in {".key", ".p12", ".pfx", ".pem"},
                f"Private-key filename is forbidden: {name}")


def reject_sensitive_bytes(name: str, value: bytes) -> None:
    reject_secret_name(name)
    for label, pattern in SECRET_PATTERNS.items():
        require(pattern.search(value) is None, f"Credential-like {label} in {name}")
    require(PROFILE_PATTERN.search(value) is None, f"Local user-profile path in {name}")
    profile = os.environ.get("USERPROFILE")
    if profile and len(profile) >= 4:
        normalized = profile.replace("\\", "/").encode("utf-8", errors="ignore")
        require(normalized.lower() not in value.replace(b"\\", b"/").lower(),
                f"Current user-profile path in {name}")


def bind_fact(root: Path, declared: Any, cache: dict[str, dict[str, Any]], *, label: str) -> dict[str, Any]:
    fact = validate_fact_shape(declared, label=label)
    reject_secret_name(fact["path"])
    cached = cache.get(fact["path"])
    if cached is not None:
        require(cached["fact"] == fact, f"Conflicting repeated binding: {fact['path']}")
        return cached
    current = live_fact(root, fact["path"])
    require(current == fact, f"Bound input drifted: {fact['path']}")
    data = safe_regular(root, fact["path"]).read_bytes()
    require(len(data) == fact["bytes"] and sha256(data) == fact["sha256"],
            f"Readback drifted: {fact['path']}")
    reject_sensitive_bytes(fact["path"], data)
    item = {"fact": fact, "data": data, "aliases": {fact["path"]}}
    cache[fact["path"]] = item
    return item


def bind_archive_fact(root: Path, declared: Any, cache: dict[str, dict[str, Any]], *, label: str) -> dict[str, Any]:
    require(isinstance(declared, dict) and set(declared) in (
        {"path", "bytes", "sha256", "archive_path"},
        {"path", "bytes", "sha256", "archive_path", "receipt_path"},
    ), f"{label} must add archive_path and only optional receipt_path to a file fact")
    item = dict(bind_fact(root, {key: declared[key] for key in ("path", "bytes", "sha256")}, cache,
                          label=label))
    archive_path = normal_relative(declared["archive_path"], label=f"{label} archive_path")
    aliases = set(item["aliases"])
    aliases.add(archive_path)
    if "receipt_path" in declared:
        aliases.add(normal_relative(declared["receipt_path"], label=f"{label} receipt_path"))
    item.update(archive_path=archive_path, aliases=aliases)
    return item


def embedded_facts(value: Any) -> Iterator[dict[str, Any]]:
    if isinstance(value, dict):
        if {"path", "bytes", "sha256"}.issubset(value):
            if (isinstance(value.get("path"), str) and type(value.get("bytes")) is int and
                    isinstance(value.get("sha256"), str)):
                yield {key: value[key] for key in ("path", "bytes", "sha256")}
        for nested in value.values():
            yield from embedded_facts(nested)
    elif isinstance(value, list):
        for nested in value:
            yield from embedded_facts(nested)


def all_keyed_strings(value: Any, keys: set[str]) -> Iterator[str]:
    if isinstance(value, dict):
        for key, nested in value.items():
            if key in keys and isinstance(nested, str):
                yield nested
            yield from all_keyed_strings(nested, keys)
    elif isinstance(value, list):
        for nested in value:
            yield from all_keyed_strings(nested, keys)


def receipt_binds(receipt: dict[str, Any], target: dict[str, Any]) -> bool:
    expected = target["fact"]
    aliases = target["aliases"]
    return any(
        row.get("path") in aliases and row.get("bytes") == expected["bytes"] and
        row.get("sha256") == expected["sha256"]
        for row in embedded_facts(receipt)
    )


def validate_receipt(role: str, item: dict[str, Any], document: dict[str, Any],
                     targets: list[dict[str, Any]], model: str) -> dict[str, Any]:
    expected_schema = item["schema"]
    expected_status = item["status"]
    require(document.get("schema") == expected_schema, f"{role} schema mismatch")
    require(document.get("status") == expected_status, f"{role} status mismatch")
    require(re.fullmatch(r"PASS(?:[A-Z0-9_-]*)", expected_status) is not None,
            f"{role} configured status is not a PASS status")
    if "language" in document:
        require(document["language"] == "en", f"{role} language is not English")
    provenances = list(all_keyed_strings(
        document, {"model_provenance", "provenance", "translation_provenance"}
    ))
    require(model in provenances, f"{role} does not carry exact model provenance")
    own = item["bound"]["fact"]
    checked = 0
    for target in targets:
        if target["fact"] == own:
            continue  # a receipt cannot hash-bind its own final bytes
        require(receipt_binds(document, target),
                f"{role} does not bind {target['fact']['path']} with an admitted path spelling")
        checked += 1
    return {"schema": expected_schema, "status": expected_status, "bound_target_count": checked}


class HTMLAudit(HTMLParser):
    def __init__(self, label: str) -> None:
        super().__init__(convert_charrefs=True)
        self.label = label
        self.ids: set[str] = set()
        self.refs: list[tuple[str, str, bool]] = []  # context, value, resource dependency
        self.lang: str | None = None
        self.in_style = False
        self.style_chunks: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.casefold()
        values = {key.casefold(): (value or "") for key, value in attrs}
        require(tag not in {"script", "iframe", "object", "embed", "base"},
                f"Active or base HTML element in {self.label}: {tag}")
        if tag == "html":
            self.lang = values.get("lang")
        identity = values.get("id")
        if identity:
            require(identity not in self.ids, f"Duplicate HTML id in {self.label}: {identity}")
            self.ids.add(identity)
        if tag == "img":
            require(bool(values.get("alt", "").strip()), f"Image lacks alt text in {self.label}")
        if tag == "meta" and values.get("http-equiv", "").casefold() == "refresh":
            raise PackageError(f"HTML refresh is forbidden in {self.label}")
        if tag == "a" and values.get("href"):
            self.refs.append(("a[href]", values["href"], False))
        resource_attributes = {
            "img": ("src", "srcset"), "link": ("href",), "source": ("src", "srcset"),
            "audio": ("src",), "video": ("src", "poster"), "track": ("src",),
            "input": ("src",),
        }
        for attribute in resource_attributes.get(tag, ()):
            if values.get(attribute):
                if attribute == "srcset":
                    raw = values[attribute]
                    candidates = [raw] if raw.lstrip().casefold().startswith("data:") else raw.split(",")
                    for candidate in candidates:
                        reference = candidate.strip().split()[0] if candidate.strip() else ""
                        if reference:
                            self.refs.append((f"{tag}[{attribute}]", reference, True))
                else:
                    self.refs.append((f"{tag}[{attribute}]", values[attribute], True))
        if values.get("style"):
            self.style_chunks.append(values["style"])
        if tag == "style":
            self.in_style = True

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)
        if tag.casefold() == "style":
            self.in_style = False

    def handle_endtag(self, tag: str) -> None:
        if tag.casefold() == "style":
            self.in_style = False

    def handle_data(self, data: str) -> None:
        if self.in_style:
            self.style_chunks.append(data)


CSS_URL = re.compile(r"(?is)url\(\s*(['\"]?)(.*?)\1\s*\)")
CSS_IMPORT = re.compile(r"(?is)@import\s+(?!url\()(['\"])(.*?)\1")


def resolve_offline_reference(source: str, reference: str, members: set[str],
                              html_ids: dict[str, set[str]], *, resource: bool) -> None:
    reference = reference.strip()
    require(bool(reference), f"Empty local reference in {source}")
    parsed = urlsplit(reference)
    scheme = parsed.scheme.casefold()
    if scheme or parsed.netloc:
        if resource:
            require(scheme == "data" and not parsed.netloc,
                    f"Remote resource dependency in {source}: {reference}")
        else:
            require(scheme in {"http", "https", "mailto", "tel"} or
                    (not scheme and bool(parsed.netloc)),
                    f"Unsafe navigation scheme in {source}: {reference}")
        return
    raw_path = unquote(parsed.path)
    require("\\" not in raw_path and "\x00" not in raw_path and not raw_path.startswith("/"),
            f"Unsafe offline reference in {source}: {reference}")
    if not raw_path:
        target = source
    else:
        target = posixpath.normpath(posixpath.join(posixpath.dirname(source), raw_path))
        require(target not in ("", ".", "..") and not target.startswith("../"),
                f"Offline reference escapes archive in {source}: {reference}")
        normal_relative(target, label=f"offline reference from {source}")
        require(target in members, f"Missing offline target from {source}: {target}")
    if parsed.fragment and target.lower().endswith((".html", ".htm")):
        fragment = unquote(parsed.fragment)
        require(fragment in html_ids.get(target, set()),
                f"Missing offline HTML fragment from {source}: {target}#{fragment}")


def validate_css(source: str, text: str, members: set[str], html_ids: dict[str, set[str]]) -> None:
    for match in CSS_URL.finditer(text):
        reference = match.group(2).strip()
        if reference.startswith("#"):
            continue
        resolve_offline_reference(source, reference, members, html_ids, resource=True)
    for match in CSS_IMPORT.finditer(text):
        resolve_offline_reference(source, match.group(2).strip(), members, html_ids, resource=True)


def validate_offline_html(entries: list[dict[str, Any]], entry_points: list[str],
                          *, required_entry_points: tuple[str, ...] = HTML_ENTRY_POINTS) -> dict[str, Any]:
    require(tuple(entry_points) == required_entry_points,
            "Offline HTML entry points differ from their required ordered closure")
    members = {entry["archive_path"] for entry in entries}
    require(len(members) == len(entries), "Duplicate HTML archive path")
    require(set(entry_points).issubset(members), "Offline HTML entry point is absent")
    by_name = {entry["archive_path"]: entry["data"] for entry in entries}
    audits: dict[str, HTMLAudit] = {}
    for name, value in by_name.items():
        if PurePosixPath(name).suffix.casefold() not in {".html", ".htm"}:
            continue
        try:
            text = value.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise PackageError(f"HTML is not UTF-8: {name}") from exc
        audit = HTMLAudit(name)
        audit.feed(text)
        audit.close()
        require(audit.lang is not None and audit.lang.casefold().startswith("en"),
                f"HTML language is not English: {name}")
        audits[name] = audit
    require(set(entry_points).issubset(audits), "Every offline entry point must be HTML")
    html_ids = {name: audit.ids for name, audit in audits.items()}
    for name, audit in audits.items():
        for _context, reference, resource in audit.refs:
            resolve_offline_reference(name, reference, members, html_ids, resource=resource)
        for css in audit.style_chunks:
            validate_css(name, css, members, html_ids)
    for name, value in by_name.items():
        suffix = PurePosixPath(name).suffix.casefold()
        if suffix == ".css":
            try:
                validate_css(name, value.decode("utf-8"), members, html_ids)
            except UnicodeDecodeError as exc:
                raise PackageError(f"CSS is not UTF-8: {name}") from exc
        elif suffix == ".svg":
            try:
                root = ET.fromstring(value)
            except ET.ParseError as exc:
                raise PackageError(f"Malformed SVG: {name}") from exc
            for element in root.iter():
                require(element.tag.rsplit("}", 1)[-1].casefold() != "script",
                        f"SVG script is forbidden: {name}")
                for key, reference in element.attrib.items():
                    if key.rsplit("}", 1)[-1].casefold() in {"href", "src"} and reference:
                        if reference.startswith("#"):
                            continue
                        resolve_offline_reference(name, reference, members, html_ids, resource=True)
    return {
        "entry_points": list(entry_points),
        "file_count": len(entries),
        "html_file_count": len(audits),
        "remote_resource_dependencies": 0,
        "local_reference_closure": True,
    }


def validate_backend(entries: list[dict[str, Any]]) -> dict[str, Any]:
    basenames = {PurePosixPath(entry["archive_path"]).name for entry in entries}
    require(REQUIRED_BACKEND_BASENAMES.issubset(basenames),
            "Backend bundle lacks MANIFEST, records, schema, or common dataset")
    json_documents = 0
    jsonl_records = 0
    for entry in entries:
        name = entry["archive_path"]
        suffix = PurePosixPath(name).suffix.casefold()
        if suffix == ".json":
            try:
                json.loads(entry["data"])
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise PackageError(f"Malformed backend JSON: {name}") from exc
            json_documents += 1
        elif suffix == ".jsonl":
            try:
                lines = entry["data"].decode("utf-8").splitlines()
                for number, line in enumerate(lines, 1):
                    if not line.strip():
                        continue
                    require(isinstance(json.loads(line), dict),
                            f"Backend JSONL row is not an object: {name}:{number}")
                    jsonl_records += 1
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise PackageError(f"Malformed backend JSONL: {name}") from exc
    return {"file_count": len(entries), "json_documents": json_documents,
            "jsonl_records_checked": jsonl_records, "required_surfaces_present": True}


def validate_notice(value: bytes, *, title: str) -> None:
    try:
        text = value.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise PackageError("Licence/component-rights notice is not UTF-8") from exc
    folded = text.casefold()
    require("cc by-sa 4.0" in folded, "Licence notice lacks exact CC BY-SA 4.0 term")
    require("component" in folded and "rights" in folded,
            "Licence notice does not preserve component rights")
    require("independent" in folded and ("endorsement" in folded or "endorsed" in folded),
            "Licence notice lacks independent/non-endorsement boundary")
    heading = next((line[1:].strip() for line in text.splitlines() if line.startswith("#")), "")
    require(bool(heading) and FORBIDDEN_TITLE.search(heading) is None,
            "Forbidden umbrella or placeholder label in licence title")
    require(title.casefold() not in {"ttp", "translation and transcription project"},
            "Forbidden release title")


def validate_readme(value: bytes, *, title: str, model: str, required_names: list[str]) -> None:
    try:
        text = value.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise PackageError("README is not UTF-8") from exc
    heading = next((line[1:].strip() for line in text.splitlines() if line.startswith("#")), "")
    require(bool(heading), "README lacks a Markdown title")
    require(FORBIDDEN_TITLE.search(heading) is None, "Forbidden umbrella or placeholder label in README title")
    require(title in text, "README does not contain the exact release title")
    require(model in text, "README does not contain exact model provenance")
    for name in required_names:
        require(name in text, f"README omits release artifact: {name}")


def validate_release_metadata(config: dict[str, Any]) -> tuple[dict[str, Any], str]:
    release = config.get("release")
    require(isinstance(release, dict) and set(release) ==
            {"id", "title", "language", "model_provenance"}, "Invalid release metadata fields")
    release_id = release["id"]
    require(isinstance(release_id, str) and re.fullmatch(r"[a-z0-9][a-z0-9.-]{2,80}", release_id),
            "Release id must be a lowercase portable slug")
    require(isinstance(release["title"], str) and release["title"].strip() == release["title"] and
            len(release["title"]) >= 12, "Release title is missing or implausibly short")
    require(FORBIDDEN_TITLE.search(release["title"]) is None,
            "Release title contains an umbrella or placeholder label")
    require(release["language"] == "en", "Release language must be en")
    model = release["model_provenance"]
    require(isinstance(model, str) and model.strip() == model and len(model) >= 12 and
            FORBIDDEN_TITLE.search(model) is None, "Exact model provenance is required")
    output = normal_relative(config.get("output_directory"), label="output_directory")
    require(PurePosixPath(output).parts == ("release", "english", release_id),
            "Output must be exactly a fresh release/english/<release-id> child")
    return release, output


def validate_metadata_contract(metadata: dict[str, Any], review: dict[str, Any],
                               metadata_fact: dict[str, Any], release: dict[str, Any]) -> list[str]:
    """Return the authoritative ordered filenames after validating the contract."""
    require(metadata.get("schema") == "ag-bridge-english-release-metadata-contract-v1" and
            metadata.get("status") == "metadata_preparation_complete",
            "English release metadata contract schema/status mismatch")
    work = metadata.get("work")
    language = metadata.get("language")
    provenance = metadata.get("model_provenance")
    require(isinstance(work, dict) and work.get("title") == release["title"] and
            work.get("version") == release["id"],
            "Release title/version differs from metadata contract")
    require(isinstance(language, dict) and language.get("bcp47") == "en",
            "Metadata contract language is not English")
    require(isinstance(provenance, dict) and
            provenance.get("exact_statement") == release["model_provenance"],
            "Release model provenance differs from metadata contract")
    rows = metadata.get("reader_first_release_files")
    require(isinstance(rows, list) and len(rows) == 13, "Metadata contract must name exactly 13 files")
    expected_kinds = (
        "reader_pdf", "reader_html", "reader_pdf", "reader_html", "reader_pdf",
        "reader_html_bundle", "resumable_source", "native_backend", "rights_notice",
        "reader_start_here", "release_manifest", "checksums", "qa_receipt",
    )
    names = []
    for order, (row, kind) in enumerate(zip(rows, expected_kinds), 1):
        require(isinstance(row, dict) and row.get("order") == order and row.get("kind") == kind and
                row.get("required") is True and row.get("bytes") is None and
                row.get("sha256") is None and row.get("binding_status") == "pending_final_artifact",
                f"Metadata release-file row {order} violates the pending-binding contract")
        names.append(output_leaf(row.get("name"), ".zip" if kind.endswith("bundle") else
                                 ".pdf" if kind == "reader_pdf" else
                                 ".html" if kind == "reader_html" else
                                 ".md" if kind == "rights_notice" or kind == "reader_start_here" else
                                 ".txt" if kind == "checksums" else
                                 ".json" if kind in {"release_manifest", "qa_receipt"} else
                                 ".zip", label=f"metadata release file {order}"))
    require(len(names) == len(set(name.casefold() for name in names)),
            "Metadata release filenames collide")
    require(review.get("schema") == "ag-bridge-english-release-metadata-review-v1" and
            review.get("status") == "PASS", "Release metadata review is not PASS")
    require(any(row == metadata_fact for row in embedded_facts(review)),
            "Release metadata review does not bind the exact contract")
    return names


def add_archive_entry(target: dict[str, dict[str, Any]], item: dict[str, Any], role: str,
                      *, archive_path: str | None = None) -> None:
    name = archive_path or item.get("archive_path") or item["fact"]["path"]
    name = normal_relative(name, label=f"{role} archive path")
    reject_secret_name(name)
    key = name.casefold()
    existing = target.get(key)
    if existing is not None:
        require(existing["archive_path"] == name and existing["data"] == item["data"] and
                existing["fact"] == item["fact"], f"Archive member collision: {name}")
        existing["roles"].add(role)
        return
    target[key] = {"archive_path": name, "data": item["data"], "fact": item["fact"],
                   "roles": {role}}


def archive_inventory(entries: list[dict[str, Any]], kind: str, model: str) -> bytes:
    return canonical({
        "schema": ARCHIVE_SCHEMA,
        "archive_kind": kind,
        "model_provenance": model,
        "file_count": len(entries),
        "files": [
            {"archive_path": entry["archive_path"], "source": entry["fact"],
             "roles": sorted(entry["roles"])}
            for entry in entries
        ],
    })


def encode_zip(members: dict[str, bytes]) -> bytes:
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9,
                         allowZip64=True, strict_timestamps=True) as archive:
        for name in sorted(members):
            normal_relative(name, label="ZIP member")
            info = zipfile.ZipInfo(name, ZIP_TIME)
            info.create_system = 3
            info.external_attr = ZIP_MODE << 16
            info.internal_attr = 0
            info.compress_type = zipfile.ZIP_DEFLATED
            info.extra = b""
            info.comment = b""
            archive.writestr(info, members[name], compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return stream.getvalue()


def verify_zip(value: bytes, members: dict[str, bytes]) -> None:
    with zipfile.ZipFile(io.BytesIO(value), "r") as archive:
        infos = archive.infolist()
        require([info.filename for info in infos] == sorted(members), "ZIP member order is not canonical")
        require(len(infos) == len({info.filename.casefold() for info in infos}) == len(members),
                "ZIP contains duplicate or case-colliding members")
        require(archive.testzip() is None, "ZIP CRC failure")
        for info in infos:
            require(info.date_time == ZIP_TIME and info.create_system == 3 and
                    (info.external_attr >> 16) == ZIP_MODE and info.compress_type == zipfile.ZIP_DEFLATED,
                    f"ZIP metadata drift: {info.filename}")
            require(not info.is_dir() and not (info.flag_bits & 1),
                    f"Directory or encrypted ZIP member: {info.filename}")
            require(archive.read(info.filename) == members[info.filename],
                    f"ZIP byte mismatch: {info.filename}")


def deterministic_archive(entries: list[dict[str, Any]], prefix: str, kind: str,
                          model: str) -> tuple[bytes, dict[str, Any]]:
    prefix = normal_relative(prefix, label=f"{kind} archive prefix")
    require(len(PurePosixPath(prefix).parts) == 1, "Archive prefix must be one portable directory name")
    entries = sorted(entries, key=lambda row: row["archive_path"])
    require(len(entries) == len({row["archive_path"].casefold() for row in entries}),
            f"{kind} archive paths collide")
    inventory = archive_inventory(entries, kind, model)
    members = {f"{prefix}/{entry['archive_path']}": entry["data"] for entry in entries}
    inventory_name = f"{prefix}/INVENTORY.json"
    require(inventory_name.casefold() not in {name.casefold() for name in members},
            f"{kind} inventory collides with an input")
    members[inventory_name] = inventory
    first = encode_zip(members)
    second = encode_zip(members)
    require(first == second, f"{kind} ZIP in-memory replay mismatch")
    verify_zip(first, members)
    rows = [{"archive_path": entry["archive_path"], "source": entry["fact"],
             "roles": sorted(entry["roles"])} for entry in entries]
    return first, {
        "archive_kind": kind,
        "archive_prefix": prefix,
        "file_count": len(entries),
        "zip_member_count": len(members),
        "uncompressed_bytes": sum(map(len, members.values())),
        "content_fingerprint": sha256(canonical(rows)),
        "inventory": {"path": "INVENTORY.json", "bytes": len(inventory), "sha256": sha256(inventory)},
        "double_in_memory_replay": True,
    }


def require_payload_size(size: int) -> None:
    require(type(size) is int and 0 <= size < MAX_RELEASE_BYTES,
            "Release payload must be strictly smaller than 500,000,000 bytes")


def artifact_fact(name: str, value: bytes) -> dict[str, Any]:
    return {"path": name, "bytes": len(value), "sha256": sha256(value)}


def prepare(config_path: Path, root: Path = ROOT) -> dict[str, Any]:
    """Bind and validate every input without creating an output directory."""
    root = root.resolve(strict=True)
    if config_path.is_absolute():
        lexical_config = config_path.absolute()
    else:
        relative_argument = normal_relative(config_path.as_posix(), label="binding document argument")
        lexical_config = root.joinpath(*PurePosixPath(relative_argument).parts)
    try:
        config_relative = lexical_config.relative_to(root).as_posix()
    except ValueError as exc:
        raise PackageError("Binding document must be inside the repository") from exc
    config_file = safe_regular(root, config_relative)
    config_data = config_file.read_bytes()
    reject_sensitive_bytes(config_relative, config_data)
    try:
        config = json.loads(config_data)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PackageError("Binding document is not a UTF-8 JSON object") from exc
    required_top = {
        "schema", "release", "release_metadata", "output_directory", "readers", "offline_html",
        "source_bundle", "backend_bundle", "license_and_component_rights",
        "readme", "output_names", "receipts",
    }
    require(isinstance(config, dict) and set(config) == required_top, "Binding document fields drifted")
    require(config["schema"] == CONFIG_SCHEMA, "Unsupported English release binding schema")
    release, output_relative = validate_release_metadata(config)
    model = release["model_provenance"]

    config_fact = {"path": config_relative, "bytes": len(config_data), "sha256": sha256(config_data)}
    cache: dict[str, dict[str, Any]] = {
        config_relative: {"fact": config_fact, "data": config_data, "aliases": {config_relative}}
    }

    metadata_config = config["release_metadata"]
    require(isinstance(metadata_config, dict) and set(metadata_config) == {"input", "review"},
            "Invalid release-metadata binding")
    metadata_bound = bind_fact(root, metadata_config["input"], cache, label="release metadata contract")
    metadata_review_bound = bind_fact(root, metadata_config["review"], cache,
                                      label="release metadata review")
    require(metadata_bound["fact"]["path"].startswith("00_control/english/") and
            metadata_review_bound["fact"]["path"].startswith("qa/english/"),
            "Release metadata contract/review is outside the English control lane")
    try:
        metadata_document = json.loads(metadata_bound["data"])
        metadata_review_document = json.loads(metadata_review_bound["data"])
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PackageError("Release metadata contract or review is not JSON") from exc
    require(isinstance(metadata_document, dict) and isinstance(metadata_review_document, dict),
            "Release metadata contract/review must be JSON objects")
    metadata_release_names = validate_metadata_contract(
        metadata_document, metadata_review_document, metadata_bound["fact"], release
    )

    readers_config = config["readers"]
    require(isinstance(readers_config, list) and len(readers_config) == 3,
            "Exactly three reader PDFs are required")
    readers = []
    for index, (row, book) in enumerate(zip(readers_config, BOOKS), 1):
        require(isinstance(row, dict) and set(row) == {"book", "input", "output_name", "page_count"},
                f"Invalid reader binding {index}")
        require(row["book"] == book, "Reader order must be ak, bgk, companion")
        output_name = output_leaf(row["output_name"], ".pdf", label=f"{book} reader output")
        require(type(row["page_count"]) is int and row["page_count"] > 0,
                f"Invalid page count for {book}")
        bound = bind_fact(root, row["input"], cache, label=f"{book} reader")
        require(bound["fact"]["path"].startswith("build/english/"),
                f"{book} reader is outside build/english")
        require(bound["data"].startswith(b"%PDF-") and bound["data"].rstrip().endswith(b"%%EOF"),
                f"{book} reader lacks PDF header or terminal EOF")
        readers.append({"book": book, "output_name": output_name,
                        "page_count": row["page_count"], **bound})

    html_config = config["offline_html"]
    require(isinstance(html_config, dict) and set(html_config) ==
            {"output_name", "archive_prefix", "entry_points", "promoted_readers", "files"},
            "Invalid offline HTML binding")
    html_output = output_leaf(html_config["output_name"], ".zip", label="offline HTML output")
    require(isinstance(html_config["files"], list) and html_config["files"], "Offline HTML file list is empty")
    html_entries = [bind_archive_fact(root, row, cache, label=f"offline HTML file {index}")
                    for index, row in enumerate(html_config["files"], 1)]
    for entry in html_entries:
        entry["roles"] = {"offline_html"}
    require(all(entry["fact"]["path"].startswith("build/english/") for entry in html_entries),
            "Offline HTML input is outside build/english")
    entry_points = [normal_relative(value, label="HTML entry point") for value in html_config["entry_points"]]
    html_validation = validate_offline_html(html_entries, entry_points)
    promoted_config = html_config["promoted_readers"]
    require(isinstance(promoted_config, list) and len(promoted_config) == 2,
            "Exactly two promoted course HTML readers are required")
    promoted = []
    for row, book in zip(promoted_config, ("ak", "bgk")):
        require(isinstance(row, dict) and set(row) == {"book", "input", "output_name"} and
                row["book"] == book, "Promoted HTML order must be ak, bgk")
        output_name = output_leaf(row["output_name"], ".html", label=f"{book} promoted HTML output")
        bound = bind_fact(root, row["input"], cache, label=f"{book} promoted standalone HTML")
        require(bound["fact"]["path"].startswith("build/english/"),
                f"Promoted {book} HTML is outside build/english")
        standalone = {**bound, "archive_path": output_name, "roles": {"promoted_reader_html"}}
        standalone["aliases"] = {*standalone["aliases"], output_name}
        validation = validate_offline_html([standalone], [output_name],
                                           required_entry_points=(output_name,))
        promoted.append({"book": book, "output_name": output_name,
                         "validation": validation, **standalone})

    source_config = config["source_bundle"]
    require(isinstance(source_config, dict) and set(source_config) ==
            {"output_name", "archive_prefix", "reader_sources", "control", "rights", "reproducibility"},
            "Invalid source bundle binding")
    source_output = output_leaf(source_config["output_name"], ".zip", label="source bundle output")
    source_groups: dict[str, list[dict[str, Any]]] = {}
    for group in ("reader_sources", "control", "rights", "reproducibility"):
        rows = source_config[group]
        require(isinstance(rows, list) and rows, f"Source bundle {group} list is empty")
        source_groups[group] = [bind_fact(root, row, cache, label=f"source {group} {index}")
                                for index, row in enumerate(rows, 1)]
    reader_paths = [item["fact"]["path"] for item in source_groups["reader_sources"]]
    require(reader_paths == expected_reader_source_paths(),
            "Reader source bundle is not the exact ordered 274-file closure")
    require(all(item["fact"]["path"].startswith("00_control/english/")
                for item in source_groups["control"]),
            "Source control entry is outside 00_control/english")
    rights_paths = {item["fact"]["path"] for item in source_groups["rights"]}
    require(expected_component_rights_paths().issubset(rights_paths),
            "Source rights bundle lacks the exact 60 component-rights ledgers")
    original_companion_rights = validate_fact_shape(
        (metadata_document.get("licensing") or {}).get("original_companion_rights"),
        label="metadata original companion rights",
    )
    require(any(item["fact"] == original_companion_rights for item in source_groups["rights"]),
            "Source rights bundle lacks metadata-bound original companion rights")
    require(all(path.startswith("authority/") or path == "LICENSE.md" or
                path == original_companion_rights["path"] for path in rights_paths),
            "Source rights entry is outside its admitted authority/licence boundary")
    source_fact_by_path = {item["fact"]["path"]: item["fact"]
                           for item in source_groups["reader_sources"]}
    metadata_components = metadata_document.get("components")
    require(isinstance(metadata_components, list) and len(metadata_components) == 3,
            "Release metadata does not describe exactly three components")
    for component in metadata_components:
        require(isinstance(component, dict), "Malformed release metadata component")
        declared_frontmatter = validate_fact_shape(component.get("frontmatter"),
                                                   label="metadata component frontmatter")
        require(source_fact_by_path.get(declared_frontmatter["path"]) == declared_frontmatter,
                "Metadata component frontmatter differs from the exact 274-source closure")
    reproducibility_paths = {item["fact"]["path"] for item in source_groups["reproducibility"]}
    require("scripts/english/package_release_en.py" in reproducibility_paths,
            "Source bundle must bind this release packager")
    require(all(path.startswith("scripts/") for path in reproducibility_paths),
            "Reproducibility entry is outside scripts/")
    categorized = [item["fact"]["path"] for values in source_groups.values() for item in values]
    require(len(categorized) == len(set(categorized)), "Source bundle categories overlap")

    backend_config = config["backend_bundle"]
    require(isinstance(backend_config, dict) and set(backend_config) ==
            {"output_name", "archive_prefix", "files"}, "Invalid backend bundle binding")
    backend_output = output_leaf(backend_config["output_name"], ".zip", label="backend bundle output")
    require(isinstance(backend_config["files"], list) and backend_config["files"],
            "Backend bundle file list is empty")
    backend_entries = [bind_archive_fact(root, row, cache, label=f"backend file {index}")
                       for index, row in enumerate(backend_config["files"], 1)]
    require(all(item["fact"]["path"].startswith("backend/english/") for item in backend_entries),
            "Backend input is outside backend/english")
    backend_validation = validate_backend(backend_entries)

    licence_config = config["license_and_component_rights"]
    require(isinstance(licence_config, dict) and set(licence_config) == {"input", "output_name"},
            "Invalid licence/component-rights binding")
    licence_output = output_leaf(licence_config["output_name"], ".md", label="licence output")
    require("LICENSE" in licence_output.upper() and "RIGHTS" in licence_output.upper(),
            "Licence output name must identify component rights")
    licence = bind_fact(root, licence_config["input"], cache, label="licence/component-rights notice")
    validate_notice(licence["data"], title=release["title"])
    controlling_notice = (metadata_document.get("licensing") or {}).get("controlling_notice")
    require(isinstance(controlling_notice, dict) and
            {key: controlling_notice.get(key) for key in ("path", "bytes", "sha256")} == licence["fact"],
            "Licence input differs from the metadata controlling notice")

    readme_config = config["readme"]
    require(isinstance(readme_config, dict) and set(readme_config) == {"input", "output_name"},
            "Invalid README binding")
    readme_output = output_leaf(readme_config["output_name"], ".md", label="README output")
    require("README" in readme_output.upper(), "README output name must identify README")
    readme = bind_fact(root, readme_config["input"], cache, label="README")

    metadata_config = config["output_names"]
    require(isinstance(metadata_config, dict) and set(metadata_config) ==
            {"manifest", "checksums", "candidate_qa"}, "Invalid metadata output names")
    metadata_names = {
        "manifest": output_leaf(metadata_config["manifest"], ".json", label="manifest output"),
        "checksums": output_leaf(metadata_config["checksums"], ".txt", label="checksums output"),
        "candidate_qa": output_leaf(metadata_config["candidate_qa"], ".json", label="candidate QA output"),
    }

    fixed_names = [
        readers[0]["output_name"], promoted[0]["output_name"],
        readers[1]["output_name"], promoted[1]["output_name"],
        readers[2]["output_name"], html_output, source_output, backend_output,
        licence_output, readme_output, *metadata_names.values(),
    ]
    require(len(fixed_names) == len(set(name.casefold() for name in fixed_names)),
            "Release output names collide")
    require(len(fixed_names) == 13, "Release inventory is not exactly 13 files")
    require(fixed_names == metadata_release_names,
            "Configured filenames/order differ from RELEASE_METADATA_EN.json")
    reader_names = [row["output_name"] for row in readers]
    validate_readme(readme["data"], title=release["title"], model=model,
                    required_names=fixed_names[:10])

    receipts_config = config["receipts"]
    require(isinstance(receipts_config, dict) and set(receipts_config) == set(RECEIPT_ROLES),
            "Receipts must contain exactly the six required roles")
    receipts: dict[str, dict[str, Any]] = {}
    for role in RECEIPT_ROLES:
        row = receipts_config[role]
        require(isinstance(row, dict) and set(row) == {"input", "schema", "status"} and
                isinstance(row["schema"], str) and isinstance(row["status"], str),
                f"Invalid {role} binding")
        bound = bind_fact(root, row["input"], cache, label=role)
        require(bound["fact"]["path"].startswith("qa/english/"),
                f"{role} receipt is outside qa/english")
        try:
            document = json.loads(bound["data"])
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise PackageError(f"{role} receipt is not JSON") from exc
        require(isinstance(document, dict), f"{role} receipt is not a JSON object")
        receipts[role] = {"bound": bound, "schema": row["schema"], "status": row["status"],
                          "document": document}
    require(len({item["bound"]["fact"]["path"] for item in receipts.values()}) == len(RECEIPT_ROLES),
            "Every required QA role must use a distinct receipt")

    receipt_targets = {
        "integration_qa": source_groups["reader_sources"],
        "html_qa": [*html_entries, *promoted],
        "pdf_qa": readers,
        "backend_qa": backend_entries,
        "visual_qa": readers,
        "responsive_qa": [entry for entry in html_entries if entry["archive_path"] in entry_points] + promoted,
    }
    receipt_validation = {
        role: validate_receipt(role, item, item["document"], receipt_targets[role], model)
        for role, item in receipts.items()
    }

    source_archive_map: dict[str, dict[str, Any]] = {}
    for group, items in source_groups.items():
        for item in items:
            add_archive_entry(source_archive_map, item, group)
    add_archive_entry(source_archive_map, cache[config_relative], "release_binding_document")
    add_archive_entry(source_archive_map, metadata_bound, "release_metadata_contract")
    add_archive_entry(source_archive_map, metadata_review_bound, "release_metadata_review")
    add_archive_entry(source_archive_map, licence, "license_and_component_rights")
    add_archive_entry(source_archive_map, readme, "release_readme")
    for role, item in receipts.items():
        add_archive_entry(source_archive_map, item["bound"], role)

    backend_archive_map: dict[str, dict[str, Any]] = {}
    for item in backend_entries:
        add_archive_entry(backend_archive_map, item, "backend", archive_path=item["archive_path"])
    backend_receipt = receipts["backend_qa"]["bound"]
    if backend_receipt["fact"]["path"] not in {entry["archive_path"] for entry in backend_archive_map.values()}:
        add_archive_entry(backend_archive_map, backend_receipt, "backend_qa",
                          archive_path="qa/" + PurePosixPath(backend_receipt["fact"]["path"]).name)

    require_payload_size(sum(item["fact"]["bytes"] for item in cache.values()))
    return {
        "root": root,
        "config": config,
        "config_fact": config_fact,
        "release": release,
        "release_metadata": {"contract": metadata_bound, "review": metadata_review_bound,
                             "release_names": metadata_release_names},
        "model": model,
        "output_relative": output_relative,
        "readers": readers,
        "html": {"output_name": html_output, "prefix": html_config["archive_prefix"],
                 "entries": html_entries, "validation": html_validation,
                 "entry_points": entry_points, "promoted": promoted},
        "source": {"output_name": source_output, "prefix": source_config["archive_prefix"],
                   "entries": sorted(source_archive_map.values(), key=lambda item: item["archive_path"]),
                   "groups": source_groups},
        "backend": {"output_name": backend_output, "prefix": backend_config["archive_prefix"],
                    "entries": sorted(backend_archive_map.values(), key=lambda item: item["archive_path"]),
                    "validation": backend_validation},
        "licence": {"output_name": licence_output, **licence},
        "readme": {"output_name": readme_output, **readme},
        "metadata_names": metadata_names,
        "fixed_names": fixed_names,
        "receipts": receipts,
        "receipt_validation": receipt_validation,
        "cache": cache,
    }


def render_candidate(boundary: dict[str, Any]) -> dict[str, bytes]:
    """Purely render one complete candidate from an already frozen boundary."""
    model = boundary["model"]
    html_zip, html_evidence = deterministic_archive(
        boundary["html"]["entries"], boundary["html"]["prefix"], "offline_html", model
    )
    source_zip, source_evidence = deterministic_archive(
        boundary["source"]["entries"], boundary["source"]["prefix"],
        "source_control_rights", model
    )
    backend_zip, backend_evidence = deterministic_archive(
        boundary["backend"]["entries"], boundary["backend"]["prefix"], "backend", model
    )
    core: dict[str, bytes] = {
        boundary["readers"][0]["output_name"]: boundary["readers"][0]["data"],
        boundary["html"]["promoted"][0]["output_name"]: boundary["html"]["promoted"][0]["data"],
        boundary["readers"][1]["output_name"]: boundary["readers"][1]["data"],
        boundary["html"]["promoted"][1]["output_name"]: boundary["html"]["promoted"][1]["data"],
        boundary["readers"][2]["output_name"]: boundary["readers"][2]["data"],
    }
    core[boundary["html"]["output_name"]] = html_zip
    core[boundary["source"]["output_name"]] = source_zip
    core[boundary["backend"]["output_name"]] = backend_zip
    core[boundary["licence"]["output_name"]] = boundary["licence"]["data"]
    core[boundary["readme"]["output_name"]] = boundary["readme"]["data"]
    for name, value in core.items():
        reject_sensitive_bytes(name, value)

    source_facts = [item["fact"] for item in boundary["source"]["groups"]["reader_sources"]]
    receipt_facts = {
        role: {**item["bound"]["fact"], **boundary["receipt_validation"][role]}
        for role, item in boundary["receipts"].items()
    }
    core_facts = [artifact_fact(name, value) for name, value in core.items()]
    manifest_name = boundary["metadata_names"]["manifest"]
    checksums_name = boundary["metadata_names"]["checksums"]
    qa_name = boundary["metadata_names"]["candidate_qa"]
    manifest = canonical({
        "schema": MANIFEST_SCHEMA,
        "status": "READY_FOR_RELEASE_NOT_PUBLISHED",
        "release_id": boundary["release"]["id"],
        "title": boundary["release"]["title"],
        "language": "en",
        "model_provenance": model,
        "binding_document": boundary["config_fact"],
        "release_metadata": {
            "contract": boundary["release_metadata"]["contract"]["fact"],
            "review": boundary["release_metadata"]["review"]["fact"],
        },
        "reader_first": [
            {"kind": "reader_pdf", "book": boundary["readers"][0]["book"],
             "file": artifact_fact(boundary["readers"][0]["output_name"], boundary["readers"][0]["data"]),
             "input": boundary["readers"][0]["fact"], "page_count": boundary["readers"][0]["page_count"]},
            {"kind": "reader_html", "book": boundary["html"]["promoted"][0]["book"],
             "file": artifact_fact(boundary["html"]["promoted"][0]["output_name"],
                                   boundary["html"]["promoted"][0]["data"]),
             "input": boundary["html"]["promoted"][0]["fact"]},
            {"kind": "reader_pdf", "book": boundary["readers"][1]["book"],
             "file": artifact_fact(boundary["readers"][1]["output_name"], boundary["readers"][1]["data"]),
             "input": boundary["readers"][1]["fact"], "page_count": boundary["readers"][1]["page_count"]},
            {"kind": "reader_html", "book": boundary["html"]["promoted"][1]["book"],
             "file": artifact_fact(boundary["html"]["promoted"][1]["output_name"],
                                   boundary["html"]["promoted"][1]["data"]),
             "input": boundary["html"]["promoted"][1]["fact"]},
            {"kind": "reader_pdf", "book": boundary["readers"][2]["book"],
             "file": artifact_fact(boundary["readers"][2]["output_name"], boundary["readers"][2]["data"]),
             "input": boundary["readers"][2]["fact"], "page_count": boundary["readers"][2]["page_count"]},
            {"kind": "reader_html_bundle", "book": "companion",
             "file": artifact_fact(boundary["html"]["output_name"], html_zip)},
        ],
        "offline_html": {"file": artifact_fact(boundary["html"]["output_name"], html_zip),
                         "validation": boundary["html"]["validation"],
                         "promoted_standalone_readers": [
                             {"book": item["book"],
                              "file": artifact_fact(item["output_name"], item["data"]),
                              "validation": item["validation"]}
                             for item in boundary["html"]["promoted"]
                         ], **html_evidence},
        "source_control_rights": {
            "file": artifact_fact(boundary["source"]["output_name"], source_zip),
            "reader_source_count": len(source_facts),
            "reader_source_closure_sha256": sha256(canonical(source_facts)),
            "component_rights_ledger_count": len(expected_component_rights_paths()),
            **source_evidence,
        },
        "backend": {"file": artifact_fact(boundary["backend"]["output_name"], backend_zip),
                    "validation": boundary["backend"]["validation"], **backend_evidence},
        "license_and_component_rights": artifact_fact(
            boundary["licence"]["output_name"], boundary["licence"]["data"]
        ),
        "readme": artifact_fact(boundary["readme"]["output_name"], boundary["readme"]["data"]),
        "required_qa_receipts": receipt_facts,
        "files": core_facts,
        "output_inventory": boundary["fixed_names"],
        "checksum_policy": f"{checksums_name} covers every release file except itself",
    })
    manifest_fact = artifact_fact(manifest_name, manifest)
    candidate_qa = canonical({
        "schema": QA_SCHEMA,
        "status": "PASS_RELEASE_CANDIDATE_NOT_PUBLISHED",
        "release_id": boundary["release"]["id"],
        "language": "en",
        "model_provenance": model,
        "binding_document": boundary["config_fact"],
        "release_metadata": {
            "contract": boundary["release_metadata"]["contract"]["fact"],
            "review": boundary["release_metadata"]["review"]["fact"],
            "filenames_and_order_exact": True,
        },
        "manifest": manifest_fact,
        "reader_first": boundary["fixed_names"][:6],
        "reader_pdfs": [reader["output_name"] for reader in boundary["readers"]],
        "source_closure": {
            "expected": 274,
            "actual": len(source_facts),
            "exact_order_and_identity": True,
            "sha256": sha256(canonical(source_facts)),
        },
        "component_rights": {
            "required_ledger_count": 60,
            "required_ledgers_present": True,
            "notice": artifact_fact(boundary["licence"]["output_name"], boundary["licence"]["data"]),
        },
        "qa_receipts": receipt_facts,
        "archives": {"offline_html": html_evidence, "source_control_rights": source_evidence,
                     "backend": backend_evidence},
        "checks": {
            "exact_three_pdf_readers_and_six_reader_first_files": True,
            "complete_offline_html_local_resource_closure": True,
            "exact_274_source_closure": True,
            "compact_resumable_source_control_rights_archive": True,
            "backend_required_surfaces_and_json_parse": True,
            "integration_html_pdf_backend_visual_responsive_receipts": True,
            "exact_component_rights_notice_preserved": True,
            "exact_model_provenance_bound": True,
            "deterministic_zip_timestamp_order_permissions": True,
            "double_in_memory_replay_required_before_write": True,
            "path_traversal_symlink_secret_profile_title_guards": True,
            "strict_sub_500_mb_payload_gate": True,
            "exclusive_fresh_child_no_overwrite_writer": True,
        },
        "checksum_policy": {
            "file": checksums_name,
            "covers": [*core.keys(), manifest_name, qa_name],
            "excludes_only_itself_to_avoid_a_hash_cycle": True,
        },
    })
    qa_fact = artifact_fact(qa_name, candidate_qa)
    summed = {**core, manifest_name: manifest, qa_name: candidate_qa}
    checksums = "".join(
        f"{sha256(value)}  {name}\n" for name, value in sorted(summed.items())
    ).encode("utf-8")
    result = {**core, manifest_name: manifest, checksums_name: checksums, qa_name: candidate_qa}
    require(set(result) == set(boundary["fixed_names"]) and len(result) == 13,
            "Final English release inventory drifted")
    require(boundary["fixed_names"] == sorted(result),
            "Release filenames do not preserve metadata reader-first ordering")
    require_payload_size(sum(map(len, result.values())))
    # The checksum list covers all and only non-self files, including candidate QA.
    expected_lines = {
        f"{artifact_fact(name, value)['sha256']}  {name}" for name, value in result.items()
        if name != checksums_name
    }
    require(set(checksums.decode("utf-8").splitlines()) == expected_lines,
            "SHA256SUMS coverage mismatch")
    require(qa_fact == artifact_fact(qa_name, result[qa_name]), "Candidate QA identity drift")
    return result


def verify_live_inputs(boundary: dict[str, Any]) -> None:
    for relative, item in boundary["cache"].items():
        require(live_fact(boundary["root"], relative) == item["fact"],
                f"Input changed after snapshot: {relative}")


def build_candidate(config_path: Path, root: Path = ROOT) -> dict[str, Any]:
    """Prepare, render twice in memory, compare every byte, and recheck inputs."""
    boundary = prepare(config_path, root)
    first = render_candidate(boundary)
    second = render_candidate(boundary)
    require(first.keys() == second.keys() and all(first[name] == second[name] for name in first),
            "Complete candidate in-memory replay mismatch")
    verify_live_inputs(boundary)
    return {
        "boundary": boundary,
        "files": first,
        "replay": {
            "count": 2,
            "byte_identical": True,
            "candidate_fingerprint": sha256(canonical([
                artifact_fact(name, value) for name, value in sorted(first.items())
            ])),
        },
    }


def safe_output_parent(root: Path) -> Path:
    root = root.resolve(strict=True)
    require(not path_is_link_or_reparse(root), "Repository root is a link/reparse point")
    current = root
    for part in ("release", "english"):
        current /= part
        if current.exists() or current.is_symlink():
            require(current.is_dir() and not path_is_link_or_reparse(current),
                    f"Unsafe release parent: {current.relative_to(root).as_posix()}")
        else:
            current.mkdir(exist_ok=False)
    return current


def write_package(prepared: dict[str, Any]) -> dict[str, Any]:
    """Exclusively write a replay-verified package; never replace any path."""
    boundary = prepared.get("boundary")
    files = prepared.get("files")
    require(isinstance(boundary, dict) and isinstance(files, dict) and
            prepared.get("replay", {}).get("count") == 2 and
            prepared.get("replay", {}).get("byte_identical") is True,
            "Writer requires a complete double-replay prepared candidate")
    verify_live_inputs(boundary)
    # ``prepared`` is a mutable public return value.  Re-render the frozen
    # boundary before creating an output path so a caller cannot substitute
    # bytes after the two replay renders and have readback bless the substitute.
    expected_files = render_candidate(boundary)
    require(files.keys() == expected_files.keys() and
            all(files[name] == expected_files[name] for name in expected_files),
            "Prepared candidate differs from its replay-verified boundary")
    candidate_fingerprint = sha256(canonical([
        artifact_fact(name, value) for name, value in sorted(expected_files.items())
    ]))
    require(prepared["replay"].get("candidate_fingerprint") == candidate_fingerprint,
            "Prepared candidate fingerprint differs from its replay-verified boundary")
    verify_live_inputs(boundary)
    parent = safe_output_parent(boundary["root"])
    target = parent / boundary["release"]["id"]
    require(not target.exists() and not target.is_symlink(),
            f"Refusing to overwrite existing release child: {boundary['output_relative']}")
    target.mkdir(exist_ok=False)
    require(target.parent == parent and target.is_dir() and not path_is_link_or_reparse(target),
            "Unsafe new release child")
    # Candidate QA is the final completion marker.  Every write is exclusive.
    qa_name = boundary["metadata_names"]["candidate_qa"]
    order = [name for name in boundary["fixed_names"] if name != qa_name] + [qa_name]
    for name in order:
        path = target / name
        require(path.parent == target and not path.exists(), f"Unsafe release output: {name}")
        with path.open("xb") as stream:
            stream.write(files[name])
            stream.flush()
            os.fsync(stream.fileno())
        require(path.read_bytes() == files[name], f"Release readback mismatch: {name}")
    require({path.name for path in target.iterdir()} == set(files), "Final release inventory mismatch")
    return {
        "status": "PASS_RELEASE_CANDIDATE_WRITTEN_NOT_PUBLISHED",
        "directory": boundary["output_relative"],
        "file_count": len(files),
        "total_bytes": sum(map(len, files.values())),
        "candidate_fingerprint": candidate_fingerprint,
        "files": [live_fact(boundary["root"], f"{boundary['output_relative']}/{name}")
                  for name in boundary["fixed_names"]],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, type=Path,
                        help="Repository-local d100-en-release-bindings-v1 JSON")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--verify-only", action="store_true", help="Double-render in memory; write nothing")
    mode.add_argument("--build", action="store_true", help="Double-render, then create the configured child")
    args = parser.parse_args(argv)
    try:
        prepared = build_candidate(args.config, ROOT)
        if args.build:
            report = write_package(prepared)
        else:
            report = {
                "status": "PASS_VERIFIED_IN_MEMORY_NOT_WRITTEN",
                "directory": prepared["boundary"]["output_relative"],
                "file_count": len(prepared["files"]),
                "total_bytes": sum(map(len, prepared["files"].values())),
                **prepared["replay"],
            }
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    except (PackageError, OSError, ValueError, KeyError, TypeError) as exc:
        print(f"English release packaging failed: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
