#!/usr/bin/env python3
"""Build the three English books as a portable, native-MathML reader package.

Production requires the shared translation gate. There is deliberately no
partial-book, skip-missing, network fetch, TeX, or publication mode. Focused
tests call ``render_book`` with explicitly bounded synthetic/Unit 1 inputs.
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass, field
import hashlib
from html import escape
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
from typing import Callable
from urllib.parse import quote, unquote, urlsplit
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parents[2]
BOOKS = ("ak", "bgk", "companion")
BOOK_LABELS = {"ak": "Algebraic Curves", "bgk": "Bundles, Sheaves and Cohomology", "companion": "Original Companion"}
READ_FORMAT = "markdown+yaml_metadata_block+tex_math_dollars+fenced_divs+bracketed_spans"
EXPECTED_PANDOC = "pandoc 3.9.0.2"
PROVENANCE = "OpenAI Codex gpt-5.6-sol, Ultra."
PUBLISHABLE_TRANSLATION_STATUSES = {
    "complete",
    "complete_semantic_authority_bound",
    "source_scope_complete",
}
LAYOUT_TEX = re.compile(r"^(?:\s|\\(?:clearpage|newpage|pagebreak|begingroup|endgroup|small|normalsize)\b)*$")
RIGHTS_LOCATOR = re.compile(r"authority/(?:RIGHTS|ASSET_CLOSURE)[A-Za-z0-9_.-]*\.(?:csv|json)")
FAVICON_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" role="img" aria-label="Algebraic geometry reader"><rect width="64" height="64" rx="8" fill="#16324f"/><path d="M12 47 29 15h6l17 32h-8l-4-8H24l-4 8Zm15-15h10l-5-10Z" fill="#f5f8fb"/></svg>
"""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def fact(path: Path, root: Path) -> dict:
    data = path.read_bytes()
    return {"path": path.resolve().relative_to(root.resolve()).as_posix(),
            "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def regular(path: Path, root: Path) -> Path:
    resolved = path.resolve()
    require(resolved.is_relative_to(root.resolve()), f"input escapes project: {path}")
    require(path.is_file() and not path.is_symlink(), f"missing or linked required input: {path}")
    return resolved


def pandoc_executable() -> str:
    executable = shutil.which("pandoc")
    require(executable is not None, "Pandoc is required; no HTML fallback is permitted")
    version = subprocess.run([executable, "--version"], check=True, capture_output=True,
                             encoding="utf-8", timeout=30).stdout.splitlines()[0]
    require(version == EXPECTED_PANDOC, f"unexpected Pandoc: {version!r}; expected {EXPECTED_PANDOC!r}")
    return executable


def pandoc(executable: str, arguments: list[str], text: str, cwd: Path) -> str:
    environment = os.environ.copy()
    environment.update(TZ="UTC", SOURCE_DATE_EPOCH="1788480000")
    process = subprocess.run([executable, *arguments], input=text, capture_output=True,
                             encoding="utf-8", cwd=cwd, env=environment, timeout=300)
    require(process.returncode == 0, f"Pandoc failed ({process.returncode}): {process.stderr}")
    require(not process.stderr.strip(), f"Pandoc emitted diagnostics; refusing degraded output: {process.stderr}")
    return process.stdout


def walk(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


def inline_text(value) -> str:
    if isinstance(value, list):
        return "".join(inline_text(item) for item in value)
    if not isinstance(value, dict):
        return ""
    kind, content = value.get("t"), value.get("c")
    if kind in {"Str", "MetaString"}:
        return content
    if kind in {"Space", "SoftBreak", "LineBreak"}:
        return " "
    if kind in {"Code", "Math"}:
        return content[-1]
    if kind in {"Link", "Image", "Span"}:
        return inline_text(content[1])
    return inline_text(content)


def text_inlines(value: str) -> list[dict]:
    return [{"t": "Str", "c": value}]


def link(label: str, target: str) -> dict:
    return {"t": "Link", "c": [["", [], []], text_inlines(label), [target, ""]]}


@dataclass
class Package:
    root: Path
    output: Path
    source_books: dict[Path, str]
    copied: dict[str, dict] = field(default_factory=dict)
    cross_links: list[tuple[str, str]] = field(default_factory=list)

    def copy(self, source: Path, destination: str) -> str:
        source = regular(source, self.root)
        target = (self.output / destination).resolve()
        require(target.is_relative_to(self.output.resolve()), "package path escapes output")
        identity = fact(source, self.root)
        previous = self.copied.get(destination)
        require(previous is None or previous == identity, f"package collision: {destination}")
        if previous is None:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            require(hashlib.sha256(target.read_bytes()).hexdigest() == identity["sha256"],
                    f"asset copy changed bytes: {source}")
            self.copied[destination] = identity
        return quote(destination, safe="/-._~")

    def resolve(self, target: str, source: Path) -> Path:
        require("\\" not in target and not re.match(r"^[A-Za-z]:", target),
                f"nonportable resource path: {target}")
        if target.startswith(("authority/", "source/", "00_control/")):
            return regular(self.root / target, self.root)
        return regular(source.parent / target, self.root)

    def asset(self, target: str, source: Path) -> str:
        parsed = urlsplit(target)
        require(not parsed.scheme and not parsed.netloc and not parsed.query,
                f"image must use frozen local bytes: {target}")
        asset = self.resolve(unquote(parsed.path), source)
        require(asset.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp"},
                f"unsupported reader image type: {target}")
        if asset.suffix.lower() == ".svg":
            validate_svg(asset)
        destination = "assets/" + asset.relative_to(self.root.resolve()).as_posix()
        return self.copy(asset, destination) + ("#" + parsed.fragment if parsed.fragment else "")

    def explicit_rights(self, text: str) -> list[tuple[str, str]]:
        """Package explicit rights/closure locators, not a recursive authority archive."""
        return [(relative, self.copy(self.root / relative, "rights/" + relative))
                for relative in sorted(set(RIGHTS_LOCATOR.findall(text)))]

    def href(self, target: str, source: Path, book: str) -> str:
        parsed = urlsplit(target)
        if parsed.scheme:
            require(parsed.scheme in {"http", "https", "mailto"}, f"unsafe link scheme: {target}")
            return target
        require(not parsed.netloc and not parsed.query, f"unsupported local link: {target}")
        if not parsed.path:
            require(bool(parsed.fragment), "empty local link")
            return target
        if parsed.path == "bgk-reader.html":
            self.cross_links.append(("bgk", unquote(parsed.fragment)))
            return "bgk.html" + ("#" + parsed.fragment if parsed.fragment else "")
        resolved = self.resolve(unquote(parsed.path), source)
        if resolved in self.source_books:
            destination_book = self.source_books[resolved]
            fragment = unquote(parsed.fragment)
            if not fragment:
                heading = re.search(
                    r"(?m)^#{1,6}\s+.*?\{#([A-Za-z0-9_.:-]+)\}\s*$",
                    resolved.read_text(encoding="utf-8-sig"),
                )
                require(heading is not None,
                        f"Markdown book link has no stable destination heading: {target}")
                fragment = heading.group(1)
            self.cross_links.append((destination_book, fragment))
            prefix = "" if destination_book == book else destination_book + ".html"
            return prefix + "#" + quote(fragment, safe="-._~:")
        require(resolved.suffix.lower() != ".md", f"unmapped Markdown source link: {target}")
        destination = "references/" + resolved.relative_to(self.root.resolve()).as_posix()
        return self.copy(resolved, destination) + ("#" + parsed.fragment if parsed.fragment else "")


def svg_for_validation(raw: str, path: Path) -> str:
    """Resolve a tiny, safe subset of legacy internal SVG namespace entities.

    Frozen Commons SVGs occasionally carry an obsolete SVG 1.0 doctype whose
    internal subset aliases namespace URIs.  The reader ships the original
    attribution-preserving bytes, but ElementTree cannot parse those aliases.
    Resolve only literal internal aliases for inspection; reject parameter,
    external, recursive, markup-bearing, or undeclared entities.
    """
    doctype_start = raw.upper().find("<!DOCTYPE")
    if doctype_start < 0:
        require("<!ENTITY" not in raw.upper(), f"SVG entity declaration outside SVG doctype: {path}")
        return raw
    first_close = raw.find(">", doctype_start)
    require(first_close >= 0, f"unterminated SVG doctype: {path}")
    subset_start = raw.find("[", doctype_start, first_close)
    if subset_start >= 0:
        subset_end = raw.find("]>", subset_start)
        require(subset_end >= 0, f"unterminated SVG internal subset: {path}")
        doctype_end = subset_end + 2
        subset = raw[subset_start + 1:subset_end]
    else:
        doctype_end = first_close + 1
        subset = ""
    declaration = raw[doctype_start:doctype_end]
    declarations = re.findall(
        r"(?is)<!ENTITY\s+([A-Za-z_][A-Za-z0-9_.:-]*)\s+[\"']([^<>&\"']*)[\"']\s*>",
        subset,
    )
    leftovers = re.sub(
        r"(?is)<!ENTITY\s+([A-Za-z_][A-Za-z0-9_.:-]*)\s+[\"']([^<>&\"']*)[\"']\s*>",
        "",
        subset,
    )
    require("<!ENTITY" not in leftovers.upper(), f"unsupported SVG entity declaration: {path}")
    require("%" not in subset and "SYSTEM" not in subset.upper(), f"external SVG entity is unsupported: {path}")
    entities = dict(declarations)
    require(len(entities) == len(declarations), f"duplicate SVG entity declaration: {path}")
    for value in entities.values():
        parsed = urlsplit(value)
        require(parsed.scheme in {"http", "https"} and not parsed.netloc == "", f"unsafe SVG entity value: {path}")
    prepared = raw[:doctype_start] + raw[doctype_end:]

    def resolve_entity(match: re.Match[str]) -> str:
        name = match.group(1)
        if name in entities:
            return entities[name]
        require(name in {"amp", "lt", "gt", "quot", "apos"}, f"undeclared SVG entity: {path}")
        return match.group(0)

    return re.sub(r"&([A-Za-z_][A-Za-z0-9_.:-]*);", resolve_entity, prepared)


def validate_svg(path: Path) -> None:
    raw = path.read_text(encoding="utf-8-sig")
    prepared = svg_for_validation(raw, path)
    try:
        tree = ET.fromstring(prepared)
    except ET.ParseError as error:
        raise RuntimeError(f"invalid SVG: {path}: {error}") from error
    for element in tree.iter():
        tag = element.tag.rsplit("}", 1)[-1].lower()
        require(tag not in {"script", "foreignobject"}, f"active SVG content: {path}")
        for name, value in element.attrib.items():
            attribute = name.rsplit("}", 1)[-1].lower()
            require(not attribute.startswith("on"), f"active SVG attribute: {path}")
            if attribute in {"href", "src"}:
                passive_link = tag == "a" and urlsplit(value).scheme in {"http", "https", "mailto"}
                require(passive_link or value.startswith(("#", "data:image/")),
                        f"external SVG dependency: {path}: {value}")
        styles = list(element.attrib.values())
        if tag == "style":
            styles.append(element.text or "")
        for style in styles:
            require(not re.search(r"@import", style, re.I), f"external SVG stylesheet dependency: {path}")
            for dependency in re.findall(r"url\(([^)]*)\)", style, re.I):
                require(dependency.strip().strip("\"'").startswith(("#", "data:image/")),
                        f"external SVG stylesheet dependency: {path}")


def validate_stylesheet(path: Path) -> None:
    stylesheet = path.read_text(encoding="utf-8-sig")
    require(not re.search(r"@import\b|url\s*\(", stylesheet, re.I),
            "English stylesheet must not add unbundled dependencies")


def ensure_favicon(output: Path) -> None:
    """Write and bind the small local browser icon needed by every page."""
    favicon = output / "favicon.svg"
    expected = FAVICON_SVG.encode("utf-8")
    if favicon.exists():
        regular(favicon, output)
        require(favicon.read_bytes() == expected, "unexpected existing reader favicon")
        return
    favicon.write_bytes(expected)


def prepare_source(source: Path, package: Package, book: str, executable: str,
                   serializer: Callable) -> tuple[dict, dict]:
    regular(source, package.root)
    before = fact(source, package.root)
    original = source.read_text(encoding="utf-8-sig")
    transformed, receipts = serializer(original, source)
    document = json.loads(pandoc(executable, [f"--from={READ_FORMAT}", "--to=json"],
                                transformed, package.root))
    metadata = document["meta"]
    language = inline_text(metadata.get("language", metadata.get("lang", {})))
    require(language in {"", "en"}, f"non-English source metadata: {source}: {language}")
    if "translation_status" in metadata:
        translation_status = inline_text(metadata["translation_status"])
        require(translation_status in PUBLISHABLE_TRANSLATION_STATUSES,
                f"incomplete translation: {source} ({translation_status!r})")
    headings = [node["c"][1][0] for node in walk(document["blocks"]) if node.get("t") == "Header"]
    require(headings and all(headings), f"source lacks heading IDs: {source}")
    explicit_ids = re.findall(r"\{#([A-Za-z0-9_.:-]+)\}", original)
    require(set(explicit_ids).issubset(set(headings) | {
        node["c"][0][0] for node in walk(document["blocks"])
        if node.get("t") in {"Div", "Span"}}), f"lost explicit source IDs: {source}")
    math_count = 0
    image_count = 0
    table_count = 0
    layout = []
    # Materialise before replacing Math nodes with a Span containing that Math.
    for node in list(walk(document["blocks"])):
        kind = node.get("t")
        if kind == "Image":
            require(bool(inline_text(node["c"][1]).strip()), f"image lacks alternative text: {source}")
            node["c"][2][0] = package.asset(node["c"][2][0], source)
            image_count += 1
        elif kind == "Link":
            node["c"][2][0] = package.href(node["c"][2][0], source, book)
        elif kind == "Math":
            math_count += 1
            if node["c"][0]["t"] == "DisplayMath":
                formula = dict(node)
                node.clear()
                node.update(t="Span", c=[["", ["display-math"], [
                    ["tabindex", "0"], ["role", "group"],
                    ["aria-label", "Mathematical formula; scroll horizontally if needed"]]], [formula]])
        elif kind == "Table":
            table_count += 1
        elif kind in {"RawBlock", "RawInline"}:
            format_name, content = node["c"]
            if format_name in {"tex", "latex"} and LAYOUT_TEX.fullmatch(content):
                layout.append(content)
                node["c"] = ["html", ""]
            else:
                require(format_name == "html" and re.fullmatch(r"\s*(?:<!--[\s\S]*?-->\s*)+", content),
                        f"unsupported raw content (not silently omitted): {source}: {content[:180]}")
    source_target = package.copy(source, "sources/" + source.relative_to(package.root.resolve()).as_posix())
    require(fact(source, package.root) == before, f"source changed while rendering: {source}")
    provenance = [link("English Markdown source", source_target)]
    source_url = inline_text(metadata.get("source_url", {}))
    if source_url:
        provenance += [{"t": "Str", "c": " · "}, link("Frozen source revision", source_url)]
    licence = inline_text(metadata.get("license", {}))
    if licence:
        provenance += text_inlines(" · Licence: " + licence)
    rights_links = package.explicit_rights(original)
    for relative, target in rights_links:
        provenance += [{"t": "Str", "c": " · "}, link("Rights record: " + Path(relative).name, target)]
    document["blocks"].append({"t": "Div", "c": [["", ["source-provenance"], []],
                                  [{"t": "Para", "c": provenance}]]})
    document["meta"] = {}
    return document, {"source": before, "heading_ids": headings,
                      "explicit_ids": explicit_ids, "math_nodes": math_count,
                      "image_nodes": image_count, "table_nodes": table_count,
                      "math_serialization": receipts,
                      "html_omitted_layout_only_tex": layout, "explicit_rights_records": rights_links}


class Inventory(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.elements = []
        self.ids = []
        self.hrefs = []
        self.resources = []
        self.math = 0

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        self.elements.append((tag, attrs))
        if attrs.get("id"):
            self.ids.append(attrs["id"])
        if attrs.get("href"):
            self.hrefs.append((tag, attrs["href"]))
        for key in ("src", "srcset", "poster", "data"):
            if attrs.get(key):
                self.resources.append(attrs[key])
        self.math += tag == "math"

    handle_startendtag = handle_starttag


def inspect_html(text: str, records: list[dict], output: Path) -> dict:
    parsed = Inventory()
    parsed.feed(text)
    require(len(parsed.ids) == len(set(parsed.ids)), "duplicate HTML IDs")
    require(any(tag == "html" and attrs.get("lang") == "en" for tag, attrs in parsed.elements),
            "HTML language is not English")
    require(sum(tag == "main" for tag, _ in parsed.elements) == 1, "expected one main landmark")
    require("main-content" in parsed.ids and "TOC" in parsed.ids, "missing reader landmarks")
    require(any(tag == "a" and attrs.get("class") == "skip-link" and
                attrs.get("href") == "#main-content" for tag, attrs in parsed.elements), "missing skip link")
    expected_ids = {item for record in records for item in record["explicit_ids"]}
    require(expected_ids.issubset(parsed.ids), "HTML lost explicit stable IDs")
    expected_math = sum(record["math_nodes"] for record in records)
    # TOC duplicates some formulas in heading labels; it may add MathML nodes.
    main = text.split('<main id="main-content" tabindex="-1">', 1)[1].split("</main>", 1)[0]
    main_inventory = Inventory()
    main_inventory.feed(main)
    require(main_inventory.math == expected_math, "HTML formula count differs from source AST")
    require(sum(tag == "img" for tag, _ in main_inventory.elements) ==
            sum(record["image_nodes"] for record in records), "HTML image count differs from source AST")
    expected_tables = sum(record["table_nodes"] for record in records)
    require(sum(tag == "table" for tag, _ in main_inventory.elements) == expected_tables,
            "HTML table count differs from source AST")
    for tag, attrs in parsed.elements:
        require(tag not in {"script", "iframe", "object", "embed"}, "active HTML content")
        require(not any(key.startswith("on") for key in attrs), "active HTML attribute")
        if tag == "img":
            require(bool(attrs.get("alt", "").strip()), "HTML image lost alternative text")
        if tag == "span" and "math" in attrs.get("class", "").split():
            raise RuntimeError("unconverted TeX fallback in HTML")
    resources = parsed.resources + [href for tag, href in parsed.hrefs if tag == "link"]
    for target in resources:
        parsed_target = urlsplit(target)
        require(not parsed_target.scheme and not parsed_target.netloc, f"external render dependency: {target}")
        regular(output / unquote(parsed_target.path), output)
    for tag, target in parsed.hrefs:
        if tag != "a":
            continue
        parsed_target = urlsplit(target)
        if not parsed_target.scheme and not parsed_target.path:
            require(unquote(parsed_target.fragment) in parsed.ids, f"broken internal link: {target}")
    return {"status": "PASS", "heading_ids": [item for record in records for item in record["heading_ids"]],
            "ids": parsed.ids, "source_math_nodes": expected_math, "all_mathml_nodes": parsed.math,
            "image_nodes": sum(record["image_nodes"] for record in records), "table_nodes": expected_tables,
            "external_render_dependencies": 0}


def inspect_landing_html(text: str, output: Path, expected_books: tuple[str, ...] = BOOKS) -> dict:
    """Validate the separately authored landing page and its offline closure."""
    parsed = Inventory()
    parsed.feed(text)
    require(len(parsed.ids) == len(set(parsed.ids)), "duplicate landing-page HTML IDs")
    require(any(tag == "html" and attrs.get("lang") == "en" for tag, attrs in parsed.elements),
            "landing-page language is not English")
    mains = [attrs for tag, attrs in parsed.elements if tag == "main"]
    require(len(mains) == 1 and mains[0].get("id") == "main-content",
            "expected one landing-page main landmark")
    require(mains[0].get("tabindex") == "-1",
            "landing-page skip target is not programmatically focusable")
    require(any(tag == "a" and attrs.get("class") == "skip-link" and
                attrs.get("href") == "#main-content" for tag, attrs in parsed.elements),
            "missing landing-page skip link")
    for tag, attrs in parsed.elements:
        require(tag not in {"script", "iframe", "object", "embed"},
                "active landing-page HTML content")
        require(not any(key.startswith("on") for key in attrs),
                "active landing-page HTML attribute")

    resources = parsed.resources + [href for tag, href in parsed.hrefs if tag == "link"]
    for target in resources:
        parsed_target = urlsplit(target)
        require(not parsed_target.scheme and not parsed_target.netloc and not parsed_target.query,
                f"external landing-page render dependency: {target}")
        regular(output / unquote(parsed_target.path), output)

    local_links = []
    for tag, target in parsed.hrefs:
        if tag != "a":
            continue
        parsed_target = urlsplit(target)
        require(not parsed_target.scheme and not parsed_target.netloc and not parsed_target.query,
                f"external landing-page navigation target: {target}")
        if parsed_target.path:
            regular(output / unquote(parsed_target.path), output)
            local_links.append(unquote(parsed_target.path))
        elif parsed_target.fragment:
            require(unquote(parsed_target.fragment) in parsed.ids,
                    f"broken landing-page anchor: {target}")
        else:
            raise RuntimeError("empty landing-page link")
    expected = {book + ".html" for book in expected_books}
    require(expected.issubset(set(local_links)),
            "landing page does not link every English book")
    return {"status": "PASS", "main_focus_target": "#main-content",
            "book_links": sorted(expected), "local_navigation_targets": sorted(set(local_links)),
            "render_resources": sorted(set(resources)), "external_render_dependencies": 0}


def template(book: str, navigation: tuple[str, ...]) -> str:
    navigation_html = " · ".join(
        f'<a href="{key}.html"' + (' aria-current="page"' if key == book else '') +
        f'>{escape(BOOK_LABELS[key])}</a>' for key in navigation)
    return '''<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>$pagetitle$</title><link rel="icon" href="favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="reader.css"></head>
<body>
<a class="skip-link" href="#main-content">Skip to main content</a>
<header class="book-header"><p class="edition-label">Independent English edition</p>
<h1 class="book-title">$title$</h1>$if(subtitle)$<p>$subtitle$</p>$endif$
$if(author)$<p>$author$</p>$endif$
<nav aria-label="Books">''' + navigation_html + '''</nav></header>
$if(toc)$<details class="contents" open><summary>Contents</summary>
<nav id="TOC" role="doc-toc" aria-label="Table of contents">$toc$</nav></details>$endif$
<main id="main-content" tabindex="-1">$body$</main>
<footer><p><a href="#TOC">Back to contents</a> · <a href="index.html">All three books</a></p>
<p>Translation and edition production: ''' + PROVENANCE + '''</p>
<p>Course text and media retain their recorded licences. See the edition notices,
media credits, and the packaged source and rights records. No endorsement is implied.</p></footer>
</body></html>
'''


def render_book(book: str, sources: list[Path], metadata: dict, package: Package,
                executable: str, serializer: Callable, navigation: tuple[str, ...] = BOOKS) -> dict:
    require(book in BOOKS and sources, "invalid or empty book")
    require(len(sources) == len(set(sources)), "duplicate book source")
    ensure_favicon(package.output)
    # Validate the whole required list before serialising any source.
    for source in sources:
        regular(source, package.root)
    combined = None
    records = []
    for source in sources:
        document, record = prepare_source(source, package, book, executable, serializer)
        if combined is None:
            combined = document
        else:
            require(document["pandoc-api-version"] == combined["pandoc-api-version"], "Pandoc AST version drift")
            combined["blocks"].extend(document["blocks"])
        records.append(record)
    identifiers = [node["c"][1][0] for node in walk(combined["blocks"]) if node.get("t") == "Header"]
    duplicate = [key for key, count in Counter(identifiers).items() if count > 1]
    require(not duplicate, f"duplicate heading IDs across required inputs: {duplicate}")
    combined["meta"] = {key: {"t": "MetaString", "c": str(metadata[key])}
                        for key in ("title", "subtitle", "author") if metadata.get(key)}
    combined["meta"]["lang"] = {"t": "MetaString", "c": "en"}
    with tempfile.TemporaryDirectory(prefix="english-html-template-") as temporary:
        template_path = Path(temporary) / "reader.html"
        template_path.write_text(template(book, navigation), encoding="utf-8")
        result = pandoc(executable, ["--from=json", "--to=html5", "--mathml", "--standalone",
                                     "--toc", "--toc-depth=2", f"--template={template_path}"],
                        json.dumps(combined, ensure_ascii=False), package.root)
    inspection = inspect_html(result, records, package.output)
    target = package.output / (book + ".html")
    target.write_text(result, encoding="utf-8", newline="\n")
    return {"book": book, "output": fact(target, package.output), "sources": records, "checks": inspection}


def verify_package_links(package: Package, books: dict[str, dict]) -> None:
    for destination_book, fragment in package.cross_links:
        require(destination_book in books, f"cross-book destination missing: {destination_book}")
        require(not fragment or fragment in books[destination_book]["checks"]["ids"],
                f"broken cross-book anchor: {destination_book}#{fragment}")
    for book in books:
        parsed = Inventory()
        parsed.feed((package.output / (book + ".html")).read_text(encoding="utf-8"))
        for tag, target in parsed.hrefs:
            if tag != "a":
                continue
            url = urlsplit(target)
            if not url.scheme and url.path:
                regular(package.output / unquote(url.path), package.output)


def landing_page(metadata: dict[str, dict]) -> str:
    entries = "".join(f'<li><a href="{book}.html">{escape(metadata[book]["title"])}</a></li>' for book in BOOKS)
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            '<title>Algebraic Geometry — English Readers</title><link rel="icon" href="favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="reader.css">'
            '</head><body><a class="skip-link" href="#main-content">Skip to main content</a>'
            '<header><h1>Algebraic Geometry — English Readers</h1></header>'
            '<main id="main-content" tabindex="-1"><nav aria-label="Books"><ol>' + entries + '</ol></nav>'
            '<p>All books use native MathML. Images and source files are included for offline reading. '
            'External source and licence links require a connection. '
            '<a href="rights/LICENSE.md">Preserved licence and attribution notice</a>. '
            'The rights tables are included; this reader is not a complete authority archive.</p></main>'
            '<footer><p>' + PROVENANCE + '</p></footer></body></html>\n')


def build(output: Path) -> dict:
    import reader_common_en as common

    output = output.resolve()
    require(output.is_relative_to((common.ROOT / "build" / "english").resolve()) and
            output != (common.ROOT / "build" / "english").resolve(),
            "output must be a dedicated directory below build/english")
    require(not output.exists(), f"output exists; choose a new versioned directory: {output}")
    gate = common.require_translation_handoffs()
    integration = common.require_integration_receipt()
    sources = {book: common.book_sources(book) for book in BOOKS}
    metadata = {book: common.book_metadata(book) for book in BOOKS}
    for paths in sources.values():
        for path in paths:
            regular(path, common.ROOT)
    executable = pandoc_executable()
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".html-en-", dir=output.parent) as temporary:
        stage = Path(temporary) / "package"
        stage.mkdir()
        mapping = {path.resolve(): book for book, paths in sources.items() for path in paths}
        package = Package(common.ROOT, stage, mapping)
        validate_stylesheet(common.ROOT / "source/en/reader.css")
        package.copy(common.ROOT / "source/en/reader.css", "reader.css")
        ensure_favicon(stage)
        package.copy(common.ROOT / "LICENSE.md", "rights/LICENSE.md")
        # Preserve every course rights table verbatim; prose is in translated credits.
        rights = ["authority/RIGHTS.csv"]
        rights += [f"authority/RIGHTS-unit-{unit:02d}.csv" for unit in range(2, 31)]
        rights += [f"authority/RIGHTS-bgk-unit-{unit:02d}.csv" for unit in range(1, 31)]
        for path in rights:
            package.copy(common.ROOT / path, "rights/" + path)
        books = {book: render_book(book, sources[book], metadata[book], package, executable,
                                   common.serialize_source) for book in BOOKS}
        landing_path = stage / "index.html"
        landing_text = landing_page(metadata)
        landing_path.write_text(landing_text, encoding="utf-8", newline="\n")
        landing_checks = inspect_landing_html(landing_text, stage)
        verify_package_links(package, books)
        require(common.require_translation_handoffs() == gate, "translation inputs changed during the build")
        require(common.require_integration_receipt() == integration, "integration QA changed during the build")
        for copied in package.copied.values():
            require(fact(common.ROOT / copied["path"], common.ROOT) == copied,
                    f"copied input changed during the build: {copied['path']}")
        receipt = {"schema": "english-html-reader-build-v1", "status": "PASS",
                   "provenance": PROVENANCE, "pandoc": EXPECTED_PANDOC,
                   "translation_handoffs": gate, "integration_qa": integration,
                   "landing_page": {"output": fact(landing_path, stage), "checks": landing_checks},
                   "books": books,
                   "copied_inputs": package.copied,
                   "authority_archive_scope": "Only selected image bytes, all 60 rights tables, LICENSE.md, and rights/closure records explicitly named in the English sources; not a full authority archive.",
                   "dependencies": [fact(Path(__file__), common.ROOT),
                                    fact(Path(common.__file__), common.ROOT),
                                    fact(common.ROOT / "scripts/bgk_reader_math_serialization.py", common.ROOT),
                                    fact(common.ROOT / "scripts/bgk_reader_math_serialization_v1.json", common.ROOT)],
                   "files": [fact(path, stage) for path in sorted(stage.rglob("*")) if path.is_file()]}
        (stage / "build-receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n",
                                                encoding="utf-8", newline="\n")
        # Refuse replacement, even if another process created the destination meanwhile.
        require(not output.exists(), "output was created during the build")
        stage.rename(output)
    return receipt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "build/english/html")
    arguments = parser.parse_args()
    receipt = build(arguments.output)
    print(json.dumps({"status": receipt["status"], "output": str(arguments.output.resolve()),
                      "books": list(receipt["books"])}, indent=2))


if __name__ == "__main__":
    main()
