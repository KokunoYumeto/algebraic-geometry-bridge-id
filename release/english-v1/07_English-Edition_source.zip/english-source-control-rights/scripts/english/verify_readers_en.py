#!/usr/bin/env python3
"""Fail-closed post-build QA for the complete English HTML and PDF readers.

The verifier consumes one explicit HTML build receipt and exactly three
single-book PDF double-build receipts.  It never builds the corpus.  A
successful run atomically publishes three independent receipts below a new
``qa/english`` output directory:

* ``MACHINE_QA.json`` -- source/build closure, links, HTML structure and
  Poppler text/page-box/image/font diagnostics;
* ``RESPONSIVE_QA.json`` -- real desktop/tablet/mobile browser measurements;
* ``VISUAL_QA.json`` -- browser screenshots, every-page PDF raster manifests,
  contact sheets and observed high-resolution risk pages.

No receipt is emitted if a required browser, Poppler program, observation or
binding is unavailable.  Production dependencies are imported lazily so the
unit tests can use synthetic fixtures and injected observers without launching
a browser or Poppler.
"""
from __future__ import annotations

import argparse
from collections import Counter
from contextlib import contextmanager
import hashlib
from html.parser import HTMLParser
import json
import math
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import tempfile
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Iterable, Protocol
from urllib.parse import quote, unquote, urlsplit


ROOT = Path(__file__).resolve().parents[2]
BOOKS = ("ak", "bgk", "companion")
HTML_SCHEMA = "english-html-reader-build-v1"
PDF_DOUBLE_SCHEMA = "d100-en-pdf-double-build-v1"
PDF_REPLAY_SCHEMA = "d100-en-pdf-replay-v1"
PENDING_LAYOUT_STATUS = "BUILT_PENDING_LAYOUT_QA"
VIEWPORTS = (
    {"name": "desktop", "width": 1440, "height": 900},
    {"name": "tablet", "width": 834, "height": 1112},
    {"name": "mobile", "width": 390, "height": 844},
)
OUTPUT_FILES = ("MACHINE_QA.json", "RESPONSIVE_QA.json", "VISUAL_QA.json")
HEX_256 = re.compile(r"^[0-9a-f]{64}$")
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


class QAError(RuntimeError):
    """A deterministic reader-QA failure."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise QAError(message)


def json_hash(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True,
                         separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def bytes_fact(path: Path, *, root: Path | None = None,
               recorded_path: str | None = None) -> dict[str, Any]:
    data = path.read_bytes()
    if recorded_path is not None:
        name = recorded_path
    elif root is not None and path.resolve().is_relative_to(root.resolve()):
        name = path.resolve().relative_to(root.resolve()).as_posix()
    else:
        name = str(path.resolve())
    return {"path": name, "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def validate_fact_shape(value: Any, context: str) -> dict[str, Any]:
    require(isinstance(value, dict), f"{context}: file fact is not an object")
    require(isinstance(value.get("path"), str) and value["path"],
            f"{context}: missing file path")
    require(isinstance(value.get("bytes"), int) and value["bytes"] >= 0,
            f"{context}: invalid byte count")
    require(isinstance(value.get("sha256"), str) and
            bool(HEX_256.fullmatch(value["sha256"])),
            f"{context}: invalid SHA-256")
    return {key: value[key] for key in ("path", "bytes", "sha256")}


def read_json(path: Path, context: str) -> dict[str, Any]:
    require(path.is_file(), f"{context} is missing: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise QAError(f"{context} is not valid UTF-8 JSON: {path}") from error
    require(isinstance(value, dict), f"{context} must contain a JSON object")
    return value


def safe_relative(value: str, context: str) -> PurePosixPath:
    require("\\" not in value and not re.match(r"^[A-Za-z]:", value),
            f"{context}: non-portable path: {value!r}")
    pure = PurePosixPath(value)
    require(not pure.is_absolute() and value not in {"", "."},
            f"{context}: path must be relative: {value!r}")
    require(all(part not in {"", ".", ".."} for part in pure.parts),
            f"{context}: unsafe relative path: {value!r}")
    return pure


def safe_join(base: Path, value: str, context: str) -> Path:
    pure = safe_relative(value, context)
    target = (base / Path(*pure.parts)).resolve()
    require(target.is_relative_to(base.resolve()), f"{context}: path escaped its root")
    return target


def root_fact_path(root: Path, fact: dict[str, Any], context: str,
                   *, allow_external: bool = False) -> Path:
    row = validate_fact_shape(fact, context)
    raw = row["path"]
    candidate = Path(raw)
    if candidate.is_absolute():
        require(allow_external, f"{context}: absolute path is not admitted: {raw}")
        return candidate.resolve()
    return safe_join(root, raw, context)


def verify_root_fact(root: Path, fact: dict[str, Any], context: str,
                     *, allow_external: bool = False) -> Path:
    row = validate_fact_shape(fact, context)
    path = root_fact_path(root, row, context, allow_external=allow_external)
    require(path.is_file(), f"{context}: recorded file is missing: {row['path']}")
    current = bytes_fact(path, recorded_path=row["path"])
    require(current == row, f"{context}: recorded bytes are stale: {row['path']}")
    return path


def verify_package_fact(package: Path, fact: dict[str, Any], context: str) -> Path:
    row = validate_fact_shape(fact, context)
    path = safe_join(package, row["path"], context)
    require(path.is_file(), f"{context}: package file is missing: {row['path']}")
    require(bytes_fact(path, recorded_path=row["path"]) == row,
            f"{context}: package bytes differ from receipt: {row['path']}")
    return path


def expected_sources() -> dict[str, list[str]]:
    source = "source/en"
    mastery = (2, 3, 4, 5, 6, 7, 9, 10, 12, 13, 14, 15, 23, 24, 25, 26, 27)
    credits = (1, *range(2, 10), *range(11, 31))
    ak = [f"{source}/frontmatter-units-01-30.md"]
    ak += [f"{source}/{stem}-{unit:02d}{suffix}.md"
           for unit in range(1, 31)
           for stem, suffix in (("lecture", ""), ("worksheet", ""),
                                ("worksheet", "-solutions"))]
    ak += [f"{source}/" + ("media-credits.md" if unit == 1 else
                           f"media-credits-unit-{unit:02d}.md") for unit in credits]
    bgk = [f"{source}/bgk/frontmatter-bgk-units-01-30.md",
           f"{source}/bgk/glossary-bgk-units-01-30.md"]
    bgk += [f"{source}/bgk/{stem}-{unit:02d}{suffix}.md"
            for unit in range(1, 31)
            for stem, suffix in (("lecture", ""), ("worksheet", ""),
                                 ("worksheet", "-solutions"))]
    bgk += [f"{source}/media-credits-bgk-unit-{unit:02d}.md"
            for unit in range(1, 31)]
    companion_names = ["frontmatter.md", "seam-varieties-to-schemes.md"]
    companion_names += [f"mastery-bgk-{unit:02d}.md" for unit in mastery]
    companion_names += [f"integrative-{unit:02d}.md" for unit in range(1, 13)]
    companion_names += ["stacks-navigation-capstone.md"]
    companion = [f"{source}/bridge/{name}" for name in companion_names]
    result = {"ak": ak, "bgk": bgk, "companion": companion}
    require(sum(map(len, result.values())) == 274, "internal source closure is not 274 files")
    return result


def source_fact_map(rows: Iterable[dict[str, Any]], context: str) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for index, value in enumerate(rows):
        row = validate_fact_shape(value, f"{context}[{index}]")
        require(row["path"] not in result, f"{context}: duplicate source fact: {row['path']}")
        result[row["path"]] = row
    return result


class HTMLInventory(HTMLParser):
    """Lossless-enough inventory of the QA-relevant parts of one HTML page."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.ids: list[dict[str, Any]] = []
        self.links: list[dict[str, Any]] = []
        self.resources: list[dict[str, Any]] = []
        self.images: list[dict[str, Any]] = []
        self.mathml: list[dict[str, Any]] = []
        self.tables: list[dict[str, Any]] = []
        self.elements = 0
        self.html_languages: list[str] = []
        self.active_content: list[dict[str, Any]] = []

    def handle_starttag(self, tag: str, attributes: list[tuple[str, str | None]]) -> None:
        attrs = {name.lower(): (value if value is not None else "")
                 for name, value in attributes}
        tag = tag.lower()
        line, column = self.getpos()
        where = {"line": line, "column": column}
        self.elements += 1
        if tag == "html":
            self.html_languages.append(attrs.get("lang", ""))
        if attrs.get("id"):
            self.ids.append({"id": attrs["id"], **where})
        if tag == "a" and "href" in attrs:
            self.links.append({"href": attrs["href"], **where})
        if tag == "link" and "href" in attrs:
            self.resources.append({"attribute": "href", "value": attrs["href"],
                                   "tag": tag, **where})
        for attribute in ("src", "poster", "data"):
            if attrs.get(attribute):
                self.resources.append({"attribute": attribute,
                                       "value": attrs[attribute], "tag": tag, **where})
        if attrs.get("srcset"):
            for candidate in attrs["srcset"].split(","):
                url = candidate.strip().split()[0] if candidate.strip() else ""
                if url:
                    self.resources.append({"attribute": "srcset", "value": url,
                                           "tag": tag, **where})
        if tag == "img":
            self.images.append({"src": attrs.get("src", ""),
                                "alt_present": "alt" in attrs,
                                "alt": attrs.get("alt", ""), **where})
        if tag == "math":
            self.mathml.append(where)
        if tag == "table":
            self.tables.append(where)
        if tag in {"script", "iframe", "object", "embed"}:
            self.active_content.append({"tag": tag, **where})
        for name in attrs:
            if name.startswith("on"):
                self.active_content.append({"tag": tag, "attribute": name, **where})

    handle_startendtag = handle_starttag


def _resolve_html_reference(package: Path, page: Path, value: str,
                            context: str, *, resource: bool) -> dict[str, Any]:
    parsed = urlsplit(value)
    if parsed.scheme or parsed.netloc:
        if resource:
            raise QAError(f"{context}: external render resource: {value}")
        if parsed.scheme == "mailto":
            require(not parsed.netloc and bool(parsed.path),
                    f"{context}: malformed mail link: {value}")
        else:
            require(parsed.scheme in {"http", "https"} and bool(parsed.netloc),
                    f"{context}: unsafe external link: {value}")
        return {"kind": "external", "value": value, "scheme": parsed.scheme}
    require(not parsed.query, f"{context}: local reference has a query: {value}")
    require("\\" not in parsed.path, f"{context}: backslash in local reference: {value}")
    path_text = unquote(parsed.path)
    if path_text:
        target = (page.parent / Path(*PurePosixPath(path_text).parts)).resolve()
        require(target.is_relative_to(package.resolve()),
                f"{context}: local reference escapes package: {value}")
        require(target.is_file(), f"{context}: broken local reference: {value}")
    else:
        target = page
    return {"kind": "local", "value": value,
            "target": target.relative_to(package.resolve()).as_posix(),
            "fragment": unquote(parsed.fragment)}


def inspect_html_package(root: Path, receipt_path: Path) -> dict[str, Any]:
    receipt_path = receipt_path.resolve()
    require(receipt_path.name == "build-receipt.json", "HTML receipt must be build-receipt.json")
    require(receipt_path.is_relative_to((root / "build/english").resolve()),
            "HTML receipt is outside build/english")
    receipt = read_json(receipt_path, "HTML build receipt")
    require(receipt.get("schema") == HTML_SCHEMA and receipt.get("status") == "PASS",
            "HTML build receipt is not a PASS english-html-reader-build-v1 receipt")
    package = receipt_path.parent

    files = receipt.get("files")
    require(isinstance(files, list) and files, "HTML receipt has no package file inventory")
    inventory: dict[str, dict[str, Any]] = {}
    for index, fact in enumerate(files):
        row = validate_fact_shape(fact, f"HTML files[{index}]")
        safe_relative(row["path"], f"HTML files[{index}]")
        require(row["path"] not in inventory, f"duplicate HTML package fact: {row['path']}")
        verify_package_fact(package, row, f"HTML package {row['path']}")
        inventory[row["path"]] = row
    actual = {path.relative_to(package).as_posix() for path in package.rglob("*")
              if path.is_file() and path.resolve() != receipt_path}
    require(actual == set(inventory),
            "HTML package inventory differs from its exact on-disk closure: "
            f"missing={sorted(set(inventory) - actual)}, extra={sorted(actual - set(inventory))}")

    books = receipt.get("books")
    require(isinstance(books, dict) and set(books) == set(BOOKS),
            "HTML receipt does not contain exactly ak, bgk and companion")
    expected = expected_sources()
    expected_source_count = sum(len(rows) for rows in expected.values())
    all_source_facts: dict[str, dict[str, Any]] = {}
    page_facts: dict[str, dict[str, Any]] = {}
    expected_page_checks: dict[str, dict[str, Any]] = {}
    for book in BOOKS:
        record = books[book]
        require(isinstance(record, dict) and record.get("book") == book,
                f"HTML book record is malformed: {book}")
        output = validate_fact_shape(record.get("output"), f"HTML {book} output")
        verify_package_fact(package, output, f"HTML {book} output")
        require(output["path"] == f"{book}.html", f"unexpected HTML output for {book}")
        page_facts[output["path"]] = output
        sources = record.get("sources")
        require(isinstance(sources, list), f"HTML {book} sources are missing")
        observed_paths = []
        for index, source_record in enumerate(sources):
            require(isinstance(source_record, dict), f"HTML {book} source record {index} is invalid")
            source = validate_fact_shape(source_record.get("source"),
                                         f"HTML {book} source {index}")
            observed_paths.append(source["path"])
            require(source["path"] not in all_source_facts,
                    f"HTML source appears in multiple books: {source['path']}")
            verify_root_fact(root, source, f"HTML source {source['path']}")
            all_source_facts[source["path"]] = source
        require(observed_paths == expected[book],
                f"HTML {book} source order/closure differs from the required reader closure")
        checks = record.get("checks")
        require(isinstance(checks, dict) and checks.get("status") == "PASS",
                f"HTML builder checks are not PASS for {book}")
        expected_page_checks[output["path"]] = checks

    landing = receipt.get("landing_page")
    require(isinstance(landing, dict), "HTML landing page record is missing")
    landing_output = validate_fact_shape(landing.get("output"), "HTML landing output")
    verify_package_fact(package, landing_output, "HTML landing output")
    require(landing_output["path"] == "index.html", "HTML landing page is not index.html")
    require(isinstance(landing.get("checks"), dict) and
            landing["checks"].get("status") == "PASS",
            "HTML landing-page builder checks are not PASS")
    page_facts["index.html"] = landing_output
    expected_page_checks["index.html"] = landing["checks"]
    require(set(path for path in inventory if path.lower().endswith(".html")) == set(page_facts),
            "HTML pages on disk differ from landing/book receipt records")

    copied = receipt.get("copied_inputs")
    require(isinstance(copied, dict), "HTML copied-input map is missing")
    for destination, source_fact in copied.items():
        safe_relative(destination, f"HTML copied destination {destination}")
        source = validate_fact_shape(source_fact, f"HTML copied source for {destination}")
        verify_root_fact(root, source, f"HTML copied source {source['path']}")
        target = safe_join(package, destination, f"HTML copied destination {destination}")
        require(target.is_file(), f"HTML copied destination is missing: {destination}")
        copied_current = bytes_fact(target, recorded_path=source["path"])
        require(copied_current == source,
                f"HTML copied bytes no longer match source input: {destination}")
        require(destination in inventory, f"HTML copied destination is absent from file inventory: {destination}")
    for source_path, source in all_source_facts.items():
        destination = "sources/" + source_path
        require(copied.get(destination) == source,
                f"HTML package does not bind its exact Markdown source copy: {source_path}")

    for name in ("translation_handoffs", "dependencies"):
        values = receipt.get(name)
        require(isinstance(values, list) and values, f"HTML receipt lacks {name}")
        for index, value in enumerate(values):
            verify_root_fact(root, value, f"HTML {name}[{index}]")
    verify_root_fact(root, receipt.get("integration_qa"), "HTML integration QA")

    parsed_pages: dict[str, tuple[HTMLInventory, Path]] = {}
    for relative in sorted(page_facts):
        path = safe_join(package, relative, f"HTML page {relative}")
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as error:
            raise QAError(f"HTML page is not valid UTF-8: {relative}") from error
        parser = HTMLInventory()
        try:
            parser.feed(text)
            parser.close()
        except Exception as error:
            raise QAError(f"HTML parser failed for {relative}") from error
        ids = [row["id"] for row in parser.ids]
        duplicates = sorted(name for name, count in Counter(ids).items() if count > 1)
        require(not duplicates, f"duplicate IDs in {relative}: {duplicates}")
        require(parser.html_languages == ["en"], f"{relative}: expected one html lang=en root")
        require(not parser.active_content, f"{relative}: active content found: {parser.active_content}")
        require(all(row["alt_present"] and row["alt"].strip() for row in parser.images),
                f"{relative}: an image has absent or empty alternative text")
        parsed_pages[relative] = (parser, path)

    page_ids = {relative: {row["id"] for row in parser.ids}
                for relative, (parser, _) in parsed_pages.items()}
    page_rows = []
    all_local_targets: set[str] = set()
    for relative in sorted(parsed_pages):
        parser, path = parsed_pages[relative]
        links = []
        for index, item in enumerate(parser.links):
            resolved = _resolve_html_reference(package, path, item["href"],
                                               f"{relative} link {index}", resource=False)
            if resolved["kind"] == "local":
                all_local_targets.add(resolved["target"])
                fragment = resolved["fragment"]
                if fragment and resolved["target"].lower().endswith(".html"):
                    require(fragment in page_ids.get(resolved["target"], set()),
                            f"{relative}: broken HTML fragment {item['href']}")
            links.append({**item, **resolved})
        resources = []
        for index, item in enumerate(parser.resources):
            resolved = _resolve_html_reference(package, path, item["value"],
                                               f"{relative} resource {index}", resource=True)
            all_local_targets.add(resolved["target"])
            resources.append({**item, **resolved})
        checks = expected_page_checks[relative]
        if relative != "index.html":
            require(len(parser.mathml) == checks.get("all_mathml_nodes"),
                    f"{relative}: MathML count differs from build receipt")
            require(len(parser.images) == checks.get("image_nodes"),
                    f"{relative}: image count differs from build receipt")
            require(len(parser.tables) == checks.get("table_nodes"),
                    f"{relative}: table count differs from build receipt")
            expected_ids = set(checks.get("ids", []))
            require(expected_ids == page_ids[relative],
                    f"{relative}: complete ID set differs from build receipt")
        page_rows.append({
            "path": relative, "file": page_facts[relative],
            "element_count": parser.elements,
            "ids": parser.ids, "links": links, "resources": resources,
            "mathml_nodes": parser.mathml, "tables": parser.tables,
            "images": parser.images,
        })

    return {
        "receipt": bytes_fact(receipt_path, root=root),
        "receipt_data": receipt, "package": package,
        "translation_handoffs": receipt["translation_handoffs"],
        "integration_qa": receipt["integration_qa"],
        "expected_source_count": expected_source_count,
        "file_inventory": [inventory[name] for name in sorted(inventory)],
        "source_facts": all_source_facts,
        "pages": page_rows,
        "local_targets": sorted(all_local_targets),
        "checks": {
            "exact_package_inventory": True,
            "exact_required_source_closure": len(all_source_facts) == expected_source_count,
            "current_source_bytes_bound": True,
            "packaged_source_bytes_bound": True,
            "every_html_page_parsed": len(page_rows) == 4,
            "every_link_and_resource_resolved": True,
            "every_id_unique_and_receipt_bound": True,
            "every_image_has_nonempty_alt": True,
        },
    }


def _closure_source_facts(replay: dict[str, Any], root: Path,
                          book: str, context: str) -> dict[str, dict[str, Any]]:
    closure = replay.get("input_closure")
    require(isinstance(closure, dict) and closure.get("book") == book,
            f"{context}: invalid frozen input closure")
    require(replay.get("input_closure_sha256") == json_hash(closure),
            f"{context}: input closure hash mismatch")
    sources = closure.get("sources")
    require(isinstance(sources, list), f"{context}: source closure missing")
    facts = source_fact_map(sources, f"{context} sources")
    require(list(facts) == expected_sources()[book],
            f"{context}: PDF source order/closure is not exact for {book}")
    for path, fact in facts.items():
        verify_root_fact(root, fact, f"{context} source {path}")
    return facts


def _verify_closure_files(root: Path, value: Any, context: str) -> None:
    """Verify every path/bytes/hash triple embedded in a frozen PDF closure."""
    if isinstance(value, dict):
        if {"path", "bytes", "sha256"}.issubset(value):
            fact = validate_fact_shape(value, context)
            verify_root_fact(root, fact, context, allow_external=True)
            return
        for key, child in value.items():
            _verify_closure_files(root, child, f"{context}.{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            _verify_closure_files(root, child, f"{context}[{index}]")


def inspect_pdf_bindings(root: Path, receipt_paths: list[Path],
                         html: dict[str, Any]) -> list[dict[str, Any]]:
    require(len(receipt_paths) == 3, "exactly three PDF double-build receipts are required")
    observed_books: set[str] = set()
    result = []
    html_receipt = html["receipt_data"]
    for path in receipt_paths:
        path = path.resolve()
        require(path.is_relative_to((root / "build/english/pdf").resolve()),
                f"PDF double-build receipt is outside build/english/pdf: {path}")
        report = read_json(path, "PDF double-build receipt")
        require(report.get("schema") == PDF_DOUBLE_SCHEMA and
                report.get("status") == PENDING_LAYOUT_STATUS and
                report.get("language") == "en",
                f"PDF double-build receipt is not an English pending-layout receipt: {path}")
        books = report.get("books")
        require(isinstance(books, list) and len(books) == 1,
                f"each PDF receipt must bind exactly one book: {path}")
        row = books[0]
        book = row.get("book") if isinstance(row, dict) else None
        require(book in BOOKS and book not in observed_books,
                f"duplicate or unknown PDF book in {path}: {book}")
        observed_books.add(book)
        require(row.get("identical_pdf_bytes") is True,
                f"PDF replays are not declared byte-identical: {book}")
        require(isinstance(row.get("page_count"), int) and row["page_count"] > 0,
                f"PDF report has an invalid page count: {book}")
        replay_checks = row.get("replay_checks")
        require(isinstance(replay_checks, dict) and replay_checks and all(replay_checks.values()),
                f"PDF replay checks are not all PASS: {book}")
        mutex = report.get("mutex")
        require(isinstance(mutex, dict) and mutex.get("released") is True,
                f"PDF report lacks released mutex custody: {book}")
        require(report.get("integration_qa") == html_receipt.get("integration_qa"),
                f"HTML/PDF integration-QA binding differs for {book}")
        require(report.get("translation_handoffs") == html_receipt.get("translation_handoffs"),
                f"HTML/PDF translation-handoff binding differs for {book}")

        replay_records: dict[str, dict[str, Any]] = {}
        output_paths: dict[str, Path] = {}
        for label in ("a", "b"):
            output_fact = validate_fact_shape(row.get(label), f"PDF {book} replay {label} output")
            output_path = verify_root_fact(root, output_fact,
                                           f"PDF {book} replay {label} output")
            output_paths[label] = output_path
            replay_path = output_path.parent / "BUILD_RECEIPT.json"
            replay = read_json(replay_path, f"PDF {book} replay {label} receipt")
            require(replay.get("schema") == PDF_REPLAY_SCHEMA and
                    replay.get("status") == PENDING_LAYOUT_STATUS and
                    replay.get("language") == "en" and replay.get("book") == book and
                    replay.get("replay") == label,
                    f"PDF replay receipt identity is invalid: {book}/{label}")
            require(replay.get("output") == output_fact,
                    f"PDF report/replay output binding differs: {book}/{label}")
            require(replay.get("pdf_validation", {}).get("file") == output_fact and
                    replay.get("pdf_validation", {}).get("page_count") == row.get("page_count"),
                    f"PDF structural validation binding differs: {book}/{label}")
            require(replay.get("mutex", {}).get("released") is True and
                    replay.get("mutex_held_during_replay") is True,
                    f"PDF replay lacks complete mutex custody: {book}/{label}")
            _verify_closure_files(root, replay.get("input_closure"),
                                  f"PDF {book}/{label} closure")
            sources = _closure_source_facts(replay, root, book,
                                            f"PDF {book}/{label}")
            expected_html = {name: html["source_facts"][name]
                             for name in expected_sources()[book]}
            require(sources == expected_html,
                    f"HTML/PDF source facts differ for {book}/{label}")
            replay_records[label] = {
                "receipt": bytes_fact(replay_path, root=root),
                "receipt_data": replay, "sources": sources,
            }
        require(all(row["a"].get(key) == row["b"].get(key)
                    for key in ("bytes", "sha256")),
                f"PDF replay byte facts are not identical in report: {book}")
        require(output_paths["a"].read_bytes() == output_paths["b"].read_bytes(),
                f"PDF replay bytes differ on disk: {book}")
        require(replay_records["a"]["receipt_data"]["input_closure_sha256"] ==
                replay_records["b"]["receipt_data"]["input_closure_sha256"] ==
                row.get("input_closure_sha256"),
                f"PDF input closure hashes differ across report/replays: {book}")
        require(replay_records["a"]["sources"] == replay_records["b"]["sources"],
                f"PDF source closures differ between replays: {book}")
        result.append({
            "book": book, "receipt": bytes_fact(path, root=root),
            "receipt_data": report,
            "page_count": row["page_count"], "canonical_pdf": output_paths["a"],
            "canonical_output": row["a"],
            "equivalent_replay_output": row["b"],
            "replay_receipts": {label: replay_records[label]["receipt"]
                                for label in ("a", "b")},
            "translation_handoffs": report["translation_handoffs"],
            "integration_qa": report["integration_qa"],
            "source_facts": replay_records["a"]["sources"],
            "replays": replay_records,
            "checks": {
                "double_build_receipt_valid": True,
                "released_mutex_custody": True,
                "replay_receipts_bound": True,
                "input_closure_hashes_exact": True,
                "current_source_bytes_bound": True,
                "html_pdf_source_facts_equal": True,
                "normalized_pdf_bytes_identical": True,
            },
        })
    require(observed_books == set(BOOKS),
            "three PDF receipts do not cover exactly ak, bgk and companion")
    return sorted(result, key=lambda value: BOOKS.index(value["book"]))


RESPONSIVE_SCRIPT = r"""
() => {
  const visible = el => {
    const s = getComputedStyle(el), r = el.getBoundingClientRect();
    if (el.matches && el.matches('.skip-link:not(:focus)')) return false;
    return s.display !== 'none' && s.visibility !== 'hidden' && r.width > 0 && r.height > 0;
  };
  const scrollContainer = el => {
    for (let node = el; node && node !== document.documentElement; node = node.parentElement) {
      const s = getComputedStyle(node);
      if ((s.overflowX === 'auto' || s.overflowX === 'scroll') &&
          node.scrollWidth > node.clientWidth + 1) return true;
    }
    return false;
  };
  const describe = el => {
    const r = el.getBoundingClientRect();
    return {tag: el.tagName.toLowerCase(), id: el.id || '',
            class_name: typeof el.className === 'string' ? el.className : '',
            left: r.left, right: r.right, top: r.top, bottom: r.bottom,
            width: r.width, height: r.height};
  };
  const elements = [...document.querySelectorAll('body *')].filter(visible);
  const overflow = elements.filter(el => {
    const r = el.getBoundingClientRect();
    return (r.left < -1 || r.right > window.innerWidth + 1) && !scrollContainer(el);
  }).map(describe);
  const images = [...document.images].map(img => ({...describe(img),
    complete: img.complete, natural_width: img.naturalWidth,
    natural_height: img.naturalHeight, alt: img.getAttribute('alt')}));
  const maths = [...document.querySelectorAll('math')].map(describe);
  const tables = [...document.querySelectorAll('table')].map(table => ({...describe(table),
    client_width: table.clientWidth, scroll_width: table.scrollWidth,
    scroll_contained: scrollContainer(table)}));
  const ids = [...document.querySelectorAll('[id]')].map(el => el.id);
  const stylesheets = [...document.styleSheets].map(sheet => {
    let ruleCount = null, readable = true;
    try { ruleCount = sheet.cssRules.length; } catch (_) { readable = false; }
    return {href: sheet.href || '', readable, rule_count: ruleCount};
  });
  return {
    url: location.href, title: document.title, ready_state: document.readyState,
    viewport: {width: window.innerWidth, height: window.innerHeight,
               device_pixel_ratio: window.devicePixelRatio},
    document: {scroll_width: document.documentElement.scrollWidth,
               client_width: document.documentElement.clientWidth,
               scroll_height: document.documentElement.scrollHeight},
    fonts_status: document.fonts ? document.fonts.status : 'unsupported',
    element_count: elements.length, link_count: document.links.length,
    ids, stylesheets, overflowing_elements: overflow, images, mathml: maths, tables
  };
}
"""


class BrowserObserver(Protocol):
    def observe(self, package: Path, pages: list[dict[str, Any]],
                evidence: Path) -> dict[str, Any]: ...


class PDFObserver(Protocol):
    def observe(self, pdf: Path, book: str, page_count: int,
                evidence: Path) -> dict[str, Any]: ...


class _QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, format: str, *args: Any) -> None:
        return


@contextmanager
def local_server(directory: Path):
    def handler(*args: Any, **kwargs: Any):
        return _QuietHandler(*args, directory=str(directory), **kwargs)
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_address[1]}"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


def evidence_fact(path: Path, evidence: Path) -> dict[str, Any]:
    require(path.resolve().is_relative_to(evidence.resolve()),
            "evidence artifact escaped staging directory")
    relative = path.resolve().relative_to(evidence.resolve()).as_posix()
    return bytes_fact(path, recorded_path="evidence/" + relative)


class PlaywrightBrowserObserver:
    def observe(self, package: Path, pages: list[dict[str, Any]],
                evidence: Path) -> dict[str, Any]:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as error:
            raise QAError("Python Playwright is unavailable") from error
        destination = evidence / "responsive"
        destination.mkdir(parents=True)
        rows: list[dict[str, Any]] = []
        launch_errors: list[str] = []
        with local_server(package) as origin, sync_playwright() as runtime:
            browser = None
            engine_name = ""
            browser_executable = None
            candidates: list[tuple[str, Path | None]] = [
                ("chromium", None),
                ("firefox", None),
                ("webkit", None),
            ]
            # The Python adapter may be installed without Playwright's private
            # browser bundle.  Reuse an installed system Chromium browser in
            # that case instead of downloading a second browser solely for QA.
            for executable in (
                Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
                Path(r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"),
                Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
                Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
            ):
                if executable.is_file():
                    candidates.append(("chromium", executable))
            for name, explicit_executable in candidates:
                try:
                    browser_type = getattr(runtime, name)
                    launch = {"headless": True}
                    if explicit_executable is not None:
                        launch["executable_path"] = str(explicit_executable)
                    browser = browser_type.launch(**launch)
                    engine_name = name if explicit_executable is None else f"{name}-system"
                    executable = explicit_executable or Path(browser_type.executable_path)
                    if executable.is_file():
                        browser_executable = bytes_fact(
                            executable, recorded_path=str(executable.resolve()))
                    break
                except Exception as error:  # engine package may not be installed
                    launch_errors.append(f"{name}: {type(error).__name__}: {error}")
            # The Python binding may be present without Playwright's separate
            # browser bundle.  A locally installed Chromium-family browser is
            # still a real headless observation backend; record its exact
            # executable fact rather than silently treating it as bundled.
            if browser is None:
                local_candidates = (
                    Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
                    Path(r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"),
                    Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
                    Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
                )
                for executable in local_candidates:
                    if not executable.is_file():
                        continue
                    try:
                        browser = runtime.chromium.launch(
                            headless=True, executable_path=str(executable))
                        engine_name = "chromium-local"
                        browser_executable = bytes_fact(
                            executable, recorded_path=str(executable.resolve()))
                        break
                    except Exception as error:
                        launch_errors.append(
                            f"chromium-local {executable}: "
                            f"{type(error).__name__}: {error}")
            require(browser is not None,
                    "Playwright is installed but no headless engine launched: " +
                    " | ".join(launch_errors))
            try:
                version = browser.version
                for viewport in VIEWPORTS:
                    context = browser.new_context(
                        viewport={"width": viewport["width"], "height": viewport["height"]},
                        device_scale_factor=1,
                    )
                    try:
                        for page_record in pages:
                            relative = page_record["path"]
                            page = context.new_page()
                            console_errors: list[str] = []
                            page_errors: list[str] = []
                            page.on("console", lambda message: console_errors.append(message.text)
                                    if message.type == "error" else None)
                            page.on("pageerror", lambda error: page_errors.append(str(error)))
                            url = origin + "/" + "/".join(quote(part) for part in PurePosixPath(relative).parts)
                            response = page.goto(url, wait_until="networkidle", timeout=60_000)
                            require(response is not None and response.ok,
                                    f"browser failed to load {relative}: HTTP " +
                                    (str(response.status) if response else "no response"))
                            page.evaluate("""async () => {
                              if (document.fonts) await document.fonts.ready;
                              await Promise.all([...document.images].map(img => img.complete ?
                                Promise.resolve() : new Promise(resolve => {
                                  img.addEventListener('load', resolve, {once:true});
                                  img.addEventListener('error', resolve, {once:true});
                                })));
                            }""")
                            metrics = page.evaluate(RESPONSIVE_SCRIPT)
                            screenshot = destination / f"{Path(relative).stem}-{viewport['name']}.png"
                            # A thirty-unit page can exceed browser full-page bitmap limits.
                            # DOM measurements cover every element; the screenshot is a real
                            # initial-viewport witness at the measured dimensions.
                            page.screenshot(path=str(screenshot), full_page=False)
                            require(screenshot.read_bytes().startswith(PNG_SIGNATURE),
                                    f"browser screenshot is not PNG: {relative}/{viewport['name']}")
                            rows.append({"page": relative, "viewport": dict(viewport),
                                         "metrics": metrics,
                                         "console_errors": console_errors,
                                         "page_errors": page_errors,
                                         "screenshot": evidence_fact(screenshot, evidence),
                                         "capture_scope": "initial_viewport"})
                            page.close()
                    finally:
                        context.close()
            finally:
                browser.close()
        return {"observed": True,
                "backend": {"adapter": "playwright", "engine": engine_name,
                            "version": version, "headless": True,
                            "executable": browser_executable},
                "viewports": [dict(row) for row in VIEWPORTS], "pages": rows}


class SeleniumBrowserObserver:
    def observe(self, package: Path, pages: list[dict[str, Any]],
                evidence: Path) -> dict[str, Any]:
        try:
            from selenium import webdriver
            from selenium.webdriver.chrome.service import Service as ChromeService
            from selenium.webdriver.edge.service import Service as EdgeService
        except ImportError as error:
            raise QAError("Python Selenium is unavailable") from error
        destination = evidence / "responsive"
        destination.mkdir(parents=True)
        errors = []
        driver = None
        engine = ""
        driver_executable = None
        for name, driver_name, factory, options_type, service_type in (
            ("chrome", "chromedriver", webdriver.Chrome, webdriver.ChromeOptions, ChromeService),
            ("edge", "msedgedriver", webdriver.Edge, webdriver.EdgeOptions, EdgeService),
        ):
            executable = shutil.which(driver_name)
            if not executable:
                errors.append(f"{name}: local {driver_name} is unavailable")
                continue
            try:
                options = options_type()
                options.add_argument("--headless=new")
                options.add_argument("--disable-gpu")
                options.add_argument("--no-sandbox")
                driver = factory(service=service_type(executable_path=executable), options=options)
                engine = name
                driver_executable = bytes_fact(
                    Path(executable), recorded_path=str(Path(executable).resolve()))
                break
            except Exception as error:
                errors.append(f"{name}: {type(error).__name__}: {error}")
        require(driver is not None, "Selenium found no launchable headless browser: " + " | ".join(errors))
        rows = []
        try:
            version = driver.capabilities.get("browserVersion", "unknown")
            driver.set_page_load_timeout(60)
            driver.set_script_timeout(60)
            with local_server(package) as origin:
                for viewport in VIEWPORTS:
                    driver.set_window_rect(width=viewport["width"], height=viewport["height"])
                    for _ in range(3):
                        actual = driver.execute_script("return [window.innerWidth, window.innerHeight]")
                        if actual == [viewport["width"], viewport["height"]]:
                            break
                        driver.set_window_rect(
                            width=viewport["width"] + (viewport["width"] - actual[0]),
                            height=viewport["height"] + (viewport["height"] - actual[1]))
                    for page_record in pages:
                        relative = page_record["path"]
                        url = origin + "/" + "/".join(quote(part) for part in PurePosixPath(relative).parts)
                        driver.get(url)
                        driver.execute_async_script("""
                          const done = arguments[arguments.length - 1];
                          (async () => { if (document.fonts) await document.fonts.ready;
                            await Promise.all([...document.images].map(img => img.complete ?
                              Promise.resolve() : new Promise(resolve => {
                                img.addEventListener('load', resolve, {once:true});
                                img.addEventListener('error', resolve, {once:true});
                              }))); done(); })();
                        """)
                        metrics = driver.execute_script("return (" + RESPONSIVE_SCRIPT + ")();")
                        screenshot = destination / f"{Path(relative).stem}-{viewport['name']}.png"
                        require(driver.save_screenshot(str(screenshot)),
                                f"Selenium screenshot failed: {relative}/{viewport['name']}")
                        require(screenshot.read_bytes().startswith(PNG_SIGNATURE),
                                f"Selenium screenshot is not PNG: {relative}/{viewport['name']}")
                        console_errors = []
                        try:
                            console_errors = [item.get("message", "") for item in driver.get_log("browser")
                                              if item.get("level") == "SEVERE"]
                        except Exception:
                            pass
                        rows.append({"page": relative, "viewport": dict(viewport),
                                     "metrics": metrics, "console_errors": console_errors,
                                     "page_errors": [],
                                     "screenshot": evidence_fact(screenshot, evidence),
                                     "capture_scope": "viewport"})
        finally:
            driver.quit()
        return {"observed": True,
                "backend": {"adapter": "selenium", "engine": engine,
                            "version": version, "headless": True,
                            "driver_executable": driver_executable},
                "viewports": [dict(row) for row in VIEWPORTS], "pages": rows}


class AutomaticBrowserObserver:
    def observe(self, package: Path, pages: list[dict[str, Any]],
                evidence: Path) -> dict[str, Any]:
        failures = []
        for observer in (PlaywrightBrowserObserver(), SeleniumBrowserObserver()):
            try:
                return observer.observe(package, pages, evidence)
            except QAError as error:
                failures.append(str(error))
        raise QAError("No available headless browser could perform responsive QA: " +
                      " | ".join(failures))


def validate_browser_observation(observation: dict[str, Any],
                                 static_pages: list[dict[str, Any]],
                                 evidence: Path) -> None:
    require(isinstance(observation, dict) and observation.get("observed") is True,
            "responsive observer did not attest real observation")
    require(observation.get("viewports") == [dict(row) for row in VIEWPORTS],
            "responsive observer did not use the required viewport set")
    pages = observation.get("pages")
    require(isinstance(pages, list), "responsive page observations are missing")
    expected = {(page["path"], viewport["name"])
                for page in static_pages for viewport in VIEWPORTS}
    observed = {(row.get("page"), row.get("viewport", {}).get("name")) for row in pages}
    require(observed == expected and len(pages) == len(expected),
            "responsive observations do not cover every page/viewport exactly once")
    static = {row["path"]: row for row in static_pages}
    for row in pages:
        page_name = row["page"]
        viewport = row["viewport"]
        metrics = row.get("metrics")
        require(isinstance(metrics, dict) and metrics.get("ready_state") == "complete",
                f"browser did not fully load {page_name}/{viewport['name']}")
        actual = metrics.get("viewport", {})
        require(actual.get("width") == viewport["width"] and
                actual.get("height") == viewport["height"],
                f"browser viewport differs from request: {page_name}/{viewport['name']}")
        document = metrics.get("document", {})
        require(document.get("scroll_width", math.inf) <= document.get("client_width", 0) + 1,
                f"document-level horizontal overflow: {page_name}/{viewport['name']}")
        require(metrics.get("overflowing_elements") == [],
                f"uncontained responsive overflow: {page_name}/{viewport['name']}")
        require(row.get("console_errors") == [] and row.get("page_errors") == [],
                f"browser errors: {page_name}/{viewport['name']}")
        require(metrics.get("fonts_status") in {"loaded", "unsupported"},
                f"browser fonts did not settle: {page_name}/{viewport['name']}")
        stylesheets = metrics.get("stylesheets")
        require(isinstance(stylesheets, list) and stylesheets and
                all(item.get("readable") and item.get("rule_count", 0) > 0
                    for item in stylesheets),
                f"browser stylesheet observation failed: {page_name}/{viewport['name']}")
        require(metrics.get("ids") == [item["id"] for item in static[page_name]["ids"]],
                f"browser/static ID inventories differ: {page_name}/{viewport['name']}")
        require(metrics.get("link_count") == len(static[page_name]["links"]),
                f"browser/static link counts differ: {page_name}/{viewport['name']}")
        images = metrics.get("images")
        maths = metrics.get("mathml")
        tables = metrics.get("tables")
        require(isinstance(images, list) and len(images) == len(static[page_name]["images"]),
                f"browser image count differs from parser: {page_name}/{viewport['name']}")
        require(all(item.get("complete") and item.get("natural_width", 0) > 0 and
                    item.get("natural_height", 0) > 0 and
                    isinstance(item.get("alt"), str) and item["alt"].strip()
                    for item in images),
                f"browser found a broken or unlabelled image: {page_name}/{viewport['name']}")
        require(isinstance(maths, list) and len(maths) == len(static[page_name]["mathml_nodes"]) and
                all(item.get("width", 0) > 0 and item.get("height", 0) > 0 for item in maths),
                f"browser MathML observation failed: {page_name}/{viewport['name']}")
        require(isinstance(tables, list) and len(tables) == len(static[page_name]["tables"]) and
                all(item.get("width", 0) > 0 and item.get("height", 0) > 0 and
                    (item.get("scroll_width", 0) <= item.get("client_width", 0) + 1 or
                     item.get("scroll_contained") is True) for item in tables),
                f"browser table layout failed: {page_name}/{viewport['name']}")
        screenshot = validate_fact_shape(row.get("screenshot"),
                                         f"responsive screenshot {page_name}/{viewport['name']}")
        verify_package_fact(evidence.parent, screenshot,
                            f"responsive screenshot {page_name}/{viewport['name']}")
        require((evidence.parent / screenshot["path"]).read_bytes().startswith(PNG_SIGNATURE),
                f"responsive screenshot is not PNG: {page_name}/{viewport['name']}")


def _run(command: list[str], *, timeout: int = 300) -> str:
    process = subprocess.run(command, capture_output=True, check=False, timeout=timeout)
    if process.returncode:
        stderr = process.stderr.decode("utf-8", errors="replace").strip()
        raise QAError(f"command failed ({process.returncode}): {Path(command[0]).name}: {stderr}")
    return process.stdout.decode("utf-8", errors="replace")


def _png_metrics(path: Path) -> dict[str, Any]:
    try:
        from PIL import Image
    except ImportError as error:
        raise QAError("Pillow is required for raster observation/contact sheets") from error
    with Image.open(path) as original:
        require(original.format == "PNG", f"Poppler render is not PNG: {path}")
        width, height = original.size
        require(width > 0 and height > 0, f"Poppler rendered an empty image: {path}")
        image = original.convert("L")
        image.thumbnail((1200, 1600))
        histogram = image.histogram()
        total = sum(histogram)
        white = sum(histogram[250:]) / total
        dark = sum(histogram[:245]) / total
        edge = max(1, min(image.width, image.height) // 100)
        bands = [image.crop((0, 0, image.width, edge)),
                 image.crop((0, image.height - edge, image.width, image.height)),
                 image.crop((0, 0, edge, image.height)),
                 image.crop((image.width - edge, 0, image.width, image.height))]
        edge_hist = [0] * 256
        for band in bands:
            for index, count in enumerate(band.histogram()):
                edge_hist[index] += count
        edge_total = sum(edge_hist)
        edge_ink = sum(edge_hist[:245]) / edge_total if edge_total else 0.0
        minimum, maximum = image.getextrema()
    return {"width_px": width, "height_px": height,
            "near_white_ratio": round(white, 8), "ink_ratio": round(dark, 8),
            "edge_ink_ratio": round(edge_ink, 8),
            "gray_min": minimum, "gray_max": maximum}


def _parse_box_output(text: str, page: int) -> dict[str, Any] | None:
    boxes: dict[str, list[float]] = {}
    size = None
    rotation = None
    for line in text.splitlines():
        match = re.match(r"(?:Page\s+\d+\s+)?(MediaBox|CropBox|BleedBox|TrimBox|ArtBox):\s+"
                         r"([-+0-9.]+)\s+([-+0-9.]+)\s+([-+0-9.]+)\s+([-+0-9.]+)", line)
        if match:
            boxes[match.group(1)] = [float(match.group(i)) for i in range(2, 6)]
        match = re.match(r"(?:Page(?:\s+\d+)?\s+)?size:\s+([-+0-9.]+)\s+x\s+([-+0-9.]+)\s+pts", line, re.I)
        if match:
            size = [float(match.group(1)), float(match.group(2))]
        match = re.match(r"(?:Page(?:\s+\d+)?\s+)?rot:\s+(-?\d+)", line, re.I)
        if match:
            rotation = int(match.group(1))
    if "MediaBox" not in boxes or "CropBox" not in boxes:
        return None
    media = boxes["MediaBox"]
    crop = boxes["CropBox"]
    require(media[2] > media[0] and media[3] > media[1], f"invalid MediaBox on page {page}")
    require(crop[0] >= media[0] - .01 and crop[1] >= media[1] - .01 and
            crop[2] <= media[2] + .01 and crop[3] <= media[3] + .01 and
            crop[2] > crop[0] and crop[3] > crop[1],
            f"invalid CropBox on page {page}")
    return {"page": page, "size_points": size,
            "rotation": rotation, "boxes": boxes,
            "raw_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()}


def _parse_fonts(text: str) -> list[dict[str, Any]]:
    rows = []
    pattern = re.compile(r"^(.*?)\s+(yes|no)\s+(yes|no)\s+(yes|no)\s+(\d+)\s+(\d+)\s*$")
    for line in text.splitlines():
        match = pattern.match(line)
        if match and not line.lstrip().startswith("name"):
            prefix = match.group(1).split()
            rows.append({"descriptor": match.group(1),
                         "name": prefix[0] if prefix else "",
                         "embedded": match.group(2) == "yes",
                         "subset": match.group(3) == "yes",
                         "unicode": match.group(4) == "yes",
                         "object": [int(match.group(5)), int(match.group(6))]})
    return rows


def _parse_images(text: str) -> list[dict[str, Any]]:
    rows = []
    for line in text.splitlines():
        parts = line.split()
        if len(parts) >= 6 and all(part.isdigit() for part in parts[:2]) and parts[0] != "page":
            rows.append({"page": int(parts[0]), "index": int(parts[1]),
                         "type": parts[2], "width": int(parts[3]),
                         "height": int(parts[4]), "color": parts[5],
                         "raw": line.strip()})
    return rows


def _contact_sheets(page_paths: list[tuple[int, Path]], destination: Path,
                    evidence: Path) -> list[dict[str, Any]]:
    try:
        from PIL import Image, ImageDraw
    except ImportError as error:
        raise QAError("Pillow is required for PDF contact sheets") from error
    destination.mkdir(parents=True)
    result = []
    per_sheet, columns = 20, 4
    thumb_w, thumb_h, label_h = 220, 300, 22
    for group_index in range(0, len(page_paths), per_sheet):
        group = page_paths[group_index:group_index + per_sheet]
        rows = math.ceil(len(group) / columns)
        sheet = Image.new("RGB", (columns * thumb_w, rows * (thumb_h + label_h)), "#d8d8d8")
        draw = ImageDraw.Draw(sheet)
        page_numbers = []
        for slot, (page_number, path) in enumerate(group):
            with Image.open(path) as source:
                thumb = source.convert("RGB")
                thumb.thumbnail((thumb_w - 8, thumb_h - 8))
            x = (slot % columns) * thumb_w + (thumb_w - thumb.width) // 2
            y = (slot // columns) * (thumb_h + label_h) + 4
            sheet.paste(thumb, (x, y))
            draw.text(((slot % columns) * thumb_w + 6,
                       (slot // columns) * (thumb_h + label_h) + thumb_h),
                      f"page {page_number}", fill="black")
            page_numbers.append(page_number)
        target = destination / f"contact-{group_index // per_sheet + 1:03d}.png"
        sheet.save(target, format="PNG", optimize=True)
        result.append({"pages": page_numbers, "file": evidence_fact(target, evidence)})
    return result


def _risk_plan(pages: list[dict[str, Any]], image_counts: Counter[int]) -> list[dict[str, Any]]:
    candidates = []
    last = len(pages)
    for row in pages:
        reasons = []
        page = row["page"]
        if page in {1, last}:
            reasons.append("boundary_page")
        if row["text"]["characters"] < 20:
            reasons.append("low_extracted_text")
        if row["raster"]["near_white_ratio"] > .985:
            reasons.append("near_blank_raster")
        if row["raster"]["edge_ink_ratio"] > .02:
            reasons.append("edge_ink_clipping_risk")
        if image_counts[page] >= 2:
            reasons.append("multiple_embedded_images")
        score = (4 * ("low_extracted_text" in reasons) +
                 4 * ("near_blank_raster" in reasons) +
                 5 * ("edge_ink_clipping_risk" in reasons) +
                 min(image_counts[page], 3) +
                 1 * ("boundary_page" in reasons))
        candidates.append({"page": page, "score": score,
                           "reasons": reasons or ["highest_remaining_raster_risk"]})
    selected = sorted(candidates, key=lambda value: (-value["score"], value["page"]))[:12]
    for boundary in (1, last):
        if not any(row["page"] == boundary for row in selected):
            selected.append(next(row for row in candidates if row["page"] == boundary))
    return sorted(selected, key=lambda value: value["page"])


class PopplerPDFObserver:
    def __init__(self) -> None:
        names = ("pdfinfo", "pdftoppm", "pdftotext", "pdffonts", "pdfimages")
        self.tools = {name: shutil.which(name) for name in names}
        missing = [name for name, path in self.tools.items() if not path]
        require(not missing, "required Poppler programs are unavailable: " + ", ".join(missing))

    def observe(self, pdf: Path, book: str, page_count: int,
                evidence: Path) -> dict[str, Any]:
        destination = evidence / "pdf" / book
        pages_dir = destination / "pages"
        text_dir = destination / "text"
        risk_dir = destination / "risk"
        pages_dir.mkdir(parents=True)
        text_dir.mkdir(parents=True)
        risk_dir.mkdir(parents=True)
        pdfinfo = _run([self.tools["pdfinfo"], "-box", str(pdf)])
        match = re.search(r"^Pages:\s+(\d+)\s*$", pdfinfo, re.M)
        require(match and int(match.group(1)) == page_count,
                f"Poppler page count differs from receipt: {book}")
        box_rows = []
        for page in range(1, page_count + 1):
            text = _run([self.tools["pdfinfo"], "-f", str(page), "-l", str(page),
                         "-box", str(pdf)])
            parsed = _parse_box_output(text, page)
            require(parsed is not None, f"Poppler omitted page boxes: {book} page {page}")
            box_rows.append(parsed)

        text_output = text_dir / "all-pages.txt"
        _run([self.tools["pdftotext"], "-layout", "-enc", "UTF-8",
              str(pdf), str(text_output)])
        require(text_output.is_file(), f"pdftotext created no output: {book}")
        extracted = text_output.read_text(encoding="utf-8", errors="strict")
        chunks = extracted.split("\f")
        if chunks and not chunks[-1].strip():
            chunks.pop()
        require(len(chunks) == page_count,
                f"pdftotext page segmentation differs from receipt: {book}")
        text_manifest = [{"page": number,
                          "characters": len(text),
                          "non_whitespace_characters": len(re.sub(r"\s", "", text)),
                          "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()}
                         for number, text in enumerate(chunks, 1)]

        prefix = pages_dir / "page"
        _run([self.tools["pdftoppm"], "-png", "-r", "144", str(pdf), str(prefix)],
             timeout=1800)
        rendered: dict[int, Path] = {}
        for path in pages_dir.glob("page-*.png"):
            match = re.search(r"-(\d+)\.png$", path.name)
            if match:
                rendered[int(match.group(1))] = path
        require(set(rendered) == set(range(1, page_count + 1)),
                f"Poppler did not render every page exactly once: {book}")

        fonts_text = _run([self.tools["pdffonts"], str(pdf)])
        fonts = _parse_fonts(fonts_text)
        require(fonts and all(row["embedded"] for row in fonts),
                f"PDF has absent or unembedded fonts: {book}")
        images_text = _run([self.tools["pdfimages"], "-list", str(pdf)])
        images = _parse_images(images_text)
        require(all(1 <= row["page"] <= page_count and row["width"] > 0 and row["height"] > 0
                    for row in images), f"invalid pdfimages diagnostics: {book}")
        image_counts = Counter(row["page"] for row in images)

        page_rows = []
        for number in range(1, page_count + 1):
            path = rendered[number]
            metrics = _png_metrics(path)
            box = box_rows[number - 1]["boxes"]["CropBox"]
            expected_ratio = (box[2] - box[0]) / (box[3] - box[1])
            if (box_rows[number - 1].get("rotation") or 0) % 180:
                expected_ratio = 1 / expected_ratio
            observed_ratio = metrics["width_px"] / metrics["height_px"]
            require(abs(expected_ratio - observed_ratio) <= .02,
                    f"render/page-box aspect ratio mismatch: {book} page {number}")
            text_row = text_manifest[number - 1]
            require(not (metrics["gray_min"] >= 252 and
                         text_row["non_whitespace_characters"] == 0 and
                         image_counts[number] == 0),
                    f"wholly blank unexplained PDF page: {book} page {number}")
            page_rows.append({"page": number,
                              "render": evidence_fact(path, evidence),
                              "raster": metrics, "text": text_row,
                              "boxes": box_rows[number - 1],
                              "embedded_image_count": image_counts[number]})

        contacts = _contact_sheets([(number, rendered[number])
                                    for number in range(1, page_count + 1)],
                                   destination / "contact-sheets", evidence)
        plan = _risk_plan(page_rows, image_counts)
        high_resolution = []
        for item in plan:
            number = item["page"]
            target_prefix = risk_dir / f"page-{number:04d}"
            _run([self.tools["pdftoppm"], "-png", "-r", "216",
                  "-f", str(number), "-l", str(number), "-singlefile",
                  str(pdf), str(target_prefix)], timeout=300)
            target = target_prefix.with_suffix(".png")
            require(target.is_file(), f"risk-page render missing: {book} page {number}")
            high_resolution.append({**item, "status": "OBSERVED",
                                    "render": evidence_fact(target, evidence),
                                    "raster": _png_metrics(target)})
        return {
            "observed": True, "book": book, "page_count": page_count,
            "poppler": {name: bytes_fact(Path(path), recorded_path=str(Path(path).resolve()))
                        for name, path in self.tools.items()},
            "document_info_sha256": hashlib.sha256(pdfinfo.encode("utf-8")).hexdigest(),
            "pages": page_rows,
            "font_diagnostics": {"status": "PASS", "fonts": fonts,
                                 "raw_sha256": hashlib.sha256(fonts_text.encode("utf-8")).hexdigest()},
            "image_diagnostics": {"status": "PASS", "images": images,
                                  "raw_sha256": hashlib.sha256(images_text.encode("utf-8")).hexdigest()},
            "text_extraction": {"status": "PASS", "all_pages": text_manifest,
                                "aggregate": evidence_fact(text_output, evidence)},
            "contact_sheets": contacts,
            "risk_page_plan": high_resolution,
            "checks": {"every_page_rendered": True, "every_page_text_observed": True,
                       "every_page_box_observed": True, "fonts_embedded": True,
                       "image_inventory_observed": True,
                       "every_contact_sheet_generated": True,
                       "every_planned_risk_page_observed": True},
        }


def validate_pdf_observation(observation: dict[str, Any], book: str,
                             page_count: int, evidence: Path) -> None:
    require(isinstance(observation, dict) and observation.get("observed") is True and
            observation.get("book") == book and observation.get("page_count") == page_count,
            f"PDF observer did not attest the expected document: {book}")
    pages = observation.get("pages")
    require(isinstance(pages, list) and [row.get("page") for row in pages] ==
            list(range(1, page_count + 1)), f"PDF page manifest is incomplete: {book}")
    for row in pages:
        render = validate_fact_shape(row.get("render"), f"PDF {book} page render")
        verify_package_fact(evidence.parent, render, f"PDF {book} page render")
        require((evidence.parent / render["path"]).read_bytes().startswith(PNG_SIGNATURE),
                f"PDF render is not PNG: {book} page {row['page']}")
        require(isinstance(row.get("text"), dict) and
                HEX_256.fullmatch(str(row["text"].get("sha256", ""))),
                f"PDF text manifest missing: {book} page {row['page']}")
        require(isinstance(row.get("boxes"), dict) and
                "MediaBox" in row["boxes"].get("boxes", {}) and
                "CropBox" in row["boxes"].get("boxes", {}),
                f"PDF page boxes missing: {book} page {row['page']}")
        require(isinstance(row.get("raster"), dict) and
                row["raster"].get("width_px", 0) > 0 and
                row["raster"].get("height_px", 0) > 0,
                f"PDF raster diagnostics missing: {book} page {row['page']}")
    require(observation.get("font_diagnostics", {}).get("status") == "PASS" and
            observation.get("image_diagnostics", {}).get("status") == "PASS" and
            observation.get("text_extraction", {}).get("status") == "PASS",
            f"PDF Poppler diagnostics are incomplete: {book}")
    contacts = observation.get("contact_sheets")
    require(isinstance(contacts, list) and contacts, f"PDF contact-sheet plan is empty: {book}")
    contact_pages = []
    for item in contacts:
        fact = validate_fact_shape(item.get("file"), f"PDF {book} contact sheet")
        verify_package_fact(evidence.parent, fact, f"PDF {book} contact sheet")
        contact_pages.extend(item.get("pages", []))
    require(contact_pages == list(range(1, page_count + 1)),
            f"PDF contact sheets do not cover every page exactly once: {book}")
    plan = observation.get("risk_page_plan")
    require(isinstance(plan, list) and plan and all(row.get("status") == "OBSERVED" for row in plan),
            f"PDF risk-page plan was not actually observed: {book}")
    for item in plan:
        fact = validate_fact_shape(item.get("render"), f"PDF {book} risk render")
        verify_package_fact(evidence.parent, fact, f"PDF {book} risk render")
    checks = observation.get("checks")
    require(isinstance(checks, dict) and checks and all(checks.values()),
            f"PDF observer checks are not all PASS: {book}")


def _without_private_bindings(value: dict[str, Any]) -> dict[str, Any]:
    return {key: child for key, child in value.items()
            if key not in {"receipt_data", "package", "canonical_pdf", "replays"}}


def verify_readers(*, root: Path, html_receipt: Path,
                   pdf_receipts: list[Path], output: Path,
                   browser: BrowserObserver | None = None,
                   poppler: PDFObserver | None = None) -> dict[str, Path]:
    root = root.resolve()
    output = output.resolve()
    qa_root = (root / "qa/english").resolve()
    require(output.is_relative_to(qa_root) and output != qa_root,
            "reader-QA output must be a dedicated directory below qa/english")
    require(not output.exists(), f"reader-QA output already exists: {output}")
    html = inspect_html_package(root, html_receipt)
    pdfs = inspect_pdf_bindings(root, pdf_receipts, html)
    output.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix=".reader-qa-en-", dir=output.parent) as temporary:
        stage = Path(temporary) / "receipt-set"
        evidence = stage / "evidence"
        evidence.mkdir(parents=True)
        browser_observer = browser if browser is not None else AutomaticBrowserObserver()
        responsive = browser_observer.observe(html["package"], html["pages"], evidence)
        validate_browser_observation(responsive, html["pages"], evidence)

        pdf_observer = poppler if poppler is not None else PopplerPDFObserver()
        pdf_observations = []
        for binding in pdfs:
            observed = pdf_observer.observe(binding["canonical_pdf"], binding["book"],
                                             binding["page_count"], evidence)
            validate_pdf_observation(observed, binding["book"],
                                     binding["page_count"], evidence)
            pdf_observations.append(observed)

        html_public = _without_private_bindings(html)
        pdf_public = [_without_private_bindings(row) for row in pdfs]
        input_receipts = {"html": html["receipt"],
                          "pdf_double_builds": [row["receipt"] for row in pdfs]}
        machine = {
            "schema": "english-reader-machine-qa-v1", "status": "PASS",
            "language": "en", "inputs": input_receipts,
            "source_build_binding": {
                "expected_source_count": html["expected_source_count"],
                "html_sources": [html["source_facts"][path]
                                 for book in BOOKS for path in expected_sources()[book]],
                "html_pdf_exact_match": True,
                "integration_qa_exact_match": True,
                "translation_handoffs_exact_match": True,
            },
            "html": html_public,
            "pdf": [{"binding": pdf_public[index],
                     "page_boxes": [row["boxes"] for row in observation["pages"]],
                     "text_pages": [row["text"] for row in observation["pages"]],
                     "text_aggregate": observation["text_extraction"].get("aggregate"),
                     "font_diagnostics": observation["font_diagnostics"],
                     "image_diagnostics": observation["image_diagnostics"],
                     "poppler": observation.get("poppler", {}),
                     "checks": observation["checks"]}
                    for index, observation in enumerate(pdf_observations)],
            "checks": {"all_build_receipts_current_and_exact": True,
                       "all_274_source_bytes_current_and_cross_format_bound": True,
                       "all_html_pages_links_ids_mathml_tables_images_alt_resources_parsed": True,
                       "all_pdf_pages_have_poppler_text_boxes_and_renders": True,
                       "all_pdf_font_and_image_diagnostics_observed": True},
            "human_gate": False,
        }
        responsive_receipt = {
            "schema": "english-reader-responsive-qa-v1", "status": "PASS",
            "language": "en", "inputs": input_receipts,
            "observation": responsive,
            "checks": {"real_headless_browser_observation": True,
                       "desktop_tablet_mobile_complete": True,
                       "no_document_or_uncontained_element_overflow": True,
                       "all_images_mathml_and_tables_laid_out": True,
                       "no_browser_or_console_errors": True},
            "human_gate": False,
        }
        visual = {
            "schema": "english-reader-visual-qa-v1", "status": "PASS",
            "language": "en", "inputs": input_receipts,
            "html_screenshots": [{"page": row["page"], "viewport": row["viewport"],
                                  "capture_scope": row.get("capture_scope"),
                                  "file": row["screenshot"]}
                                 for row in responsive["pages"]],
            "pdf": [{"book": observation["book"],
                     "page_count": observation["page_count"],
                     "page_renders": [{"page": row["page"], "file": row["render"],
                                       "raster": row["raster"]}
                                      for row in observation["pages"]],
                     "contact_sheet_plan": observation["contact_sheets"],
                     "risk_page_plan": observation["risk_page_plan"]}
                    for observation in pdf_observations],
            "checks": {"every_html_page_viewport_screenshot_observed": True,
                       "every_pdf_page_render_observed": True,
                       "contact_sheets_cover_every_pdf_page": True,
                       "risk_page_plan_high_resolution_observed": True},
            "human_gate": False,
        }
        payloads = {"MACHINE_QA.json": machine,
                    "RESPONSIVE_QA.json": responsive_receipt,
                    "VISUAL_QA.json": visual}
        for name, payload in payloads.items():
            (stage / name).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
                                      encoding="utf-8", newline="\n")
        require(not output.exists(), "reader-QA output appeared during verification")
        stage.rename(output)
    return {name: output / name for name in OUTPUT_FILES}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--html-receipt", type=Path, required=True)
    parser.add_argument("--pdf-receipt", type=Path, action="append", required=True,
                        help="Repeat exactly three times, once for each single-book double build")
    parser.add_argument("--output", type=Path, required=True,
                        help="New dedicated output directory below qa/english")
    arguments = parser.parse_args()
    paths = verify_readers(root=ROOT, html_receipt=arguments.html_receipt,
                           pdf_receipts=arguments.pdf_receipt, output=arguments.output)
    print(json.dumps({"status": "PASS",
                      "receipts": {name: str(path.resolve()) for name, path in paths.items()}},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
