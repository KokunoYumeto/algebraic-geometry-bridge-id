"""Build all three English PDFs in two serialized, byte-identical replays.

Full translation and integrated source-bound QA must exist before execution.
This module never invokes legacy builders or writes Indonesian artifacts.
The caller must run the PDF skill's artifact-operation marker before the
first actual authoring invocation. Importing/testing this module builds nothing.
"""
from __future__ import annotations

import argparse
import ast
import ctypes
from ctypes import wintypes
import html
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import time
import threading
import types
from urllib.parse import unquote, urlsplit

from markdown_it import MarkdownIt
from pypdf import PdfReader


# Load the shared reader module from the exact bytes recorded by this process.
# A normal import can execute a cached bytecode image and then hash different,
# later source bytes.  Executing this immutable snapshot makes the receipt's
# reader-common identity the code actually consumed by the build.
THIS_FILE = Path(__file__).resolve()
BOOTSTRAP_ROOT = THIS_FILE.parents[2]
READER_COMMON_PATH = BOOTSTRAP_ROOT / "scripts/english/reader_common_en.py"
READER_COMMON_BYTES = READER_COMMON_PATH.read_bytes()
reader_common = types.ModuleType("d100_frozen_reader_common_en")
reader_common.__file__ = str(READER_COMMON_PATH)
exec(compile(READER_COMMON_BYTES, str(READER_COMMON_PATH), "exec"), reader_common.__dict__)

ROOT = reader_common.ROOT
EPOCH = reader_common.EPOCH
PROVENANCE = reader_common.PROVENANCE
READ_FORMAT = reader_common.READ_FORMAT
book_sources = reader_common.book_sources
book_metadata = reader_common.book_metadata
require_translation_handoffs = reader_common.require_translation_handoffs
require_integration_receipt = reader_common.require_integration_receipt
serialize_source = reader_common.serialize_source
split_frontmatter = reader_common.split_frontmatter

OUTPUT = ROOT / "build/english/pdf"
HEADER = ROOT / "source/en/pdf-header.tex"
BUILD_READER = ROOT / "scripts/build_reader.py"
MATH_SERIALIZER = ROOT / "scripts/bgk_reader_math_serialization.py"
MUTEX_NAME = r"Global\InterlanguageTeXSlotV1"
PDF_IDS = re.compile(rb"/ID\s*\[\s*<[0-9a-fA-F]{32}>\s*<[0-9a-fA-F]{32}>\s*\]")
RAW_HTML_IMAGE = re.compile(r"<\s*img\b", re.I)
MARKDOWN = MarkdownIt("commonmark", {"html": True})


class STARTUPINFOW(ctypes.Structure):
    _fields_ = [("cb", wintypes.DWORD), ("lpReserved", wintypes.LPWSTR),
                ("lpDesktop", wintypes.LPWSTR), ("lpTitle", wintypes.LPWSTR),
                *[(name, wintypes.DWORD) for name in (
                    "dwX", "dwY", "dwXSize", "dwYSize", "dwXCountChars",
                    "dwYCountChars", "dwFillAttribute", "dwFlags")],
                ("wShowWindow", wintypes.WORD), ("cbReserved2", wintypes.WORD),
                ("lpReserved2", ctypes.c_void_p), ("hStdInput", wintypes.HANDLE),
                ("hStdOutput", wintypes.HANDLE), ("hStdError", wintypes.HANDLE)]


class STARTUPINFOEXW(ctypes.Structure):
    _fields_ = [("StartupInfo", STARTUPINFOW), ("lpAttributeList", ctypes.c_void_p)]


class PROCESS_INFORMATION(ctypes.Structure):
    _fields_ = [("hProcess", wintypes.HANDLE), ("hThread", wintypes.HANDLE),
                ("dwProcessId", wintypes.DWORD), ("dwThreadId", wintypes.DWORD)]


class JOB_BASIC_LIMITS(ctypes.Structure):
    _fields_ = [("PerProcessUserTimeLimit", ctypes.c_longlong),
                ("PerJobUserTimeLimit", ctypes.c_longlong), ("LimitFlags", wintypes.DWORD),
                ("MinimumWorkingSetSize", ctypes.c_size_t), ("MaximumWorkingSetSize", ctypes.c_size_t),
                ("ActiveProcessLimit", wintypes.DWORD), ("Affinity", ctypes.c_size_t),
                ("PriorityClass", wintypes.DWORD), ("SchedulingClass", wintypes.DWORD)]


class IO_COUNTERS(ctypes.Structure):
    _fields_ = [(name, ctypes.c_ulonglong) for name in (
        "ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
        "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]


class JOB_EXTENDED_LIMITS(ctypes.Structure):
    _fields_ = [("BasicLimitInformation", JOB_BASIC_LIMITS), ("IoInfo", IO_COUNTERS),
                *[(name, ctypes.c_size_t) for name in (
                    "ProcessMemoryLimit", "JobMemoryLimit", "PeakProcessMemoryUsed", "PeakJobMemoryUsed")]]


class JOB_ACCOUNTING(ctypes.Structure):
    _fields_ = [(name, ctypes.c_longlong) for name in (
        "TotalUserTime", "TotalKernelTime", "ThisPeriodTotalUserTime", "ThisPeriodTotalKernelTime")] + [
        (name, wintypes.DWORD) for name in (
            "TotalPageFaultCount", "TotalProcesses", "ActiveProcesses", "TotalTerminatedProcesses")]


def windows_kernel():
    if os.name != "nt":
        raise RuntimeError("The PDF worker requires Windows 10+ job objects and the global TeX mutex")
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    signatures = {
        "CreateMutexW": ([ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR], wintypes.HANDLE),
        "WaitForSingleObject": ([wintypes.HANDLE, wintypes.DWORD], wintypes.DWORD),
        "ReleaseMutex": ([wintypes.HANDLE], wintypes.BOOL),
        "CloseHandle": ([wintypes.HANDLE], wintypes.BOOL),
        "CreateJobObjectW": ([ctypes.c_void_p, wintypes.LPCWSTR], wintypes.HANDLE),
        "CreateFileW": ([wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                         ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD,
                         wintypes.HANDLE], wintypes.HANDLE),
        "SetInformationJobObject": ([wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD], wintypes.BOOL),
        "QueryInformationJobObject": ([wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p], wintypes.BOOL),
        "TerminateJobObject": ([wintypes.HANDLE, wintypes.UINT], wintypes.BOOL),
        "InitializeProcThreadAttributeList": ([ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(ctypes.c_size_t)], wintypes.BOOL),
        "UpdateProcThreadAttribute": ([ctypes.c_void_p, wintypes.DWORD, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_void_p], wintypes.BOOL),
        "DeleteProcThreadAttributeList": ([ctypes.c_void_p], None),
        "CreateProcessW": ([wintypes.LPCWSTR, wintypes.LPWSTR, ctypes.c_void_p, ctypes.c_void_p, wintypes.BOOL, wintypes.DWORD, ctypes.c_void_p, wintypes.LPCWSTR, ctypes.POINTER(STARTUPINFOEXW), ctypes.POINTER(PROCESS_INFORMATION)], wintypes.BOOL),
        "ResumeThread": ([wintypes.HANDLE], wintypes.DWORD),
        "GetExitCodeProcess": ([wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)], wintypes.BOOL),
    }
    for name, (arguments, result) in signatures.items():
        function = getattr(kernel, name)
        function.argtypes, function.restype = arguments, result
    return kernel


def wincheck(value, operation):
    if not value:
        raise OSError(ctypes.get_last_error(), operation)


def wait_for_file_release(path, kernel, timeout=1.0):
    """Prove no descendant still holds the worker log before mutex release."""
    if not 0 < timeout <= 10:
        raise ValueError("File-release timeout must be positive and bounded")
    deadline = time.monotonic() + timeout
    invalid = ctypes.c_void_p(-1).value
    while True:
        ctypes.set_last_error(0)
        handle = kernel.CreateFileW(str(path), 0x80000000, 0, None, 3, 0x80, None)
        if handle not in (None, 0, invalid):
            wincheck(kernel.CloseHandle(handle), "CloseHandle(log release probe)")
            return
        error = ctypes.get_last_error()
        if error not in (32, 33):  # sharing or lock violation are retryable
            raise OSError(error, f"CreateFileW(exclusive log probe): {path}")
        if time.monotonic() >= deadline:
            raise RuntimeError(f"Worker log handle was not released within {timeout}s: {path}")
        time.sleep(0.01)


# A failed OS observation must not close ownership handles or release the mutex.
# Keep strong references on this exceptional path; no destructor releases them.
FAILED_CUSTODY = []


class WindowsJob:
    """Kernel ownership, assigned atomically before any worker instruction runs.

    No breakaway flags are enabled. Ordinary CreateProcess descendants and
    nested jobs remain owned even if an intermediate process exits instantly.
    WMI/service-broker launches are out of scope and are not used by this runner.
    """
    def __init__(self, kernel=None):
        self.kernel = kernel or windows_kernel()
        self.handle = self.kernel.CreateJobObjectW(None, None)
        wincheck(self.handle, "CreateJobObjectW")
        self.process = PROCESS_INFORMATION()
        self.cleanup_attempted = False
        self.started = False
        limits = JOB_EXTENDED_LIMITS()
        limits.BasicLimitInformation.LimitFlags = 0x2000  # KILL_ON_JOB_CLOSE; no breakaway.
        try:
            wincheck(self.kernel.SetInformationJobObject(self.handle, 9, ctypes.byref(limits), ctypes.sizeof(limits)),
                     "SetInformationJobObject(KILL_ON_JOB_CLOSE)")
        except BaseException:
            self.kernel.CloseHandle(self.handle)  # No process has been created.
            self.handle = None
            raise

    def launch(self, arguments, cwd, stream, environment):
        import msvcrt
        # The explicit HANDLE_LIST excludes the job, mutex, and unrelated handles.
        # Duplicate only the two I/O descriptors, and close those duplicates as
        # soon as CreateProcess returns. The originals remain non-inheritable.
        with open(os.devnull, "rb") as null_stream:
            log_fd, input_fd = os.dup(stream.fileno()), os.dup(null_stream.fileno())
            attributes = None
            initialized = False
            try:
                os.set_inheritable(log_fd, True)
                os.set_inheritable(input_fd, True)
                handles = (wintypes.HANDLE * 2)(msvcrt.get_osfhandle(log_fd), msvcrt.get_osfhandle(input_fd))
                jobs = (wintypes.HANDLE * 1)(self.handle)
                size = ctypes.c_size_t()
                self.kernel.InitializeProcThreadAttributeList(None, 2, 0, ctypes.byref(size))
                if not size.value:
                    raise RuntimeError("Windows process attribute-list size unavailable")
                attributes = ctypes.create_string_buffer(size.value)
                wincheck(self.kernel.InitializeProcThreadAttributeList(attributes, 2, 0, ctypes.byref(size)),
                         "InitializeProcThreadAttributeList")
                initialized = True
                wincheck(self.kernel.UpdateProcThreadAttribute(attributes, 0, 0x20002, handles, ctypes.sizeof(handles), None, None),
                         "UpdateProcThreadAttribute(HANDLE_LIST)")
                # Windows 10+ JOB_LIST assigns ownership as part of CreateProcess,
                # avoiding even the suspended-create/assignment failure interval.
                wincheck(self.kernel.UpdateProcThreadAttribute(attributes, 0, 0x2000D, jobs, ctypes.sizeof(jobs), None, None),
                         "UpdateProcThreadAttribute(JOB_LIST)")
                startup = STARTUPINFOEXW()
                startup.StartupInfo.cb = ctypes.sizeof(startup)
                startup.StartupInfo.dwFlags = 0x100  # STARTF_USESTDHANDLES
                startup.StartupInfo.hStdInput = handles[1]
                startup.StartupInfo.hStdOutput = handles[0]
                startup.StartupInfo.hStdError = handles[0]
                startup.lpAttributeList = ctypes.cast(attributes, ctypes.c_void_p)
                command = ctypes.create_unicode_buffer(subprocess.list2cmdline(arguments))
                env = ctypes.create_unicode_buffer("\0".join(
                    key + "=" + value for key, value in sorted(environment.items(), key=lambda pair: pair[0].upper())) + "\0\0")
                flags = 0x4 | 0x400 | 0x80000 | 0x08000000  # SUSPENDED, UNICODE_ENVIRONMENT, EXTENDED_STARTUPINFO, NO_WINDOW
                wincheck(self.kernel.CreateProcessW(arguments[0], command, None, None, True, flags,
                         env, str(cwd), ctypes.byref(startup), ctypes.byref(self.process)), "CreateProcessW(JOB_LIST)")
                self.started = True
                if self.kernel.ResumeThread(self.process.hThread) == 0xFFFFFFFF:
                    raise OSError(ctypes.get_last_error(), "ResumeThread")
            finally:
                if initialized:
                    self.kernel.DeleteProcThreadAttributeList(attributes)
                os.close(input_fd)
                os.close(log_fd)
                if self.process.hThread:
                    self.kernel.CloseHandle(self.process.hThread)
                    self.process.hThread = None

    def accounting(self):
        state = JOB_ACCOUNTING()
        wincheck(self.kernel.QueryInformationJobObject(self.handle, 1, ctypes.byref(state), ctypes.sizeof(state), None),
                 "QueryInformationJobObject(accounting)")
        limits = JOB_EXTENDED_LIMITS()
        wincheck(self.kernel.QueryInformationJobObject(self.handle, 9, ctypes.byref(limits), ctypes.sizeof(limits), None),
                 "QueryInformationJobObject(peak memory)")
        return {"active_processes": state.ActiveProcesses, "total_processes": state.TotalProcesses,
                "terminated_processes": state.TotalTerminatedProcesses,
                "peak_job_committed_bytes": limits.PeakJobMemoryUsed}

    def root_exit_code(self):
        if not self.started:
            return 0
        wait = self.kernel.WaitForSingleObject(self.process.hProcess, 0)
        if wait == 0x102:
            return None
        if wait != 0:
            raise RuntimeError(f"Root process wait failed: {wait:#x}")
        code = wintypes.DWORD()
        wincheck(self.kernel.GetExitCodeProcess(self.process.hProcess, ctypes.byref(code)), "GetExitCodeProcess")
        return code.value

    def empty(self):
        return self.accounting()["active_processes"] == 0 and self.root_exit_code() is not None

    def terminate_and_drain(self, timeout=10):
        self.cleanup_attempted = True
        # Termination is addressed only by this fresh, unnamed owned job handle.
        wincheck(self.kernel.TerminateJobObject(self.handle, 1), "TerminateJobObject(owned job)")
        deadline = time.monotonic() + timeout
        last_error = None
        while True:
            try:
                if self.empty():
                    return
            except OSError as error:
                last_error = error
            if time.monotonic() >= deadline:
                raise RuntimeError("Owned job exit could not be confirmed within cleanup deadline; custody retained") from last_error
            time.sleep(0.05)

    def close_empty(self):
        if not self.empty():
            raise RuntimeError("Refusing to close a nonempty or unobserved job")
        if self.process.hProcess:
            wincheck(self.kernel.CloseHandle(self.process.hProcess), "CloseHandle(process)")
            self.process.hProcess = None
        wincheck(self.kernel.CloseHandle(self.handle), "CloseHandle(empty job)")
        self.handle = None


class TeXSlot:
    """Hold the same mutex through workers, descendant drain, replays and checks."""
    def __init__(self, timeout_ms=60000):
        if not isinstance(timeout_ms, int) or not 0 <= timeout_ms <= 60000:
            raise ValueError("Mutex acquisition must use one bounded 0..60000ms timeout")
        self.timeout_ms = timeout_ms
        self.handle = None
        self.acquired = False
        self.jobs = []
        self.release_blocked_reason = None
        self.receipt = {"name": MUTEX_NAME, "owner_pid": os.getpid(), "timeout_ms": timeout_ms,
                        "released": False, "process_ownership": "atomic Windows JOB_LIST; no breakaway"}

    def __enter__(self):
        if self.handle or self.acquired:
            raise RuntimeError("TeXSlot cannot be entered recursively")
        self.kernel = windows_kernel()
        self.handle = self.kernel.CreateMutexW(None, False, MUTEX_NAME)
        wincheck(self.handle, "CreateMutexW")
        result = self.kernel.WaitForSingleObject(self.handle, self.timeout_ms)
        if result not in (0, 0x80):
            self.kernel.CloseHandle(self.handle)
            self.handle = None
            raise RuntimeError(f"TeX mutex not acquired; wait result {result:#x}")
        self.acquired = True
        self.owner_thread = threading.get_ident()
        self.receipt.update(acquired=True, abandoned_mutex_recovered=result == 0x80, acquired_unix=time.time())
        return self

    def assert_owned(self):
        if not self.acquired or not self.handle or threading.get_ident() != self.owner_thread:
            raise RuntimeError("A live TeXSlot owned by this thread is required")

    def register(self, job):
        self.assert_owned()
        if self.jobs:
            raise RuntimeError("A second worker cannot overlap the owned job")
        self.jobs.append(job)

    def block_release(self, reason):
        self.assert_owned()
        self.release_blocked_reason = str(reason)
        self.receipt["release_blocked_reason"] = self.release_blocked_reason

    def __exit__(self, exc_type, exc, tb):
        self.assert_owned()
        try:
            for job in list(self.jobs):
                if not job.cleanup_attempted:
                    job.terminate_and_drain()
                job.close_empty()
                self.jobs.remove(job)
            if self.release_blocked_reason:
                raise RuntimeError(self.release_blocked_reason)
            wincheck(self.kernel.ReleaseMutex(self.handle), "ReleaseMutex")
        except BaseException as error:
            self.receipt.update(released=False, custody_failure=str(error))
            FAILED_CUSTODY.append(self)
            # Do not close either the mutex or a job whose exit is unconfirmed.
            raise RuntimeError("TeX mutex release refused; owned process custody is unresolved") from error
        self.acquired = False
        self.receipt.update(released=True, released_unix=time.time())
        wincheck(self.kernel.CloseHandle(self.handle), "CloseHandle(mutex)")
        self.handle = None


def captured_run(arguments, cwd, log, *, slot, timeout=1200, cleanup_timeout=10):
    """Run one hidden process and its atomic job under the already-held slot."""
    slot.assert_owned()
    if slot.jobs:
        raise RuntimeError("A second captured worker cannot overlap")
    if not 0 < timeout <= 7200 or not 0 < cleanup_timeout <= 60:
        raise ValueError("Worker and cleanup timeouts must be positive and bounded")
    if not arguments or not all(isinstance(value, str) and "\0" not in value for value in arguments):
        raise ValueError("Expected an explicit argument vector")
    if not Path(arguments[0]).is_absolute() or not Path(arguments[0]).is_file():
        raise RuntimeError("Captured executable must be an existing absolute file")
    cwd, log = Path(cwd).resolve(), Path(log).resolve()
    if not cwd.is_dir() or not log.is_relative_to(cwd):
        raise RuntimeError("Worker log must be inside its existing working directory")
    environment = dict(os.environ)
    environment.update(SOURCE_DATE_EPOCH=EPOCH, FORCE_SOURCE_DATE="1", TZ="UTC",
                       MIKTEX_ENABLE_INSTALLER="0")
    start = time.monotonic()
    result = None
    pending_error = None
    with log.open("xb") as stream:
        job = WindowsJob(slot.kernel)
        slot.register(job)
        try:
            job.launch(arguments, cwd, stream, environment)
            while True:
                state = job.accounting()
                code = job.root_exit_code()
                # On an unsuccessful parent exit, stop descendants immediately.
                if code is not None and code != 0:
                    raise RuntimeError(f"Command failed with {code}; inspect {log}")
                if state["active_processes"] == 0 and code is not None:
                    break
                if time.monotonic() - start >= timeout:
                    raise TimeoutError(f"Owned build job exceeded {timeout}s")
                time.sleep(0.05)
            result = {"command": [Path(arguments[0]).name, *[
                          value.replace(str(ROOT), "{PROJECT_ROOT}").replace(ROOT.as_posix(), "{PROJECT_ROOT}")
                          for value in arguments[1:]]],
                      "root_pid": job.process.dwProcessId, "ownership": "Windows JOB_LIST at CreateProcess",
                      "kill_on_job_close": True, "breakaway_allowed": False, **state,
                      "elapsed_seconds": round(time.monotonic() - start, 3), "exit_code": code}
            job.close_empty()
            slot.jobs.remove(job)
        except BaseException as error:
            try:
                job.terminate_and_drain(cleanup_timeout)
                job.close_empty()
                slot.jobs.remove(job)
            except BaseException as cleanup_error:
                slot.receipt["worker_cleanup_failure"] = str(cleanup_error)
                # __exit__ will not release the mutex unless this job is proven empty.
                raise RuntimeError("Captured worker cleanup failed; ownership retained by TeXSlot") from cleanup_error
            pending_error = (error, error.__traceback__)
    # The writer above is now closed.  Windows may report zero active job
    # processes a few milliseconds before inherited file handles become
    # unavailable.  Prove release while the mutex is still owned.
    try:
        wait_for_file_release(log, slot.kernel, timeout=min(float(cleanup_timeout), 10.0))
    except BaseException as error:
        slot.block_release(error)
        raise
    if pending_error:
        error, traceback = pending_error
        raise error.with_traceback(traceback)
    return result


def fact_from_bytes(path, data):
    path = Path(path).resolve()
    relative = path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else str(path)
    return {"path": relative, "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def snapshot_file(path, *, data=None):
    path = Path(path).resolve()
    payload = path.read_bytes() if data is None else data
    return {"path_object": path, "data": payload, "fact": fact_from_bytes(path, payload)}


def public_snapshot(snapshot):
    return dict(snapshot["fact"])


def verify_snapshot(snapshot):
    current = snapshot_file(snapshot["path_object"])
    if current["fact"] != snapshot["fact"]:
        raise RuntimeError(f"Frozen input changed during build: {snapshot['fact']['path']}")


def absolute_file_fact(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def closure_hash(value):
    encoded = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def write_new_bytes(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)


def _legacy_asset_constants(source_bytes=None):
    """Read only literal asset conversion data; do not import/run an old builder."""
    data = BUILD_READER.read_bytes() if source_bytes is None else source_bytes
    parsed = ast.parse(data.decode("utf-8"), filename=str(BUILD_READER))
    wanted = {"PDF_ASSET_REPLACEMENTS", "PDF_GENERATED_ASSETS"}
    result = {}
    for node in parsed.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name in wanted:
                result[name] = ast.literal_eval(node.value)
    if set(result) != wanted:
        raise RuntimeError("Frozen print-asset conversion constants missing")
    return result


def normalize_pdf_ids(data: bytes) -> bytes:
    """Replace only the two random fixed-length PDF trailer IDs."""
    matches = list(PDF_IDS.finditer(data))
    if len(matches) != 1:
        raise RuntimeError(f"Expected one PDF trailer ID, found {len(matches)}")
    match = matches[0]
    original = match.group()
    replacement = re.sub(rb"<[0-9a-fA-F]{32}>", b"<" + b"0" * 32 + b">", original)
    assert len(replacement) == len(original)
    return data[:match.start()] + replacement + data[match.end():]


def markdown_image_sources(text):
    """Return semantic Markdown image destinations and reject raw HTML images."""
    found = []

    def visit(tokens):
        for token in tokens or ():
            if token.type in ("html_inline", "html_block") and RAW_HTML_IMAGE.search(token.content or ""):
                raise RuntimeError("Raw HTML <img> is not admitted by the frozen-image staging path")
            if token.type == "image":
                source = token.attrGet("src")
                if not source:
                    raise RuntimeError("Markdown image has an empty destination")
                found.append(source)
            visit(token.children)

    visit(MARKDOWN.parse(text))
    return found


def normalize_markdown_destination(value):
    value = html.unescape(value.strip())
    return re.sub(r"\\([^\w\s])", r"\1", value)


def canonical_asset_relative(value):
    value = normalize_markdown_destination(value)
    parsed = urlsplit(value)
    if parsed.scheme or parsed.netloc or parsed.query or parsed.fragment:
        raise RuntimeError(f"Only plain local print images are allowed: {value}")
    decoded = unquote(parsed.path).replace("\\", "/")
    while decoded.startswith("./"):
        decoded = decoded[2:]
    pure = PurePosixPath(decoded)
    if not decoded or pure.is_absolute() or ".." in pure.parts or re.match(r"^[A-Za-z]:", decoded):
        raise RuntimeError(f"Unsafe print image destination: {value}")
    path = (ROOT / Path(*pure.parts)).resolve()
    allowed = (ROOT / "authority/assets").resolve()
    if not path.is_relative_to(allowed):
        raise RuntimeError(f"Undeclared print image path: {value}")
    return path.relative_to(ROOT).as_posix()


def _matching_square(text, start):
    depth = 1
    index = start
    while index < len(text):
        if text[index] == "\\":
            index += 2
            continue
        if text[index] == "[":
            depth += 1
        elif text[index] == "]":
            depth -= 1
            if depth == 0:
                return index
        index += 1
    return None


def _is_escaped(text, index):
    slashes = 0
    index -= 1
    while index >= 0 and text[index] == "\\":
        slashes += 1
        index -= 1
    return slashes % 2 == 1


def rewrite_markdown_images(text, target_by_source):
    """Rewrite inline and reference images, then semantically reject residue."""
    before = markdown_image_sources(text)
    mapping = {normalize_markdown_destination(key): value for key, value in target_by_source.items()}
    canonical_mapping = {}
    for key, value in mapping.items():
        canonical = canonical_asset_relative(key)
        previous = canonical_mapping.setdefault(canonical, value)
        if previous != value:
            raise RuntimeError(f"Ambiguous canonical print image mapping: {canonical}")
    replacements = []

    def target(raw, *, required):
        normalized = normalize_markdown_destination(raw)
        value = mapping.get(normalized)
        if value is None:
            try:
                value = canonical_mapping.get(canonical_asset_relative(normalized))
            except RuntimeError:
                if required:
                    raise
        if value is None and required:
            raise RuntimeError(f"Image was not frozen during preflight: {raw}")
        return value

    index = 0
    while True:
        index = text.find("![", index)
        if index < 0:
            break
        if _is_escaped(text, index):
            index += 2
            continue
        close = _matching_square(text, index + 2)
        if close is None:
            raise RuntimeError("Unclosed Markdown image description")
        cursor = close + 1
        while cursor < len(text) and text[cursor].isspace():
            cursor += 1
        if cursor >= len(text) or text[cursor] != "(":
            index = close + 1  # Reference-style image; its definition is handled below.
            continue
        cursor += 1
        while cursor < len(text) and text[cursor].isspace():
            cursor += 1
        if cursor >= len(text):
            raise RuntimeError("Unclosed Markdown image destination")
        if text[cursor] == "<":
            start = cursor + 1
            end = start
            while end < len(text) and (text[end] != ">" or _is_escaped(text, end)):
                end += 1
            if end >= len(text):
                raise RuntimeError("Unclosed angle-bracket image destination")
        else:
            start = cursor
            end = start
            parentheses = 0
            while end < len(text):
                char = text[end]
                if char == "\\":
                    end += 2
                    continue
                if char == "(":
                    parentheses += 1
                elif char == ")":
                    if parentheses == 0:
                        break
                    parentheses -= 1
                elif char.isspace() and parentheses == 0:
                    break
                end += 1
            if end == start:
                raise RuntimeError("Markdown image has an empty destination")
        replacements.append((start, end, target(text[start:end], required=True)))
        index = end

    definition = re.compile(
        r"(?m)^(?: {0,3})\[[^\]\r\n]+\]:[ \t]*(?:<(?P<angle>[^>\r\n]+)>|(?P<bare>(?:\\.|[^\s])+))"
    )
    for match in definition.finditer(text):
        group = "angle" if match.group("angle") is not None else "bare"
        replacement = target(match.group(group), required=False)
        if replacement is not None:
            replacements.append((match.start(group), match.end(group), replacement))

    for start, end, replacement in sorted(set(replacements), reverse=True):
        text = text[:start] + replacement + text[end:]
    after = markdown_image_sources(text)
    allowed = set(canonical_mapping.values())
    if len(after) != len(before) or any(source not in allowed for source in after):
        raise RuntimeError(f"Residual or changed Markdown image destinations: {after}")
    return text


def _install_frozen_math_serializer(snapshot):
    module = types.ModuleType("d100_frozen_bgk_reader_math_serialization")
    module.__file__ = str(snapshot["path_object"])
    exec(compile(snapshot["data"], str(snapshot["path_object"]), "exec"), module.__dict__)
    reader_common._serializer = module


def prepare_dependencies():
    dependencies = {
        "build_script": snapshot_file(THIS_FILE),
        "reader_common": snapshot_file(READER_COMMON_PATH, data=READER_COMMON_BYTES),
        "pdf_header": snapshot_file(HEADER),
        "legacy_asset_constants": snapshot_file(BUILD_READER),
        "math_serializer": snapshot_file(MATH_SERIALIZER),
    }
    dependencies["asset_constants"] = _legacy_asset_constants(
        dependencies["legacy_asset_constants"]["data"]
    )
    _install_frozen_math_serializer(dependencies["math_serializer"])
    return dependencies


def prepare_book(book, dependencies):
    source_snapshots = []
    asset_cache = {}
    assets = {}
    image_map = {}
    replacements = dependencies["asset_constants"]["PDF_ASSET_REPLACEMENTS"]
    generated = dependencies["asset_constants"]["PDF_GENERATED_ASSETS"]

    def cached_snapshot(relative):
        path = (ROOT / relative).resolve()
        if path not in asset_cache:
            if not path.is_file():
                raise RuntimeError(f"Frozen print asset missing: {relative}")
            asset_cache[path] = snapshot_file(path)
        return asset_cache[path]

    for source in book_sources(book):
        snapshot = snapshot_file(source)
        text = snapshot["data"].decode("utf-8")
        source_snapshots.append(snapshot)
        for destination in markdown_image_sources(text):
            normalized = normalize_markdown_destination(destination)
            canonical = canonical_asset_relative(normalized)
            previous = image_map.setdefault(normalized, canonical)
            if previous != canonical:
                raise RuntimeError(f"Ambiguous image destination: {destination}")
            if canonical in assets:
                continue
            selected_relative = replacements.get(canonical, canonical)
            selected_path = (ROOT / selected_relative).resolve()
            if not selected_path.is_relative_to((ROOT / "authority/assets").resolve()):
                raise RuntimeError(f"Print fallback escaped authority assets: {selected_relative}")
            source_asset = cached_snapshot(canonical)
            selected_asset = cached_snapshot(selected_relative)
            spec = generated.get(canonical)
            needs_conversion = (
                spec is not None
                or selected_path.suffix.lower() in (".gif", ".svg", ".webp")
                or canonical == "authority/assets/Quadratic_Koch.png"
            )
            assets[canonical] = {
                "canonical": canonical,
                "source": source_asset,
                "selected": selected_asset,
                "conversion_spec": spec,
                "needs_conversion": needs_conversion,
            }
    return {"book": book, "sources": source_snapshots, "assets": assets,
            "image_map": image_map}


def preflight_tools(needs_magick):
    names = ["pandoc", "lualatex"] + (["magick"] if needs_magick else [])
    result = {}
    for name in names:
        executable = shutil.which(name)
        if not executable:
            raise RuntimeError(f"Required executable is unavailable: {name}")
        path = Path(executable).resolve()
        if not path.is_absolute() or not path.is_file():
            raise RuntimeError(f"Required executable is not an absolute file: {name}")
        result[name] = absolute_file_fact(path)
    return result


def public_dependencies(dependencies):
    result = {
        key: public_snapshot(value)
        for key, value in dependencies.items()
        if isinstance(value, dict) and "fact" in value
    }
    result["tools"] = {key: dict(value) for key, value in dependencies["tools"].items()}
    return result


def frozen_book_closure(book, dependencies):
    assets = []
    for key in sorted(book["assets"]):
        asset = book["assets"][key]
        assets.append({"canonical": key, "source": public_snapshot(asset["source"]),
                       "selected": public_snapshot(asset["selected"]),
                       "needs_conversion": asset["needs_conversion"]})
    value = {"book": book["book"], "dependencies": public_dependencies(dependencies),
             "sources": [public_snapshot(row) for row in book["sources"]], "assets": assets}
    return value, closure_hash(value)


def prepare_build(books):
    dependencies = prepare_dependencies()
    frozen = {book: prepare_book(book, dependencies) for book in books}
    needs_magick = any(
        asset["needs_conversion"]
        for book in frozen.values() for asset in book["assets"].values()
    )
    dependencies["tools"] = preflight_tools(needs_magick)
    for book in frozen.values():
        book["input_closure"], book["input_closure_sha256"] = frozen_book_closure(book, dependencies)
    return dependencies, frozen


def report_names(selection):
    if selection == "all":
        return ("DOUBLE_BUILD_all.json", *(f"DOUBLE_BUILD_{book}.json" for book in ("ak", "bgk", "companion")))
    return (f"DOUBLE_BUILD_{selection}.json",)


def preflight_output_namespace(books, report_name):
    targets = [OUTPUT / book / ("replay-" + replay)
               for book in books for replay in ("a", "b")]
    names = (report_name,) if isinstance(report_name, str) else tuple(report_name)
    targets.extend(OUTPUT / name for name in names)
    existing = [str(path) for path in targets if path.exists()]
    if existing:
        raise RuntimeError(f"Refusing to overwrite existing English PDF outputs: {existing}")


def write_double_build_reports(report, selection):
    names = report_names(selection)
    aggregate_fact = None
    written = []
    for name in names:
        payload = report
        if selection == "all" and name != "DOUBLE_BUILD_all.json":
            book = name.removeprefix("DOUBLE_BUILD_").removesuffix(".json")
            rows = [row for row in report["books"] if row.get("book") == book]
            if len(rows) != 1:
                raise RuntimeError(f"Cannot derive exact single-book report view: {book}")
            payload = {**report, "books": rows, "aggregate_report": aggregate_fact}
        path = OUTPUT / name
        encoded = (json.dumps(payload, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
        write_new_bytes(path, encoded)
        current = fact_from_bytes(path, encoded)
        written.append(current)
        if name == "DOUBLE_BUILD_all.json":
            aggregate_fact = current
    return written


def verify_frozen_book(book, dependencies):
    for key, value in dependencies.items():
        if isinstance(value, dict) and "fact" in value:
            verify_snapshot(value)
    for tool in dependencies["tools"].values():
        if absolute_file_fact(tool["path"]) != tool:
            raise RuntimeError(f"Required executable changed during build: {tool['path']}")
    for source in book["sources"]:
        verify_snapshot(source)
    seen = set()
    for asset in book["assets"].values():
        for snapshot in (asset["source"], asset["selected"]):
            path = snapshot["path_object"]
            if path not in seen:
                verify_snapshot(snapshot)
                seen.add(path)
    closure, digest = frozen_book_closure(book, dependencies)
    if closure != book["input_closure"] or digest != book["input_closure_sha256"]:
        raise RuntimeError(f"Frozen input closure changed in memory for {book['book']}")


def stage_assets(book, stage, dependencies, slot):
    target_for_canonical = {}
    receipts = []
    magick = dependencies["tools"].get("magick", {}).get("path")
    for canonical in sorted(book["assets"]):
        asset = book["assets"][canonical]
        selected = asset["selected"]
        identity = hashlib.sha256((canonical + "\0" + selected["fact"]["sha256"]).encode("utf-8")).hexdigest()[:20]
        if asset["needs_conversion"]:
            if not magick:
                raise RuntimeError("ImageMagick was not frozen during preflight")
            consumed = asset["source"] if asset["conversion_spec"] else selected
            source_suffix = consumed["path_object"].suffix.lower() or ".bin"
            staged_input = stage / "asset-inputs" / (identity + source_suffix)
            write_new_bytes(staged_input, consumed["data"])
            target = stage / "assets" / (identity + ".png")
            target.parent.mkdir(parents=True, exist_ok=True)
            spec = asset["conversion_spec"]
            if spec:
                arguments = [magick, *spec["magick_before_source"], str(staged_input),
                             *spec["magick_after_source"], str(target)]
            elif canonical == "authority/assets/Quadratic_Koch.png":
                arguments = [magick, str(staged_input), "-colorspace", "Gray", "-depth", "8",
                             "-type", "Grayscale", "-strip", str(target)]
            else:
                arguments = [magick, "-background", "none", "-density", "216",
                             str(staged_input) + "[0]", "-resize", "1600x1600>", "-strip", str(target)]
            execution = captured_run(arguments, stage, stage / (identity + "-image.log"),
                                     slot=slot, timeout=120)
            output_data = target.read_bytes()
            if not output_data.startswith(b"\x89PNG\r\n\x1a\n"):
                raise RuntimeError(f"Print conversion did not produce PNG bytes: {canonical}")
            row = {"canonical": canonical, "source": public_snapshot(asset["source"]),
                   "selected_fallback": public_snapshot(selected),
                   "staged_input": fact_from_bytes(staged_input, staged_input.read_bytes()),
                   "output": fact_from_bytes(target, output_data), "command": execution}
        else:
            suffix = selected["path_object"].suffix.lower()
            if not suffix:
                raise RuntimeError(f"Print image has no extension: {canonical}")
            target = stage / "assets" / (identity + suffix)
            write_new_bytes(target, selected["data"])
            row = {"canonical": canonical, "source": public_snapshot(asset["source"]),
                   "selected_fallback": public_snapshot(selected),
                   "output": fact_from_bytes(target, selected["data"]), "command": None}
        target_for_canonical[canonical] = target.relative_to(stage).as_posix()
        receipts.append(row)
    mapping = {source: target_for_canonical[canonical] for source, canonical in book["image_map"].items()}
    staged_closure = [{"canonical": row["canonical"],
                       "bytes": row["output"]["bytes"],
                       "sha256": row["output"]["sha256"]} for row in receipts]
    return mapping, receipts, closure_hash(staged_closure)


def stage_source(text, source, image_targets):
    text, math_receipts = serialize_source(text, source)
    text = split_frontmatter(text)
    before_ids = re.findall(r"\{#[^}]+\}", text)
    text = rewrite_markdown_images(text, image_targets)
    text = text.replace("★", r"\sourceblackstar{}").replace(r"\vcentcolon=", ":=")
    # Exact source/HTML credits remain unaltered; PDF transliterations match
    # established component-credit treatment and are disclosed in the receipt.
    text = text.replace("דוד שי", "David Shai").replace("１３２人目", "132ninme")
    text = re.sub(r"(?<![\w}\]])`([^`\n]{40,})`", lambda m: r"\nolinkurl{" + m.group(1) + "}", text)
    # Keep figure placement with its immediately following component credit.
    text = text.replace("\n![", "\n\\floatplacement{figure}{H}\n\n![")
    if re.findall(r"\{#[^}]+\}", text) != before_ids:
        raise RuntimeError("Print staging changed stable heading IDs")
    return text, math_receipts


def validate_pdf(path):
    data = Path(path).read_bytes()
    if not data.startswith(b"%PDF-"):
        raise RuntimeError("English PDF lacks a PDF header")
    if not data.rstrip().endswith(b"%%EOF"):
        raise RuntimeError("English PDF lacks a terminal EOF marker")
    try:
        reader = PdfReader(io.BytesIO(data), strict=True)
        if reader.is_encrypted:
            raise RuntimeError("English PDF is unexpectedly encrypted")
        page_count = len(reader.pages)
        if page_count < 1:
            raise RuntimeError("English PDF has no pages")
        for page in reader.pages:
            _ = page.mediabox
            page.get_contents()
    except RuntimeError:
        raise
    except BaseException as error:
        raise RuntimeError("English PDF could not be parsed page by page") from error
    return {"file": fact_from_bytes(path, data), "page_count": page_count,
            "pdf_header": data.splitlines()[0].decode("ascii", errors="replace")}


def verify_recorded_file(file_fact):
    path = Path(file_fact["path"])
    if not path.is_absolute():
        path = ROOT / path
    current = fact_from_bytes(path, path.read_bytes())
    if current != file_fact:
        raise RuntimeError(f"Staged build input changed while consumed: {file_fact['path']}")


def one_replay(book, label, slot, frozen, dependencies):
    if frozen.get("book") != book:
        raise RuntimeError("Replay received the wrong frozen book closure")
    verify_frozen_book(frozen, dependencies)  # No directory is created before this preflight.
    stage = OUTPUT / book / ("replay-" + label)
    if stage.exists():
        raise RuntimeError(f"Refusing to overwrite existing replay: {stage}")
    stage.mkdir(parents=True)
    metadata = book_metadata(book)
    staged_header = stage / "pdf-header.tex"
    write_new_bytes(staged_header, dependencies["pdf_header"]["data"])
    staged_header_fact = fact_from_bytes(staged_header, staged_header.read_bytes())
    image_targets, staged_assets, staged_asset_closure = stage_assets(
        frozen, stage, dependencies, slot
    )
    math_records, texts = [], []
    for source_snapshot in frozen["sources"]:
        source = source_snapshot["path_object"]
        staged, records = stage_source(source_snapshot["data"].decode("utf-8"), source, image_targets)
        texts.append(staged)
        math_records.extend(records)
    assembled = stage / "reader.md"
    assembled.write_text("\n\n".join(texts) + "\n", encoding="utf-8")
    assembled_fact = fact_from_bytes(assembled, assembled.read_bytes())
    pandoc = dependencies["tools"]["pandoc"]["path"]
    engine = dependencies["tools"]["lualatex"]["path"]
    output = stage / metadata["pdf_name"]
    command = [pandoc, str(assembled), "--from=" + READ_FORMAT, "--standalone", "--toc",
               "--metadata=lang:en", "--metadata=title:" + metadata["title"],
               "--metadata=subtitle:" + metadata["subtitle"],
               "--metadata=author:" + metadata["author"], "--metadata=date:2026-09-04",
               "--include-in-header=" + str(staged_header), "--resource-path=" + str(stage),
               "--pdf-engine=" + engine, "--variable=papersize:a4",
               "--variable=geometry:margin=25mm", "--variable=colorlinks:true",
               "--output=" + str(output)]
    execution = captured_run(command, stage, stage / "pandoc-pdf.log", slot=slot)
    verify_recorded_file(assembled_fact)
    verify_recorded_file(staged_header_fact)
    for asset in staged_assets:
        verify_recorded_file(asset["output"])
    log = (stage / "pandoc-pdf.log").read_text(encoding="utf-8", errors="replace")
    rejected_log_markers = ("Missing character:", "! LaTeX Error:", "Emergency stop",
                            "Fatal error occurred", "No pages of output")
    present = [marker for marker in rejected_log_markers if marker in log]
    if present:
        raise RuntimeError(f"PDF log contains rejected diagnostics: {present}")
    normalized = normalize_pdf_ids(output.read_bytes())
    normalized_path = output.with_suffix(".normalized.tmp")
    write_new_bytes(normalized_path, normalized)
    os.replace(normalized_path, output)
    if len(normalized) < 10000:
        raise RuntimeError("Implausibly small English PDF")
    pdf_validation = validate_pdf(output)
    verify_frozen_book(frozen, dependencies)
    receipt = {
        "schema": "d100-en-pdf-replay-v1", "status": "BUILT_PENDING_LAYOUT_QA",
        "language": "en", "book": book, "replay": label,
        "input_closure_sha256": frozen["input_closure_sha256"],
        "input_closure": frozen["input_closure"],
        "assembled": assembled_fact,
        "staged_header": staged_header_fact,
        "staged_assets": staged_assets,
        "staged_asset_closure_sha256": staged_asset_closure,
        "math_serialization": math_records,
        "math_serialization_sha256": closure_hash(math_records),
        "execution": execution,
        "output": pdf_validation["file"], "pdf_validation": pdf_validation,
        "mutex_held_during_replay": True,
        "source_date_epoch": EPOCH, "provenance": PROVENANCE,
        "print_only_credit_transliterations": {"דוד שי": "David Shai", "１３２人目": "132ninme"},
    }
    return receipt


def compare_replays(first, second):
    checks = {
        "input_closure": first["input_closure_sha256"] == second["input_closure_sha256"],
        "assembled_markdown": first["assembled"]["sha256"] == second["assembled"]["sha256"]
                              and first["assembled"]["bytes"] == second["assembled"]["bytes"],
        "staged_assets": first["staged_asset_closure_sha256"] == second["staged_asset_closure_sha256"],
        "math_serialization": first["math_serialization_sha256"] == second["math_serialization_sha256"],
        "normalized_pdf": first["output"]["sha256"] == second["output"]["sha256"]
                          and first["output"]["bytes"] == second["output"]["bytes"],
        "page_count": first["pdf_validation"]["page_count"] == second["pdf_validation"]["page_count"],
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise RuntimeError(f"Deterministic replay mismatch: {failed}")
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--book", choices=("all", "ak", "bgk", "companion"), default="all")
    args = parser.parse_args()
    books = ("ak", "bgk", "companion") if args.book == "all" else (args.book,)
    output_reports = report_names(args.book)
    # All gates, dependencies, source bytes, assets and executables are frozen
    # before any replay namespace is created.
    translation = require_translation_handoffs()
    integration = require_integration_receipt()
    dependencies, frozen = prepare_build(books)
    preflight_output_namespace(books, output_reports)
    translation_recheck = require_translation_handoffs()
    integration_recheck = require_integration_receipt()
    if translation_recheck != translation or integration_recheck != integration:
        raise RuntimeError("Translation/integration gate identities changed during preflight")
    for book in books:
        verify_frozen_book(frozen[book], dependencies)
    results = []
    replay_receipts = []
    with TeXSlot() as slot:
        for book in books:
            first = one_replay(book, "a", slot, frozen[book], dependencies)
            second = one_replay(book, "b", slot, frozen[book], dependencies)
            checks = compare_replays(first, second)
            replay_receipts.extend((first, second))
            results.append({"book": book, "a": first["output"], "b": second["output"],
                            "page_count": first["pdf_validation"]["page_count"],
                            "replay_checks": checks, "identical_pdf_bytes": True,
                            "input_closure_sha256": first["input_closure_sha256"]})
    if not slot.receipt.get("released"):
        raise RuntimeError("TeX mutex release is not proven")
    for receipt in replay_receipts:
        receipt["mutex"] = dict(slot.receipt)
        stage = OUTPUT / receipt["book"] / ("replay-" + receipt["replay"])
        (stage / "BUILD_RECEIPT.json").write_text(
            json.dumps(receipt, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )
    report = {"schema": "d100-en-pdf-double-build-v1", "status": "BUILT_PENDING_LAYOUT_QA",
              "translation_handoffs": translation, "integration_qa": integration,
              "books": results, "mutex": dict(slot.receipt),
              "next_action": "All-page visual and text/math/layout checks before release", "language": "en"}
    write_double_build_reports(report, args.book)
    print(json.dumps(report))


if __name__ == "__main__":
    main()
