"""Shared English reader order, frozen-input gate and exact math staging.

No imports of legacy builders, output writes, directory scans or subprocesses.
The German/Indonesian authority and completed readers remain read-only.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
CONTROL = ROOT / "00_control/english"
PROVENANCE = "OpenAI Codex gpt-5.6-sol, Ultra."
EPOCH = "1788480000"  # 2026-09-04T00:00:00Z
MASTERY_UNITS = (2, 3, 4, 5, 6, 7, 9, 10, 12, 13, 14, 15, 23, 24, 25, 26, 27)
CLASSICAL_CREDIT_UNITS = (1, *range(2, 10), *range(11, 31))
READ_FORMAT = "markdown+yaml_metadata_block+tex_math_dollars+fenced_divs+bracketed_spans"


def fact(path: Path) -> dict:
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def book_sources(book: str) -> list[Path]:
    """Return the exact 274-file reader closure, partitioned into three books."""
    source = ROOT / "source/en"
    if book == "ak":
        result = [source / "frontmatter-units-01-30.md"]
        result += [source / f"{stem}-{n:02}{suffix}.md" for n in range(1, 31) for stem, suffix in (("lecture", ""), ("worksheet", ""), ("worksheet", "-solutions"))]
        result += [source / ("media-credits.md" if n == 1 else f"media-credits-unit-{n:02}.md") for n in CLASSICAL_CREDIT_UNITS]
        return result
    if book == "bgk":
        result = [source / "bgk/frontmatter-bgk-units-01-30.md", source / "bgk/glossary-bgk-units-01-30.md"]
        result += [source / "bgk" / f"{stem}-{n:02}{suffix}.md" for n in range(1, 31) for stem, suffix in (("lecture", ""), ("worksheet", ""), ("worksheet", "-solutions"))]
        result += [source / f"media-credits-bgk-unit-{n:02}.md" for n in range(1, 31)]
        return result
    if book == "companion":
        names = ["frontmatter.md", "seam-varieties-to-schemes.md"]
        names += [f"mastery-bgk-{n:02}.md" for n in MASTERY_UNITS]
        names += [f"integrative-{n:02}.md" for n in range(1, 13)]
        names += ["stacks-navigation-capstone.md"]
        return [source / "bridge" / name for name in names]
    raise ValueError(f"Unknown book: {book}")


def book_metadata(book: str) -> dict:
    values = {
        "ak": ("Algebraic Curves — Units 1–30", "Thirty lectures and worksheets, independent English edition", "Holger Brenner (source work)", "algebraic-curves-en-units-01-30.pdf"),
        "bgk": ("Bundles, Sheaves and Cohomology — Units 1–30", "Thirty lectures and worksheets, independent English edition", "Holger Brenner (source work)", "bundles-sheaves-cohomology-en-units-01-30.pdf"),
        "companion": ("From Varieties to Schemes: An Original Editorial Companion", "Prerequisite bridge, mastery route, solved integrative problems and Stacks capstone", "Independent editorial companion; source references credited individually", "varieties-to-schemes-editorial-companion-en.pdf"),
    }
    title, subtitle, author, name = values[book]
    return {"title": title, "subtitle": subtitle, "author": author, "pdf_name": name, "language": "en", "date": "2026-09-04", "provenance": PROVENANCE}


def split_frontmatter(text: str) -> str:
    return re.sub(r"\A---\r?\n.*?\r?\n---\r?\n", "", text, count=1, flags=re.S).lstrip("\r\n")


def _embedded_facts(value):
    if isinstance(value, dict):
        if isinstance(value.get("path"), str) and isinstance(value.get("sha256"), str):
            yield value
        for nested in value.values():
            yield from _embedded_facts(nested)
    elif isinstance(value, list):
        for nested in value:
            yield from _embedded_facts(nested)


def require_translation_handoffs() -> list[dict]:
    """No build of a silently shortened corpus; require every frozen packet."""
    inventories = [CONTROL / name for name in ("PACKETS.json", "SUPPLEMENTARY_PACKETS.json")]
    facts = [fact(path) for path in inventories]
    admitted_targets = set()
    for inventory in inventories:
        manifest = json.loads(inventory.read_text(encoding="utf-8"))
        for packet in manifest["packets"]:
            handoff = ROOT / packet["handoff"]
            if not handoff.is_file():
                raise RuntimeError(f"Translation handoff missing: {packet['id']}")
            receipt = json.loads(handoff.read_text(encoding="utf-8"))
            if receipt.get("status") != "translation_draft_complete":
                raise RuntimeError(f"Translation packet not complete: {packet['id']}")
            declared = list(_embedded_facts(receipt))
            for relative in packet["targets"]:
                current = fact(ROOT / relative)
                candidates = [row for row in declared if row.get("path") == relative]
                if not any(row.get("sha256") == current["sha256"] and row.get("bytes") == current["bytes"] for row in candidates):
                    # Keep original draft handoffs immutable after justified
                    # integrated corrections. A later PASS receipt must bind
                    # both this exact handoff and the corrected current source.
                    integrated_path = ROOT / "qa/english/TRANSLATION_INTEGRATION_QA.json"
                    if not integrated_path.is_file():
                        raise RuntimeError(f"Handoff lacks current target identity: {relative}")
                    integrated = json.loads(integrated_path.read_text(encoding="utf-8"))
                    bound = list(_embedded_facts(integrated))
                    def contains(value):
                        return any(all(row.get(k) == value[k] for k in ("path", "bytes", "sha256")) for row in bound)
                    if not candidates or integrated.get("status") != "PASS" or integrated.get("language") != "en" or not contains(current) or not contains(fact(handoff)):
                        raise RuntimeError(f"No source-bound integrated correction evidence: {relative}")
                if relative in admitted_targets:
                    raise RuntimeError(f"Overlapping translation target: {relative}")
                admitted_targets.add(relative)
            facts.append(fact(handoff))
    expected = {p.relative_to(ROOT).as_posix() for b in ("ak", "bgk", "companion") for p in book_sources(b)}
    if admitted_targets != expected or len(expected) != 274:
        raise RuntimeError("Frozen translation packets and reader source closure differ")
    return facts


def require_integration_receipt() -> dict:
    """Full builds require the later source-bound integrated review, not a draft."""
    path = ROOT / "qa/english/TRANSLATION_INTEGRATION_QA.json"
    report = json.loads(path.read_text(encoding="utf-8"))
    if report.get("status") != "PASS" or report.get("language") != "en":
        raise RuntimeError("English integrated translation QA is not PASS")
    expected = [fact(p) for b in ("ak", "bgk", "companion") for p in book_sources(b)]
    declared = list(_embedded_facts(report))
    for current in expected:
        if not any(all(row.get(k) == current[k] for k in ("path", "bytes", "sha256")) for row in declared):
            raise RuntimeError(f"Integrated QA does not bind current source: {current['path']}")
    return fact(path)


_serializer = None


def serialize_source(text: str, source: Path) -> tuple[str, list[dict]]:
    """Reuse the exact established math transforms, with English staging prose."""
    global _serializer
    relative = source.relative_to(ROOT).as_posix()
    if not relative.startswith("source/en/bgk/"):
        return text, []
    if _serializer is None:
        module_path = ROOT / "scripts/bgk_reader_math_serialization.py"
        spec = importlib.util.spec_from_file_location("d100_frozen_math_serializer", module_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _serializer = module
    original = relative.replace("source/en/", "source/id-ID/", 1)
    english_cd_override = None
    serializer_input = text
    if relative == "source/en/bgk/worksheet-28.md":
        record = next(
            row for row in _serializer.load_contract()["records"]
            if row["id"] == "bgk-reader-math-08"
        )
        matches = _serializer.CD_PATTERN.findall(text)
        if len(matches) != 1:
            raise RuntimeError("Expected exactly one reviewed CD diagram in BGK worksheet 28")
        corrected_input = matches[0]
        corrected_topology = _serializer.parse_cd(corrected_input)
        corrected_output = _serializer.render_cd(corrected_topology)
        serializer_input = text.replace(corrected_input, record["input"], 1)
        english_cd_override = {
            "record": record,
            "corrected_input": corrected_input,
            "corrected_output": corrected_output,
            "topology": corrected_topology,
        }
    staged, records = _serializer.serialize_reader_math(serializer_input, original, through=30)
    translated_records = []
    for record in records:
        row = dict(record)
        row["english_source"] = relative
        if record.get("staging_note"):
            if record["id"] != "bgk-reader-math-11":
                raise RuntimeError("Untranslated staging note outside the declared English adaptation")
            english_note = "**Edition note (serialization).** The missing backslash in the arrow command is restored according to the frozen TeX witness. This corrects command spelling, not the mathematical claim."
            staged = staged.replace(record["staging_note"], english_note, 1)
            row["english_staging_note"] = english_note
        translated_records.append(row)
    if english_cd_override is not None:
        record = english_cd_override["record"]
        if staged.count(record["output"]) != 1:
            raise RuntimeError("Frozen BGK 28 serializer output is missing or duplicated")
        staged = staged.replace(record["output"], english_cd_override["corrected_output"], 1)
        translated_records.append({
            "id": "english-bgk-reader-math-08-reviewed-topology",
            "english_source": relative,
            "kind": "reviewed_preapplied_cd_topology_serialization",
            "source_record_id": record["id"],
            "input_sha256": hashlib.sha256(
                english_cd_override["corrected_input"].encode("utf-8")
            ).hexdigest(),
            "output_sha256": hashlib.sha256(
                english_cd_override["corrected_output"].encode("utf-8")
            ).hexdigest(),
            "topology": english_cd_override["topology"],
            "mathematical_content_changed": False,
        })
    if relative == "source/en/bgk/lecture-26.md":
        pattern = re.compile(
            r"(?m)^\$(\r?\n)(s_i-s_j=r_\{ij\}\\quad\\text\{on \}U_i\\cap U_j\.)(\r?\n)\$$"
        )
        matches = list(pattern.finditer(staged))
        if len(matches) != 1:
            raise RuntimeError("Expected exactly one reviewed lone-dollar display in BGK lecture 26")
        before = matches[0].group(0)
        after = "$$" + matches[0].group(1) + matches[0].group(2) + matches[0].group(3) + "$$"
        staged = staged[:matches[0].start()] + after + staged[matches[0].end():]
        translated_records.append({
            "id": "english-reader-display-delimiter-01",
            "english_source": relative,
            "kind": "render_only_markdown_math_delimiter_normalization",
            "before_sha256": hashlib.sha256(before.encode("utf-8")).hexdigest(),
            "after_sha256": hashlib.sha256(after.encode("utf-8")).hexdigest(),
            "mathematical_content_changed": False,
        })
    return staged, translated_records
