#!/usr/bin/env python3
"""Generate and dry-run the three hash-pinned English backend lane inputs.

No corpus text is written.  The only outputs are deterministic input JSON below
``backend/english/inputs``, a dry-run receipt below ``qa/english/backend``, and
three lane receipts named ``00_control/english/packets/BACKEND-*.json``.
"""
from __future__ import annotations

import argparse
import copy
import json
import math
import re
import sys
from collections import defaultdict
from functools import lru_cache
from pathlib import Path

import export_backend_en as en


ROOT = Path(__file__).resolve().parents[2]
STAMP = "2026-09-05T00:00:00Z"
TERM_MAP = "scripts/english/backend_term_map_en.json"
GENERATOR = "scripts/english/prepare_backend_inputs_en.py"
TESTS = "scripts/english/test_export_backend_en.py"
INPUT_PATHS = {
    "classical": "backend/english/inputs/classical.json",
    "bgk": "backend/english/inputs/bgk.json",
    "original": "backend/english/inputs/original.json",
}
PACKET_PATHS = {
    "classical": "00_control/english/packets/BACKEND-CLASSICAL.json",
    "bgk": "00_control/english/packets/BACKEND-BGK.json",
    "original": "00_control/english/packets/BACKEND-ORIGINAL.json",
}
DRY_RUN_RECEIPT = "qa/english/backend/FULL_CORPUS_DRY_RUN.json"


class PreparationError(ValueError):
    pass


def require(ok: bool, message: str) -> None:
    if not ok:
        raise PreparationError(message)


def load_term_map() -> dict[str, str]:
    payload = json.loads(en.safe_path(ROOT, TERM_MAP).read_bytes())
    require(payload.get("schema") == "ag-bridge-backend-german-english-term-map-v1",
            "Wrong backend term-map schema")
    result = {}
    for pair in payload.get("translations", []):
        require(isinstance(pair, list) and len(pair) == 2
                and all(isinstance(value, str) and value.strip() for value in pair),
                "Malformed backend term-map row")
        source, target = pair
        require(source not in result, f"Duplicate backend term translation: {source}")
        result[source] = target
    return result


TERM_EN = load_term_map()


def semantic_concept_slug(stable_id: str) -> str | None:
    prefix = "concept.br-bgk-2019."
    slug = stable_id[len(prefix):] if stable_id.startswith(prefix) else (
        stable_id[len("concept."):] if stable_id.startswith("concept.") else "")
    if not slug or slug.startswith(("agt-", "bgk-t")):
        return None
    return slug


def humanise_slug(slug: str) -> str:
    value = slug.replace("-", " ")
    replacements = {
        "cech": "Čech", "kahler": "Kähler", "bezout": "Bézout",
        "riemann roch": "Riemann–Roch", "hilbert samuel": "Hilbert–Samuel",
        "non zero divisor": "non-zero-divisor", "quasi coherent": "quasi-coherent",
        "quasi projective": "quasi-projective", "base point free": "base-point-free",
        "finite type": "finite type", "z graded": "Z-graded", "k algebra": "K-algebra",
        "r valued": "R-valued", "o x": "O_X", "t 0": "T_0", "t 1": "T_1",
    }
    for old, new in replacements.items():
        value = re.sub(rf"\b{re.escape(old)}\b", new, value, flags=re.I)
    return value


def source_term(record: dict) -> str | None:
    return record["payload"].get("source_term") or record["payload"].get("ledger_row", {}).get("source_term")


def concept_english(record: dict) -> tuple[str, str]:
    slug = semantic_concept_slug(record["stable_id"])
    if slug is not None:
        return humanise_slug(slug), "stable semantic concept identifier"
    source = record["payload"].get("source_label")
    require(source in TERM_EN, f"No exact English concept label for {record['stable_id']}: {source!r}")
    return TERM_EN[source], "exact German mathematical source-label map"


def term_english(record: dict, records: dict[str, dict]) -> tuple[str, str]:
    source = source_term(record)
    if source in TERM_EN:
        return TERM_EN[source], "exact German mathematical source-term map"
    parent = records.get(record.get("parent_id"))
    require(parent is not None and parent["entity_class"] == "concept",
            f"Term lacks an English source-term map or semantic concept: {record['stable_id']}")
    slug = semantic_concept_slug(parent["stable_id"])
    require(slug is not None, f"Numeric concept term lacks exact English map: {record['stable_id']}")
    return humanise_slug(slug), "stable semantic concept identifier"


DISPLAY_OVERRIDES = {
    ("program.complete-mathematics-curriculum.id.v0", "/payload/title"):
        "Complete mathematics curriculum — English edition",
    ("course.o016-d100.bgk-bridge", "/payload/title"):
        "Bundles, Sheaves and Cohomology",
    ("program.br-bgk-2019.id", "/payload/title"):
        "English mathematics programme",
    ("course.d100.original-bridge", "/payload/title"):
        "Algebraic Geometry: Bridge Material and Integrated Exercises",
    ("resource.d100.original-bridge.editorial", "/payload/title"):
        "Algebraic Geometry Bridge Material — English",
}


def adapt_language_reference(value: str) -> str:
    result = value
    for old, new in (("Bahasa Indonesia", "English"), ("bahasa Indonesia", "English"),
                     ("Indonesian-language", "English-language"), ("Indonesian", "English")):
        result = result.replace(old, new)
    return result


def context_maps(records: list[dict], target_by_term: dict[str, str]) -> dict[str, dict[str, str]]:
    result: dict[str, dict[str, str]] = defaultdict(dict)
    for record in records:
        if record["entity_class"] != "term" or record.get("parent_id") not in result and record.get("parent_id") is None:
            continue
        target = target_by_term[record["stable_id"]]
        payload = record["payload"]
        values = []
        for row in (payload, payload.get("ledger_row", {})):
            for key in ("preferred_target", "accepted_variants", "rejected_or_variant"):
                value = row.get(key)
                if isinstance(value, str) and value.strip():
                    values.append(value)
                    values.extend(part.strip() for part in value.split(";") if part.strip())
        for value in values:
            result[record["parent_id"]].setdefault(value, target)
    return result


def translated_field(item: dict, record: dict, records: dict[str, dict],
                     term_targets: dict[str, tuple[str, str]],
                     native_context: dict[str, dict[str, str]]) -> tuple[str, str]:
    pointer, native = item["pointer"], item["native_value"]
    explicit = DISPLAY_OVERRIDES.get((record["stable_id"], pointer))
    if explicit is not None:
        return explicit, "explicit English backend display label"
    if record["entity_class"] == "term":
        target, basis = term_targets[record["stable_id"]]
        leaf = pointer.rsplit("/", 1)[-1]
        if leaf == "preferred_target":
            return target, basis
        if leaf in {"accepted_variants", "rejected_or_variant"}:
            mapped = native_context.get(record["parent_id"], {}).get(native, target)
            if mapped == target:
                mapped += " (same English rendering; native variant retained in provenance)"
            return mapped, basis + "; variant relation preserved in native provenance"
    if record["entity_class"] == "concept":
        label, basis = concept_english(record)
        leaf = pointer.rsplit("/", 1)[-1]
        if leaf == "preferred_label":
            return label, basis
        mapped = native_context.get(record["stable_id"], {}).get(native, label)
        if pointer == "/payload/accepted_variants" and mapped == label:
            mapped += " (same English rendering; native variants retained in provenance)"
        return mapped, basis + "; locale-specific search label"
    adapted = adapt_language_reference(native)
    if adapted != native:
        return adapted, "English locale adaptation of already-English backend prose"
    return native, "native backend field is already English or a language-neutral mathematical token"


def populate_translations(records: list[dict], config: dict) -> None:
    by_id = {record["stable_id"]: record for record in records}
    term_targets = {record["stable_id"]: term_english(record, by_id)
                    for record in records if record["entity_class"] == "term"}
    contexts = context_maps(records, {key: value[0] for key, value in term_targets.items()})
    result = []
    for item in en.translation_inventory(records, config):
        record = by_id[item["stable_id"]]
        value, basis = translated_field(item, record, by_id, term_targets, contexts)
        require(isinstance(value, str) and value.strip(), f"Empty generated translation: {item['stable_id']} {item['pointer']}")
        row = {"stable_id": item["stable_id"], "pointer": item["pointer"],
               "source_value_sha256": item["source_value_sha256"], "language": "en",
               "value": value, "translation_basis": basis}
        if value == item["native_value"]:
            row["unchanged_english"] = True
        result.append(row)
    config["field_translations"] = result


def display_atoms(block: str) -> list[tuple[int, int]]:
    """Split a paragraph only where display math and prose were merged."""
    matches = list(re.finditer(r"\$\$.*?\$\$", block, re.S))
    if not matches:
        return [(0, len(block))]
    ranges = []
    cursor = 0
    for match in matches:
        if block[cursor:match.start()].strip():
            ranges.append((cursor, match.start()))
        elif ranges:
            ranges[-1] = (ranges[-1][0], match.start())
        ranges.append((match.start(), match.end()))
        cursor = match.end()
    if block[cursor:].strip():
        ranges.append((cursor, len(block)))
    elif ranges:
        ranges[-1] = (ranges[-1][0], len(block))
    return ranges


def fine_atoms(block: str) -> list[tuple[int, int]]:
    """Add exact sentence/punctuation cuts only for failed structural alignment."""
    if block.lstrip().startswith("$$"):
        match = re.fullmatch(r"(\$\$.*?)([.,;:])(\s*\$\$)", block, re.S)
        if match:
            return [(0, match.start(2)), (match.start(2), len(block))]
        return [(0, len(block))]
    if block.lstrip().startswith("<!--"):
        return [(0, len(block))]
    boundaries = [0]
    boundaries.extend(match.start() for match in re.finditer(
        r"(?<=[.!?])(?=\s+(?:[A-Z]|[>*_`]))", block))
    boundaries.append(len(block))
    return [(start, end) for start, end in zip(boundaries, boundaries[1:]) if start < end]


def protected_signature(text: str) -> set[str]:
    protected = " ".join(re.findall(r"\$\$.*?\$\$|(?<!\$)\$(?!\$).*?(?<!\$)\$(?!\$)|https?://\S+|`[^`]+`", text, re.S))
    return set(re.findall(r"\\[A-Za-z]+|[A-Za-z]+|\d+", protected.lower()))


def partition_score(native: str, english: str, piece_count: int) -> float:
    old, new = protected_signature(native), protected_signature(english)
    overlap = len(old & new) / max(1, len(old | new))
    containment = len(old & new) / max(1, len(old))
    old_len = max(1, len(re.sub(r"\s+", "", native)))
    new_len = max(1, len(re.sub(r"\s+", "", english)))
    return 20.0 * overlap + 8.0 * containment - abs(math.log(new_len / old_len)) - 0.05 * (piece_count - 1)


def monotone_partition(rows: list[dict], blocks: list[str], atoms: list[tuple[int, int, int]],
                       *, strict_types: bool = True) -> list[list[tuple[int, int, int]]]:
    native_types = [record["payload"].get("markdown", "").lstrip().startswith("$$") for record in rows]
    atom_types = [blocks[number - 1][start:end].lstrip().startswith("$$") for number, start, end in atoms]
    n, m = len(rows), len(atoms)

    @lru_cache(maxsize=None)
    def solve(i: int, j: int):
        if i == n:
            return (0.0, ()) if j == m else None
        best = None
        last = m - (n - i - 1)
        for end in range(j + 1, last + 1):
            if strict_types and atom_types[j] != native_types[i]:
                break
            tail = solve(i + 1, end)
            if tail is None:
                continue
            pieces = [blocks[number - 1][start:stop] for number, start, stop in atoms[j:end]]
            english = "\n\n".join(pieces)
            type_penalty = -30.0 if atom_types[j] != native_types[i] else 0.0
            score = partition_score(rows[i]["payload"].get("markdown", ""), english, len(pieces)) \
                + type_penalty + tail[0]
            candidate = (score, (end,) + tail[1])
            if best is None or score > best[0] + 1e-12 or (abs(score - best[0]) <= 1e-12 and candidate[1] < best[1]):
                best = candidate
        return best

    result = solve(0, 0)
    require(result is not None, "Translated block types cannot be partitioned monotonically")
    ends, start, groups = result[1], 0, []
    for end in ends:
        groups.append(atoms[start:end])
        start = end
    require(start == m and len(groups) == n, "Internal translated block partition error")
    return groups


def derive_block_bindings(records: list[dict], config: dict) -> None:
    documents = {source: en.parse_document(en.safe_path(ROOT, binding["path"]).read_bytes(), binding["path"])
                 for source, binding in config["sources"].items()}
    groups = defaultdict(list)
    for record in records:
        path = en.source_path(record)
        if record["entity_class"] == "segment" and path in documents and not record["payload"].get("heading_level"):
            groups[(path, record["parent_id"])].append(record)
    bindings = {}
    for (path, parent), rows in groups.items():
        rows.sort(key=en.block_key)
        blocks = en.translated_blocks(documents[path], parent, config["lane"])
        if len(rows) == len(blocks):
            continue
        atoms = [(number, start, end) for number, block in enumerate(blocks, 1)
                 for start, end in display_atoms(block)]
        try:
            groups_for_rows = monotone_partition(rows, blocks, atoms)
        except PreparationError as exc:
            atoms = [(number, start, end) for number, block in enumerate(blocks, 1)
                     for start, end in fine_atoms(block)]
            try:
                groups_for_rows = monotone_partition(rows, blocks, atoms)
            except PreparationError:
                try:
                    groups_for_rows = monotone_partition(rows, blocks, atoms, strict_types=False)
                except PreparationError as final_exc:
                    raise PreparationError(f"Unresolved translated block boundary: {config['lane']} {parent}: "
                                           f"{len(rows)} native / {len(blocks)} English / {len(atoms)} atoms: {final_exc}") from final_exc
        for record, group in zip(rows, groups_for_rows):
            references = []
            for number, start, end in group:
                block = blocks[number - 1]
                if start == 0 and end == len(block):
                    references.append(number)
                else:
                    piece = block[start:end]
                    references.append({"block": number, "start": start, "end": end,
                                       "sha256": en.sha(piece.encode("utf-8"))})
            bindings[record["stable_id"]] = references
    config["block_bindings"] = bindings


def build_config(lane: str) -> tuple[dict, list[dict]]:
    records, _, _, native_facts = en.load_native(ROOT, lane)
    expected = en.expected_reader_source_order(ROOT, lane)
    native_paths = list(dict.fromkeys(en.source_path(record) for record in records if en.is_source_record(record)))
    native_paths = [path for path in native_paths if path is not None]
    by_target = {path.replace("source/id-ID/", "source/en/", 1): path for path in native_paths}
    sources = {}
    supplements = []
    for target in expected:
        if target in by_target:
            fact = en.file_fact(ROOT, target)
            sources[by_target[target]] = fact
        else:
            require(lane == "bgk" and target == "source/en/media-credits-bgk-unit-01.md",
                    f"Reader source has no native backend source record: {lane} {target}")
            native_path = "source/id-ID/media-credits-bgk-unit-01.md"
            english_fact, native_fact = en.file_fact(ROOT, target), en.file_fact(ROOT, native_path)
            supplements.append({**english_fact, "native_path": native_path,
                "native_bytes": native_fact["bytes"], "native_sha256": native_fact["sha256"],
                "stable_id": "artifact.br-bgk-2019.u01.media-credits",
                "template_stable_id": "artifact.br-bgk-2019.u02.15",
                "reason": "The frozen BGK native graph begins media-credit artifacts at Unit 2 although the Unit 1 source and translated reader file both exist."})
    mapped_native = set(sources)
    historical = [path for path in native_paths if path not in mapped_native]
    require(all(en.historical_frontmatter(path) for path in historical),
            f"Non-frontmatter native source omitted from {lane} reader mapping")
    config = {"schema": "ag-bridge-english-backend-input-v2", "lane": lane,
        "timestamp": STAMP, "native_inputs": native_facts,
        "contract_inputs": [en.file_fact(ROOT, path) for path in en.v2_contract_paths(lane)],
        "english_source_order": [en.file_fact(ROOT, path) for path in expected],
        "sources": sources, "historical_source_paths": historical,
        "supplemental_sources": supplements, "field_translations": [], "block_bindings": {}}
    derive_block_bindings(records, config)
    populate_translations(records, config)
    en.validate_config(config, records)
    en.validate_v2_runtime(config, ROOT, native_facts)
    return config, records


def generated_configs() -> dict[str, dict]:
    return {lane: build_config(lane)[0] for lane in ("classical", "bgk", "original")}


def write_exact(relative: str, data: bytes) -> None:
    path = en.safe_path(ROOT, relative)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    require(path.read_bytes() == data, f"Generated output readback mismatch: {relative}")


def input_bytes(configs: dict[str, dict]) -> dict[str, bytes]:
    return {lane: en.pretty(config) for lane, config in configs.items()}


def check_existing(configs: dict[str, dict]) -> None:
    for lane, data in input_bytes(configs).items():
        path = en.safe_path(ROOT, INPUT_PATHS[lane])
        require(path.is_file() and path.read_bytes() == data, f"Generated backend input drift: {INPUT_PATHS[lane]}")


def dry_run(configs: dict[str, dict]) -> tuple[dict, dict[str, dict]]:
    lane_reports = {}
    for lane, config in configs.items():
        files, report = en.run(copy.deepcopy(config), ROOT)
        lane_reports[lane] = {"status": report["status"], "counts": report["counts"],
            "input_sha256": report["input_sha256"], "field_translation_count": report["native"]["field_translation_count"],
            "block_binding_count": len(config["block_bindings"]),
            "supplemental_source_records": report["native"]["adapter_only_source_records"],
            "output_files": [{"path": path, "bytes": len(data), "sha256": en.sha(data)}
                             for path, data in sorted(files.items())]}
    all_sources = [fact for lane in ("classical", "bgk", "original")
                   for fact in configs[lane]["english_source_order"]]
    require(len(all_sources) == 274 and len({fact["path"] for fact in all_sources}) == 274,
            "Full English source closure is not exactly 274 files")
    try:
        gate = en.require_full_corpus_integration_qa(ROOT)
    except (en.AdapterError, OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        gate = {"status": "PENDING", "reason": str(exc),
                "required_path": "qa/english/TRANSLATION_INTEGRATION_QA.json"}
    else:
        gate = {"status": "PASS", "receipt": gate}
    status = "DRAFT_CHECKS_PASS_FINAL_GATE_READY" if gate["status"] == "PASS" else "DRAFT_CHECKS_PASS_FINAL_GATE_PENDING"
    receipt = {"schema": "ag-bridge-english-backend-full-corpus-dry-run-v1", "schema_version": "1.0.0",
        "status": status, "language": "en", "timestamp": STAMP,
        "scope": ["classical", "bgk", "original"], "source_file_count": len(all_sources),
        "source_order": all_sources, "input_files": [en.file_fact(ROOT, INPUT_PATHS[lane]) for lane in ("classical", "bgk", "original")],
        "implementation_inputs": [en.file_fact(ROOT, path) for path in
            ("scripts/english/export_backend_en.py", GENERATOR, TERM_MAP, TESTS, en.READER_COMMON_SCRIPT,
             en.COMMON_SCRIPT, en.COMMON_SCHEMA, en.PROFILE_SCHEMA, en.ORIGINAL_SCRIPT)],
        "lanes": lane_reports, "finalization_gate": gate,
        "claims": {"native_graphs_mutated": False, "source_en_mutated": False,
            "source_id_ID_mutated": False, "common_projection_replayed_in_memory": True,
            "draft_and_final_semantics_distinct": True, "html_or_pdf_touched": False}}
    return receipt, lane_reports


def packet_receipt(lane: str, config: dict, report: dict, dry_fact: dict) -> dict:
    return {"schema": "ag-bridge-english-backend-lane-handoff-v1", "schema_version": "1.0.0",
        "packet_id": "BACKEND-" + lane.upper(), "lane": lane, "language": "en",
        "status": "draft_backend_dry_run_complete_final_gate_pending",
        "timestamp": STAMP, "input": en.file_fact(ROOT, INPUT_PATHS[lane]),
        "native_inputs": config["native_inputs"], "contract_inputs": config["contract_inputs"],
        "english_source_order": config["english_source_order"], "dry_run": dry_fact,
        "result": report, "remaining": {
            "required_gate": "qa/english/TRANSLATION_INTEGRATION_QA.json with status PASS and exact facts for all 274 current English sources",
            "next_command": f"python -B scripts/english/export_backend_en.py --input {INPUT_PATHS[lane]} --final-write backend/english/<fresh-final-directory>"},
        "publication_status": "not_published"}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--write-inputs", action="store_true", help="Write only the three deterministic input files")
    modes.add_argument("--check", action="store_true", help="Verify existing inputs and run the full dry-run without writes")
    modes.add_argument("--write", action="store_true", help="Write inputs, full dry-run receipt, and lane receipts")
    args = parser.parse_args(argv)
    try:
        configs = generated_configs()
        if args.write_inputs or args.write:
            for lane, data in input_bytes(configs).items():
                write_exact(INPUT_PATHS[lane], data)
        else:
            check_existing(configs)
        if args.write_inputs:
            print(json.dumps({"status": "INPUTS_WRITTEN", "inputs": INPUT_PATHS}, indent=2))
            return 0
        receipt, reports = dry_run(configs)
        if args.write:
            write_exact(DRY_RUN_RECEIPT, en.pretty(receipt))
            dry_fact = en.file_fact(ROOT, DRY_RUN_RECEIPT)
            for lane in ("classical", "bgk", "original"):
                write_exact(PACKET_PATHS[lane], en.pretty(packet_receipt(lane, configs[lane], reports[lane], dry_fact)))
        print(json.dumps({"status": receipt["status"], "source_file_count": receipt["source_file_count"],
                          "lanes": {lane: {key: reports[lane][key] for key in
                              ("status", "field_translation_count", "block_binding_count")}
                                    for lane in reports}, "written": bool(args.write)}, ensure_ascii=False, indent=2))
        return 0
    except (PreparationError, en.AdapterError, OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        print(f"English backend input preparation failed: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
