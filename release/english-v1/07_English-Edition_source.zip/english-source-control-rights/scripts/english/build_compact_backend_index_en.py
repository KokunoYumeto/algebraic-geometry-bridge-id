"""Create a compact release index for the complete English native backend.

The three native ``records.jsonl`` files are the complete lossless backend
records.  Their expanded common datasets and per-entity JSONL projections are
derivable duplicates, so this index makes the release backend reader-resumable
without shipping those duplicate hundreds of megabytes.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
MODEL = "OpenAI Codex gpt-5.6-sol, Ultra."
BACKEND_ROOT = "backend/english/release-en-v1.0.0"
OUTPUT = BACKEND_ROOT + "/index"
LANES = ("classical", "bgk", "original")


class CompactBackendError(RuntimeError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise CompactBackendError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def fact(relative: str) -> dict[str, object]:
    path = ROOT / relative
    require(path.is_file(), "Missing backend input: " + relative)
    data = path.read_bytes()
    return {"path": relative, "bytes": len(data), "sha256": sha(data)}


def record_counts(relative: str) -> dict[str, int]:
    result: Counter[str] = Counter()
    with (ROOT / relative).open("r", encoding="utf-8", newline="") as stream:
        for number, line in enumerate(stream, 1):
            require(bool(line.strip()), f"Blank backend record row: {relative}:{number}")
            row = json.loads(line)
            require(isinstance(row, dict) and isinstance(row.get("entity_class"), str),
                    f"Malformed backend record row: {relative}:{number}")
            result[row["entity_class"]] += 1
    require(bool(result), "No records in backend file: " + relative)
    return dict(sorted(result.items()))


def build() -> dict[str, object]:
    output = ROOT / OUTPUT
    require(not output.exists(), "Compact backend index already exists")
    lanes = []
    selected = []
    for lane in LANES:
        prefix = BACKEND_ROOT + "/" + lane
        manifest_relative = prefix + "/MANIFEST.json"
        manifest = json.loads((ROOT / manifest_relative).read_bytes())
        require(manifest.get("schema") == "ag-bridge-english-backend-adapter-manifest-v1" and
                manifest.get("status") == "translated_final_frozen_adapter_checks_pass" and
                manifest.get("language") == "en" and manifest.get("model_provenance") == MODEL,
                "Unexpected final backend manifest: " + lane)
        manifest_files = {row["path"]: row for row in manifest.get("files", [])}
        records_relative = prefix + "/records.jsonl"
        schema_relative = prefix + "/record.schema.json"
        records = fact(records_relative)
        schema = fact(schema_relative)
        require(manifest_files.get("records.jsonl") == {"path": "records.jsonl", "bytes": records["bytes"], "sha256": records["sha256"]},
                "Manifest record identity drifted: " + lane)
        require(manifest_files.get("record.schema.json") == {"path": "record.schema.json", "bytes": schema["bytes"], "sha256": schema["sha256"]},
                "Manifest schema identity drifted: " + lane)
        json.loads((ROOT / schema_relative).read_bytes())
        counts = record_counts(records_relative)
        require(counts == manifest.get("counts"), "Manifest entity counts drifted: " + lane)
        manifest_fact = fact(manifest_relative)
        lanes.append({"lane": lane, "manifest": manifest_fact, "record_schema": schema,
                      "records": records, "entity_counts": counts,
                      "omitted_derivable_duplicates": [
                          "common.dataset.json", "per-entity JSONL projections"
                      ]})
        selected.extend([manifest_fact, schema, records])
    index = {
        "schema": "d100-en-native-backend-index-v1",
        "status": "PASS",
        "language": "en",
        "model_provenance": MODEL,
        "scope": "Complete lossless native English records for all three release components",
        "lanes": lanes,
        "checks": {"all_three_lane_manifests_current": True, "all_records_jsonl_rows_parsed": True,
                   "entity_counts_match_final_manifests": True, "omitted_files_are_derivable_duplicates": True},
    }
    manifest = {
        "schema": "d100-en-compact-native-backend-manifest-v1",
        "status": "PASS",
        "language": "en",
        "model_provenance": MODEL,
        "index_schema": index["schema"],
        "complete_native_record_closure": selected,
        "release_cap_rationale": "The native record streams are retained; only redundant expanded projections are omitted.",
    }
    output.mkdir(parents=True, exist_ok=False)
    for name, data in (("common.dataset.json", canonical(index)), ("MANIFEST.json", canonical(manifest))):
        path = output / name
        path.write_bytes(data)
        require(path.read_bytes() == data, "Index write/readback mismatch: " + name)
    return {"status": "PASS", "output": OUTPUT,
            "files": [fact(OUTPUT + "/MANIFEST.json"), fact(OUTPUT + "/common.dataset.json")],
            "lanes": [{"lane": row["lane"], "records": row["records"]} for row in lanes]}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args(argv)
    try:
        require(args.write, "Use --write to create the one fresh compact backend index")
        print(json.dumps(build(), ensure_ascii=False, indent=2))
        return 0
    except (CompactBackendError, OSError, UnicodeError, json.JSONDecodeError) as exc:
        print("Compact English backend index failed: " + str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
