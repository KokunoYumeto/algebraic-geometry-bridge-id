#!/usr/bin/env python3
"""Fail-closed English overlay of the three final corr1 native backends.

This is an adapter, not an Indonesian exporter or a publication receipt. It
never imports an exporter's main function and never opens Indonesian sources.
The native graph remains primary; the existing common-v1 transformation is
reused in memory, with its full native-record extension and reverse check.

Input JSON (all paths lane-relative; no implicit corpus discovery)::

  {"schema":"ag-bridge-english-backend-input-v2", "lane":"classical",
   "timestamp":"2026-09-04T00:00:00Z",
   "sources":{"source/id-ID/lecture-01.md":
      {"path":"source/en/lecture-01.md", "sha256":"<64 hex>"}},
   "historical_source_paths":[], "supplemental_sources":[],
   "english_source_order":[], "native_inputs":[], "contract_inputs":[],
   "field_translations":[],
   "block_bindings":{}}

Every native reader source must be mapped or explicitly retained as historical
frontmatter. Only superseded cumulative frontmatters can be historical; never
a lecture, worksheet, solution, final frontmatter, or original companion.
Metadata lacking a safe English source is returned by --inventory. Supply each
listed JSON pointer as a field_translations entry with stable_id, pointer,
source_value_sha256, value, language="en", and translation_basis. This explicit
translation input may confirm already-English wording with unchanged_english.
It cannot alter IDs, rights assignments, source URLs, or solution-coverage flags.

Block bindings are optional {native_segment_id:[one_based_English_block,...]}.
When a translated paragraph merges native segments, a list item may instead be
{"block":N,"start":I,"end":J,"sha256":"..."} and names a hash-pinned
Unicode slice. Bindings are needed only if boundaries changed; they must
partition each heading's entire block sequence, in native source order, without
omissions.

--inventory is read-only and needs no English source files. --check assembles
and validates a draft in memory. --write additionally creates a fresh directory
ONLY below backend/english. --final-check and --final-write are separate,
fail-closed operations which require the exact full-corpus English translation
integration PASS receipt. Nothing overwrites an existing export. Historical
native records and original reviews remain explicitly identified as evidence,
not as English reader content or English QA. Draft mode asserts no English
mathematical QA.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path, PurePosixPath
from typing import Any

import yaml
from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[2]
MODEL = "OpenAI Codex gpt-5.6-sol, Ultra."
LANES = {"classical": "units-01-30-corr1", "bgk": "bgk-units-01-30-corr1",
         "original": "original-bridge-corr1"}
COMMON_SCRIPT = "scripts/generate_common_backend_v1_receipts.py"
ORIGINAL_SCRIPT = "scripts/export_backend_original_bridge.py"
READER_COMMON_SCRIPT = "scripts/english/reader_common_en.py"
FINALIZATION_QA_SCRIPT = "scripts/english/finalize_translation_integration_qa_en_v1.py"
CONTRACT = "backend/common-backend-v1-contract/upstream/"
COMMON_SCHEMA = CONTRACT + "backend-v1.v0.41.0.schema.json"
PROFILE_SCHEMA = CONTRACT + "source-format-profile-v1.v0.41.0.schema.json"
PINS = {COMMON_SCRIPT: "ead98b528a7898411fe3fc371add4da6ca31f163ae36bd5ca8b4845e9db936c6",
        ORIGINAL_SCRIPT: "7284d8d1e717764d037a225d0e098b4de084977b22cca78956d4ffd059e48c26",
        READER_COMMON_SCRIPT: "66945507e927b41b2ed5fe8f005a72043a9cff4a25c994552dab864572e1c29d",
        COMMON_SCHEMA: "3de8d107b1c75db0f8d60c42ef7e3488bc3fcc93f72e955def71a771475cf2b2",
        PROFILE_SCHEMA: "2bb1429c36236329be94d58205b6123a0266a1e111277e3d303692ca8430e271"}
HEADING = re.compile(r"^(#{1,6})[ \t]+(.+?)[ \t]+\{#([^}]+)\}[ \t]*$", re.M)
SOURCE = re.compile(r"^(source/id-ID/[^#\r\n]+?\.md)(?:$|#|:\d)")
CONTENT_CLASSES = {"unit", "exercise", "solution", "segment"}
TEXT_FIELDS = {"markdown", "local_markdown", "section_markdown", "prompt_markdown",
               "problem_markdown", "solution_markdown", "check_markdown"}
# These fields are native evidence or typed machine values, not translated UI.
EVIDENCE_KEYS = {"source_entity", "source_reference", "local_target_witness", "review",
                 "source_file", "source_profile", "source_span", "formula_spans", "links",
                 "source_edition", "source_editions", "source_credit", "creator", "credit",
                 "creator_or_artist", "uploader", "license", "license_expression",
                 "license_url", "usage_terms", "witnesses", "current_commons_metadata",
                 "commons_template", "embedded_pdf_notice", "authority_identity",
                 "observed_course_root_revision", "reader_outputs", "metadata", "frontmatter"}
MACHINE_KEYS = {"unit_type", "segment_type", "kind", "family", "content_origin",
                "solution_origin", "source_language", "target_language", "locale",
                "status", "edition_kind", "authority_state", "host", "target", "course_root",
                "official_pdf", "curriculum_admission", "source_inline_label",
                "predicate", "relation_type", "offset_unit", "format",
                "media_type", "translation_qa_role", "upstream_report_disposition",
                "publication_gate", "whole_tree_build_state", "part", "commit", "tree",
                "relationship", "unit"}
PROTECTED_SUFFIXES = ("_id", "_ids", "_sha256", "_sha1", "_url", "_path", "_utc", "_date")


class AdapterError(ValueError):
    pass


def require(ok: bool, message: str) -> None:
    if not ok:
        raise AdapterError(message)


def canonical(value: Any, newline: bytes = b"\n") -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"), allow_nan=False).encode("utf-8") + newline


def pretty(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2,
                       allow_nan=False) + "\n").encode("utf-8")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def value_sha(value: Any) -> str:
    return sha(canonical(value, b""))


def safe_path(root: Path, relative: str) -> Path:
    p = PurePosixPath(relative)
    require(bool(relative) and "\\" not in relative and ":" not in relative
            and not p.is_absolute() and ".." not in p.parts, f"Unsafe relative path: {relative}")
    result = (root / p).resolve()
    require(result.is_relative_to(root.resolve()), f"Path escapes lane: {relative}")
    return result


def source_path(record: dict) -> str | None:
    # Direct native location wins over historical nested source provenance.
    for candidate in (record.get("path"), record.get("source_locator"),
                      record.get("provenance", {}).get("source_file", {}).get("path")):
        if isinstance(candidate, str) and (match := SOURCE.match(candidate)):
            return match.group(1)
    return None


def is_source_record(record: dict) -> bool:
    return record["entity_class"] in CONTENT_CLASSES or (
        record["entity_class"] == "artifact" and source_path(record) is not None
        and ("markdown" in record["payload"] or record["payload"].get("media_type") == "text/markdown"))


def historical_frontmatter(path: str) -> bool:
    name = PurePosixPath(path).name
    return path == "source/id-ID/frontmatter.md" or (
        name.startswith(("frontmatter-units-", "frontmatter-bgk-units-"))
        and not name.endswith("01-30.md"))


def file_fact(root: Path, relative: str) -> dict:
    data = safe_path(root, relative).read_bytes()
    return {"path": relative, "bytes": len(data), "sha256": sha(data)}


def load_module(root: Path, relative: str, name: str):
    require(relative in PINS and sha(safe_path(root, relative).read_bytes()) == PINS[relative],
            f"Pinned transformation implementation drift: {relative}")
    spec = importlib.util.spec_from_file_location(name, safe_path(root, relative))
    require(spec is not None and spec.loader is not None, f"Cannot import {relative}")
    module = importlib.util.module_from_spec(spec)
    # Suppress import bytecode outside this task's two assigned implementation files.
    old = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = old
    return module


def expected_reader_source_order(root: Path, lane: str) -> list[str]:
    reader = load_module(root, READER_COMMON_SCRIPT, "english_backend_reader_source_order")
    require(Path(reader.ROOT).resolve() == root.resolve(), "Pinned reader source-order root differs from adapter root")
    book = {"classical": "ak", "bgk": "bgk", "original": "companion"}[lane]
    result = [path.relative_to(root).as_posix() for path in reader.book_sources(book)]
    require(len(result) == len(set(result)), f"Duplicate reader source in {lane} order")
    return result


def v2_contract_paths(lane: str) -> list[str]:
    result = [COMMON_SCRIPT, COMMON_SCHEMA, PROFILE_SCHEMA, READER_COMMON_SCRIPT]
    if lane == "original":
        result.append(ORIGINAL_SCRIPT)
    return result


def validate_v2_runtime(config: dict, root: Path, native_facts: list[dict]) -> None:
    if config.get("schema") != "ag-bridge-english-backend-input-v2":
        return
    require(config["native_inputs"] == native_facts, "Pinned native input facts drifted")
    expected_contracts = [file_fact(root, path) for path in v2_contract_paths(config["lane"])]
    require(config["contract_inputs"] == expected_contracts, "Pinned backend contract facts drifted")
    order = expected_reader_source_order(root, config["lane"])
    require([fact["path"] for fact in config["english_source_order"]] == order,
            "Pinned English source order differs from reader contract")
    require(config["english_source_order"] == [file_fact(root, path) for path in order],
            "Pinned English source-order facts drifted")
    for entry in config["sources"].values():
        require({k: entry[k] for k in ("path", "bytes", "sha256")} == file_fact(root, entry["path"]),
                f"Pinned English source fact drifted: {entry['path']}")
    for row in config.get("supplemental_sources", []):
        require({"path": row["path"], "bytes": row["bytes"], "sha256": row["sha256"]}
                == file_fact(root, row["path"]), "Pinned supplemental English source drifted")
        native = file_fact(root, row["native_path"])
        require(row["native_bytes"] == native["bytes"] and row["native_sha256"] == native["sha256"],
                "Pinned supplemental native source drifted")


def load_native(root: Path, lane: str) -> tuple[list[dict], dict, dict, list[dict]]:
    require(lane in LANES, "Unknown native lane")
    prefix = "backend/" + LANES[lane] + "/"
    manifest_data = safe_path(root, prefix + "MANIFEST.json").read_bytes()
    manifest = json.loads(manifest_data)
    facts = [{"path": prefix + "MANIFEST.json", "bytes": len(manifest_data), "sha256": sha(manifest_data)}]
    data_by_name = {}
    for name in ("records.jsonl", "record.schema.json"):
        data = safe_path(root, prefix + name).read_bytes()
        matches = [f for f in manifest["files"] if f["path"] in {name, prefix + name}]
        require(len(matches) == 1, f"Native manifest does not uniquely bind {name}")
        require(matches[0]["bytes"] == len(data) and matches[0]["sha256"] == sha(data),
                f"Native manifest hash/length mismatch: {prefix + name}")
        data_by_name[name] = data
        facts.append({"path": prefix + name, "bytes": len(data), "sha256": sha(data)})
    records = [json.loads(line) for line in data_by_name["records.jsonl"].splitlines() if line]
    native_bytes = data_by_name["records.jsonl"]
    newline = b"\r\n" if native_bytes.split(b"\n", 1)[0].endswith(b"\r") else b"\n"
    require(b"".join(canonical(r, newline) for r in records) == native_bytes,
            "Native JSONL is not canonical UTF-8 LF/CRLF; exact source-byte reverse cannot be asserted")
    schema = json.loads(data_by_name["record.schema.json"])
    validate_native(records, schema)
    require(dict(Counter(r["entity_class"] for r in records)) == manifest["counts"], "Native entity-count drift")
    return records, manifest, schema, facts


def validate_native(records: list[dict], schema: dict) -> None:
    validator = Draft202012Validator(schema)
    ids = {r["stable_id"] for r in records}
    require(len(ids) == len(records), "Duplicate native stable ID")
    for r in records:
        error = next(validator.iter_errors(r), None)
        require(error is None, f"Native schema: {r['stable_id']}: {error}")
        for key in ("parent_id", "resource_id", "edition_id", "rights_id", "supersedes"):
            require(r[key] is None or r[key] in ids, f"Dangling native {key}: {r['stable_id']}")
        for key in ("concept_ids", "prerequisite_ids"):
            require(set(r[key]) <= ids, f"Dangling native {key}: {r['stable_id']}")
        if r["entity_class"] == "relation":
            require(r["payload"].get("subject_id") in ids and r["payload"].get("object_id") in ids,
                    f"Dangling native relation: {r['stable_id']}")


def validate_config(config: dict, records: list[dict]) -> None:
    version = config.get("schema")
    require(version in {"ag-bridge-english-backend-input-v1", "ag-bridge-english-backend-input-v2"},
            "Wrong input schema")
    require(config.get("lane") in LANES, "Wrong input lane")
    require(isinstance(config.get("sources"), dict), "Missing explicit source mappings")
    require(re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:Z|[+-]\d\d:\d\d)",
                         config.get("timestamp", "")) is not None, "Supply an explicit ISO timestamp")
    sources = {source_path(r) for r in records if is_source_record(r)} - {None}
    historical = config.get("historical_source_paths", [])
    require(len(historical) == len(set(historical)), "Duplicate historical source path")
    require(all(historical_frontmatter(p) for p in historical), "Only superseded frontmatter may be historical")
    require(config["lane"] == "classical" or "source/id-ID/frontmatter.md" not in historical,
            "Generic historical frontmatter belongs only to the classical native lane")
    require(not (set(historical) & config["sources"].keys()), "Source is both historical and translated")
    require(set(config["sources"]) | set(historical) == sources,
            "Source coverage mismatch: " + json.dumps({"missing": sorted(sources - set(config["sources"]) - set(historical)),
                "extra": sorted((set(config["sources"]) | set(historical)) - sources)}))
    targets = []
    for entry in config["sources"].values():
        require(isinstance(entry, dict) and str(entry.get("path", "")).startswith("source/en/"),
                "English targets must be explicit source/en paths")
        require(re.fullmatch(r"[a-f0-9]{64}", entry.get("sha256", "")) is not None, "Unpinned English source")
        if version.endswith("-v2"):
            require(type(entry.get("bytes")) is int and entry["bytes"] >= 0, "English source byte length is not pinned")
        targets.append(entry["path"])
    require(len(targets) == len(set(targets)), "Two native files map to one English source")
    supplements = config.get("supplemental_sources", [])
    require(isinstance(supplements, list), "supplemental_sources must be a list")
    supplemental_targets = []
    supplemental_native = []
    for row in supplements:
        require(isinstance(row, dict), "Malformed supplemental source")
        require(row.get("native_path") == "source/id-ID/media-credits-bgk-unit-01.md"
                and row.get("path") == "source/en/media-credits-bgk-unit-01.md"
                and row.get("stable_id") == "artifact.br-bgk-2019.u01.media-credits"
                and row.get("template_stable_id") == "artifact.br-bgk-2019.u02.15"
                and config["lane"] == "bgk", "Only the declared BGK Unit 1 media-credit source omission may be supplemented")
        for prefix in ("", "native_"):
            require(type(row.get(prefix + "bytes")) is int and row[prefix + "bytes"] >= 0,
                    "Supplemental source byte length is not pinned")
            require(re.fullmatch(r"[a-f0-9]{64}", row.get(prefix + "sha256", "")) is not None,
                    "Supplemental source hash is not pinned")
        require(isinstance(row.get("reason"), str) and row["reason"].strip(), "Supplemental source needs a reason")
        supplemental_targets.append(row["path"])
        supplemental_native.append(row["native_path"])
    require(len(supplemental_targets) == len(set(supplemental_targets))
            and len(supplemental_native) == len(set(supplemental_native)), "Duplicate supplemental source")
    require(not (set(targets) & set(supplemental_targets)), "Supplemental target duplicates a native-backed target")
    require(not (sources & set(supplemental_native)), "Supplemental native source already exists in the native graph")
    if version.endswith("-v2"):
        for key in ("native_inputs", "contract_inputs", "english_source_order"):
            require(isinstance(config.get(key), list) and config[key], f"Missing v2 {key}")
            for fact in config[key]:
                require(isinstance(fact, dict) and isinstance(fact.get("path"), str)
                        and type(fact.get("bytes")) is int and fact["bytes"] >= 0
                        and re.fullmatch(r"[a-f0-9]{64}", fact.get("sha256", "")) is not None,
                        f"Malformed v2 {key} fact")
        order = [fact["path"] for fact in config["english_source_order"]]
        require(len(order) == len(set(order)), "Duplicate English source-order path")
        require(set(order) == set(targets) | set(supplemental_targets), "English source-order closure mismatch")


def parse_document(data: bytes, path: str) -> dict:
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise AdapterError(f"Not UTF-8: {path}") from exc
    require("\r" not in text.replace("\r\n", ""), f"Bare CR: {path}")
    raw_text = text
    text = text.replace("\r\n", "\n")
    front = re.match(r"\A---\n(.*?)\n---(?:\n|$)", text, re.S)
    if front is None:
        require(str(path).startswith("source/en/") and PurePosixPath(path).name.startswith("media-credits"),
                f"Missing YAML frontmatter: {path}")
        metadata, body, body_start, frontmatter = {"language": "en"}, text, 0, ""
    else:
        metadata = yaml.safe_load(front.group(1))
        body, body_start, frontmatter = text[front.end():], front.end(), front.group()
    require(isinstance(metadata, dict) and (metadata.get("language") or metadata.get("lang")) == "en",
            f"Not an English source: {path}")
    matches = list(HEADING.finditer(body))
    require(matches, f"No anchored headings: {path}")
    require(len(matches) == len(re.findall(r"^#{1,6}\s+", body, re.M)), f"Unanchored heading: {path}")
    prefix = body[:matches[0].start()]
    prefix_blocks = [match.group() for match in re.finditer(r"```\{=latex\}\n\\clearpage\n```", prefix)]
    prefix_check = re.sub(r"<!--.*?-->", "", prefix, flags=re.S)
    prefix_check = re.sub(r"```\{=latex\}\n\\clearpage\n```", "", prefix_check)
    require(not prefix_check.strip(),
            f"Unbound reader text before first heading: {path}")
    require(metadata.get("stable_id") in (None, matches[0].group(3)), f"Frontmatter stable ID mismatch: {path}")
    headings = {}
    for i, m in enumerate(matches):
        sid, level = m.group(3), len(m.group(1))
        require(sid not in headings, f"Duplicate heading {sid}: {path}")
        end = matches[i + 1].start() if i + 1 < len(matches) else len(body)
        subtree = next((n.start() for n in matches[i + 1:] if len(n.group(1)) <= level), len(body))
        blocks = []
        for block in re.finditer(r"\S(?:.*?\S)?(?=\n[ \t]*\n|\Z)", body[m.end():end].strip(), re.S):
            value = block.group().strip()
            blocks.append(value)
        headings[sid] = {"stable_id": sid, "title": m.group(2), "level": level,
            "line": text[:body_start + m.start()].count("\n") + 1,
            "start": m.start(), "end": end, "subtree_end": subtree,
            "markdown": body[m.start():end], "section_markdown": body[m.start():subtree],
            "local_body": body[m.end():end].strip(),
            "blocks": blocks}
    return {"path": path, "fact": {"path": path, "bytes": len(data), "sha256": sha(data)},
            "text": text, "raw_text": raw_text, "body": body, "frontmatter": frontmatter, "metadata": metadata,
            "prefix_blocks": prefix_blocks,
            "headings": headings}


def pointer_items(value: Any, prefix: str = "/payload"):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in EVIDENCE_KEYS or key in MACHINE_KEYS or key.startswith("source_") or key.endswith(PROTECTED_SUFFIXES):
                continue
            escaped = key.replace("~", "~0").replace("/", "~1")
            yield from pointer_items(child, prefix + "/" + escaped)
    elif isinstance(value, list):
        for i, child in enumerate(value):
            yield from pointer_items(child, prefix + "/" + str(i))
    elif isinstance(value, str) and value.strip():
        if not re.match(r"^(?:https?://|[a-f0-9]{40,64}$)", value):
            yield prefix, value


def fields_requiring_translation(record: dict, config: dict) -> list[tuple[str, str]]:
    kind, payload = record["entity_class"], record["payload"]
    path = source_path(record)
    if path in config.get("historical_source_paths", []):
        return []
    if kind in {"relation", "qa_event", "edition"} or (kind == "artifact" and not is_source_record(record)):
        return []  # Retained in original locale, never English QA/build/edition evidence.
    if record["language"] not in {"id-ID", "en"} and not (is_source_record(record) and path in config["sources"]):
        return []  # German resource titles, verbatim component-rights witnesses, etc.
    auto = TEXT_FIELDS | {"title", "title_markdown", "body_prefix"} if is_source_record(record) and path in config["sources"] else set()
    result = []
    for pointer, value in pointer_items(payload):
        field = pointer.split("/")[2]
        if field in auto:
            continue
        if kind == "resource" and pointer == "/payload/title" and payload.get("relationship") == "source_reference":
            continue  # Verbatim German/URL reference identity, not an English display title.
        if kind == "concept" and pointer.startswith("/payload/matching_keywords/") and value == payload.get("source_label"):
            continue  # Retain the German lookup key beside its translated English keyword.
        # Native structural role tokens remain machine values, not UI labels.
        if field in {"role", "scope"} and re.fullmatch(r"[a-z][a-z0-9_]*", value):
            continue
        result.append((pointer, value))
    # The origin sentence names a language and therefore needs an explicit EN input.
    if "source_problem_origin" in payload:
        result.append(("/payload/source_problem_origin", payload["source_problem_origin"]))
    # Embedded term ledger is data, but its reader target/rationale must not leak Indonesian.
    ledger = payload.get("ledger_row")
    if isinstance(ledger, dict):
        existing = {p for p, _ in result}
        for p, value in pointer_items(ledger, "/payload/ledger_row"):
            if p not in existing:
                result.append((p, value))
    return result


def translation_inventory(records: list[dict], config: dict) -> list[dict]:
    return [{"stable_id": r["stable_id"], "pointer": p, "native_value": v,
             "source_value_sha256": value_sha(v), "language": "en", "value": None,
             "translation_basis": None, "reason": "backend-only reader text; explicit English input required"}
            for r in records for p, v in fields_requiring_translation(r, config)]


def put_pointer(record: dict, pointer: str, value: Any) -> None:
    keys = [p.replace("~1", "/").replace("~0", "~") for p in pointer.lstrip("/").split("/")]
    target = record
    for key in keys[:-1]:
        target = target[int(key)] if isinstance(target, list) else target[key]
    if isinstance(target, list):
        target[int(keys[-1])] = value
    else:
        target[keys[-1]] = value


def english_target_locales(payload: Any) -> None:
    """Update target locale metadata only; source locales remain untouched."""
    if isinstance(payload, dict):
        for key, value in payload.items():
            if key in {"target_language", "locale"} and value == "id-ID":
                payload[key] = "en"
            elif key not in EVIDENCE_KEYS and not key.startswith("source_"):
                english_target_locales(value)
    elif isinstance(payload, list):
        for item in payload:
            english_target_locales(item)


def unchanged_prose(old: str, new: str) -> bool:
    if " ".join(old.split()) != " ".join(new.split()):
        return False
    residual = re.sub(r"<!--.*?-->|\$\$.*?\$\$|(?<!\\)\$.*?(?<!\\)\$", "", old, flags=re.S)
    residual = re.sub(r"\{#[^}]+\}|https?://\S+|\\[A-Za-z]+", "", residual)
    return len(re.findall(r"\b[A-Za-zÀ-ÿ]{3,}\b", residual)) >= 4


def linguistic_source_field(record: dict, field: str) -> bool:
    if field != "markdown" or record["entity_class"] != "segment":
        return True
    segment_type = record["payload"].get("kind", record["payload"].get("segment_type"))
    return segment_type not in {"display_math", "image", "figure_reference", "source_comment", "raw_tex"}


def block_key(record: dict) -> tuple[int, str]:
    locator = record.get("source_locator") or ""
    match = re.search(r"(?:block-|:)(\d+)$", locator)
    return (int(match.group(1)) if match else int(record.get("order") or 0), record["stable_id"])


def translated_blocks(document: dict, parent: str, lane: str) -> list[str]:
    if parent in document["headings"]:
        blocks = document["headings"][parent]["blocks"]
        if lane == "classical":
            blocks = [block for block in blocks if not (block.startswith("<!--") and block.endswith("-->"))]
        return blocks
    # The classical native graph records the exact Pandoc page-break prefix in
    # Units 12--30 as edition-parented source segments.  It is outside every
    # anchored reader heading, so bind only those exact accepted prefix blocks.
    require(lane == "classical" and document.get("prefix_blocks"),
            f"Missing segment parent heading: {parent}")
    return document["prefix_blocks"]


def artifact_only_source_paths(records: list[dict], documents: dict) -> set[str]:
    result = set()
    for path in documents:
        source_records = [record for record in records
                          if is_source_record(record) and source_path(record) == path]
        if source_records and all(record["entity_class"] == "artifact" for record in source_records):
            result.add(path)
    return result


def bind_blocks(records: list[dict], documents: dict, config: dict) -> dict[str, str]:
    groups = defaultdict(list)
    for r in records:
        path = source_path(r)
        if r["entity_class"] == "segment" and path in documents and not r["payload"].get("heading_level"):
            groups[(path, r["parent_id"])].append(r)
    bound, used_overrides = {}, set()
    overrides = config.get("block_bindings", {})
    artifact_only = artifact_only_source_paths(records, documents)
    if config["lane"] != "original":
        for path, document in documents.items():
            if path in artifact_only:
                continue
            for sid, heading in document["headings"].items():
                visible = heading["blocks"]
                if config["lane"] == "classical":
                    visible = [b for b in visible if not (b.startswith("<!--") and b.endswith("-->"))]
                require(not visible or (path, sid) in groups,
                        f"English blocks have no native segment identities: {sid}")
    for (path, parent), rows in groups.items():
        blocks = translated_blocks(documents[path], parent, config["lane"])
        rows.sort(key=block_key)
        explicit = any(r["stable_id"] in overrides for r in rows)
        require(explicit or len(rows) == len(blocks), f"Block count changed under {parent}: {len(rows)} native / {len(blocks)} English; supply explicit block_bindings")
        selected = []
        for i, r in enumerate(rows, 1):
            sid = r["stable_id"]
            references = overrides.get(sid) if explicit else [i]
            require(isinstance(references, list) and references,
                    f"Missing/invalid explicit block binding: {sid}")
            pieces = []
            previous = None
            for reference in references:
                if type(reference) is int:
                    require(1 <= reference <= len(blocks), f"Invalid block number: {sid}")
                    number = reference
                    start, end = 0, len(blocks[reference - 1])
                    selected.append((reference, start, end))
                    piece = blocks[reference - 1]
                else:
                    require(isinstance(reference, dict) and set(reference) == {"block", "start", "end", "sha256"},
                            f"Invalid block-slice binding: {sid}")
                    number, start, end = reference["block"], reference["start"], reference["end"]
                    require(type(number) is int and type(start) is int and type(end) is int
                            and 1 <= number <= len(blocks) and 0 <= start < end <= len(blocks[number - 1]),
                            f"Invalid block-slice range: {sid}")
                    piece = blocks[number - 1][start:end]
                    require(reference["sha256"] == sha(piece.encode("utf-8")), f"Stale block-slice hash: {sid}")
                    selected.append((number, start, end))
                current = (number, start, end)
                separator = "" if previous is not None and previous[0] == current[0] \
                    and previous[2] == current[1] else ("\n\n" if pieces else "")
                pieces.append(separator + piece)
                previous = current
            bound[sid] = "".join(pieces)
            if explicit:
                used_overrides.add(sid)
        require(selected == sorted(selected), f"Block bindings omit, duplicate, or reorder content: {parent}")
        for number, block in enumerate(blocks, 1):
            spans = [(start, end) for n, start, end in selected if n == number]
            require(spans and spans[0][0] == 0 and spans[-1][1] == len(block)
                    and all(left[1] == right[0] for left, right in zip(spans, spans[1:])),
                    f"Block bindings omit, duplicate, or reorder content: {parent}")
    require(set(overrides) == used_overrides, "Unused/unknown block_bindings")
    return bound


def original_parts(heading: dict, document: dict, native_payload: dict) -> dict:
    result = {}
    section = heading["section_markdown"]
    fields = [f for f in ("problem_markdown", "solution_markdown", "check_markdown") if f in native_payload]
    if fields == ["solution_markdown"]:
        return {"solution_markdown": section}
    if not fields:
        return result
    require(len(fields) == 3, "Unknown original solution-part layout")
    suffixes = {"problem_markdown": r"-(statement|problem|soal)$", "solution_markdown": r"-(solution|solusi)$",
                "check_markdown": r"-(check|periksa)$"}
    for field, pattern in suffixes.items():
        matches = [h for sid, h in document["headings"].items() if sid.startswith(heading["stable_id"] + "-") and re.search(pattern, sid)]
        if len(matches) == 1:
            result[field] = matches[0]["section_markdown"]
    if len(result) == 3:
        return result
    # Unanchored bold labels are not guessed from language: match their native
    # ordinal structural positions, then take the same boundaries in English.
    old = native_payload["section_markdown"]
    old_markers = list(re.finditer(r"^\*\*[^*]+\*\*", old, re.M))
    new_markers = list(re.finditer(r"^\*\*[^*]+\*\*", section, re.M))
    require(len(old_markers) == len(new_markers), "Original bold-label structure changed")
    positions = []
    for field in fields:
        part = native_payload[field]
        require(old.count(part) == 1, f"Ambiguous native {field}")
        offset = old.index(part)
        matches = [i for i, m in enumerate(old_markers) if m.start() == offset]
        require(len(matches) == 1, f"No structural marker for {field}")
        positions.append(new_markers[matches[0]].start())
    require(positions == sorted(set(positions)), "Original solution parts reordered")
    for i, field in enumerate(fields):
        result[field] = section[positions[i]:positions[i + 1] if i + 1 < len(fields) else len(section)]
        require(result[field].strip(), f"Empty original {field}")
    return result


def supplemental_source_records(records: list[dict], config: dict,
                                supplemental_bytes: dict[str, dict[str, bytes]]) -> list[dict]:
    by_id = {record["stable_id"]: record for record in records}
    result = []
    declared = {row["stable_id"] for row in config.get("supplemental_sources", [])}
    require(set(supplemental_bytes) == declared, "Missing or unexpected supplemental source bytes")
    for row in config.get("supplemental_sources", []):
        blobs = supplemental_bytes[row["stable_id"]]
        english, native = blobs.get("english"), blobs.get("native")
        require(isinstance(english, bytes) and isinstance(native, bytes), "Malformed supplemental source bytes")
        require(len(english) == row["bytes"] and sha(english) == row["sha256"], "Supplemental English source hash drift")
        require(len(native) == row["native_bytes"] and sha(native) == row["native_sha256"], "Supplemental native source hash drift")
        template = by_id.get(row["template_stable_id"])
        require(template is not None and template["entity_class"] == "artifact"
                and template["rights_id"] is not None, "Supplemental source template is unavailable")
        # The source file is real but the frozen native backend omitted its
        # artifact.  Copy only structural/FK assignments from the adjacent
        # media-credit artifact and expose the derivation instead of pretending
        # that an Indonesian backend record existed.
        artifact = copy.deepcopy(template)
        artifact.update(stable_id=row["stable_id"], source_local_id=PurePosixPath(row["path"]).name,
                        path=row["path"], source_locator=row["path"], content_sha256=sha(english),
                        language="en", translation_state="draft", timestamp=config["timestamp"],
                        responsible_workflow="ag-bridge-english-backend-adapter-v1", supersedes=None)
        artifact["payload"] = {"bytes": len(english), "media_type": "text/markdown", "unit": 1}
        artifact["provenance"] = {
            "english_adapter": {"model_provenance": MODEL, "adapter_only_source_closure": True,
                "english_qa_claimed": False, "source_binding": {"path": row["path"], "bytes": len(english), "sha256": sha(english)},
                "native_source_binding": {"path": row["native_path"], "bytes": len(native), "sha256": sha(native)},
                "native_record": None, "native_record_sha256": None,
                "template_stable_id": template["stable_id"], "template_record_sha256": value_sha(template),
                "reason": row["reason"]}}
        result.append(artifact)
    return result


def embedded_facts(value: Any):
    if isinstance(value, dict):
        if isinstance(value.get("path"), str) and type(value.get("bytes")) is int \
                and isinstance(value.get("sha256"), str):
            yield value
        for child in value.values():
            yield from embedded_facts(child)
    elif isinstance(value, list):
        for child in value:
            yield from embedded_facts(child)


def validate_integration_qa(root: Path, expected_paths: list[str],
                            relative: str = "qa/english/TRANSLATION_INTEGRATION_QA.json") -> dict:
    path = safe_path(root, relative)
    require(path.is_file(), "English translation integration QA receipt is absent")
    data = path.read_bytes()
    report = json.loads(data)
    require(report.get("schema") == "d100-en-translation-integration-qa-v1",
            "English translation integration QA has the wrong schema")
    require(report.get("status") == "PASS" and report.get("language") == "en",
            "English translation integration QA is not PASS")
    require(len(expected_paths) == len(set(expected_paths)) == 274,
            "Finalization gate expected source closure is not exactly 274 files")
    require(report.get("target_count") == 274,
            "English translation integration QA target count is not exactly 274")
    require(report.get("deterministic") is True,
            "English translation integration QA is not a terminal deterministic report")
    require(report.get("review_receipt_count") == 15 and report.get("translation_packet_count") == 18,
            "English translation integration QA has incomplete review or translation-packet counts")
    facts = report.get("facts")
    require(isinstance(facts, dict) and isinstance(facts.get("current_sources"), list),
            "English translation integration QA lacks its canonical current-source facts")
    declared = facts["current_sources"]
    current = [file_fact(root, source) for source in expected_paths]
    require(declared == current,
            "English integration QA does not bind the exact ordered current 274-source closure")
    require(facts.get("tooling") == [file_fact(root, path) for path in
                                      (READER_COMMON_SCRIPT, FINALIZATION_QA_SCRIPT)],
            "English translation integration QA tooling is not current")
    return {"path": relative, "bytes": len(data), "sha256": sha(data)}


def require_full_corpus_integration_qa(root: Path) -> dict:
    reader = load_module(root, READER_COMMON_SCRIPT, "english_backend_finalization_source_order")
    require(Path(reader.ROOT).resolve() == root.resolve(), "Pinned reader QA root differs from adapter root")
    paths = [path.relative_to(root).as_posix() for book in ("ak", "bgk", "companion")
             for path in reader.book_sources(book)]
    return validate_integration_qa(root, paths)


def finalize_english_records(records: list[dict], qa_fact: dict) -> None:
    finalized = 0
    for record in records:
        adapter = record.get("provenance", {}).get("english_adapter")
        if not isinstance(adapter, dict):
            continue
        require(record["language"] == "en" and record["translation_state"] == "draft",
                f"Unexpected pre-finalization state: {record['stable_id']}")
        adapter["english_qa_claimed"] = True
        adapter["translation_integration_qa"] = copy.deepcopy(qa_fact)
        record["translation_state"] = "mathematically_reviewed"
        finalized += 1
    require(finalized > 0, "No English records were available to finalize")


def adapt_native(records: list[dict], config: dict, source_bytes: dict[str, bytes], original_helpers=None,
                 supplemental_bytes: dict[str, dict[str, bytes]] | None = None) -> tuple[list[dict], dict]:
    validate_config(config, records)
    expected = translation_inventory(records, config)
    translations = {}
    for entry in config.get("field_translations", []):
        key = (entry.get("stable_id"), entry.get("pointer"))
        require(key not in translations, f"Duplicate translation input: {key}")
        translations[key] = entry
    needed = {(r["stable_id"], r["pointer"]): r for r in expected}
    require(set(translations) == set(needed), "Field translation coverage mismatch: " + json.dumps({
        "missing": sorted(set(needed) - set(translations)), "extra": sorted(set(translations) - set(needed))}))
    translations_by_id = defaultdict(list)
    for key, entry in translations.items():
        require(entry.get("source_value_sha256") == needed[key]["source_value_sha256"], f"Stale translation input: {key}")
        require(entry.get("language") == "en" and isinstance(entry.get("value"), str) and entry["value"].strip()
                and isinstance(entry.get("translation_basis"), str) and entry["translation_basis"].strip(), f"Incomplete English translation input: {key}")
        require(entry["value"] != needed[key]["native_value"] or entry.get("unchanged_english") is True,
                f"Unchanged backend prose requires explicit unchanged_english evidence: {key}")
        translations_by_id[key[0]].append(entry)
    require(set(source_bytes) == set(config["sources"]), "Missing or unexpected source bytes")
    documents = {}
    for path, binding in config["sources"].items():
        data = source_bytes[path]
        require(sha(data) == binding["sha256"], f"English source hash drift: {binding['path']}")
        documents[path] = parse_document(data, binding["path"])
    heading_ids = defaultdict(set)
    for r in records:
        path = source_path(r)
        if path in documents and r["entity_class"] in CONTENT_CLASSES and r["payload"].get("heading_level"):
            heading_ids[path].add(r["stable_id"])
    artifact_only = artifact_only_source_paths(records, documents)
    for path, doc in documents.items():
        if path in artifact_only:
            require(not heading_ids[path], f"Artifact-only source unexpectedly has native heading records: {path}")
            continue
        require(heading_ids[path] == set(doc["headings"]), f"Heading coverage changed: {path}")
    blocks = bind_blocks(records, documents, config)
    output, translated, history = [], [], []
    for native in records:
        provenance_note = None
        r = copy.deepcopy(native)
        sid, payload, path = r["stable_id"], r["payload"], source_path(r)
        changed = False
        if is_source_record(r) and path in documents:
            doc = documents[path]
            if r["entity_class"] == "artifact":
                if "markdown" in payload:
                    payload.update(markdown=doc["raw_text"], metadata=doc["metadata"], frontmatter=doc["frontmatter"],
                                   body_prefix=doc["body"][:next(iter(doc["headings"].values()))["start"]])
                payload["bytes"] = doc["fact"]["bytes"]
                if "source_profile" in payload:
                    payload["source_profile"].update(path=doc["path"], sha256=doc["fact"]["sha256"])
                content = doc["raw_text"]
                metric_text = doc["body"]
                r["source_locator"] = doc["path"]
            elif sid in blocks:
                content = blocks[sid] + ("\n" if config["lane"] == "bgk" else "")
                metric_text = content
                require(not linguistic_source_field(native, "markdown")
                        or not unchanged_prose(native["payload"].get("markdown", ""), content),
                        f"Untranslated source prose: {sid}")
                payload["markdown"] = content
                native_type_field = "kind" if "kind" in payload else "segment_type" if "segment_type" in payload else None
                if native_type_field is not None:
                    native_display = payload[native_type_field] == "display_math"
                    english_display = content.lstrip().startswith("$$")
                    if native_display != english_display:
                        new_type = "display_math" if english_display else (
                            "paragraph" if native_type_field == "kind" else "prose")
                        payload[native_type_field] = new_type
                        provenance_note = {"field": native_type_field,
                            "native_value": native["payload"][native_type_field], "english_value": new_type,
                            "reason": "Exact translated source slice changed display/prose structure"}
                    else:
                        provenance_note = None
                r["source_locator"] = doc["path"] + "#" + r["parent_id"] + ":segment:" + sid
            else:
                anchor = sid if sid in doc["headings"] else r["parent_id"]
                require(anchor in doc["headings"], f"No English heading binding: {sid}")
                h = doc["headings"][anchor]
                metric_text = h["local_body"]
                for field in ("title", "title_markdown"):
                    if field in payload:
                        payload[field] = h["title"]
                for field in ("markdown", "local_markdown", "prompt_markdown", "section_markdown", "solution_markdown"):
                    if field in payload:
                        if config["lane"] == "bgk" and field in {"prompt_markdown", "solution_markdown"}:
                            payload[field] = h["local_body"]
                        else:
                            payload[field] = h["section_markdown"] if field == "section_markdown" else h["markdown"].strip() + "\n"
                if config["lane"] == "original":
                    payload["markdown"] = h["markdown"]
                    payload["section_markdown"] = h["section_markdown"]
                    payload["source_span"] = {k: h[k] for k in ("start", "end", "subtree_end")}
                    payload["source_span"]["offset_unit"] = "unicode_code_points_in_body"
                    payload.update(original_parts(h, doc, native["payload"]))
                content = h["section_markdown"].strip() + "\n" if config["lane"] == "classical" else payload.get("markdown", h["markdown"].strip() + "\n")
                r["source_locator"] = doc["path"] + "#" + anchor
            for field in TEXT_FIELDS:
                if field in payload and field in native["payload"]:
                    require(not linguistic_source_field(native, field)
                            or not unchanged_prose(native["payload"][field], payload[field]),
                            f"Untranslated {field}: {sid}")
            if "formula_spans" in payload or "links" in payload:
                require(original_helpers is not None, "Original native span/link helpers are required")
                span_text = doc["body"] if r["entity_class"] == "artifact" else payload["markdown"]
                payload["formula_spans"] = original_helpers.math_spans(span_text)
                payload["links"] = original_helpers.links(span_text)
            if "source_file" in payload:
                payload["source_file"] = copy.deepcopy(doc["fact"])
            if "source_file_sha256" in payload:
                payload["source_file_sha256"] = doc["fact"]["sha256"]
            for field in ("display_math_count", "display_math_block_count"):
                if field in payload:
                    payload[field] = len(re.findall(r"\$\$(.*?)\$\$", metric_text, re.S))
            if "inline_math_delimiter_count" in payload:
                payload["inline_math_delimiter_count"] = len(re.findall(r"(?<!\$)\$(?!\$)", metric_text))
            r["path"], r["content_sha256"] = doc["path"], sha(content.encode("utf-8"))
            changed = True
        for entry in translations_by_id[sid]:
            put_pointer(r, entry["pointer"], entry["value"])
            changed = True
        if changed:
            # Preserve all frozen evidence verbatim, but do not present an old
            # review/source-byte claim as a review of this English translation.
            provenance = copy.deepcopy(native["provenance"])
            for key in ("source_file", "source_file_sha256", "source_provenance", "indexed_unit_record_sha256", "mathematical_review"):
                provenance.pop(key, None)
            payload.pop("review", None)
            english_target_locales(payload)
            provenance["english_adapter"] = {"model_provenance": MODEL, "native_record": copy.deepcopy(native),
                "native_record_sha256": value_sha(native), "english_qa_claimed": False,
                "source_binding": copy.deepcopy(documents[path]["fact"]) if path in documents and is_source_record(native) else None,
                "translation_inputs": copy.deepcopy(translations_by_id[sid]),
                "source_locator_semantics": "English source" if path in documents and is_source_record(native)
                    else "retained native evidence locator; English field inputs embedded here",
                "structural_text_normalization": "CRLF to LF; source artifact payload and source-byte hash remain exact"}
            if is_source_record(native) and path in documents and r["entity_class"] == "segment" \
                    and provenance_note is not None:
                provenance["english_adapter"]["source_structure_reclassification"] = provenance_note
            r.update(provenance=provenance, language="en", translation_state="draft", timestamp=config["timestamp"],
                     responsible_workflow="ag-bridge-english-backend-adapter-v1")
            if not (is_source_record(native) and path in documents) and r["entity_class"] != "asset":
                r["content_sha256"] = value_sha(payload)
            translated.append(sid)
        else:
            history.append(sid)
        output.append(r)
    require([r["stable_id"] for r in output] == [r["stable_id"] for r in records], "Native identities changed")
    restored = [r.get("provenance", {}).get("english_adapter", {}).get("native_record", r) for r in output]
    require(restored == records, "Native reverse reconstruction failed")
    supplements = supplemental_source_records(records, config, supplemental_bytes or {})
    output.extend(supplements)
    return output, {"translated_record_ids": translated, "retained_source_or_historical_record_ids": history,
                    "english_sources": [documents[p]["fact"] for p in sorted(documents)], "native_reverse_equal": True,
                    "artifact_only_english_sources": sorted(artifact_only),
                    "english_mathematical_qa_claimed": False, "field_translation_count": len(translations),
                    "adapter_only_source_records": [{"stable_id": r["stable_id"],
                        "path": r["path"], "bytes": r["payload"]["bytes"], "sha256": r["content_sha256"]}
                        for r in supplements]}


def common_projection(records: list[dict], config: dict, root: Path = ROOT, *, finalized: bool = False) -> tuple[dict, dict]:
    """Reuse accepted common-v1 mapping; retain every native field losslessly.

    No authority lookup or historical receipt replay occurs. Strict MediaWiki
    profile promotion is explicitly unavailable in this bounded adapter; frozen
    revision identities stay in the native extension. The frozen profile schema
    has no authored-Markdown profile, so original content is never called German.
    """
    base = load_module(root, COMMON_SCRIPT, "english_common_base")
    for relative in (COMMON_SCHEMA, PROFILE_SCHEMA):
        require(sha(safe_path(root, relative).read_bytes()) == PINS[relative], f"Frozen schema drift: {relative}")
    schema = json.loads(safe_path(root, COMMON_SCHEMA).read_bytes())
    profile_schema = json.loads(safe_path(root, PROFILE_SCHEMA).read_bytes())
    lane = config["lane"]
    native = {r["stable_id"]: r for r in records}
    translated_ids = {r["stable_id"] for r in records if "english_adapter" in r["provenance"]}
    projected = copy.deepcopy(records)
    for r in projected:
        p = r["payload"]
        if "title" in p:
            p.setdefault("title_markdown", p["title"])
        if "kind" in p:
            p.setdefault("segment_type", p["kind"])
        if r["entity_class"] == "term" and isinstance(p.get("ledger_row"), dict):
            for key in ("preferred_target", "source_term", "source_language", "rationale", "rejected_or_variant"):
                if key in p["ledger_row"]:
                    p.setdefault(key, p["ledger_row"][key])
        if r["entity_class"] == "concept" and r["parent_id"] and native[r["parent_id"]]["entity_class"] != "concept":
            r["parent_id"] = None  # Original course membership stays in the native extension.
    variant = base.native_lane_variant({"schema": "bgk" if lane == "bgk" else "classical"})
    if lane == "original":
        variant.update(editorial_resource="resource.d100.original-bridge.editorial",
                       editorial_rights="rights.d100.original-bridge.cc-by-sa-4.0")
    variant["scope_slug"] = "algebraic-geometry-bridge-en-" + lane
    base.native_lane_variant = lambda manifest: variant
    synthetic_id = "adapter.scope.algebraic-geometry-bridge-en-original.program"
    if lane == "original":
        courses = [r for r in projected if r["entity_class"] == "course"]
        require(len(courses) == 1 and courses[0]["parent_id"] is None, "Unexpected original native course topology")
        synthetic = copy.deepcopy(courses[0])
        synthetic.update(entity_class="program", stable_id=synthetic_id, parent_id=None,
                         source_local_id=synthetic_id, payload={"title": "Original bridge adapter scope"})
        projected.append(synthetic)
        courses[0]["parent_id"] = synthetic_id
    manifest = {"schema": "bgk-english-adapter" if lane == "bgk" else "english-adapter",
                "schema_version": "1.0.0", "through_unit": 30,
                "generated_from_build_utc": config["timestamp"]}
    try:
        dataset, details = base.build_dataset(projected, manifest, {}, profile_schema)
    except SystemExit as exc:
        raise AdapterError(f"Common projection failed: {exc}") from exc
    # The projection's convenience aliases must not replace native evidence.
    for rows in dataset["tables"].values():
        for r in rows:
            extension = r["extensions"]
            key = r["stable_key"]
            if "ag-bridge.native-record" in extension and key in native:
                extension["ag-bridge.native-record"] = copy.deepcopy(native[key])
            if key == synthetic_id:
                extension.pop("ag-bridge.native-record", None)
                extension.pop("ag-bridge.native-ordinal", None)
                extension.update({"ag-bridge.adapter-only": True, "ag-bridge.derivation-basis": "common schema requires program_id; native course has no parent"})
            if r["record_type"] == "segment_variant" and r["locale"] == "en":
                r["role"] = "translation"
            source_id = key if key in native else extension.get("ag-bridge.derived-from-native-id")
            extension["ag-bridge.english-reader-content"] = source_id in translated_ids
    if lane == "original":
        # There are no native terms in this finite companion. Do not fabricate
        # the base adapter's terminology scope or an Indonesian ledger binding.
        require(not dataset["tables"]["terms"], "Unexpected original native terminology topology")
        dataset["tables"]["units"] = [r for r in dataset["tables"]["units"]
            if r.get("unit_kind") != "terminology_scope"]
    dataset["dataset_version"] = "english-" + lane + ("-final-v1" if finalized else "-draft-v1")
    try:
        base.validate_dataset(dataset, schema)
        closure = base.validate_fk_closure(dataset)
    except SystemExit as exc:
        raise AdapterError(f"Common validation failed: {exc}") from exc
    expected = b"".join(canonical(r, b"\r\n") for r in records)
    require(base.reverse_native_jsonl(dataset) == expected, "Common projection does not reverse to complete English native records")
    details.update(closure=closure, native_reverse_equal=True,
        strict_source_profiles="not_promoted; frozen identities retained losslessly in native extensions",
        original_authored_markdown_profile="preserved_native_not_misidentified_as_mediawiki")
    return dataset, details


def materialize(root: Path, relative: str, files: dict[str, bytes]) -> None:
    output = safe_path(root, relative)
    boundary = safe_path(root, "backend/english")
    require(output != boundary and output.is_relative_to(boundary), "Output must be a fresh child of backend/english")
    require(not output.exists(), "Refusing to overwrite an existing English export")
    require(all(name and not any(c in name for c in ("/", "\\", ":")) and name not in {".", ".."} for name in files), "Unsafe output filename")
    output.mkdir(parents=True, exist_ok=False)
    # The manifest is the final completion marker, never the first write.
    for name, data in sorted(files.items(), key=lambda item: (item[0] == "MANIFEST.json", item[0])):
        with (output / name).open("xb") as stream:
            stream.write(data)
        require((output / name).read_bytes() == data, f"Output readback mismatch: {name}")


def run(config: dict, root: Path = ROOT, *, inventory: bool = False,
        finalize: bool = False) -> tuple[dict[str, bytes], dict]:
    records, manifest, schema, facts = load_native(root, config["lane"])
    validate_config(config, records)
    validate_v2_runtime(config, root, facts)
    require(not (inventory and finalize), "Inventory mode cannot finalize records")
    if inventory:
        return {}, {"schema": "ag-bridge-english-backend-translation-inputs-v1",
                    "lane": config["lane"], "native_inputs": facts,
                    "field_translations": translation_inventory(records, config)}
    qa_fact = require_full_corpus_integration_qa(root) if finalize else None
    source_bytes = {path: safe_path(root, entry["path"]).read_bytes() for path, entry in config["sources"].items()}
    supplemental_bytes = {row["stable_id"]: {
        "english": safe_path(root, row["path"]).read_bytes(),
        "native": safe_path(root, row["native_path"]).read_bytes()}
        for row in config.get("supplemental_sources", [])}
    helpers = load_module(root, ORIGINAL_SCRIPT, "english_original_native_helpers") if config["lane"] == "original" else None
    adapted, details = adapt_native(records, config, source_bytes, helpers, supplemental_bytes)
    if finalize:
        finalize_english_records(adapted, qa_fact)
        details["english_mathematical_qa_claimed"] = True
        details["translation_integration_qa"] = qa_fact
    details["native_source_serialization_verified"] = True
    details["native_recovered_records_jsonl_sha256"] = next(f["sha256"] for f in facts if f["path"].endswith("/records.jsonl"))
    validate_native(adapted, schema)
    common, common_details = common_projection(adapted, config, root, finalized=finalize)
    replay, replay_details = common_projection(adapted, config, root, finalized=finalize)
    require(canonical(common) == canonical(replay) and common_details == replay_details, "Common projection is not deterministic")
    files = {"record.schema.json": pretty(schema), "records.jsonl": b"".join(canonical(r, b"\r\n") for r in adapted),
             "common.dataset.json": pretty(common)}
    for kind in schema["properties"]["entity_class"]["enum"]:
        files[kind + ".jsonl"] = b"".join(canonical(r, b"\r\n") for r in adapted if r["entity_class"] == kind)
    implementation_paths = [COMMON_SCRIPT, COMMON_SCHEMA, PROFILE_SCHEMA, READER_COMMON_SCRIPT,
                            FINALIZATION_QA_SCRIPT, "scripts/english/export_backend_en.py"]
    if config["lane"] == "original":
        implementation_paths.append(ORIGINAL_SCRIPT)
    implementation_inputs = []
    for path in implementation_paths:
        data = safe_path(root, path).read_bytes()
        implementation_inputs.append({"path": path, "bytes": len(data), "sha256": sha(data)})
    receipt = {"schema": "ag-bridge-english-backend-adapter-manifest-v1", "schema_version": "1.0.0",
        "lane": config["lane"], "language": "en", "status":
            "translated_final_frozen_adapter_checks_pass" if finalize else "translated_draft_adapter_checks_pass",
        "model_provenance": MODEL, "timestamp": config["timestamp"], "native_inputs": facts,
        "implementation_inputs": implementation_inputs,
        "native_manifest": manifest, "input_sha256": value_sha(config), "counts": dict(Counter(r["entity_class"] for r in adapted)),
        "native": details, "common": common_details,
        "english_source_order": config.get("english_source_order"),
        "translation_integration_qa": qa_fact,
        "qa_policy": "Root full-corpus translation integration PASS is bound." if finalize else
            "Historical native QA/build/review evidence is retained, not rerun or claimed for English.",
        "publication_status": "not_a_build_or_publication_or_common_migration_receipt",
        "files": [{"path": p, "bytes": len(b), "sha256": sha(b)} for p, b in sorted(files.items())]}
    files["MANIFEST.json"] = pretty(receipt)
    return files, receipt


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Explicit source/translation-input JSON below backend/english or 00_control/english")
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--inventory", action="store_true")
    modes.add_argument("--check", action="store_true")
    modes.add_argument("--write", metavar="RELATIVE_OUTPUT")
    modes.add_argument("--final-check", action="store_true")
    modes.add_argument("--final-write", metavar="RELATIVE_OUTPUT")
    args = parser.parse_args(argv)
    try:
        require(args.input.startswith(("backend/english/", "00_control/english/")), "Input must belong to the English lane")
        config = json.loads(safe_path(ROOT, args.input).read_bytes())
        final = bool(args.final_check or args.final_write)
        files, report = run(config, inventory=args.inventory, finalize=final)
        output = args.write or args.final_write
        if output:
            materialize(ROOT, output, files)
        print(json.dumps(report if args.inventory else {"status": report["status"], "lane": report["lane"],
                           "counts": report["counts"], "written": output or None}, ensure_ascii=False, indent=2))
        return 0
    except (AdapterError, OSError, ValueError, KeyError, yaml.YAMLError) as exc:
        print(f"English backend adapter failed: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
