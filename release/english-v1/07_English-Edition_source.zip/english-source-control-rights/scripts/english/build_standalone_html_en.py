"""Build two self-contained, offline English course readers.

The full English HTML directory remains the canonical multi-reader package.
This tool derives two compact single-file course readers from it for reader-first
release slots.  It inlines only locally bound resources, preserves content and
IDs, converts cross-package navigation to the eventual release page, and
validates the result with the release packager's offline-HTML validator.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import mimetypes
import re
import tempfile
from pathlib import Path
from urllib.parse import unquote, urlsplit

from bs4 import BeautifulSoup

import package_release_en as package


ROOT = Path(__file__).resolve().parents[2]
MODEL = "OpenAI Codex gpt-5.6-sol, Ultra."
SCHEMA = "d100-en-standalone-html-build-v1"
HTML_BUILD = "build/english/html-en-v6"
OUTPUT_DEFAULT = "build/english/standalone-en-v1.0.0"
BOOKS = ("ak", "bgk")
RELEASE_PAGE = (
    "https://github.com/KokunoYumeto/algebraic-geometry-bridge-id/releases/tag/en-v1.0.0"
)


class StandaloneError(RuntimeError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise StandaloneError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def fact(path: Path) -> dict[str, object]:
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": sha(data)}


def canonical(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def safe_local(root: Path, value: str) -> Path | None:
    parsed = urlsplit(value)
    if parsed.scheme or parsed.netloc:
        return None
    raw = unquote(parsed.path)
    if not raw:
        return None
    require("\\" not in raw and "\x00" not in raw and not raw.startswith("/"),
            f"Unsafe local reader reference: {value}")
    target = (root / raw).resolve()
    require(target.is_relative_to(root.resolve()) and target.is_file(),
            f"Missing local reader resource: {value}")
    return target


def data_uri(path: Path) -> str:
    mime, _ = mimetypes.guess_type(path.name)
    if path.suffix.casefold() == ".svg":
        mime = "image/svg+xml"
    require(bool(mime), f"Cannot infer MIME type for local resource: {path.name}")
    return "data:" + mime + ";base64," + base64.b64encode(path.read_bytes()).decode("ascii")


CSS_URL = re.compile(r"(?is)url\(\s*(['\"]?)(.*?)\1\s*\)")


def inline_css(text: str, root: Path, resources: dict[str, dict[str, object]]) -> str:
    def replace(match: re.Match[str]) -> str:
        raw = match.group(2).strip()
        local = safe_local(root, raw)
        if local is None:
            require(not urlsplit(raw).scheme and not urlsplit(raw).netloc,
                    f"Remote CSS resource is forbidden in standalone reader: {raw}")
            return match.group(0)
        resources[local.relative_to(ROOT).as_posix()] = fact(local)
        return "url('" + data_uri(local) + "')"

    return CSS_URL.sub(replace, text)


def rewrite_srcset(value: str, root: Path, resources: dict[str, dict[str, object]]) -> str:
    rows: list[str] = []
    for candidate in value.split(","):
        item = candidate.strip()
        require(bool(item), "Empty srcset candidate")
        pieces = item.split()
        raw = pieces[0]
        local = safe_local(root, raw)
        if local is None:
            require(bool(urlsplit(raw).scheme or urlsplit(raw).netloc or raw.startswith("data:")),
                    f"Unsafe srcset reference: {raw}")
            rows.append(item)
            continue
        resources[local.relative_to(ROOT).as_posix()] = fact(local)
        rows.append(" ".join([data_uri(local), *pieces[1:]]))
    return ", ".join(rows)


def transform(book: str, build_root: Path, source_data: bytes) -> tuple[bytes, list[dict[str, object]]]:
    require(book in BOOKS, f"Unsupported standalone book: {book}")
    soup = BeautifulSoup(source_data.decode("utf-8"), "html.parser")
    require(soup.html is not None and soup.head is not None and soup.body is not None,
            f"{book} source is not a complete HTML reader")
    require((soup.html.get("lang") or "").casefold() == "en", f"{book} reader language is not English")
    require(not soup.find_all("script"), f"Active scripts are forbidden in {book} reader")
    resources: dict[str, dict[str, object]] = {}

    for tag in list(soup.find_all("link")):
        href = tag.get("href")
        if not isinstance(href, str):
            continue
        local = safe_local(build_root, href)
        if local is None:
            continue
        rel = {str(value).casefold() for value in (tag.get("rel") or [])}
        resources[local.relative_to(ROOT).as_posix()] = fact(local)
        if "stylesheet" in rel:
            style = soup.new_tag("style")
            style.string = inline_css(local.read_text(encoding="utf-8"), build_root, resources)
            tag.replace_with(style)
        else:
            tag["href"] = data_uri(local)

    for tag in soup.find_all(True):
        for attribute in ("src", "poster"):
            value = tag.get(attribute)
            if not isinstance(value, str):
                continue
            local = safe_local(build_root, value)
            if local is None:
                require(value.startswith("data:") or bool(urlsplit(value).scheme or urlsplit(value).netloc),
                        f"Unsafe resource reference: {value}")
                continue
            resources[local.relative_to(ROOT).as_posix()] = fact(local)
            tag[attribute] = data_uri(local)
        value = tag.get("srcset")
        if isinstance(value, str):
            tag["srcset"] = rewrite_srcset(value, build_root, resources)
        if tag.name == "a" and isinstance(tag.get("href"), str):
            href = tag["href"]
            parsed = urlsplit(href)
            if not parsed.scheme and not parsed.netloc:
                raw = unquote(parsed.path)
                require("\\" not in raw and "\x00" not in raw and not raw.startswith("/"),
                        f"Unsafe navigation reference: {href}")
                if not raw or raw == book + ".html":
                    tag["href"] = "#" + unquote(parsed.fragment) if parsed.fragment else "#TOC"
                else:
                    tag["href"] = RELEASE_PAGE

    note = soup.new_tag("aside", attrs={"class": "standalone-reader-note", "role": "note"})
    note.string = (
        "This is a self-contained course reader. The full offline bundle retains "
        "the companion reader, source files, and component-rights records."
    )
    soup.body.insert(0, note)
    rendered = ("<!doctype html>\n" + str(soup) + "\n").encode("utf-8")
    package.validate_offline_html(
        [{"archive_path": book + ".html", "data": rendered}], [book + ".html"],
        required_entry_points=(book + ".html",),
    )
    return rendered, [resources[key] for key in sorted(resources)]


def read_build() -> tuple[Path, dict, list[dict[str, object]]]:
    build_root = ROOT / HTML_BUILD
    receipt_path = build_root / "build-receipt.json"
    require(build_root.is_dir() and receipt_path.is_file(), "English HTML build is absent")
    receipt = json.loads(receipt_path.read_bytes())
    require(receipt.get("schema") == "english-html-reader-build-v1" and receipt.get("status") == "PASS",
            "English HTML build receipt is not PASS")
    provenance = receipt.get("provenance")
    require(provenance == MODEL, "English HTML build provenance drifted")
    files = receipt.get("files")
    require(isinstance(files, list) and files, "HTML build receipt lacks a file inventory")
    expected = {row["path"]: row for row in files}
    for book in BOOKS:
        path = build_root / (book + ".html")
        live = fact(path)
        expected_fact = expected.get(book + ".html")
        require(expected_fact == {"path": book + ".html", "bytes": live["bytes"], "sha256": live["sha256"]},
                f"HTML build receipt does not bind {book}.html")
    return build_root, receipt, files


def build(output: Path) -> dict[str, object]:
    output = output.resolve()
    permitted = (ROOT / "build" / "english").resolve()
    require(output.is_relative_to(permitted) and output != permitted,
            "Standalone output must be a dedicated build/english child")
    require(not output.exists(), "Standalone output already exists")
    build_root, receipt, files = read_build()
    rendered: dict[str, bytes] = {}
    resource_facts: dict[str, list[dict[str, object]]] = {}
    for book in BOOKS:
        source = (build_root / (book + ".html")).read_bytes()
        first, resources = transform(book, build_root, source)
        second, replay_resources = transform(book, build_root, source)
        require(first == second and resources == replay_resources,
                f"Standalone {book} transform is not byte deterministic")
        rendered[book + ".html"] = first
        resource_facts[book] = resources
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".standalone-en-", dir=output.parent) as temporary:
        stage = Path(temporary)
        for name, data in rendered.items():
            path = stage / name
            path.write_bytes(data)
            require(path.read_bytes() == data, f"Standalone write/readback mismatch: {name}")
        output_facts = [
            {"path": (output / name).relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": sha(data)}
            for name, data in sorted(rendered.items())
        ]
        report = {
            "schema": SCHEMA,
            "status": "PASS",
            "language": "en",
            "model_provenance": MODEL,
            "inputs": {
                "html_build_receipt": fact(build_root / "build-receipt.json"),
                "source_readers": [fact(build_root / (book + ".html")) for book in BOOKS],
                "html_build_file_count": len(files),
                "inlined_resources": resource_facts,
            },
            "outputs": output_facts,
            "checks": {
                "two_independent_in_memory_replays_byte_identical": True,
                "local_resources_inlined": True,
                "no_active_content": True,
                "packager_offline_validator_passed": True,
                "course_ids_and_mathml_preserved_from_bound_source": True,
            },
        }
        report_path = stage / "BUILD_RECEIPT.json"
        report_path.write_bytes(canonical(report))
        require(report_path.read_bytes() == canonical(report), "Standalone receipt readback mismatch")
        stage.rename(output)
    return {"status": "PASS", "output": output.relative_to(ROOT).as_posix(),
            "files": [fact(output / name) for name in sorted(rendered)],
            "receipt": fact(output / "BUILD_RECEIPT.json")}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / OUTPUT_DEFAULT)
    args = parser.parse_args(argv)
    try:
        print(json.dumps(build(args.output), ensure_ascii=False, indent=2))
        return 0
    except (StandaloneError, OSError, UnicodeError, json.JSONDecodeError) as exc:
        print("Standalone English reader build failed: " + str(exc), file=__import__("sys").stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
