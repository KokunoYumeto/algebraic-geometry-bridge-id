# Native backend checkpoint

This archive contains the complete cumulative native backend for BGK Units
1–6: 4,239 canonical JSONL records, per-class projections, schema,
manifest, exporter, deterministic native QA, the frozen common-backend
contract, and the lossless common-backend-v1 preflight. The final migration
receipt is generated only after the existing Zenodo lineage reserves the exact
public identity; it is therefore a separate release asset.
