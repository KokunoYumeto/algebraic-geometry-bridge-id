# Resumable source checkpoint

This archive contains the translated Markdown for BGK Units 1–6, the exact
reader builder/style inputs, cumulative terminology and correction ledgers,
the admitted component media, rights tables, unit worklogs and QA, and compact
frozen course/unit authority identities. `AUTHORITY_POINTERS.json` binds all
twelve semantic page/revision identities and official-PDF witness pointers
without duplicating raw API/HTML/XML dumps or the official PDFs.

Run `scripts/build_bgk_reader.py --through 6` from the restored repository
root. The included build and cumulative reader QA receipts bind the accepted
82-page PDF and semantic HTML bytes.
