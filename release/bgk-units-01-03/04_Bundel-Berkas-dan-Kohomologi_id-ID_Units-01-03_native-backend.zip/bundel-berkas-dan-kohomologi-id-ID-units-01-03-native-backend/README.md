# Native backend checkpoint

This archive contains the complete cumulative native backend for BGK Units
1–3: 2,370 canonical JSONL records, per-class projections, schema, manifest,
exporter, deterministic QA, and the common-backend-v1 preflight receipt and
adapter. The common projection itself is virtual and losslessly round-trips to
the native `records.jsonl`; a final migration receipt is intentionally deferred
until a public release identity exists.
