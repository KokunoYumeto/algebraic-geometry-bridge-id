# Resumable source checkpoint

This archive contains the translated Markdown for BGK Units 1–3, the exact
reader builder and style inputs, the cumulative terminology/corrections
ledgers, five admitted media files, component-rights tables, and compact frozen
course/unit authority manifests. `AUTHORITY_POINTERS.json` gives the six exact
semantic page/revision identities and official-PDF witness pointers without
duplicating the raw official PDFs or bulk API/HTML/XML dumps.

Run `scripts/build_bgk_reader.py` from the repository root after restoring the
paths in this archive. The included build and reader QA receipts bind the
accepted 50-page PDF and semantic HTML bytes.
